package com.agileeagle.gf.tech.emactivemq;

import org.apache.activemq.ActiveMQConnectionFactory;

import javax.jms.*;
import java.text.DecimalFormat;

/**
 * 模拟消费者
 * @author chenzhigang
 * @since 2016/9/9.
 */
public class EmActivemqConsumerDemo {


    public static void main(String[] args){
        // producer.
        EmActivemqConsumerDemo client = new EmActivemqConsumerDemo();
        client.consumeMessage();

    }


    public void consumeMessage() {
        try {
            // Create a ConnectionFactory
            ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory("publisher","password","tcp://localhost:61616");
            // Create a Connection
            Connection connection = connectionFactory.createConnection();
            connection.start();

            // Create a Session
            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);

            // Create the destination (Topic or Queue)
            Queue destination = session.createQueue("TEST.FOO");

            // Create a MessageProducer from the Session to the Topic or Queue
            MessageConsumer consumer = session.createConsumer(destination);
            consumer.setMessageListener(new Listener());
        } catch (Exception e) {
            System.out.println("Caught: " + e);
            e.printStackTrace();
        }
    }

    class Listener implements MessageListener {
        public void onMessage(Message message) {
            try {
                TextMessage msg = (TextMessage)message;
                String content = msg.getText();
                DecimalFormat df = new DecimalFormat( "#,###,###,##0.00" );
                System.out.println("consumer: " + content);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
