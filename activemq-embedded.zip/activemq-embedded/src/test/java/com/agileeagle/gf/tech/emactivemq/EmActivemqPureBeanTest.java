package com.agileeagle.gf.tech.emactivemq;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * 测试启动服务方式1
 * @author chenzhigang
 * @since 2016/7/18.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:appcontext/app_tech_activemq_server_pure_bean.xml"})
public class EmActivemqPureBeanTest {
    private static Logger logger = LoggerFactory.getLogger(EmActivemqPureBeanTest.class);

    @Test
    public void startEmActivemqTest() throws InterruptedException {
        logger.info("------------");
        Thread.currentThread().sleep(1000000);
    }

}
