package com.agileeagle.gf.tech.dao.redis;

import com.agileeagle.gf.tech.cache.RichCache;

import java.util.List;
import java.util.Map;
import java.util.Set;

/*****
 * 
 * @author zhongcong
 * 
 */

/**
 * @author chenzhigang
 * @desc
 * @date 2016年6月24日下午3:16:59
 */
public interface BaseRedisDao {

}
