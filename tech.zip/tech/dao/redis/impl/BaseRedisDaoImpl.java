package com.agileeagle.gf.tech.dao.redis.impl;

import com.agileeagle.gf.tech.client.redis.ShardedJedisClient;

/**
 * @author chenzhigang on 2016/6/25.
 * @since  2016/6/25.
 */
public class BaseRedisDaoImpl {
    private ShardedJedisClient shardedJedisClient;

    public ShardedJedisClient getShardedJedisClient() {
        return shardedJedisClient;
    }

    public void setShardedJedisClient(ShardedJedisClient shardedJedisClient) {
        this.shardedJedisClient = shardedJedisClient;
    }
}
