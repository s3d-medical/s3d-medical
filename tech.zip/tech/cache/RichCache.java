package com.agileeagle.gf.tech.cache;

import java.util.List;
import java.util.Map;
import java.util.Set;

/*****
 * 
 * @author zhongcong
 * 
 */
/**
 * @author hejie
 * @desc
 * @date 2016年6月24日下午3:16:59
 */
public interface RichCache {
	/****
	 * key-value数据结构存储string类型值
	 * 
	 * @param key
	 * @param value
	 * @param seconds
	 */
	public void setString(String key, String value, int seconds);

	/**
	 * key-value数据结构存储string类型值为json
	 */
	public void setJsonString(String key, String value, int seconds);

	/****
	 * key-value数据结构获取string类型值
	 * 
	 * @param key
	 * @return
	 */

	public String getString(String key);

	public <T> List<T> getList(String key, Class<T> t);

	/****
	 * 获取long类型数据
	 * 
	 * @param key
	 * @return
	 */
	public Long getLong(String key);

	/****
	 * key-value数据结构存储object类型值
	 * 
	 * @param key
	 * @param value
	 * @param seconds
	 */

	public void setObject(String key, Object value, int seconds);

	/****
	 * 原生正反序列化的取值(慎用 个别类型无法转换，推荐使用加泛型的取值)
	 * 
	 * @param key
	 * @return
	 */
	public <T> T getObject(String key);

	/**
	 * key-value数据结构存储object的json类型值
	 */
	public void setObjectToJson(String key, Object value, int seconds);

	/*****
	 * key-value数据结构存储object类型值
	 * 
	 * @param key
	 * @return
	 */
	public <T> T getObjectFromJson(String key, Class<T> t);

	/**
	 * set success return 1, set failed return 0
	 * 
	 * @param key
	 * @param val
	 * @param expiredTime
	 *            expired time in seconds.
	 * @return
	 */
	Long setNxString(String key, String val, int expiredTime);

	Long setNxLong(String key, Long val, int expiredTime);

	/**
	 * 删除记录，根据Key
	 * 
	 * @param key
	 * @return 1成功 0失败
	 */
	public long delete(String key);

	/****
	 * 查看是否存在key值
	 * 
	 * @param key
	 * @return
	 */
	public boolean exists(String key);

	/**
	 * 对key设置指定过期时间
	 *
	 * @param key
	 * @param unixTime
	 * @return 1成功 0 找不到key或者对应的key的过期时间被更新
	 */
	public long expireAt(String key, long unixTime);

	/**
	 * 对key设置过期时间
	 *
	 * @param key
	 * @param unixTime
	 * @return 1成功 0
	 */
	public long expire(String key, int unixTime);

	/**
	 * 获取key的ttl
	 * 
	 * @param key
	 * @return 存活时间以秒为单位，-1为已经到期
	 */

	public long ttl(String key);

	/**
	 * increase value of given key, and ensure the max value of this key is
	 * limit. if limit is null, no limit for this value.
	 * 
	 * @param key
	 * @param upperLimit
	 * @return
	 */

	public boolean limitIncr(String key, Long upperLimit);

	/****
	 * 对key所对应的值作增加
	 * 
	 * @param key
	 * @param step
	 * @return
	 */
	public Integer incr(String key, Integer step);

	public Long incr(String key, Long step);

	public void lpush(String key, String... value);

	/**
	 * 向List末尾批量追加值
	 * 
	 * @param key
	 * @param values
	 * 
	 */
	public void lpush(String key, List<Object> values);

	/****
	 * 向list起始处插入值
	 * 
	 * @param key
	 * @param value
	 */
	public void rpush(String key, String... value);

	/*****
	 * 向list起始处批量插入值
	 * 
	 * @param key
	 * @param values
	 */
	public void rpush(String key, List<Object> values);

	/***
	 * 从列表末尾处弹出值
	 * 
	 * @param key
	 * @return
	 */
	public String rpop(String key);

	/**
	 * 覆盖List中指定位置的值
	 * 
	 * @param key
	 * @param index
	 * @param value
	 * @return
	 */
	public String lset(String key, int index, String value);

	/**
	 * 获取List中指定位置的值
	 * 
	 * @param key
	 * @param index
	 * @return
	 */
	public String lindex(String key, int index);

	/**
	 * List长度
	 * 
	 * @param key
	 * @return
	 */
	public long llen(String key);

	/**
	 * 保留start与end 之间的记录
	 * 
	 * @param key
	 * @param start
	 * @param end
	 * @return 状态码
	 */
	public String ltrim(String key, int start, int end);

	/**
	 * 返回列表 key 中指定区间内的元素
	 * 
	 * @param key
	 *            key
	 * @param start
	 *            开始下标
	 * @param end
	 *            结束下标
	 * @return 一个列表，包含指定区间内的元素
	 */
	public <T> List<T> lrange(String key, long start, long end, Class<T> t);

	/****
	 * object hash类型存储
	 * 
	 * @param key
	 * @param map
	 */
	public void hmsetObject(String key, Map<String, Object> map);

	/**
	 * 添加一条记录，值为 Map
	 * 
	 * @param key
	 * @param map
	 */
	public void hmsetString(String key, Map<String, String> map);

	/***
	 * 设置integer值
	 * 
	 * @param key
	 * @param field
	 * @param value
	 * @return 1成功 0失败
	 */
	public void hsetInteger(String key, String field, Integer value);

	/**
	 * key对应记录的map中添加记录
	 * 
	 * @param key
	 * @param field
	 * @param value
	 * @return 1成功 0失败
	 */
	public void hsetString(String key, String field, String value);

	/*****
	 * 
	 * @param key
	 * @param field
	 * @param value
	 * @return 1成功 0失败
	 */

	public void hsetObject(String key, String field, Object value);

	/****
	 * value转化为json实现
	 * 
	 * @param key
	 * @param field
	 * @param value
	 */
	public void hsetObjectToJson(String key, String field, Object value);

	/**
	 * 判断该key对应的map中是否有field
	 * 
	 * @param key
	 * @param field
	 * @return
	 */
	public boolean hexists(String key, String field);

	public Integer hgetInteger(String key, String field);

	public Long hgetLong(String key, String field);

	/**
	 * 获取key 对应的map中field的值
	 * 
	 * @param key
	 * @param field
	 * @return
	 */
	public String hgetString(String key, String field);

	/****
	 * 原生正反序列化的取值(慎用 个别类型无法转换，推荐使用加泛型的取值)
	 * 
	 * @param key
	 * @param field
	 * @return
	 */
	public <T> T hGetObject(String key, String field);

	/*****
	 * 获取hash对象值
	 * 
	 * @param key
	 * @param field
	 * @return
	 */
	public <T> T hGetObjectFromJson(String key, String field, Class<T> t);

	/*****
	 * 批量获取hash值
	 * 
	 * @param key
	 * @param field
	 * @return
	 */
	public List<String> hmgetString(String key, String[] field);

	/*****
	 * 批量获取hashobject
	 * 
	 * @param key
	 * @param field
	 * @return
	 */

	public <T> List<T> hmgetObject(String key, String[] field, Class<T> t);

	/**
	 * 删除key对应map中指定field的记录
	 * 
	 * @param key
	 * @param field
	 * @return 1成功 0失败
	 */
	public long hdel(String key, String field);

	/**
	 * 获取key对应map中记录总数
	 * 
	 * @param key
	 * @return 1成功 0失败
	 */
	public long hlen(String key);

	/**
	 * 获取key对应的map中所有的field 的集合
	 * 
	 * @param key
	 * @return
	 */
	public Set<String> hkeys(String key);

	/**
	 * 获取key对应的map中所有的value的集合
	 * 
	 * @param key
	 * @return
	 */
	public List<String> hvals(String key);

	/****
	 * 获取hash结构里面的所有数据
	 * 
	 * @param key
	 * @return
	 */
	public <T> Map<String, T> hGetAllObject(String key, Class<T> t);

	/**
	 * 对指定key对应的hash中指定field的value作增量操作
	 * 
	 * @param key
	 * @param field
	 * @param value
	 *            可以为负数
	 * @return 增量操作后value的值
	 */
	public long hincrBy(String key, String field, long value);

	/**
	 * 将哈希表 key 中的域 field 的值设置为 value ，当且仅当域 field 不存在
	 * 
	 * @param key
	 * @param field
	 * @param value
	 * @return 设置成功，返回 1 。如果给定域已经存在且没有操作被执行，返回 0 。
	 */
	public long hsetnx(String key, String field, String value);

	public void sadd(String key, String... values);

	/**
	 * 增加对应key的value
	 * 
	 * @param key
	 * @param values
	 * @return
	 */
	public void sadd(String key, List<Object> values);

	/**
	 * 删除对应key的value
	 * 
	 * @param key
	 * @param values
	 * 
	 */
	public long srem(String key, String... values);

	/**
	 * 返回指定set的所有value
	 * 
	 * @param key
	 * @return
	 */
	public <T> Set<T> smembers(String key, Class<T> t);

	/**
	 * 判断member是否是集合key中的成员
	 * 
	 * @param key
	 * @param member
	 * @return
	 */
	public boolean sismember(String key, String member);

	/**
	 * 返回集合中元素的个数
	 * 
	 * @param key
	 * @return
	 */
	public long scard(String key);

	/**
	 * 移除并返回集合中的一个随机元素
	 * 
	 * @param key
	 * @return
	 */
	public String spop(String key);

	/**
	 * 新增对应zset key的member
	 * 
	 * @param key
	 * @param score
	 * @param member
	 * 
	 */
	public void zadd(String key, double score, String member);

	/**
	 * 新增对应zset key的member
	 * 
	 * @param key
	 * @param members
	 * 
	 */
	public void zadd(String key, Map<Object, Double> members);

	/**
	 * 返回介于min和max score的value集合
	 * 
	 * @param key
	 * @param min
	 * @param max
	 * @return
	 */
	public <T> Set<T> zrangebyscore(String key, double min, double max, Class<T> t);

	/**
	 * 获取成员在排序设置相关的Score
	 * 
	 * @param key
	 * @param member
	 * @return
	 */
	public double zscore(String key, String member);

}
