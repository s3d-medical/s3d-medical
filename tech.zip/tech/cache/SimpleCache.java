package com.agileeagle.gf.tech.cache;

import java.util.Map;

/**
 * Cache Interface
 *
 * @author wind.chen
 */
public interface SimpleCache {
  /**
   * Get object of associated key
   *
   * @param key the key to hqlUnique
   * @return null if not found
   */
  <T> T get(String key);

  /**
   * Put an object into cache with default expired time
   *
   * @param key the key under which this object should be added
   * @param value the object to store
   */
  void put(String key, Object value);

  /**
   * Put an object into cache with specific expired time
   *
   * @param key the key under which this object should be added
   * @param value the object to store
   * @param expiredTime the expiration of this object in seconds 0 means unlimit.
   */
  void put(String key, Object value, int expiredTime);

  /**
   * Remove cache object of specified key
   *
   * @param key the cache's key to delete
   */
  void remove(String key);

  /**
   * put a piles of key and objects in map.  
   * @param keyPrefix
   * @param map
   * @param expiredTime  the expiration of this object in cache. 0 means no limit.
   */
  void putMapNotExist(String keyPrefix, Map<String, Object> map, int expiredTime);

  void putNotExist(String key, Object value, int expiredTime);

}
