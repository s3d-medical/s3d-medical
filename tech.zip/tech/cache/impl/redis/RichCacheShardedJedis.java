package com.agileeagle.gf.tech.cache.impl.redis;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.agileeagle.gf.tech.cache.RichCache;
import com.agileeagle.gf.tech.client.redis.ShardedJedisClient;

public class RichCacheShardedJedis implements RichCache {

	private ShardedJedisClient shardedJedisClient;

	public ShardedJedisClient getShardedJedisClient() {
		return shardedJedisClient;
	}

	public void setShardedJedisClient(ShardedJedisClient shardedJedisClient) {
		this.shardedJedisClient = shardedJedisClient;
	}

	@Override
	public void setString(String key, String value, int seconds) {
		this.shardedJedisClient.setString(key, value, seconds);
	}

	@Override
	public void setJsonString(String key, String value, int seconds) {
		this.shardedJedisClient.setJsonString(key, value, seconds);
	}

	@Override
	public String getString(String key) {
		return this.shardedJedisClient.getString(key);
	}

	@Override
	public Long getLong(String key) {
		return this.shardedJedisClient.getLong(key);
	}

	@Override
	public void setObject(String key, Object value, int seconds) {
		this.shardedJedisClient.setObject(key, value, seconds);
	}

	@Override
	public void setObjectToJson(String key, Object value, int seconds) {
		this.shardedJedisClient.setObjectToJson(key, value, seconds);
	}

	@Override
	public <T> T getObjectFromJson(String key, Class<T> t) {
		return this.shardedJedisClient.getObjectFromJson(key, t);
	}

	@Override
	public Long setNxString(String key, String val, int expiredTime) {
		return this.shardedJedisClient.setNxString(key, val, expiredTime);
	}

	@Override
	public Long setNxLong(String key, Long val, int expiredTime) {
		return this.shardedJedisClient.setNxLong(key, val, expiredTime);
	}

	@Override
	public long delete(String key) {
		return this.shardedJedisClient.delete(key);
	}

	@Override
	public boolean exists(String key) {
		return this.shardedJedisClient.exists(key);
	}

	@Override
	public long expireAt(String key, long unixTime) {
		return this.shardedJedisClient.expireAt(key, unixTime);
	}

	@Override
	public long expire(String key, int unixTime) {
		return this.shardedJedisClient.expire(key, unixTime);
	}

	@Override
	public long ttl(String key) {
		return this.shardedJedisClient.ttl(key);
	}

	@Override
	public boolean limitIncr(String key, Long upperLimit) {
		return this.shardedJedisClient.limitIncr(key, upperLimit);
	}

	@Override
	public Integer incr(String key, Integer step) {
		return this.shardedJedisClient.incr(key, step);
	}

	@Override
	public Long incr(String key, Long step) {
		return this.shardedJedisClient.incr(key, step);
	}

	@Override
	public void lpush(String key, String... value) {
		this.shardedJedisClient.lpush(key, value);
	}

	@Override
	public void lpush(String key, List<Object> values) {
		this.shardedJedisClient.lpush(key, values);
	}

	@Override
	public void rpush(String key, String... value) {
		this.shardedJedisClient.rpush(key, value);
	}

	@Override
	public void rpush(String key, List<Object> values) {
		this.shardedJedisClient.rpush(key, values);
	}

	@Override
	public String rpop(String key) {
		return this.shardedJedisClient.rpop(key);
	}

	@Override
	public String lset(String key, int index, String value) {
		return this.shardedJedisClient.lset(key, index, value);
	}

	@Override
	public String lindex(String key, int index) {
		return this.shardedJedisClient.lindex(key, index);
	}

	@Override
	public long llen(String key) {
		return this.shardedJedisClient.llen(key);
	}

	@Override
	public String ltrim(String key, int start, int end) {
		return this.shardedJedisClient.ltrim(key, start, end);
	}

	@Override
	public <T> List<T> lrange(String key, long start, long end, Class<T> t) {
		return this.shardedJedisClient.lrange(key, start, end, t);
	}

	@Override
	public void hmsetObject(String key, Map<String, Object> map) {
		this.shardedJedisClient.hmsetObject(key, map);
	}

	@Override
	public void hmsetString(String key, Map<String, String> map) {
		this.shardedJedisClient.hmsetString(key, map);
	}

	@Override
	public void hsetInteger(String key, String field, Integer value) {
		this.shardedJedisClient.hsetInteger(key, field, value);
	}

	@Override
	public void hsetString(String key, String field, String value) {
		this.shardedJedisClient.hsetString(key, field, value);
	}

	@Override
	public void hsetObject(String key, String field, Object value) {
		this.shardedJedisClient.hsetObject(key, field, value);
	}

	@Override
	public boolean hexists(String key, String field) {
		return this.shardedJedisClient.hexists(key, field);
	}

	@Override
	public Integer hgetInteger(String key, String field) {
		return this.shardedJedisClient.hgetInteger(key, field);
	}

	@Override
	public Long hgetLong(String key, String field) {
		return this.shardedJedisClient.hgetLong(key, field);
	}

	@Override
	public String hgetString(String key, String field) {
		return this.shardedJedisClient.hgetString(key, field);
	}

	@Override
	public <T> T hGetObjectFromJson(String key, String field, Class<T> t) {
		return this.shardedJedisClient.hGetObjectFromJson(key, field, t);
	}

	@Override
	public List<String> hmgetString(String key, String[] field) {
		return this.shardedJedisClient.hmgetString(key, field);
	}

	@Override
	public <T> List<T> hmgetObject(String key, String[] field, Class<T> t) {
		return this.shardedJedisClient.hmgetObject(key, field, t);
	}

	@Override
	public long hdel(String key, String field) {
		return this.shardedJedisClient.hdel(key, field);
	}

	@Override
	public long hlen(String key) {
		return this.shardedJedisClient.hlen(key);
	}

	@Override
	public Set<String> hkeys(String key) {
		return this.shardedJedisClient.hkeys(key);
	}

	@Override
	public List<String> hvals(String key) {
		return this.shardedJedisClient.hvals(key);
	}

	@Override
	public <T> Map<String, T> hGetAllObject(String key, Class<T> t) {
		return this.shardedJedisClient.hGetAllObject(key, t);
	}

	@Override
	public long hincrBy(String key, String field, long value) {
		return this.shardedJedisClient.hincrBy(key, field, value);
	}

	@Override
	public long hsetnx(String key, String field, String value) {
		return this.shardedJedisClient.hsetnx(key, field, value);
	}

	@Override
	public void sadd(String key, String... values) {
		this.shardedJedisClient.sadd(key, values);
	}

	@Override
	public void sadd(String key, List<Object> values) {
		this.shardedJedisClient.sadd(key, values);
	}

	@Override
	public long srem(String key, String... values) {
		return this.shardedJedisClient.srem(key, values);
	}

	@Override
	public <T> Set<T> smembers(String key, Class<T> t) {
		return this.shardedJedisClient.smembers(key, t);
	}

	@Override
	public boolean sismember(String key, String member) {
		return this.shardedJedisClient.sismember(key, member);
	}

	@Override
	public long scard(String key) {
		return this.shardedJedisClient.scard(key);
	}

	@Override
	public String spop(String key) {
		return this.shardedJedisClient.spop(key);
	}

	@Override
	public void zadd(String key, double score, String member) {
		this.shardedJedisClient.zadd(key, score, member);
	}

	@Override
	public void zadd(String key, Map<Object, Double> members) {
		this.shardedJedisClient.zadd(key, members);
	}

	@Override
	public <T> Set<T> zrangebyscore(String key, double min, double max, Class<T> t) {
		return this.shardedJedisClient.zrangebyscore(key, min, max, t);
	}

	@Override
	public double zscore(String key, String member) {
		return this.shardedJedisClient.zscore(key, member);
	}

	@Override
	public <T> T getObject(String key) {
		return (T)this.shardedJedisClient.getObject(key);
	}

	@Override
	public <T> T hGetObject(String key, String field) {
		return (T)this.shardedJedisClient.hGetObject(key, field);
	}

	@Override
	public void hsetObjectToJson(String key, String field, Object value) {
		this.shardedJedisClient.hsetObjectToJson(key, field, value);
	}

	@Override
	public <T> List<T> getList(String key, Class<T> t) {

		return this.shardedJedisClient.getList(key, t);
	}

}
