package com.agileeagle.gf.tech.cache.impl.ehcache;

import java.util.Iterator;
import java.util.Map;

import net.sf.ehcache.Cache;
import net.sf.ehcache.Element;

import org.apache.log4j.Logger;

import com.agileeagle.gf.tech.cache.SimpleCache;

/**
 * simplecache local implementation by ehcahce.
 * 
 * @author chenzhigang
 *
 */
public class SimpleCacheLocalEhcache2x implements SimpleCache {
  private Logger logger = Logger.getLogger(this.getClass());
  private Object lock = new Object();

  /**
   * Get object of associated key
   *
   * @param key the key to hqlUnique
   *
   * @return null if not found
   */
  public <T> T get(String key) {
    if (!isEnabled()) {
      return null;
    }
    Element element = this.simpleEhcache.get(key);
    if (element == null) {
      return null;
    }
    if (logger.isInfoEnabled()) {
      logger.info("Get value from ehcache. Key = " + key);
    }
    return (T) element.getObjectValue();
  }

  public void put(String key, Object value) {
    this.put(key, value, -1);
  }

  /**
   * Put an object into cache with specific expired time
   *
   * @param key the key under which this object should be added
   * @param value the object to store
   * @param expiredTime the expiration of this object in seconds
   */
  public void put(String key, Object value, int expiredTime) {
    if (!isEnabled()) {
      return;
    }
    if (value == null) {
      return;
    }
    Element element = new Element(key, value);
    if (expiredTime >= 0) {
      element.setTimeToLive(expiredTime);
    }
    if (logger.isInfoEnabled()) {
      logger.info("Put value into ehcache. Key = " + key);
    }
    this.simpleEhcache.put(element);
  }

  /**
   * Remove cache object of specified key
   *
   * @param key the cache's key to delete
   */
  public void remove(String key) {
    if (!isEnabled()) {
      return;
    }
    if (logger.isInfoEnabled()) {
      Object cachedObj = this.get(key);
      if (cachedObj != null) {
        logger.info("Remove value from ehcache. key = " + key + "value =" + cachedObj.toString());
      } else {
        logger.info("Remove value from ehcache. key = " + key);
      }
    }
    this.simpleEhcache.remove(key);
  }

  public void putMapNotExist(String keyPrefix, Map<String, Object> map, int expiredTime) {
    if (keyPrefix == null || map == null || map.isEmpty()) {
      return;
    }
    Iterator<String> it = map.keySet().iterator();
    while (it.hasNext()) {
      String key = it.next();
      Object obj = map.get(key);
      if (obj != null) {
        this.putNotExist(keyPrefix + key, obj, expiredTime);
      }
    }
  }

  /**
   * no elements there , put it.
   * 
   * @param key
   * @param value
   */
  public void putNotExist(String key, Object value, int expiredTime) {
    if (key == null || value == null) {
      return;
    }
    Object cachedVal = this.get(key);
    if (cachedVal == null) {
      synchronized (this.lock) {
        cachedVal = this.get(key);
        if (cachedVal == null) {
          this.put(key, value, expiredTime);
        }
      }
    }
  }

  public void setSimpleEhcache(Cache simpleEhcache) {
    this.simpleEhcache = simpleEhcache;
  }

  public void setEnabled(boolean enabled) {
    this.enabled = enabled;
  }

  public boolean isEnabled() {
    return enabled;
  }

  private boolean enabled = false;

  private Cache simpleEhcache;

}
