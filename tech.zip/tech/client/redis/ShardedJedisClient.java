package com.agileeagle.gf.tech.client.redis;

import com.agileeagle.core.util.IOUtil;
import com.agileeagle.gf.m.util.GfJsonUtil;
import com.agileeagle.gf.tech.cache.RichCache;
import com.agileeagle.gf.util.SerializeUtil;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.apache.log4j.Logger;
import redis.clients.jedis.JedisShardInfo;
import redis.clients.jedis.ShardedJedis;
import redis.clients.jedis.ShardedJedisPipeline;
import redis.clients.jedis.ShardedJedisPool;

import java.io.InputStream;
import java.util.*;

/**
 * @author zhongcong
 * @since 2016-06-14
 */
public class ShardedJedisClient implements RichCache {
	private Logger logger = Logger.getLogger(ShardedJedisClient.class);
	private String configJsonClassPath;

	public String getConfigJsonClassPath() {
		return configJsonClassPath;
	}

	public void setConfigJsonClassPath(String configJsonClassPath) {
		this.configJsonClassPath = configJsonClassPath;
	}

	/*****
	 * 初始化，加載連接配置
	 */

	public void init() {

		logger.info("---初始化shardedJedisPool配置开始----");

		InputStream in = null;

		in = this.getClass().getResourceAsStream(configJsonClassPath);
		if (in == null) {
			logger.error("file not find classpath file " + configJsonClassPath);
			return;
		}
		String jsonString = IOUtil.inputStream2String(in);
		JSONObject json = JSONObject.parseObject(jsonString);
		// 全局连接池的配置 maxTotal 最大连接数量 maxIdle 最大空闲连接数 maxWaitMillis 获取连接时的最大等待毫秒数
		// testOnBorrow 在获取连接的时候检查有效性
		GenericObjectPoolConfig poolConfig = json.getObject("poolConfig", GenericObjectPoolConfig.class);
		List<JedisShardInfo> shards = new ArrayList<JedisShardInfo>();
		JSONArray asay = json.getJSONArray("shardLists");
		Iterator<Object> it = asay.iterator();
		while (it.hasNext()) {
			JSONObject jsonObject = (JSONObject) it.next();
			// host 以主机：端口号/dbIndex 的形式配置
			JedisShardInfo shard = new JedisShardInfo(jsonObject.getString("host"));
			// connectionTimeout 连接超时时间
			shard.setConnectionTimeout(jsonObject.getInteger("connectionTimeout"));
			// soTimeout socket阻塞超时时间
			shard.setSoTimeout(jsonObject.getInteger("soTimeout"));
			// redis 连接密码
			shard.setPassword(jsonObject.getString("password"));
			shards.add(shard);
		}
		shardedJedisPool = new ShardedJedisPool(poolConfig, shards);
		logger.info("---初始化shardedJedisPool配置结束----");
	}

	/***
	 * 銷毀
	 */
	public void destroy() {
		logger.info("---销毁shardedJedisPool配置开始----");
		shardedJedisPool.destroy();
		logger.info("---销毁shardedJedisPool配置结束----");
	}

	/**
	 * Get sharedJedis instance.
	 * 
	 * @return
	 */
	public ShardedJedis getShardedJedis() {
		ShardedJedis jedis = getShardedJedisPool().getResource();
		return jedis;
	}

	public ShardedJedisPool getShardedJedisPool() {
		return shardedJedisPool;
	}

	public void setShardedJedisPool(ShardedJedisPool shardedJedisPool) {
		this.shardedJedisPool = shardedJedisPool;
	}

	private boolean check(String key) {
		byte[] bkey = (key == null ? null : key.getBytes());
		return check(bkey);
	}

	private boolean check(byte[] key) {
		if (key == null) {
			logger.error("Redis key can not be null.");
			return false;
		}
		return true;
	}

	private boolean hCheck(String key, String field) {
		if (!check(key) || field == null) {
			logger.error("Redis hash key can not be null.");
			return false;
		}
		return true;

	}

	/**
	 * return to pool.
	 * 
	 * @param jedis
	 */
	public void returnResource(ShardedJedis jedis) {
		getShardedJedisPool().returnResource(jedis);
	}

	/**
	 * destory resource.
	 * 
	 * @param jedis
	 */
	public void returnBrokenResource(ShardedJedis jedis) {
		getShardedJedisPool().returnBrokenResource(jedis);
	}

	private ShardedJedisPool shardedJedisPool;

	@Override
	public void setString(String key, String value, int seconds) {
		if (value == null) {
			return;
		}
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			shardedJedis.set(key, value);
			if (seconds > 0) {
				shardedJedis.expire(key, seconds);
			}
			this.returnResource(shardedJedis);
		} catch (Exception e) {
			if (shardedJedis != null) {
				this.returnBrokenResource(shardedJedis);
			}
			logger.error(e.getCause());
		}

	}

	@Override
	public String getString(String key) {
		String re = null;
		if (!this.check(key)) {
			return re;
		}
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			re = shardedJedis.get(key);
			this.returnResource(shardedJedis);
		} catch (Exception e) {
			if (shardedJedis != null) {
				this.returnBrokenResource(shardedJedis);
			}
			logger.error(e);
		}
		return re;
	}

	@Override
	public Long getLong(String key) {
		String value = getString(key);
		if (value == null) {
			return null;
		}
		return Long.parseLong(value);
	}

	@Override
	public void setObject(String key, Object value, int seconds) {
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			shardedJedis.set(key.getBytes(), SerializeUtil.serialize(value));
			if (seconds >= 0) {
				shardedJedis.expire(key, seconds);
			}

		} catch (Exception e) {
			logger.error(e);
		} finally {
			this.returnResource(shardedJedis);
		}
	}

	public void setObjectToJson(String key, Object value, int seconds) {
		String val = GfJsonUtil.toJSONString(value);
		setJsonString(key, val, seconds);
	}

	public void setJsonString(String key, String value, int seconds) {
		if (key == null || value == null) {
			return;
		}
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			shardedJedis.set(key, value);
			if (seconds >= 0) {
				shardedJedis.expire(key, seconds);
			}
			this.returnResource(shardedJedis);
		} catch (Exception e) {
			if (shardedJedis != null) {
				this.returnBrokenResource(shardedJedis);
			}
			logger.error(e.getCause());
		}
	}

	@Override
	public <T> T getObjectFromJson(String key, Class<T> t) {
		String value = getString(key);
		T r = GfJsonUtil.parseObject(value, t);
		return r;
	}

	@Override
	public long delete(String key) {
		long re = 0;
		if (!this.check(key)) {
			return re;
		}
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			re = shardedJedis.del(key.getBytes());
			this.returnResource(shardedJedis);
		} catch (Exception e) {
			if (shardedJedis != null) {
				this.returnBrokenResource(shardedJedis);
			}
			logger.error(e);
		}
		return re;
	}

	@Override
	public boolean exists(String key) {
		boolean re = false;
		if (!this.check(key)) {
			return re;
		}

		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			re = shardedJedis.exists(key.getBytes());
			this.returnResource(shardedJedis);
		} catch (Exception e) {
			if (shardedJedis != null) {
				this.returnBrokenResource(shardedJedis);
			}
			logger.error(e);
		}
		return re;

	}

	@Override
	public long expireAt(String key, long unixTime) {
		long re = 0;
		if (!this.check(key)) {
			return re;
		}

		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			re = shardedJedis.expireAt(key, unixTime);
			this.returnResource(shardedJedis);
		} catch (Exception e) {
			if (shardedJedis != null) {
				this.returnBrokenResource(shardedJedis);
			}
			logger.error(e);
		}
		return re;
	}

	@Override
	public long expire(String key, int unixTime) {
		long re = 0;
		if (!this.check(key)) {
			return re;
		}

		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			re = shardedJedis.expire(key, unixTime);
			this.returnResource(shardedJedis);
		} catch (Exception e) {
			if (shardedJedis != null) {
				this.returnBrokenResource(shardedJedis);
			}
			logger.error(e);
		}
		return re;
	}

	@Override
	public long ttl(String key) {
		long re = -1;
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			re = shardedJedis.ttl(key);
			this.returnResource(shardedJedis);
		} catch (Exception e) {
			if (shardedJedis != null) {
				this.returnBrokenResource(shardedJedis);
			}
			logger.error(e);
		}
		return re;
	}

	@Override
	public boolean limitIncr(String key, Long upperLimit) {
		Long latestValue = this.getLong(key);
		if (upperLimit != null && latestValue != null && latestValue >= upperLimit) {
			return false;
		}

		latestValue = this.incr(key, 1l);
		if (upperLimit != null && latestValue > upperLimit) {
			this.incr(key, -1);
			return false;
		}
		return true;
	}

	@Override
	public Integer incr(String key, Integer step) {
		Long lStep = (step == null ? 0L : new Long(step.longValue()));
		Long re = this.incr(key, lStep);
		return (re == null ? null : re.intValue());
	}

	@Override
	public void rpush(String key, String... value) {
		if (value == null) {
			return;
		}
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			shardedJedis.rpush(key, value);
			this.returnResource(shardedJedis);
		} catch (Exception e) {
			if (shardedJedis != null) {
				this.returnBrokenResource(shardedJedis);
			}
			logger.error(e);
		}

	}

	@Override
	public String rpop(String key) {
		String re = null;
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			re = shardedJedis.rpop(key);
			this.returnResource(shardedJedis);
		} catch (Exception e) {
			if (shardedJedis != null) {
				this.returnBrokenResource(shardedJedis);
			}
			logger.error(e);
		}
		return re;
	}

	@Override
	public String lset(String key, int index, String value) {
		String re = null;
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			re = shardedJedis.lset(key, index, value);
			this.returnResource(shardedJedis);
		} catch (Exception e) {
			if (shardedJedis != null) {
				this.returnBrokenResource(shardedJedis);
			}
			logger.error(e);
		}
		return re;
	}

	@Override
	public String lindex(String key, int index) {
		String re = null;
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			re = shardedJedis.lindex(key, index);
			this.returnResource(shardedJedis);
		} catch (Exception e) {
			if (shardedJedis != null) {
				this.returnBrokenResource(shardedJedis);
			}
			logger.error(e);
		}
		return re;
	}

	@Override
	public long llen(String key) {
		long re = 0;
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			re = shardedJedis.llen(key);
			this.returnResource(shardedJedis);
		} catch (Exception e) {
			if (shardedJedis != null) {
				this.returnBrokenResource(shardedJedis);
			}
			logger.error(e);
		}
		return re;
	}

	@Override
	public String ltrim(String key, int start, int end) {
		String re = null;
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			re = shardedJedis.ltrim(key, start, end);
			this.returnResource(shardedJedis);
		} catch (Exception e) {
			if (shardedJedis != null) {
				this.returnBrokenResource(shardedJedis);
			}
			logger.error(e);
		}
		return re;
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> List<T> lrange(String key, long start, long end, Class<T> t) {
		List<String> stringList = null;
		ShardedJedis shardedJedis = null;
		List<T> list = new ArrayList<T>();
		try {
			shardedJedis = this.getShardedJedis();
			stringList = shardedJedis.lrange(key, start, end);
			if (CollectionUtils.isEmpty(stringList)) {
				return null;
			}
			for (String s : stringList) {
				T r = GfJsonUtil.parseObject(s, t);
				list.add(r);
			}

		} catch (Exception e) {

			logger.error(e);
		} finally {
			this.returnResource(shardedJedis);

		}
		return list;
	}

	@Override
	public void hmsetObject(String key, Map<String, Object> map) {
		if (StringUtils.isEmpty(key) || MapUtils.isEmpty(map)) {
			return;
		}
		Map<String, String> convertedMap = convertToByteMap(map);
		hmsetString(key, convertedMap);

	}

	private Map<String, String> convertToByteMap(Map<String, Object> map) {
		Map<String, String> convertedMap = new HashMap<String, String>();
		Iterator<String> it = map.keySet().iterator();
		while (it.hasNext()) {
			String key = it.next();
			Object obj = map.get(key);
			convertedMap.put(key, GfJsonUtil.toJSONString(obj));
		}
		return convertedMap;
	}

	@Override
	public void hmsetString(String key, Map<String, String> map) {
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			shardedJedis.hmset(key, map);
			this.returnResource(shardedJedis);
		} catch (Exception e) {
			if (shardedJedis != null) {
				this.returnBrokenResource(shardedJedis);
			}
			logger.error(e);
		}

	}

	@Override
	public void hsetInteger(String key, String field, Integer value) {

		hsetString(key, field, (value == null ? null : "" + value));

	}

	@Override
	public void hsetString(String key, String field, String value) {
		if (!hCheck(key, field) || value == null) {
			return;
		}

		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			shardedJedis.hset(key, field, value);

			this.returnResource(shardedJedis);

		} catch (Exception e) {
			if (shardedJedis != null) {
				this.returnBrokenResource(shardedJedis);
			}
			logger.error(e);
		}

	}

	@Override
	public void hsetObject(String key, String field, Object value) {
		if (!hCheck(key, field) || value == null) {
			return;
		}
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			shardedJedis.hset(key.getBytes(), field.getBytes(), SerializeUtil.serialize(value));
			this.returnResource(shardedJedis);
		} catch (Exception e) {
			if (shardedJedis != null) {
				this.returnBrokenResource(shardedJedis);
			}
			logger.error(e);
		}

	}

	@Override
	public boolean hexists(String key, String field) {

		boolean re = false;
		if (!hCheck(key, field)) {
			return re;
		}
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			re = shardedJedis.hexists(key, field);
			this.returnResource(shardedJedis);
		} catch (Exception e) {
			if (shardedJedis != null) {
				this.returnBrokenResource(shardedJedis);
			}
			logger.error(e);
		}
		return re;

	}

	@Override
	public Integer hgetInteger(String key, String field) {
		String value = hgetString(key, field);
		return (StringUtils.isEmpty(value) ? null : Integer.parseInt(value));
	}

	@Override
	public String hgetString(String key, String field) {
		String re = null;
		if (!hCheck(key, field)) {
			return re;
		}

		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			re = shardedJedis.hget(key, field);

			this.returnResource(shardedJedis);
		} catch (Exception e) {
			if (shardedJedis != null) {
				this.returnBrokenResource(shardedJedis);
			}
			logger.error(e);
		}
		return re;
	}

	@Override
	public Long hgetLong(String key, String field) {
		String value = hgetString(key, field);
		if (value == null) {
			return null;
		}
		return Long.parseLong(value);
	}

	@Override
	public <T> T hGetObjectFromJson(String key, String field, Class<T> t) {
		String value = hgetString(key, field);
		T re = GfJsonUtil.parseObject(value, t);
		return re;
	}

	@Override
	public long hdel(String key, String field) {
		long re = 0;
		if (!hCheck(key, field)) {
			return re;
		}
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			re = shardedJedis.hdel(key, field);
			this.returnResource(shardedJedis);
		} catch (Exception e) {
			if (shardedJedis != null) {
				this.returnBrokenResource(shardedJedis);
			}
			logger.error(e);
		}
		return re;
	}

	@Override
	public long hlen(String key) {
		long re = 0;
		if (!check(key)) {
			return re;
		}
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			re = shardedJedis.hlen(key);
			this.returnResource(shardedJedis);
		} catch (Exception e) {
			if (shardedJedis != null) {
				this.returnBrokenResource(shardedJedis);
			}
			logger.error(e);
		}
		return re;
	}

	@Override
	public Set<String> hkeys(String key) {
		Set<String> re = null;
		if (!check(key)) {
			return re;
		}
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			re = shardedJedis.hkeys(key);
			this.returnResource(shardedJedis);
		} catch (Exception e) {
			if (shardedJedis != null) {
				this.returnBrokenResource(shardedJedis);
			}
			logger.error(e);
		}
		return re;
	}

	@Override
	public List<String> hvals(String key) {
		List<String> re = null;
		if (!check(key)) {
			return re;
		}
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			re = shardedJedis.hvals(key);
			this.returnResource(shardedJedis);
		} catch (Exception e) {
			if (shardedJedis != null) {
				this.returnBrokenResource(shardedJedis);
			}
			logger.error(e);
		}
		return re;
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> Map<String, T> hGetAllObject(String key, Class<T> t) {
		Map<String, T> re = null;
		if (!check(key)) {
			return re;
		}
		ShardedJedis shardedJedis = null;
		try {
			re = new HashMap<String, T>();
			shardedJedis = this.getShardedJedis();
			Map<String, String> map = shardedJedis.hgetAll(key);
			if (MapUtils.isNotEmpty(map)) {
				Iterator<String> it = map.keySet().iterator();
				while (it.hasNext()) {
					String ke = it.next();
					String value = map.get(ke);
					T r = GfJsonUtil.parseObject(value, t);
					re.put(ke, r);

				}

			}

		} catch (Exception e) {
			logger.error(e);
		} finally {
			returnResource(shardedJedis);
		}
		return re;

	}

	@Override
	public long hincrBy(String key, String field, long value) {
		long re = 0;
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			re = shardedJedis.hincrBy(key, field, value);
			this.returnResource(shardedJedis);
		} catch (Exception e) {
			if (shardedJedis != null) {
				this.returnBrokenResource(shardedJedis);
			}
			logger.error(e);
		}
		return re;
	}

	@Override
	public long hsetnx(String key, String field, String value) {
		long re = 0;
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			re = shardedJedis.hsetnx(key, field, value);
			this.returnResource(shardedJedis);
		} catch (Exception e) {
			if (shardedJedis != null) {
				this.returnBrokenResource(shardedJedis);
			}
			logger.error(e);
		}
		return re;
	}

	@Override
	public void sadd(String key, List<Object> values) {
		if (!this.check(key)) {
			return;
		}
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			List<String> jsonValues = new ArrayList<String>();
			for (Object object : values) {
				jsonValues.add(GfJsonUtil.toJSONString(object));
			}
			ShardedJedisPipeline pip = shardedJedis.pipelined();
			for (String value : jsonValues) {
				pip.sadd(key, value);
			}
			pip.sync();
			this.returnResource(shardedJedis);
		} catch (Exception e) {
			if (shardedJedis != null) {
				this.returnBrokenResource(shardedJedis);
			}
			logger.error(e);
		}

	}

	@Override
	public long srem(String key, String... values) {
		long re = 0;
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			re = shardedJedis.srem(key, values);
			this.returnResource(shardedJedis);
		} catch (Exception e) {
			if (shardedJedis != null) {
				this.returnBrokenResource(shardedJedis);
			}
			logger.error(e);
		}
		return re;
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> Set<T> smembers(String key, Class<T> t) {
		Set<T> re = null;
		ShardedJedis shardedJedis = null;
		try {
			re = new HashSet<T>();
			shardedJedis = this.getShardedJedis();
			Set<String> set = shardedJedis.smembers(key);
			if (CollectionUtils.isNotEmpty(set)) {
				Iterator<String> it = set.iterator();
				while (it.hasNext()) {
					String value = it.next();
					T r = GfJsonUtil.parseObject(value, t);
					re.add(r);
				}
			}

		} catch (Exception e) {
			logger.error(e);
		} finally {
			returnResource(shardedJedis);
		}
		return re;
	}

	@Override
	public boolean sismember(String key, String member) {
		boolean re = false;
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			re = shardedJedis.sismember(key, member);
			this.returnResource(shardedJedis);
		} catch (Exception e) {
			if (shardedJedis != null) {
				this.returnBrokenResource(shardedJedis);
			}
			logger.error(e);
		}
		return re;
	}

	@Override
	public long scard(String key) {
		long re = 0;
		if (!this.check(key)) {
			return re;
		}
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			re = shardedJedis.scard(key);
			this.returnResource(shardedJedis);
		} catch (Exception e) {
			if (shardedJedis != null) {
				this.returnBrokenResource(shardedJedis);
			}
			logger.error(e);
		}
		return re;
	}

	@Override
	public String spop(String key) {
		String re = null;
		if (!this.check(key)) {
			return re;
		}
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			re = shardedJedis.spop(key);
			this.returnResource(shardedJedis);
		} catch (Exception e) {
			if (shardedJedis != null) {
				this.returnBrokenResource(shardedJedis);
			}
			logger.error(e);
		}
		return re;
	}

	@Override
	public void zadd(String key, double score, String member) {
		if (!this.check(key)) {
			return;
		}
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			shardedJedis.zadd(key, score, member);
			this.returnResource(shardedJedis);
		} catch (Exception e) {
			if (shardedJedis != null) {
				this.returnBrokenResource(shardedJedis);
			}
			logger.error(e);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> Set<T> zrangebyscore(String key, double min, double max, Class<T> t) {
		Set<T> re = null;
		if (!this.check(key)) {
			return re;
		}
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			Set<String> set = shardedJedis.zrangeByScore(key, min, max);
			if (CollectionUtils.isNotEmpty(set)) {
				re = new LinkedHashSet<T>();
				Iterator<String> it = set.iterator();
				while (it.hasNext()) {
					String value = it.next();
					T r = GfJsonUtil.parseObject(value, t);
					re.add(r);
				}
			}

		} catch (Exception e) {
			logger.error(e);
		} finally {
			this.returnResource(shardedJedis);
		}
		return re;
	}

	@Override
	public double zscore(String key, String member) {
		double re = 0;
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			re = shardedJedis.zscore(key, member);
			this.returnResource(shardedJedis);
		} catch (Exception e) {
			if (shardedJedis != null) {
				this.returnBrokenResource(shardedJedis);
			}
			logger.error(e);
		}
		return re;
	}

	@Override
	public Long incr(String key, Long step) {
		if (!check(key)) {
			return 0l;
		}
		long re = 0;
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			re = shardedJedis.incrBy(key, (step == null ? 0L : step));
			this.returnResource(shardedJedis);
		} catch (Exception e) {
			if (shardedJedis != null) {
				this.returnBrokenResource(shardedJedis);
			}
			logger.error(e);
		}
		return re;
	}

	@Override
	public Long setNxString(String key, String val, int expiredTime) {
		if (!check(key)) {
			return 0l;
		}
		long re = 0;
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			re = shardedJedis.setnx(key, val);
			if (expiredTime > 0) {
				shardedJedis.expire(key, expiredTime);
			}
			this.returnResource(shardedJedis);
		} catch (Exception e) {
			if (shardedJedis != null) {
				this.returnBrokenResource(shardedJedis);
			}
			logger.error(e);
		}
		return re;
	}

	@Override
	public Long setNxLong(String key, Long val, int expiredTime) {
		return setNxString(key, val + "", expiredTime);
	}

	@Override
	public List<String> hmgetString(String key, String[] field) {
		if (!check(key)) {
			return null;
		}
		List<String> re = null;
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			re = shardedJedis.hmget(key, field);

			this.returnResource(shardedJedis);
		} catch (Exception e) {
			if (shardedJedis != null) {
				this.returnBrokenResource(shardedJedis);
			}
			logger.error(e);
		}
		return re;
	}

	@Override
	public <T> List<T> hmgetObject(String key, String[] field, Class<T> t) {
		if (!check(key)) {
			return null;
		}
		List<T> list = null;
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			List<String> re = shardedJedis.hmget(key, field);
			if (CollectionUtils.isNotEmpty(re)) {
				list = new ArrayList<T>();
				for (String value : re) {
					T r = GfJsonUtil.parseObject(value, t);
					list.add(r);
				}
			}

		} catch (Exception e) {

			logger.error(e);
		} finally {
			returnResource(shardedJedis);
		}
		return list;
	}

	@Override
	public void zadd(String key, Map<Object, Double> members) {
		if (!this.check(key)) {
			return;
		}
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			if (MapUtils.isEmpty(members)) {
				return;
			}
			Map<String, Double> map = new HashMap<String, Double>();

			Iterator<Object> it = members.keySet().iterator();
			while (it.hasNext()) {
				Object ob = it.next();
				Double va = members.get(ob);
				map.put(GfJsonUtil.toJSONString(ob), va);
			}

			shardedJedis.zadd(key, map);
		} catch (Exception e) {
			logger.error(e);
		} finally {
			returnResource(shardedJedis);
		}
	}

	@Override
	public void lpush(String key, List<Object> values) {
		if (!this.check(key) || CollectionUtils.isEmpty(values)) {
			return;
		}
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			List<String> jsonValues = new ArrayList<String>();
			for (Object object : values) {
				jsonValues.add(GfJsonUtil.toJSONString(object));
			}

			ShardedJedisPipeline pip = shardedJedis.pipelined();
			for (String value : jsonValues) {
				pip.lpush(key, value);
			}
			pip.sync();
		} catch (Exception e) {
			logger.error(e);
		} finally {
			returnResource(shardedJedis);
		}
	}

	@Override
	public void lpush(String key, String... value) {
		if (!this.check(key)) {
			return;
		}
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			shardedJedis.lpush(key, value);

		} catch (Exception e) {
			logger.error(e);
		} finally {
			returnResource(shardedJedis);
		}

	}

	@Override
	public void rpush(String key, List<Object> values) {
		if (!this.check(key) || CollectionUtils.isEmpty(values)) {
			return;
		}
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			List<String> jsonValues = new ArrayList<String>();
			for (Object object : values) {
				jsonValues.add(GfJsonUtil.toJSONString(object));
			}
			ShardedJedisPipeline pip = shardedJedis.pipelined();
			for (String value : jsonValues) {
				pip.rpush(key, value);
			}
			pip.sync();
		} catch (Exception e) {
			logger.error(e);
		} finally {
			returnResource(shardedJedis);
		}

	}

	@Override
	public void sadd(String key, String... values) {
		if (!this.check(key)) {
			return;
		}
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			shardedJedis.sadd(key, values);
		} catch (Exception e) {
			logger.error(e);
		} finally {
			returnResource(shardedJedis);
		}

	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> T getObject(String key) {
		T re = null;
		if (!this.check(key)) {
			return re;
		}
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			byte[] values = shardedJedis.get(key.getBytes());
			Object object = SerializeUtil.unserialize(values);
			if (object == null) {
				return null;
			}
			re = (T) object;
		} catch (Exception e) {
			logger.error(e);
		} finally {
			returnResource(shardedJedis);
		}
		return re;
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> T hGetObject(String key, String field) {
		T re = null;
		if (!this.check(key) || field == null) {
			return re;
		}
		ShardedJedis shardedJedis = null;
		try {
			shardedJedis = this.getShardedJedis();
			byte[] values = shardedJedis.hget(key.getBytes(), field.getBytes());
			Object object = SerializeUtil.unserialize(values);
			if (object == null) {
				return null;
			}
			re = (T) object;
		} catch (Exception e) {
			logger.error(e);
		} finally {
			returnResource(shardedJedis);
		}
		return re;
	}

	@Override
	public void hsetObjectToJson(String key, String field, Object value) {
		this.hsetString(key, field, GfJsonUtil.toJSONString(value));

	}

	@Override
	public <T> List<T> getList(String key,Class<T> t) {
		String value=getString(key);
		List<T> re=GfJsonUtil.parseArray(value, t);
		return re;
	}

}
