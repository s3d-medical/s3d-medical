package com.nhs.shop.unit;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 
 * @Title: CrawlService.java
 * @Package com.nhs.shop.unit
 * @Description: TODO
 * @author huxianjun
 * @date 2016年6月25日 上午11:50:18
 * @version V1.0
 */
@Service
@Transactional
public class CrawlService {
    /**
     * 
     * @Title: crawlCar4s
     * @Description: TODO
     * @param @param url
     * @param @return
     * @param @throws Exception   
     * @return String 
     * @author huxianjun 2016年6月25日 
     * @throws
     */
    public String crawlCar4s(String url) throws Exception {
        String ret = "";
        // url = URLEncoder.encode(url,"UTF-8");
        try {
            URL urlrq = new URL(url);
            HttpURLConnection conn = (HttpURLConnection) urlrq.openConnection();
            conn.setRequestMethod("GET");
            conn.setDoOutput(true);
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(10000);

            OutputStream os = conn.getOutputStream();
            os.write(("PvareaID=103703").getBytes("utf8"));
            os.close();

            InputStream in = conn.getInputStream();
            byte[] data = new byte[in.available()];
            in.read(data);
            ret = new String(data, "utf8");
            System.out.println(new String(data, "utf8").replace("><", ">\n<"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ret;
    }
}
