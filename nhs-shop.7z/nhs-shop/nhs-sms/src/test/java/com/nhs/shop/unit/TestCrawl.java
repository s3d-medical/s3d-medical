package com.nhs.shop.unit;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
public class TestCrawl {
	
	@Resource
	CrawlService crawlService;
	
	@Test
	public void testCar4s() throws Exception {
		crawlService.crawlCar4s("http://dealer.autohome.com.cn/suzhou/320502_0_0_0_1.html");
	}
	
}
