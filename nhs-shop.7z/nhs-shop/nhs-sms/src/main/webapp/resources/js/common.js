String.prototype.trim   =   function()   {   
  return   this.replace(/(^\s*)|(\s*$)/g,"");   
};

//refuse backspace
document.onkeydown = function (e){
	var code;
	//!e is IE
	if (!e){
		var e = window.event;
		code = e.keyCode; // IE
		if((code == 8                             
			&& event.srcElement.type != "text"         
	        && event.srcElement.type != "textarea"    
	        && event.srcElement.type != "password")
	        || (event.srcElement.onclick+"").indexOf("WdatePicker")!=-1){    
			window.event.keyCode = 0;  
	        window.event.returnValue = false; 
		}
	}
};

//信息提交公共方法
function toOperation(url,form)
{
	eval(form).action=url;
	eval(form).submit();
}
/*INIT XMLHTTPRequest Object*/
function initXMLHttpRequestObject(){
	var xml = 0;
	var xmlArray=["MSXML2.XMLHTTP","Microsoft.XMLHTTP"];
	for(var i=0;i<xmlArray.length;i++){
		try{//ie 6 MSXML2
			xml = new ActiveXObject(xmlArray[i]);
		}catch(e){
			
		}
		if(xml != null){	
			return xml;
		}	
	}
	xml = new XMLHttpRequest();
	return xml;
}

function R(){
	/**
	 * url:服务器地址
	 * method:发送方法
	 * callback:回调函数
	 * data:使用Post方法时，要发送的数据
	 * */
	this.send = function(url, method, callback, data) {
		var request=false;
		request=initXMLHttpRequestObject();			    
		if (method=="POST") {
			request.open("POST", url, true);
			request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');		
			request.send(data);
			request.onreadystatechange = function() {
			if (request.readyState == 4 && request.status == 200) {
				hideLoading();
				callback(request,data);
			}
			};
		} else {
			request.open("GET", url, true);
			request.send(null);
			request.onreadystatechange=function(){
		 			if(request.readyState==4){
						if(request.status==200){
							hideLoading();
							callback(request,data);
						}
		 			}
		 		};
		}
		return request;
	};
}

/* Create a div show loading */
function showLoading(appendTag)
{
	var loading=document.getElementById("loading");
	if(!loading)
		loading=document.createElement("loading");
	loading.id="loading";
	loading.innerHTML="<img src=resources/images/loading.gif>数据加载中...";
	document.getElementById(appendTag).appendChild(loading);
}
/* Hide the loading div */
function hideLoading()
{
	var loading=document.getElementById("loading");
    if(loading){
        loading.innerHTML="";
    }	
}
/* Create a div to cover the whole page */
function divCover()
{
	//隐藏SELECT元素
    var objSelects=document.getElementsByTagName("select");
    for(var i=0;i<objSelects.length;i++){
        objSelects[i].style.visibility="hidden";
    }
    //隐藏动画元素
    var obj=document.getElementsByTagName("embed");
    for(var i=0;i<obj.length;i++){
        obj[i].style.visibility="hidden";
    }
    //显示覆盖层
    var over=document.getElementById("divOver");
    if(!over){
        over=document.createElement("div");
    }
    over.id="divOver";
    var oS=over.style;
    oS.display = "block";
    oS.left="0px";
    oS.top="0px";
    oS.position = "absolute";
    oS.zIndex = "1";
    var height=document.body.scrollHeight+20;
    if((window.screen.availHeight-window.screenTop-24)>height){
        height= window.screen.availHeight-window.screenTop-24;
    }
    var width=window.screen.availWidth-22;
    over.innerHTML = "<table width="+width+" height="+height+" style='background-color: #333333; filter: Alpha(Opacity=40);'></div>";
    document.body.appendChild(over);
}
/* Hide the cover */
function hideOver()
{    
    var over=document.getElementById("divOver");
    if(over){
        over.innerHTML="";
    }
    var objSelects=document.getElementsByTagName("select");
    for(var i=0;i<objSelects.length;i++){
        objSelects[i].style.visibility="visible";
    } 
    var obj=document.getElementsByTagName("embed");
    for(var i=0;i<obj.length;i++){
        obj[i].style.visibility="visible";
    }
}
/* Resize a image */
function ResizeImage(obj, newW, newH){			
    if(obj == null) return;
    var oImg = new Image();
    oImg.src = obj.src;
    var oldW=oImg.width;
	var oldH=oImg.height;				
    if(oldW>newW || oldH>newH){
        w=oldW/newW; 
		h=oldH/newH;
        if(h>w) w=h;
        oldW=oldW/w; 
		oldH=oldH/w;
    }
    if(oldW > 0 && oldH > 0){
        obj.width=oldW;
		obj.height=oldH;}
}

/* Do some test */
function T(variables)
{
	alert(variables);
}

/*version 2.0 fant5 add*/
function stop() 
{ 
return false; 
} 
//document.oncontextmenu=stop; 