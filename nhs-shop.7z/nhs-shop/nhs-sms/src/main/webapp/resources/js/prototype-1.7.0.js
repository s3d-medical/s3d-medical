//= compat
//= require "./prototype/prototype"
//= require "./prototype/lang"
//= require "./prototype/ajax"
//= require "./prototype/dom"
//= require "./prototype/deprecated"
