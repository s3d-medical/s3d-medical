jQuery(function() {

	getRootPath = function() {
		// 获取当前网址，如： http://localhost:8080/ems/Pages/Basic/Person.jsp
		var curWwwPath = window.document.location.href;
		// 获取主机地址之后的目录，如： /ems/Pages/Basic/Person.jsp
		var pathName = window.document.location.pathname;
		var pos = curWwwPath.indexOf(pathName);
		// 获取主机地址，如： http://localhost:8080
		var localhostPath = curWwwPath.substring(0, pos);
		// 获取带"/"的项目名，如：/ems
		var projectName = pathName.substring(0,
				pathName.substr(1).indexOf('/') + 1);
		return (localhostPath + projectName);
	}

	var rootPath = getRootPath();

	jQuery('#provinceId')
			.on(
					'change',
					function() {
						var val = jQuery('#provinceId').val();
						if(val != null && val != '') {
							var ul = rootPath + '/area/listByPid/' + val;
							var secondUrl = rootPath + "/area/listByPid/" + val;
							jQuery
									.ajax({
										type : "POST",
										url : secondUrl,
										cache : false,
										dataType : "json",
										success : function(data) {
											var arr = data.content;
											if (val == '') {
												jQuery('#cityId').hide();
												jQuery('#districtId').hide();
											} else {
												if (arr.length > 0) {
													jQuery('#cityId').empty();
													var option = '<option value="">--请选择市--</option>';
													for (var i = 0; i < arr.length; i++) {
														option += '<option value='
																+ arr[i].id + '>'
																+ arr[i].name
																+ '</option>';
													}
													jQuery('#cityId').append(
															option);
													jQuery('#districtId').empty();
													jQuery('#districtId').hide();
													jQuery('#cityId').show();
												} else {
													jQuery('#cityId').empty();
													jQuery('#districtId').empty();
													jQuery('#cityId').hide();
													jQuery('#districtId').hide();
												}
											}
										}
									});
						} else {
							jQuery('#cityId').empty();
							jQuery('#districtId').empty();
							jQuery('#cityId').hide();
							jQuery('#districtId').hide();
						}
					});

	jQuery('#cityId')
			.on(
					'change',
					function() {
						var pid = jQuery('#cityId').val();
						if(pid != '' && pid != null) {
							var ul = rootPath + "/area/listByPid/" + pid;
							jQuery
									.ajax({
										type : "POST",
										url : ul,
										cache : false,
										dataType : "json",
										success : function(data) {
											var arr = data.content;
											if (pid == '') {
												jQuery('#districtId').hide();
											} else {
												if (arr.length > 0) {
													jQuery('#districtId').empty();
													var option = '<option value="">--请选择区/县--</option>';
													for (var i = 0; i < arr.length; i++) {
														option += '<option value='
																+ arr[i].id + '>'
																+ arr[i].name
																+ '</option>';
													}
													jQuery('#districtId').append(
															option);
													jQuery('#districtId').show();
												} else {
													jQuery('#districtId').empty();
													jQuery('#districtId').hide();
												}
											}
										}
									});
						} else {
							jQuery('#districtId').empty();
							jQuery('#districtId').hide();
						}
					});

});