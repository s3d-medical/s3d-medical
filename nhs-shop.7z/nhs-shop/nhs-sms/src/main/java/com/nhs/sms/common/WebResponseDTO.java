package com.nhs.sms.common;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;


public class WebResponseDTO implements Serializable {

    private static final long serialVersionUID = -1671607286610174732L;
    private Integer errorCode = WebExceptionCode.NORMAL.errorCode;
    private Object obj = null;
    private String errorMsg = WebExceptionCode.NORMAL.errorMsg;
    private final Map<String, Object> result = new HashMap<>();
    private Timestamp systemTime;

    public WebResponseDTO() {
    }

    public WebResponseDTO(Integer errorCode, String errorMsg) {
        this.errorCode = errorCode;
        this.errorMsg = errorMsg;
    }

    public Integer getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(Integer errorCode) {
        this.errorCode = errorCode;
    }

    public Object getObj() {
		return obj;
	}

	public void setObj(Object obj) {
		this.obj = obj;
	}

	public Map<String, Object> getResult() {
        return result;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public Timestamp getSystemTime() {
        return systemTime;
    }

    public void setSystemTime(Timestamp systemTime) {
        this.systemTime = systemTime;
    }

}
