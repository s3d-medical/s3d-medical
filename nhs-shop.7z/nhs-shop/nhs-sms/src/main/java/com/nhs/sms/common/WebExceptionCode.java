package com.nhs.sms.common;

public enum WebExceptionCode {

	NORMAL(1, "OK!"),

	// 系统级
	SERVEREXCEPTION(10000, "Server exception!"), // 服务器异常

	ACCOUNTEXCEPTION(20000, "Invalid accessToken!"), // 无效的accessToken
	PARAMEXCEPTION(20001, "Param to bean exception!"), // Param参数转换异常

	;
	public final Integer errorCode;
	public final String errorMsg;

	private WebExceptionCode(Integer errorCode, String errorMsg) {
		this.errorCode = errorCode;
		this.errorMsg = errorMsg;
	}

	public static WebExceptionCode getExceptionCode(final String exceptionCode) {
		try {
			System.out.println("----exceptionCode----" + exceptionCode);
			return WebExceptionCode.valueOf(exceptionCode);
		} catch (Exception e) {
		}

		return SERVEREXCEPTION;
	}
}
