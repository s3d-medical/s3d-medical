package com.nhs.sms.home.control;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.nhs.core.web.ApplicationController;

/**
 * 
 * @Title: HomeController.java
 * @Package com.qihao.office.home.control
 * @Description: TODO
 * @author hxj
 * @date 2016-5-8 下午11:19:03
 * @version V1.0
 */
@Controller
@RequestMapping(value = "/")
public class HomeController extends ApplicationController {

    @Override
    @RequestMapping()
    public String execute(HttpServletRequest request, ModelMap model) {
        return "home/main";
    }

    @RequestMapping(value = "/index")
    public String index(HttpServletRequest request, ModelMap model) {
        return "home/login";
    }

    @RequestMapping(value = "/verify")
    public String verify(HttpServletRequest request, ModelMap model,
            @RequestParam(value = "token", defaultValue = "") String token,
            @RequestParam(value = "employeeId", defaultValue = "0") Integer employeeId) {
        return "home/login";
    }
}
