package com.nhs.shop.service.goods;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nhs.shop.dao.legend.shop.ProdDao;
import com.nhs.shop.entry.legend.shop.Prod;
import com.nhs.shop.entry.legend.shop.Sku;
import com.nhs.shop.service.goods.dto.CarriageItemDto;
import com.nhs.shop.service.goods.dto.GoodsTagDto;
import com.nhs.shop.service.goods.dto.PromotionDto;

/**
 * 商品标签处理服务
 * 
 * @since 20161106
 * @author wind.chen
 */
@Service
@Transactional
public class GoodsTagsService {

	@Autowired
	private GoodsPromoService goodPromotionService;

	@Autowired
	private GoodCarriageService goodCarriageService;
	
    @Autowired
    private ProdDao prodDao;
    
	/**
	 * 获取sku的标签.  如果没有就用prod的
	 * @param sku
	 * @param prod
	 * @return
	 */
	public GoodsTagDto getSkuProdDetailTag(Sku sku, Prod prod){
		GoodsTagDto tag = new GoodsTagDto();
		// sku费用
		PromotionDto promo = this.goodPromotionService.calSkuProdPromo(1.0, sku, prod, 2);
		this.fillReducedCashTag(tag, prod, promo);
		this.fillSubsidyTag(tag, prod, promo);
		
		boolean free = this.goodCarriageService.ifDefaultProdPostFree(prod);
		this.fillPostageFreeTag(tag, prod, free);
		return tag;
	}
	
	/**
	 * 获取sku的标签
	 * 计算推广费, 是否包邮标签.
	 * @param sku
	 * @param prod
	 * @param userId
	 * @return
	 */
	public GoodsTagDto getSkuProdDimTag(Sku sku, Prod prod, String userId){
		GoodsTagDto tag = new GoodsTagDto();
		// sku上的推广费
		PromotionDto promo = this.goodPromotionService.calSkuProdPromo(1.0, sku, prod, 2);
		this.fillReducedCashTag(tag, prod, promo);
		this.fillSubsidyTag(tag, prod, promo);
		
		Boolean free = this.goodCarriageService.ifDefaultProdPostFree(prod);
		this.fillPostageFreeTag(tag, prod, free);
		return tag;
	}

	/**
	 * 获取商品详细tag.
	 * 
	 * @param prod
	 * @param cityId 用户所在城市, 城市不同tag有可能不同.
	 * @return
	 */
	public GoodsTagDto getProdDetailTag(Prod prod, Integer userCityId) {
		GoodsTagDto tag = new GoodsTagDto();
		PromotionDto promo = this.goodPromotionService.calSkuProdPromo(1.0, null, prod, 2);
		this.fillReducedCashTag(tag, prod, promo);
		this.fillSubsidyTag(tag, prod, promo);
		
		CarriageItemDto item = this.goodCarriageService.calDefaultPostageByCity(prod, userCityId);
		this.fillPostageTag(tag, prod, item);
		return tag;
	}

	/**
	 * 获取商品默认的tag
	 */
	public GoodsTagDto getProdDimTag(Integer prodId) {
		Prod prod = this.prodDao.findOne(prodId);
		return this.getProdDimTag(prod, null);
	}
	
	/**
	 * 获取商品默认的tag
	 * 
	 * @param sku
	 * @param prod
	 * @param cityId
	 * @return
	 */
	public GoodsTagDto getProdDimTag(Prod prod) {
		return this.getProdDimTag(prod, null);
	}
	
	/**
	 * 获取商品默认的tag
	 * 
	 * @param prod
	 * @param userId   不为空, 将按照用户默认收货地址的城市进行计算(针对自定义模板的, 现在只是简单判断是否包邮.)
	 * @return
	 */
	public GoodsTagDto getProdDimTag(Prod prod, String userId) {
		GoodsTagDto tag = new GoodsTagDto();
		PromotionDto promo = this.goodPromotionService.calSkuProdPromo(1.0, null, prod, 2);
		this.fillReducedCashTag(tag, prod, promo);
		this.fillSubsidyTag(tag, prod, promo);
		
		boolean free = this.goodCarriageService.ifDefaultProdPostFree(prod);
		this.fillPostageFreeTag(tag, prod, free);
		return tag;
	}

	/**
	 * 立减
	 * 
	 * @param tag
	 * @param prod
	 * @param promo
	 */
	private void fillReducedCashTag(GoodsTagDto tag, Prod prod, PromotionDto promo) {
		// 计算补贴和立减
		if (promo.getReducedCash().doubleValue() > 0.0) {
			tag.setReducedCashTag("减");
			tag.setReducedCashDesc("购买立减{" + promo.getReducedCash().toString() + "}元");
			tag.setReducedCash(promo.getReducedCash());
		} else {
			tag.setReducedCashTag("");
			tag.setReducedCash(new BigDecimal("0.00"));
			tag.setReducedCashDesc("");
		}
	}

	/**
	 * 补贴
	 * @param tag
	 * @param prod
	 * @param promo
	 */
	private void fillSubsidyTag(GoodsTagDto tag, Prod prod, PromotionDto promo) {
		if (promo.getSubsidy().doubleValue() > 0.0) {
			tag.setSubsidyTag("送");
			tag.setSubsidyDesc("送{" + promo.getSubsidy().toString() + "}积分");
			tag.setSubsidy(promo.getSubsidy());
			tag.setSubsidyMoney(promo.getSubsidyMoney());
		} else {
			tag.setSubsidyTag("");
			tag.setSubsidyDesc("");
			tag.setSubsidy(new BigDecimal("0.00"));
			tag.setSubsidyMoney(new BigDecimal("0.00"));
		}
	}
	
	/**
	 * 
	 * @param tag
	 * @param prod
	 */
	private void fillPostageFreeTag(GoodsTagDto tag, Prod prod, boolean free) {
		if (free) {
			tag.setPostageTag("包邮");
			tag.setPostage("0.00");
			tag.setPostageDesc("包邮");
		} else {
			tag.setPostageTag("");
			tag.setPostage("0.00");
			tag.setPostageDesc("");
		}
	}
	
	/**
	 * 
	 * @param tag
	 * @param prod
	 * @param userCityId
	 */
	private void fillPostageTag(GoodsTagDto tag, Prod prod, CarriageItemDto item) {		
		if (item != null && item.getVal() != null && item.getVal().doubleValue() > 0.0) {
			tag.setPostageTag(item.getType().getDesc());
			tag.setPostage(item.getVal().toString());
			tag.setPostageDesc(item.getType().getDesc() + 
					":" + item.getVal().toString() + "元");
		} else {
			tag.setPostageTag("包邮");
			tag.setPostage("0.00");
			tag.setPostageDesc("包邮");
		}
	}

}
