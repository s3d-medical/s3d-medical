package com.nhs.shop.service.order;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.nhs.apiproxy.member.acc.datatype.CurrencyEnum;
import com.nhs.apiproxy.member.acc.service.AccountTransferService;
import com.nhs.core.common.NhsConstant;
import com.nhs.core.context.SysPropsFactory;
import com.nhs.core.orm.Page;
import com.nhs.core.utils.common.ArithUtils;
import com.nhs.core.utils.common.DateUtils;
import com.nhs.core.utils.common.RandomUtils;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.core.web.WebRequestException;
import com.nhs.shop.activity.dao.ActivitySchoolDao;
import com.nhs.shop.activity.entry.ActivitySchool;
import com.nhs.shop.dao.legend.service.O2oServiceOrderDao;
import com.nhs.shop.dao.legend.service.ServiceOrderDao;
import com.nhs.shop.dao.legend.shop.O2oShopDetailDao;
import com.nhs.shop.dao.legend.shop.ShopDetailDao;
import com.nhs.shop.entry.em.order.OrderCodeEnum;
import com.nhs.shop.entry.em.order.ServiceOrderOperateEnum;
import com.nhs.shop.entry.em.order.ServiceOrderStatusEnum;
import com.nhs.shop.entry.em.order.ShopOrderStatusEnum;
import com.nhs.shop.entry.em.shop.EmRebateStatus;
import com.nhs.shop.entry.em.shop.ShopStatusEnum;
import com.nhs.shop.entry.legend.service.O2oServiceOrder;
import com.nhs.shop.entry.legend.shop.O2oShopDetail;
import com.nhs.shop.entry.legend.shop.ShopDetail;
import com.nhs.shop.entry.legend.user.UsrDetail;
import com.nhs.shop.generator.OrderNumGenerator;
import com.nhs.shop.service.BaseOrderDto;
import com.nhs.shop.service.BaseOrderService;
import com.nhs.shop.service.order.dto.ActivityOrderDto;
import com.nhs.shop.service.order.dto.ServiceOrderDetailDto;
import com.nhs.shop.service.order.dto.ServiceOrderListDto;
import com.nhs.shop.service.rebate.O2oRebateService;
import com.nhs.shop.service.shop.CalO2oShopPromotionService;
import com.nhs.shop.service.system.SystemParameterService;
import com.nhs.user.dto.MemberDetailDto;
import com.nhs.user.service.MemberService;
import com.nhs.user.service.UserService;
import com.nhs.shop.ordercal.dao.OrderCalculationRuleDao;
import com.nhs.shop.ordercal.entity.OrderCalculationRule;
import com.nhs.shop.service.o2o.calculate.CalO2oPromotionService;

/**
 * o2o商家服务订单service
 * @Title: O2oServiceOrderService.java
 * @Package com.nhs.shop.service.order
 * @Description: TODO
 * @author Administrator
 * @date 2016年7月25日 下午2:44:10
 * @version V1.0
 */
@Service
public class O2oServiceOrderService extends BaseOrderService {

    private static Logger LOG = LoggerFactory.getLogger(O2oServiceOrderService.class);

    // 默认REBATE
    private static BigDecimal DEFAULT_REBATE = new BigDecimal("1.000");

    // 默认AD_FEE_RATE
    private static BigDecimal DEFAULT_AD_FEE_RATE = new BigDecimal("0.160");

    // contactPhone
    private static String CONTACT_PHONE_DELIMITER = "、";

    @Autowired
    private O2oServiceOrderDao o2oServiceOrderDao;

    @Autowired
    private ShopDetailDao shopDetailDao;

    @Autowired
    private ServiceOrderDao serviceOrderDao;

    @Autowired
    private O2oRebateService o2oRebateService;

    @Autowired
    private O2oShopDetailDao o2oShopDetailDao;

    @Autowired
    private SystemParameterService sysService;

    @Autowired
    private CalO2oShopPromotionService o2oPromotionService;

    @Autowired
    private UserService userService; // 用户服务

    @Autowired
    private AccountTransferService accountTransferService; // 划账服务

    @Autowired
    private ActivitySchoolDao activitySchoolDao;
	
	
	@Autowired
    private CalO2oPromotionService calO2oPromotionService;
    
    @Autowired
    private OrderCalculationRuleDao orderCalculationRuleDao;
    
    @Autowired
    private MemberService memberService;

    /**
     * @Title: saveO2oServiceOrder
     * @Description: 保存o2o商家服务订单
     * @param @param userId
     * @param @param shopId
     * @param @param totalAmount
     * @param @param platformType
     * @param @param consumeReduceType  // 1：选择消费立减 0：不选择加消费立减
     * @param @param couponMoney        
     * @param @param couponType         // 1：使用佰德券     0：不选择佰德券
     * @param @param token              // 用户登录身份
     * @param @return   
     * @return Map<String,Object> 
     * @author Administrator 2016年7月25日 
     * @author chushubin 2016年11月16日 
     * @throws
     */
    public Map<String, Object> saveO2oServiceOrder(String userId, Integer shopId, Double totalAmount,
            String platformType, int consumeReduceType, BigDecimal couponMoney, int couponType) {
        Assert.notNull(userId, "userId must not be null");
        Assert.hasLength(userId);

        UsrDetail usrDetail = this.userService.findUserById(userId);
        if (usrDetail == null) {
            throw new WebRequestException("user不存在");
        }
        if (LOG.isDebugEnabled()) {
            LOG.debug("usrDetail : " + usrDetail);
        }

        ShopDetail shop = shopDetailDao.findOne(shopId);
        if (shop == null) {
            throw new WebRequestException("商家不存在");
        }
        if (LOG.isDebugEnabled()) {
            LOG.debug("shop : " + shop);
        }
		
        
        MemberDetailDto memberDto = memberService.getUserDetailByUserId(userId);
        BigDecimal gold = new BigDecimal("0.00");
        if(memberDto != null){
        	gold = memberDto.getAccountByType(CurrencyEnum.CURRENCY_GOLD_COIN.getCurrency());
        }
       
		//抵用券
        if(couponType != 0){
        	if(gold.compareTo(couponMoney.multiply(new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE))) < 0){
        		throw new WebRequestException("抵用券数量不足");
        	}
        }

        O2oServiceOrder order = new O2oServiceOrder();
        // 生成orderNo
        String orderNo = OrderNumGenerator.getOrderNumber(usrDetail.getUserMobile(), OrderCodeEnum.O2O_SERVICE_ORDER);
        if (LOG.isDebugEnabled()) {
            LOG.debug("orderNo: " + orderNo);
        }
        order.setOrderNum(orderNo);
        order.setPlatformType(platformType);
        order.setShopId(shopId);
        order.setShopName(shop.getSiteName());
        order.setUserId(userId);
        order.setStatus(ServiceOrderStatusEnum.UNPAY.getStatus());
        order.setDeleteStatus(0);
        order.setCreateTime(new Date());
        if (shop.getAdFeeRate() == null) {
            shop.setAdFeeRate(new BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE));
        }
        if (shop.getAdFeeBasicRate() == null) {
            shop.setAdFeeBasicRate(new BigDecimal(NhsConstant.DEFAULT_AD_FEE_BASIC_RATE));
        }
        BigDecimal payAmount = BigDecimal.valueOf(totalAmount);
      
        order.setTotalAmount(BigDecimal.valueOf(totalAmount));
//        order.setPayAmount(payAmount);
        o2oPromotionService.calOrderAddPayAmount(order, shop, payAmount, couponMoney, consumeReduceType);
        order.setRebate(shop.getRebate());
        order.setAdFeeRate(shop.getAdFeeRate());
        order.setAdFeeBasicRate(shop.getAdFeeBasicRate());
        order.setCouponAmount(couponMoney);
        O2oServiceOrder newOrder = o2oServiceOrderDao.save(order);

        // 生成订单时暂时把个人账户的佰德券转冻结起来，支付成功后扣除，如果未支付，将给他释放冻结部分
        // 默认不使用佰德券，只有couponType==1时使用佰德券
        // if (couponType != 0) {
        if (couponType == 1) {
            // 预冻佰德券
            BigDecimal amount = couponMoney.multiply(new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE));
            this.accountTransferService.freezeGold(userId, orderNo, amount);
        }
        // 返回结果
        Map<String, Object> map = Maps.newHashMap();
        map.put("orderId", newOrder.getId());
        map.put("orderNum", orderNo);
        map.put("totalAmount",  order.getPayAmount());

        return map;
    }

    /**
     * 获取服务订单列表
     * @Title: getOrderList
     * @Description: TODO
     * @param @param userId
     * @param @param status
     * @param @param page
     * @param @return   
     * @return List<ServiceOrderListDto> 
     * @author Administrator 2016年7月25日 
     * @throws
     */
    public List<ServiceOrderDetailDto> getOrderList(String userId, Integer status, Page<Map<String, Object>> page) {
        List<ServiceOrderDetailDto> list = Lists.newArrayList();
        if (StringUtils.isBlank(userId)) {
            return list;
        }
        Page<Map<String, Object>> pageData = serviceOrderDao.getOrderList(userId, status, page);
        List<Map<String, Object>> result = pageData.getResult();
        for (Map<String, Object> map : result) {
            ServiceOrderDetailDto dto = this.orderMap2Dto(map);
            list.add(dto);
        }
        return list;
    }

    /**
     * @Title: orderMap2Dto
     * @Description: 将o2o订单由Map类型转换成ServiceOrderDetailDto类型
     * @param @param map
     * @param @return   
     * @return ServiceOrderDetailDto 
     * @author Robin.chu 2016年11月17日 
     * @throws
     */
    private ServiceOrderDetailDto orderMap2Dto(Map<String, Object> map) {
        ServiceOrderDetailDto dto = new ServiceOrderDetailDto();
        dto.setOrderId(StringHelper.objectToInt(map.get("id"), 0));
        dto.setOrderNum(StringHelper.objectToString(map.get("order_num"), ""));
        dto.setShopId(StringHelper.objectToInt(map.get("shop_id"), 0));
        dto.setRebate(StringHelper.objectToBigDecimal(map.get("rebate"), NhsConstant.DEFAULT_REBATE));
        ShopDetail shop = shopDetailDao.findOne(dto.getShopId());
        if (shop != null) {
            dto.setPic(buildImg(shop.getShopPic2()));
            dto.setShopName(shop.getSiteName());
            dto.setAddress(shop.getShopAddr());
        } else {
            shop = new ShopDetail();
        }
        BigDecimal totalmount = StringHelper.objectToBigDecimal(map.get("total_amount"), "").setScale(2,
                BigDecimal.ROUND_DOWN);

        BigDecimal payAmount = StringHelper.objectToBigDecimal(map.get("pay_amount"), "0.00").setScale(2,
                BigDecimal.ROUND_DOWN);

        dto.setTotalAmount(totalmount.doubleValue());
        dto.setPayAmountStr(payAmount.toString());
        dto.setTotalAmountStr(totalmount.toString());
        o2oPromotionService.calOrderDetailCoupon(dto, shop);
        dto.setSubsidy(totalmount.multiply(dto.getRebate()).setScale(2, BigDecimal.ROUND_DOWN).doubleValue());
        dto.setStatus(StringHelper.objectToInt(map.get("status"), 0));
        dto.setStatusName(ServiceOrderStatusEnum.desc(dto.getStatus()));
        dto.setCreateTime(DateUtils.date2Str((Date) map.get("create_time")));
        dto.setSubsidyStr(sysService.getSingleValueByType(NhsConstant.PARAM_PRESENT_SIGN)
                + sysService.getSingleValueByType(NhsConstant.PARAM_RMB_ICON) + dto.getSubsidy().toString());
        return dto;
    }

    /**
     * 获取订单详情
     * @Title: getOrderList
     * @Description: TODO
     * @param @param userId
     * @param @param status
     * @param @param page
     * @param @return   
     * @return List<OrderListDto> 
     * @author Administrator 2016年7月20日 
     * @throws
     */
    public ServiceOrderDetailDto getOrderDetail(String userId, Integer orderId) {
        O2oServiceOrder order = o2oServiceOrderDao.findOne(orderId);
        if (order == null) {
            throw new WebRequestException("订单不存在");
        }
        ServiceOrderDetailDto dto = this.orderEntity2Dto(order);
        return dto;
    }

    /**
     * @Title: orderEntity2Dto
     * @Description: TODO
     * @param @param order
     * @param @return   
     * @return ServiceOrderDetailDto 
     * @author chushubin 2016年11月17日 
     * @throws
     */
    private ServiceOrderDetailDto orderEntity2Dto(O2oServiceOrder order) {
        ServiceOrderDetailDto dto = new ServiceOrderDetailDto();
        dto.setOrderId(order.getId());
        dto.setOrderNum(order.getOrderNum());
        dto.setShopId(order.getShopId());
        dto.setStatus(order.getStatus());
        dto.setStatusName(ShopOrderStatusEnum.desc(dto.getStatus()));
        dto.setTotalAmount(order.getTotalAmount().doubleValue());
        dto.setTotalAmountStr(order.getTotalAmount().toString());
        dto.setPayAmountStr(
                order.getPayAmount() == null ? order.getTotalAmount().toString() : order.getPayAmount().toString());
        if (order.getRebate() != null) {
            dto.setSubsidy(new BigDecimal(dto.getPayAmountStr()).multiply(order.getRebate()).doubleValue());
            dto.setRebate(order.getRebate());
        } else {
            dto.setSubsidy(new BigDecimal(dto.getPayAmountStr()).doubleValue());
            dto.setRebate(new BigDecimal(NhsConstant.DEFAULT_REBATE));
        }
        dto.setSubsidyStr(sysService.getSingleValueByType(NhsConstant.PARAM_PRESENT_SIGN)
                + sysService.getSingleValueByType(NhsConstant.PARAM_RMB_ICON) + dto.getSubsidy());
        dto.setCreateTime(DateUtils.date2Str(order.getCreateTime()));
        dto.setConsumeTime(DateUtils.date2Str(order.getPayTime()));

        ShopDetail shop = shopDetailDao.findOne(order.getShopId());
        if (shop != null) {
            dto.setPic(buildImg(shop.getShopPic2()));
            dto.setShopName(shop.getSiteName());
            dto.setAddress(shop.getShopAddr());
        } else {
            shop = new ShopDetail();
        }
        if (order.getReduceAmount().compareTo(new BigDecimal("0")) > 0) {
            dto.setReduceAmount(
                    "-" + sysService.getSingleValueByType(NhsConstant.PARAM_RMB_ICON) + order.getReduceAmount());
        } else {
            dto.setReduceAmount("");
        }
        if (order.getCouponAmount().compareTo(new BigDecimal("0")) > 0) {
            dto.setCouponAmount(
                    "-" + sysService.getSingleValueByType(NhsConstant.PARAM_RMB_ICON) + order.getCouponAmount());
        } else {
            dto.setCouponAmount("");
        }
        o2oPromotionService.calOrderDetailCoupon(dto, shop);
        dto.setValidateCode(order.getValidateCode());
        dto.setCancelTime(DateUtils.date2Str(order.getCancelTime()));
        return dto;
    }

    /**
     * 订单操作
     * @Title: doOrderOperate
     * @Description: 取消订单(CANCEL)/删除订单(DELETE)
     * @param @param operate   
     * @return void 
     * @author Administrator 2016年7月22日
     * @author robin.chu 2016年11月17日
     * @throws
     */
    public void dealOrderOperate(String userId, Integer orderId, String operate) {

        O2oServiceOrder order = o2oServiceOrderDao.findOne(orderId);
        if (order == null) {
            throw new WebRequestException("订单不存在");
        }
        if (!order.getUserId().equals(userId)) {
            throw new WebRequestException("没有权限操作订单");
        }

        ServiceOrderOperateEnum e = ServiceOrderOperateEnum.getInstance(operate);
        if (e == null) {
            throw new WebRequestException("opearte只支持取消和删除");
        }
        switch (e) {
            case CANCEL: // 取消订单
                cancel(order);
                break;
            case DELETE: // 删除订单
                delete(order);
                break;
            default:
                throw new WebRequestException("opearte只支持取消和删除");
        }
    }

    /**
     * 取消订单
     * @Title: cancel
     * @Description: TODO
     * @param @param sub   
     * @return void 
     * @author Administrator 2016年7月22日 
     * @throws
     */
    private void cancel(O2oServiceOrder order) {
        // 只有未付款订单才能取消
        if (ServiceOrderStatusEnum.UNPAY.getStatus() != order.getStatus()) {
            throw new WebRequestException("只有未付款订单才能取消");
        }
        // 更新订单状态和信息
        order.setCancelTime(new Date());
        order.setStatus(ServiceOrderStatusEnum.CANCELD.getStatus()); // 取消状态
        o2oServiceOrderDao.saveAndFlush(order);

        // 解冻取消冻结的佰德券
        if (order.getCouponAmount().compareTo(new BigDecimal(0)) > 0) {
            // 说明有冻结的佰德券，需要解冻
            BigDecimal amount = order.getCouponAmount().multiply(new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE));
            this.accountTransferService.cancelGold(order.getUserId(), order.getOrderNum(), amount);
        }
    }

    /**
     * 删除订单
     * @Title: delete
     * @Description: TODO
     * @param @param sub   
     * @return void 
     * @author Administrator 2016年7月22日 
     * @throws
     */
    private void delete(O2oServiceOrder order) {
        order.setDeleteStatus(1);
        o2oServiceOrderDao.saveAndFlush(order);
    }

    /**
     * 获取订单支付金额
     * @Title: getOrderPayAmount
     * @Description: TODO
     * @param @param orderNum
     * @param @return   
     * @return double 
     * @author Administrator 2016年7月28日 
     * @throws
     */
    public double getOrderPayAmount(String orderNum) {
        O2oServiceOrder order = o2oServiceOrderDao.findO2oServiceOrderByOrderNum(orderNum);
        if (order == null) {
            throw new WebRequestException("订单不存在");
        }
        return order.getPayAmount().doubleValue();
    }

    /**
     * <p>Description:支付成功处理，如果有预冻的佰德券，那么将冻结的佰德券扣掉，如果没有冻结的佰德券，那么就不操作账户 
     *                TODO 这个就应该是余额宝（哪划算）支付的回调方法（成功支付的时候）</p>
     * @author Administrator 2016年7月28日 
     * @author robin.chu 2016年11月17日
     * @param orderNum
     * @param payAmount
     * @param payTypeName
     */
    @Override
    public void handleOrderPay(String orderNum, String payAmount, String payTypeName, int payType, String payNo) {
        O2oServiceOrder order = o2oServiceOrderDao.findO2oServiceOrderByOrderNum(orderNum);
        if (order == null) {
            throw new WebRequestException("订单不存在");
        }
        // TODO hxj 服务订单付款后，用户不需要点使用
        // 修改订单信息, 订单状态, 支付方式等.
        order.setStatus(ServiceOrderStatusEnum.UNCOMMENT.getStatus());
        order.setPayAmount(StringHelper.objectToBigDecimal(payAmount, "0"));
        order.setPayTime(new Date());
        order.setUpdateTime(new Date());
        order.setPayTypeName(payTypeName);
        order.setRebateStatus(EmRebateStatus.not_rebate.status);
        order.setValidateCode(RandomUtils.getOrderValidateCode(6));
        o2oServiceOrderDao.saveAndFlush(order);

        // 支付成功，直接扣除冻结的佰德券
        this.accountTransferService.commitGoldByRMB(order.getUserId(), orderNum, order.getCouponAmount());

        // TODO hxj 服务订单付款后就直接结算广告费
        if (LOG.isInfoEnabled()) {
            LOG.info("开始清算商家广告费");
        }
        try {
            if (order.getRebateStatus() == null || order.getRebateStatus() == EmRebateStatus.not_rebate.status) {
                o2oRebateService.saveRebate(order, new Date());
            }
        } catch (Exception e) {
            if (LOG.isErrorEnabled()) {
                LOG.error("处理订单支付失败. ", e);
            }
        }
    }

    /**
     * 
     * @Title: calOrderFee
     * @Desc: 
     * @author wind.chen 2016年12月2日 下午5:45:18
     * @throws
     */
    private void calOrderFee() {

    }

    /**
     * 计算用户应该解冻， 并被消费的佰德劵. 
     * @Title: calDeductCoupon
     * @Desc: 
     * @author wind.chen 2016年12月2日 下午5:42:50
     *
     * @throws
     */
    private void calPayedCouponOfBuyer() {

    }

    /**
     * 计算用户
     * @Title: calSubsidyOfBuyer
     * @Desc: 
     * @author wind.chen 2016年12月2日 下午5:44:15
     *
     * @throws
     */
    private void calSubsidyOfBuyer() {

    }

    @Override
    public void verifyOrder(String userId, String orderNum) {
        O2oServiceOrder order = o2oServiceOrderDao.findO2oServiceOrderByOrderNum(orderNum);
        if (order == null) {
            throw new WebRequestException("订单不存在");
        }
        if (!order.getUserId().equals(userId)) {
            throw new WebRequestException("无权限支付该订单");
        }
        if (order.getStatus() != ServiceOrderStatusEnum.UNPAY.getStatus()) {
            throw new WebRequestException("订单不是待付款状态");
        }
        // add by shiyang？
        // 校验 商家 状态
        ShopDetail shop = shopDetailDao.findOne(order.getShopId());
        if (shop != null && shop.getStatus().equals(ShopStatusEnum.NORMAL.value())) {
        } else {
            throw new WebRequestException("店铺状态异常");
        }
    }

    /**
     * 获取店铺服务订单列表
     * @Title: getStoreOrderList
     * @Description: TODO
     * @param @param shopId
     * @param @param status
     * @param @param page
     * @param @return   
     * @return List<ServiceOrderListDto> 
     * @author guangrong 2016年9月6日 
     * @throws
     */
    public List<ServiceOrderListDto> getO2oStoreOrderList(String shopId, Integer status,
            Page<Map<String, Object>> page) {
        List<ServiceOrderListDto> list = Lists.newArrayList();
        if (StringUtils.isBlank(shopId)) {
            return list;
        }
        Page<Map<String, Object>> pageData = serviceOrderDao.getStoreOrderList(shopId, status, page);
        List<Map<String, Object>> result = pageData.getResult();
        for (Map<String, Object> map : result) {
            ServiceOrderListDto dto = this.orderEntity2ListDto(map);
            list.add(dto);
        }
        return list;
    }

    /**
     * @Title: orderEntity2ListDto
     * @Description: TODO
     * @param @param map
     * @param @return   
     * @return ServiceOrderListDto 
     * @author chushubin 2016年11月17日 
     * @throws
     */
    private ServiceOrderListDto orderEntity2ListDto(Map<String, Object> map) {
        ServiceOrderListDto dto = new ServiceOrderListDto();
        dto.setOrderId(StringHelper.objectToInt(map.get("id"), 0));
        dto.setOrderNum(StringHelper.objectToString(map.get("order_num"), ""));
        dto.setShopId(StringHelper.objectToInt(map.get("shop_id"), 0));
        dto.setRebate(StringHelper.objectToBigDecimal(map.get("rebate"), NhsConstant.DEFAULT_REBATE));
        ShopDetail shop = shopDetailDao.findOne(dto.getShopId());
        if (shop != null) {
            dto.setPic(buildImg(shop.getShopPic2()));
            dto.setShopName(shop.getSiteName());
            dto.setAddress(shop.getShopAddr());
        }
        String userId = StringHelper.objectToString(map.get("user_id"), "");

        UsrDetail usrDetail = this.userService.findUserById(userId);
        if (usrDetail != null) {
            dto.setUserNickName(usrDetail.getNickName());
            String image = usrDetail.getPortraitPic();
            if (StringUtils.isNotBlank(image) && image.indexOf("http:") < 0) {
                image = SysPropsFactory.getProperty("imgServer") + "/" + image;
            }
            dto.setUserImg(image);
            dto.setUserId(userId);
        }
        String rmbIcon = sysService.getSingleValueByType(NhsConstant.PARAM_RMB_ICON);

        BigDecimal payAmount = StringHelper.objectToBigDecimal(map.get("total_amount"), "0.00");
        dto.setPayAmountStr(payAmount == null ? rmbIcon + "0.00"
                : rmbIcon + payAmount.setScale(2, BigDecimal.ROUND_DOWN).toString());

        dto.setSubsidyStr(SysPropsFactory.getProperty(NhsConstant.SYS_COUPON_LABEL));
        dto.setStatus(StringHelper.objectToInt(map.get("status"), 0));
        dto.setStatusName(ServiceOrderStatusEnum.desc(dto.getStatus()));
        dto.setCreateTime(DateUtils.date2Str((Date) map.get("create_time")));
        return dto;
    }

    /**
     * 修改O2o店铺信息
     * @Title: updateO2oStoreOrderList
     * @Description: TODO
     * @param @param shopId
     * @param @param status
     * @param @param page
     * @param @return   
     * @return List<ServiceOrderListDto> 
     * @author guangrong 2016年9月6日 
     * @throws
     */
    @Transactional
    public void updateO2oStoreInfo(String perCost, String contactPhone, String smsMobile, String storeDesc,
            String installation, String serviceTime, String story, int shopId) {

        ShopDetail shopDetail = shopDetailDao.findOne(shopId);

        if (shopDetail != null) {
            String[] contactPhones = contactPhone.split(CONTACT_PHONE_DELIMITER);
            if (contactPhones != null && contactPhones.length > 0) {
                shopDetail.setContactTel(contactPhones[0]);
            }
            if (contactPhones != null && contactPhones.length > 1) {
                shopDetail.setContactTelSecond(contactPhones[1]);
            } else {
                shopDetail.setContactTelSecond("");
            }
            shopDetail.setDetailDesc(storeDesc);
            shopDetail.setModifyDate(new Date());
            shopDetailDao.save(shopDetail);

            O2oShopDetail o2oShopDetail = o2oShopDetailDao.findO2oShopDetailByshopId(shopId);
            if (o2oShopDetail == null) {
                o2oShopDetail = new O2oShopDetail();
                o2oShopDetail.setShopId(shopId);
                o2oShopDetail.setCreateTime(new Date());
                o2oShopDetail.setRebate(DEFAULT_REBATE);
                o2oShopDetail.setAdfeeratel(DEFAULT_AD_FEE_RATE);
            }
            o2oShopDetail.setPerCost(new BigDecimal(perCost));
            o2oShopDetail.setSmsPhone(smsMobile);
            o2oShopDetail.setInstallation(installation);
            o2oShopDetail.setStory(story);
            o2oShopDetail.setServiceTime(serviceTime);
            o2oShopDetail.setUpdateTime(new Date());
            o2oShopDetailDao.save(o2oShopDetail);

        }

    }

    /**
     * 获取参加活动的订单
     * @Title: getActivityO2oStoreOrderList
     * @Description: TODO
     * @param @param shopId
     * @param @param status
     * @param @param page
     * @param @return   
     * @return List<ServiceOrderListDto> 
     * @author guangrong 2016年9月6日 
     * @throws
     */
    public List<ActivityOrderDto> getStoreOrderSuccessList(String startTime, String endTime) {
        List<ActivityOrderDto> list = Lists.newArrayList();

        List<Map<String, Object>> result = serviceOrderDao.getStoreOrderSuccessList(startTime, endTime);
        for (Map<String, Object> map : result) {
            ActivityOrderDto dto = new ActivityOrderDto();
            dto.setUserId(StringHelper.objectToString(map.get("user_id"), ""));

            UsrDetail userDetail = userService.findUserById(dto.getUserId());
            if (userDetail == null) {
                continue;
            }

            String userMobile = userDetail.getUserMobile();

            List<ActivitySchool> activitySchoolList = activitySchoolDao.findAllActivitySchool();

            List<String> inviteeUserMobileList = new ArrayList<>();

            if (activitySchoolList != null && activitySchoolList.size() > 0) {
                for (ActivitySchool activitySchool : activitySchoolList) {
                    inviteeUserMobileList.add(activitySchool.getInviteeUserMobile());
                }
            }

            if (inviteeUserMobileList.contains(userMobile)) {
                continue;
            }

            dto.setOrderId(StringHelper.objectToInt(map.get("id"), 0));
            dto.setOrderNum(StringHelper.objectToString(map.get("order_num"), ""));

            BigDecimal payAmount = StringHelper.objectToBigDecimal(map.get("pay_amount"), "");
            dto.setPayAmountStr(payAmount == null ? "0.00" : payAmount.setScale(2, BigDecimal.ROUND_DOWN).toString());
            Date payTime = (Date) map.get("pay_time");
            dto.setPayTimeStr(DateUtils.date2Str(payTime));
            // 商家补贴暂时设置的是默认100%
            // dto.setSubsidyStr(payAmount == null ? "0.00" : payAmount.setScale(2,
            // BigDecimal.ROUND_DOWN).toString());
            list.add(dto);
        }
        return list;
    }

    /**
     * @Title: getValidateCode
     * @Description: 获取o2o服务订单验证码，验证码在那个接口中生成的呢？
     * @param @param orderNum
     * @param @return   
     * @return String 
     * @author chushubin 2016年11月16日 
     * @throws
     */
    public String getValidateCode(String orderNo) {
        O2oServiceOrder sub = o2oServiceOrderDao.findO2oServiceOrderByOrderNum(orderNo);
        if (sub == null) {
            throw new WebRequestException("订单不存在");
        }
        String validateCode = sub.getValidateCode();
        return validateCode == null ? "" : validateCode;
    }
    
    
    /**
     * 保存o2o商家服务订单(v1.9.3 新规则计算)
     * @Title: saveO2oServiceOrder
     * @Description: TODO
     * @param @param userId
     * @param @param shopId
     * @param @param totalAmount   
     * @return void 
     * @author Administrator 2016年7月25日 
     * @throws
     */
    public Map<String, Object> saveO2oServiceOrder(String userId, Integer shopId, Double totalAmount,
            String platformType, int consumeReduceType, BigDecimal couponMoney,int couponType,int discountBeyond,BigDecimal discountBeyondMoney) {
    	UsrDetail user = this.userService.findUserById(userId);
        if (user == null) {
            throw new WebRequestException("userId不存在");
        }

        ShopDetail shop = shopDetailDao.findOne(shopId);
        if (shop == null) {
            throw new WebRequestException("商家不存在");
        }
        
        //抵用券
        couponMoney = new BigDecimal("0.00"); //不适用app传的抵用券价格，自己算
//        if(couponType != 0){
//        	if(user.getGold().compareTo(couponMoney) < 0){
//        		throw new WebRequestException("抵用券数量不足");
//        	}
//        }
        
        if(discountBeyond != 0){
        	if(discountBeyondMoney.compareTo(new BigDecimal(totalAmount).multiply(new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE))) > 0){
        		throw new WebRequestException("不参与折扣的金额大于订单总金额");
        	}
        }

        O2oServiceOrder order = new O2oServiceOrder();
        String orderNum = OrderNumGenerator.getOrderNumber(user.getUserMobile(), OrderCodeEnum.O2O_SERVICE_ORDER);
        order.setOrderNum(orderNum);
        order.setPlatformType(platformType);
        order.setShopId(shopId);
        order.setShopName(shop.getSiteName());
        order.setUserId(userId);
        order.setStatus(ServiceOrderStatusEnum.UNPAY.getStatus());
        order.setDeleteStatus(0);
        order.setCreateTime(new Date());
        BigDecimal payAmount = BigDecimal.valueOf(totalAmount);
      
        order.setTotalAmount(BigDecimal.valueOf(totalAmount));
        
        order.setDiscountBeyondMoney(discountBeyondMoney);
        
        
        calO2oPromotionService.calOrderAddPayAmount(order, shop, payAmount, couponMoney, consumeReduceType);
        
        if(couponType != 0){
        	MemberDetailDto memberDto = memberService.getUserDetailByUserId(userId);
            BigDecimal gold = new BigDecimal("0.00");
            if(memberDto != null){
            	gold = memberDto.getAccountByType(CurrencyEnum.CURRENCY_GOLD_COIN.getCurrency());
            }
	        if(gold.compareTo(order.getPayAmount()) >= 0){
	        	couponMoney = order.getPayAmount();
	        	order.setPayAmount(new BigDecimal("0.00"));
	        }else{
	        	couponMoney = gold;
	        	order.setPayAmount(ArithUtils.sub2(order.getPayAmount(), couponMoney, 2, BigDecimal.ROUND_DOWN));
	        }
        }
        
        order.setRebate(shop.getRebate());
		order.setAdFeeRate(shop.getAdFeeRate());
		order.setAdFeeBasicRate(shop.getAdFeeBasicRate());
		order.setCouponAmount(couponMoney);
		
		if(order.getPayAmount().compareTo(BigDecimal.valueOf(0)) < 0){
			throw new WebRequestException("金额计算有误！");
		}
		
        O2oServiceOrder newOrder = o2oServiceOrderDao.save(order);
        
        //TODO 暂时先注释，走老规则，以后确认走新规则时会放开
       /* OrderCalculationRule orderCalculationRule = new OrderCalculationRule();
        orderCalculationRule.setOrderNum(orderNum);
        orderCalculationRule.setOrderType("o2o");
        orderCalculationRule.setRuleType(NhsConstant.SYS_VERSION_V193);
        
        orderCalculationRuleDao.save(orderCalculationRule);*/
        
        //生成订单时暂时把个人账户的佰德券转冻结起来，支付成功后扣除，如果未支付，将给他释放冻结部分
        if(couponType != 0){
        	 BigDecimal amount = couponMoney.multiply(new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE));
             this.accountTransferService.freezeGold(userId, orderNum, amount);
//	        boolean flag = userAccountService.goldFreeze(couponMoney.multiply(new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE)), userId);
//	        if(!flag){
//	        	//个人账户抵用券余额不足
//	        	throw new WebRequestException("抵用券数量不足");
//	        }
        }
        // 返回结果
        Map<String, Object> map = Maps.newHashMap();
        map.put("orderId", newOrder.getId());
        map.put("orderNum", orderNum);
        map.put("totalAmount", order.getPayAmount());
        return map;
    }
    
    
    /**
     * 获取服务订单列表(v1.9.3计算规则变化)
     * @Title: getOrderList
     * @Description: TODO
     * @param @param userId
     * @param @param status
     * @param @param page
     * @param @return   
     * @return List<ServiceOrderListDto> 
     * @author Administrator 2016年7月25日 
     * @throws
     */
    public List<ServiceOrderDetailDto> getServiceOrderList(String userId, Integer status, Page<Map<String, Object>> page) {
        List<ServiceOrderDetailDto> list = Lists.newArrayList();
        if (StringUtils.isBlank(userId)) {
            return list;
        }
        Page<Map<String, Object>> pageData = serviceOrderDao.getOrderList(userId, status, page);
        List<Map<String, Object>> result = pageData.getResult();
        for (Map<String, Object> map : result) {
        	ServiceOrderDetailDto dto = new ServiceOrderDetailDto();
            dto.setOrderId(StringHelper.objectToInt(map.get("id"), 0));
            dto.setOrderNum(StringHelper.objectToString(map.get("order_num"), ""));
            dto.setShopId(StringHelper.objectToInt(map.get("shop_id"), 0));
            dto.setRebate(StringHelper.objectToBigDecimal(map.get("rebate"), NhsConstant.DEFAULT_REBATE));
            dto.setShopDiscountRate(StringHelper.objectToString(map.get("shop_discount_rate"), NhsConstant.DEFAULT_SHOP_DISCOUNT_RATE_O2O));
            ShopDetail shop = shopDetailDao.findOne(dto.getShopId());
            if (shop != null) {
                dto.setPic(buildImg(shop.getShopPic2()));
                dto.setShopName(shop.getSiteName());
                dto.setAddress(shop.getShopAddr());
            }else{
            	shop = new ShopDetail();
            }
            BigDecimal totalmount = StringHelper.objectToBigDecimal(map.get("total_amount"), "").setScale(2,
                    BigDecimal.ROUND_DOWN);
            
            BigDecimal payAmount = StringHelper.objectToBigDecimal(map.get("pay_amount"), "0.00").setScale(2,
                    BigDecimal.ROUND_DOWN);

            dto.setTotalAmount(totalmount.doubleValue());
            dto.setPayAmountStr(payAmount.toString());
            dto.setTotalAmountStr(totalmount.toString());
            calO2oPromotionService.calOrderDetailCoupon(dto,shop);
            dto.setSubsidy(totalmount.multiply(dto.getRebate()).setScale(2, BigDecimal.ROUND_DOWN).doubleValue());
            dto.setStatus(StringHelper.objectToInt(map.get("status"), 0));
            dto.setStatusName(ServiceOrderStatusEnum.desc(dto.getStatus()));
            dto.setCreateTime(DateUtils.date2Str((Date) map.get("create_time")));
            dto.setSubsidyStr(sysService.getSingleValueByType(NhsConstant.PARAM_PRESENT_SIGN)
                    + sysService.getSingleValueByType(NhsConstant.PARAM_RMB_ICON) + dto.getSubsidy().toString());
            list.add(dto);
        }
        return list;
    }
    
  
    /**
     * 获取订单详情(v1.9.3计算规则变化)
     * @Title: getOrderList
     * @Description: TODO
     * @param @param userId
     * @param @param status
     * @param @param page
     * @param @return   
     * @return List<OrderListDto> 
     * @author Administrator 2016年7月20日 
     * @throws
     */
    public ServiceOrderDetailDto getServiceOrderDetail(String userId, Integer orderId) {
        O2oServiceOrder sub = o2oServiceOrderDao.findOne(orderId);
        if (sub == null) {
            throw new WebRequestException("订单不存在");
        }
        ServiceOrderDetailDto dto = new ServiceOrderDetailDto();
        dto.setOrderId(sub.getId());
        dto.setOrderNum(sub.getOrderNum());
        dto.setShopId(sub.getShopId());
        dto.setStatus(sub.getStatus());
        dto.setStatusName(ShopOrderStatusEnum.desc(dto.getStatus()));
        dto.setTotalAmount(sub.getTotalAmount().doubleValue());
        dto.setTotalAmountStr(sub.getTotalAmount().toString());
        dto.setPayAmountStr(sub.getPayAmount() == null ? sub.getTotalAmount().toString() : sub.getPayAmount().toString());
        if (sub.getRebate() != null) {
            dto.setSubsidy(new BigDecimal(dto.getPayAmountStr()).multiply(sub.getRebate()).doubleValue());
            dto.setRebate(sub.getRebate());
        }else{
        	dto.setSubsidy(new BigDecimal(dto.getPayAmountStr()).doubleValue());
        	dto.setRebate(new BigDecimal(NhsConstant.DEFAULT_REBATE));
        }
        dto.setSubsidyStr(sysService.getSingleValueByType(NhsConstant.PARAM_PRESENT_SIGN)
                + sysService.getSingleValueByType(NhsConstant.PARAM_RMB_ICON) + dto.getSubsidy());
        dto.setCreateTime(DateUtils.date2Str(sub.getCreateTime()));
        dto.setConsumeTime(DateUtils.date2Str(sub.getPayTime()));
        
        ShopDetail shop = shopDetailDao.findOne(sub.getShopId());
        if (shop != null) {
            dto.setPic(buildImg(shop.getShopPic2()));
            dto.setShopName(shop.getSiteName());
            dto.setAddress(shop.getShopAddr());
        }else{
        	shop = new ShopDetail();
        }
        if(sub.getReduceAmount().compareTo(new BigDecimal("0")) > 0){
        	dto.setReduceAmount("-"+sysService.getSingleValueByType(NhsConstant.PARAM_RMB_ICON)+sub.getReduceAmount());
        }else{
        	dto.setReduceAmount("");
        }
        if(sub.getCouponAmount().compareTo(new BigDecimal("0")) > 0){
        	dto.setCouponAmount("-"+sysService.getSingleValueByType(NhsConstant.PARAM_RMB_ICON)+sub.getCouponAmount());
        }else{
        	dto.setCouponAmount("");
        }
        if(sub.getShopDiscountMoney().compareTo(new BigDecimal("0")) > 0){
        	dto.setShopDiscountMoney("-"+sysService.getSingleValueByType(NhsConstant.PARAM_RMB_ICON)+sub.getShopDiscountMoney());
        }else{
        	dto.setShopDiscountMoney("");
        }
        dto.setShopDiscountRate(shop.getShopDiscountRate().toString());
        calO2oPromotionService.calOrderDetailCoupon(dto,shop);
        dto.setValidateCode(sub.getValidateCode());
        dto.setCancelTime(DateUtils.date2Str(sub.getCancelTime()));
        return dto;
    }

	@Override
	public BaseOrderDto getBaseOrderDto(String orderNum) {
		// TODO Auto-generated method stub
		return null;
	}
}
