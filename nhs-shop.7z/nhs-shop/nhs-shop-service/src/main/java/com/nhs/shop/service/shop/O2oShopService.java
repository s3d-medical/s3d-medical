package com.nhs.shop.service.shop;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.nhs.core.common.NhsConstant;
import com.nhs.core.context.SysPropsFactory;
import com.nhs.core.orm.Page;
import com.nhs.core.utils.common.ArithUtils;
import com.nhs.core.utils.common.DateUtils;
import com.nhs.core.utils.common.FormatUtils;
import com.nhs.core.utils.common.ImageUtils;
import com.nhs.core.utils.common.JsonUtils;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.core.web.WebRequestException;
import com.nhs.shop.dao.legend.pay.PayDao;
import com.nhs.shop.dao.legend.recommend.VitLogDao;
import com.nhs.shop.dao.legend.recommend.VitLogSaveDao;
import com.nhs.shop.dao.legend.region.AreasDao;
import com.nhs.shop.dao.legend.region.CityDao;
import com.nhs.shop.dao.legend.region.ProvincesDao;
import com.nhs.shop.dao.legend.service.O2oCategoryDao;
import com.nhs.shop.dao.legend.service.O2oServiceOrderDao;
import com.nhs.shop.dao.legend.shop.CategoryDao;
import com.nhs.shop.dao.legend.shop.CheckShopDao;
import com.nhs.shop.dao.legend.shop.FavoriteDao;
import com.nhs.shop.dao.legend.shop.FavoriteShopDao;
import com.nhs.shop.dao.legend.shop.O2oShopDetailDao;
import com.nhs.shop.dao.legend.shop.O2oShopPhotosDao;
import com.nhs.shop.dao.legend.shop.ProdDao;
import com.nhs.shop.dao.legend.shop.ShopAuditDao;
import com.nhs.shop.dao.legend.shop.ShopCompanyDetailDao;
import com.nhs.shop.dao.legend.shop.ShopDetailDao;
import com.nhs.shop.dao.legend.user.RoleDao;
import com.nhs.shop.dao.legend.user.UsrRoleDao;
import com.nhs.shop.entry.em.order.PayRecordStatusEnum;
import com.nhs.shop.entry.em.shop.ShopOPstatusEnum;
import com.nhs.shop.entry.em.shop.ShopStatusEnum;
import com.nhs.shop.entry.em.shop.ShopTransferEnum;
import com.nhs.shop.entry.legend.region.Areas;
import com.nhs.shop.entry.legend.region.City;
import com.nhs.shop.entry.legend.region.Provinces;
import com.nhs.shop.entry.legend.service.O2oCategory;
import com.nhs.shop.entry.legend.shop.Category;
import com.nhs.shop.entry.legend.shop.Favorite;
import com.nhs.shop.entry.legend.shop.FavoriteShop;
import com.nhs.shop.entry.legend.shop.O2oShopDetail;
import com.nhs.shop.entry.legend.shop.O2oShopPhotos;
import com.nhs.shop.entry.legend.shop.ShopAudit;
import com.nhs.shop.entry.legend.shop.ShopCompanyDetail;
import com.nhs.shop.entry.legend.shop.ShopDetail;
import com.nhs.shop.entry.legend.shop.VitLog;
import com.nhs.shop.entry.legend.user.Role;
import com.nhs.shop.entry.legend.user.UsrDetail;
import com.nhs.shop.entry.legend.user.UsrRole;
import com.nhs.shop.service.BaseService;
import com.nhs.shop.service.o2o.calculate.CalO2oPromotionService;
import com.nhs.shop.service.o2oshop.comment.O2oShopCommentService;
import com.nhs.shop.service.o2oshop.comment.dto.O2oShopCommentDto;
import com.nhs.shop.service.shop.dto.O2oCategoryDto;
import com.nhs.shop.service.shop.dto.O2oCategorySubDto;
import com.nhs.shop.service.shop.dto.O2oShopDetailDto;
import com.nhs.shop.service.shop.dto.ShopDto;
import com.nhs.shop.service.shop.dto.ShopPhotosDto;
import com.nhs.shop.service.system.SystemParameterService;
import com.nhs.shop.util.BasicConstant;
import com.nhs.user.service.UserService;

/**
 * O2o商家service
 * @Title: O2oShopService.java
 * @Package com.nhs.shop.service.goods
 * @Description: TODO
 * @author Cary
 * @date 2016年8月28日 下午7:42:18
 * @version V1.0
 */
@Service
@Transactional
public class O2oShopService extends BaseService {

    public final static List<String> WEEKLABELS = Lists.newArrayList("星期一", "星期二", "星期三", "星期四", "星期五", "星期六", "星期日");
    public final static List<String> YEARLABELS = Lists.newArrayList("1", "2", "3", "4", "5", "6", "7", "8", "9", "10",
            "11", "12");

    @Autowired
    private O2oShopDetailDao o2oShopDetailDao;

    @Autowired
    private O2oShopPhotosDao o2oShopPhotosDao;

    @Autowired
    private ProvincesDao provincesDao;

    @Autowired
    private CityDao cityDao;

    @Autowired
    private AreasDao areasDao;

    @Autowired
    private ShopDetailDao shopDetailDao;

    @Autowired
    private CategoryDao categoryDao;

    @Autowired
    private O2oCategoryDao o2oCategoryDao;

    @Autowired
    private CheckShopDao checkShopDao;

    @Autowired
    private UserService userService;

    @Autowired
    private ShopCompanyDetailDao shopCompanyDetailDao;

    @Autowired
    private O2oServiceOrderDao o2oServiceOrderDao;

    @Autowired
    private RoleDao roleDao;

    @Autowired
    private UsrRoleDao usrRoleDao;

    @Autowired
    private VitLogDao vitLogDao;

    @Autowired
    private ProdDao prodDao;

    @Autowired
    private VitLogSaveDao vitLogSaveDao;

    @Autowired
    private O2oShopCommentService shopCommentService;

    @Autowired
    private SystemParameterService sysService;

    @Autowired
    private FavoriteShopDao favoriteShopDao;

    @Autowired
    private FavoriteDao favoriteDao;
    
    @Autowired
    private PayDao payDao;
    
    @Autowired
    private ShopAuditDao shopAuditDao;
	
	@Autowired
    private CalO2oShopPromotionService calO2oShopPromotionService;
    
    @Autowired
    private CalO2oPromotionService calO2oPromotionService;
    


    /**
    * 商家详情
    * @Title: getShopDetail
    * @Description: TODO
    * @param @param shopId
    * @param @return   
    * @return Map<String,Object> 
    * @author liangdanhua 2016年8月27日
    * @throws
    */

    public O2oShopDetailDto getO2oShopDetail(Integer shopId, String userId) {
        O2oShopDetailDto osdd = new O2oShopDetailDto();
        ShopDetail shop = shopDetailDao.findOne(shopId);
        if (shop == null) {
            throw new WebRequestException("商家不存在");
        }
        // 此部分逻辑来自shopservice.getShopDetail() begin
        Map<Integer, Areas> areaMap = initAreaMap();
        Map<Integer, O2oCategory> categoryMap = initO2oCategoryMap();
        osdd.setShopId(shop.getShopId());
        osdd.setBrief(shop.getDetailDesc());
        osdd.setShopTitle(shop.getSiteName());
        osdd.setAddress(shop.getShopAddr() == null ? "" : shop.getShopAddr());
        osdd.setStarNum(5); // 先写死5个星，后面在改
        osdd.setPic(this.buildImg(shop.getShopPic2()));
        osdd.setCategoryId(shop.getCategoryId());
        if (shop.getConsumePer() != null) {
            osdd.setConsumePer(shop.getConsumePer()); // 人均消费
        }

        Areas area = areaMap.get(shop.getAreaid());
        if (area != null) {
            osdd.setArea(area.getArea());
        }
        O2oCategory category = categoryMap.get(shop.getCategoryId());
        if (category != null) {
            osdd.setCategory(category.getName());
        }

        if (StringUtils.isNotBlank(shop.getContactTel())) {
            osdd.setMobile(shop.getContactTel() == null ? "" : shop.getContactTel());
        }
        if (StringUtils.isNotBlank(shop.getContactTelSecond())) {
            osdd.setMobile((shop.getContactTel() == null ? "" : shop.getContactTel()) + "、"
                    + (shop.getContactTelSecond() == null ? "" : shop.getContactTelSecond()));
        }
        osdd.setTasteScore(9.0);
        osdd.setEnvScore(9.1);
        osdd.setServiceScore(9.0);

        osdd.setLat(shop.getLat());
        osdd.setLng(shop.getLng());
        // 此部分逻辑来自shopservice.getShopDetail() end

        // 获取店铺所有订单数量
        long totalOrderNum = o2oServiceOrderDao.countByShopIdAndStatus(shop.getShopId());
        osdd.setTotalOrderNum(String.valueOf(totalOrderNum));

//        if(shop.getAdFeeRate() == null){
//        	shop.setAdFeeRate(new BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE));
//        }
//        if(shop.getAdFeeBasicRate() == null){
//        	shop.setAdFeeBasicRate(new BigDecimal(NhsConstant.DEFAULT_AD_FEE_BASIC_RATE));
//        }
//        //商家推广费率<=10%时，按照之前规则赠送给用户佰德钻；商家推广费率>10%时，超出比例部分做立减
//        if(shop.getAdFeeRate().compareTo(new BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE_CRITICAL)) > 0){
//        	osdd.setReduce(ArithUtils.sub2(shop.getAdFeeRate(), new BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE_CRITICAL),3,BigDecimal.ROUND_DOWN).toString());
//        	shop.setRebate(new BigDecimal(NhsConstant.DEFAULT_REBATE));
//        	osdd.setDiscount(SysPropsFactory.getProperty(NhsConstant.SYS_CONSUME_REDUCE_LABEL));
//        }else{
//        	osdd.setReduce("");
//        	osdd.setDiscount("");
//        	shop.setRebate(ArithUtils.div2(shop.getAdFeeRate(), shop.getAdFeeBasicRate(), 3,BigDecimal.ROUND_DOWN));
//        }
//        osdd.setCoupon(SysPropsFactory.getProperty(NhsConstant.SYS_COUPON_LABEL));
//        osdd.setSubsidy(shop.getRebate().multiply(new BigDecimal("100")).setScale(0, BigDecimal.ROUND_DOWN) + "%");
//        osdd.setSubsidyStr(sysService.getSingleValueByType(NhsConstant.PARAM_PRESENT_SIGN) + osdd.getSubsidy());
        
        calO2oShopPromotionService.calShopDetailCoupon(osdd, shop);
        

        // 店铺配置 信息

        O2oShopDetail o2oShopDetail2 = o2oShopDetailDao.findO2oShopDetailByshopId(shopId);

        if (o2oShopDetail2 != null) {
            osdd.setConsumePer(o2oShopDetail2.getPerCost() == null ? 0 : o2oShopDetail2.getPerCost().intValue());
            osdd.setSmsPhone(o2oShopDetail2.getSmsPhone());
            osdd.setServiceTime(o2oShopDetail2.getServiceTime());
            osdd.setInstallation(o2oShopDetail2.getInstallation());
            osdd.setStory(o2oShopDetail2.getStory());
        }

        List<O2oShopPhotos> o2oShopPhotos = o2oShopPhotosDao.findO2oShopPhotosByshopId(shopId);
        for (O2oShopPhotos op : o2oShopPhotos) {
            op.setPath(buildImg(StringHelper.objectToString(op.getPath(), "")));
        }

        // 环境图片
        List<O2oShopPhotos> envPics = new ArrayList<O2oShopPhotos>();
        // 特色图片
        List<O2oShopPhotos> spePics = new ArrayList<O2oShopPhotos>();
        // 活动图片
        List<O2oShopPhotos> actPics = new ArrayList<O2oShopPhotos>();

        for (O2oShopPhotos ospt : o2oShopPhotos) {
            // 获取图片的长与宽
            Map<String, String> map = ImageUtils.getImageWidthAndHeight(ospt.getPath());
            ospt.setWidth(map.get("width"));
            ospt.setHeight(map.get("height"));
            int type = ospt.getType();
            if (type == BasicConstant.O2O_SHOP_PCI_ENV) {
                envPics.add(ospt);
            } else if (type == BasicConstant.O2O_SHOP_PCI_SPE) {
                spePics.add(ospt);
            } else if (type == BasicConstant.O2O_SHOP_PCI_ACT) {
                ospt.setWidth(map.get("width"));
                ospt.setHeight(map.get("height"));
                actPics.add(ospt);

            }
        }
        // buildImg(StringHelper.objectToString(map.get("pic"), ""))
        osdd.setPhotos(o2oShopPhotos.size());
        osdd.setEnvPics(envPics);
        osdd.setActPics(actPics);
        osdd.setSpePics(spePics);
        
        // 获取评价列表 - 3条 .评价显示规则：好评度高（优先级1），图片多（优先级2），评价内容多（优先级3）
        List<O2oShopCommentDto> dtoList = shopCommentService.getShopCommentListForShopDetail(shopId);
        if (dtoList != null) {
            if (dtoList.size() < 3) {
                dtoList = shopCommentService.getShopCommentListForShopDetailAll(shopId);
            }
        }
        osdd.setCommentList(dtoList);
        long countAll = shopCommentService.countByType(shopId, 0);
        osdd.setCommentNum((int) countAll);
        // 获取商家平均分数
        String average = shopCommentService.getShopAveage(shopId);
        osdd.setAverage(average);
        List<FavoriteShop> favoriteShops = favoriteShopDao.findByShopIdAndUserId(shopId, userId);
        if (favoriteShops != null) {
            osdd.setCollection(favoriteShops.size() + "");
        }
        return osdd;
    }

    /**
     * 
     * @Title: 保存企业信息（主方法）
     * @Description: TODO
     * @param @param shopCompanyDetail
     * @param @return   
     * @return Boolean 
     * @author zhujun 2016年8月30日 
     * @throws
     */
    public String saveCertificate(ShopCompanyDetail newCompanyDetail) {
        ShopDetail shopDetail = shopDetailDao.findShopDetail(newCompanyDetail.getUserId());
        ShopCompanyDetail oldCompanyDetail = shopCompanyDetailDao.findShopCompanyDetailByShopId(shopDetail.getShopId());
        if (oldCompanyDetail == null) {
            return this.saveCertificateInfo(shopDetail, newCompanyDetail);
        } else {
            return this.updateCertificateInfo(newCompanyDetail, oldCompanyDetail);
        }
    }

    /**
     * 
     * @Title: 保存企业信息
     * @Description: TODO
     * @param @param companyDetail
     * @param @return   
     * @return String 
     * @author zhujun 2016年8月31日 
     * @throws
     */

    public String saveCertificateInfo(ShopDetail shopDetail, ShopCompanyDetail newCompanyDetail) {
        String flag = "";
        newCompanyDetail.setShopId(shopDetail.getShopId());
        ShopCompanyDetail shopCompanyDetail = shopCompanyDetailDao.save(newCompanyDetail);
        if (shopCompanyDetail.getId() == newCompanyDetail.getId()) {
            flag = "1";
        } else {
            flag = "0";
        }
        return flag;
    }

    /**
     * 
     * @Title: 更新企业信息
     * @Description: TODO
     * @param @param oldshopCompanyDetail
     * @param @param newcompanyDetail
     * @param @return   
     * @return String 
     * @author zhujun 2016年8月31日 
     * @throws
     */
    public String updateCertificateInfo(ShopCompanyDetail newCompanyDetail, ShopCompanyDetail oldCompanyDetail) {
        String flag = "";

        oldCompanyDetail.setCompanyName(newCompanyDetail.getCompanyName());
        oldCompanyDetail.setLicenseNumber(newCompanyDetail.getLicenseNumber());
        oldCompanyDetail.setCorportateName(newCompanyDetail.getCorportateName());
        oldCompanyDetail.setLegalIdcard(newCompanyDetail.getLegalIdcard());
        oldCompanyDetail.setLicenseProvinceid(newCompanyDetail.getLicenseProvinceid());
        oldCompanyDetail.setLicenseCityid(newCompanyDetail.getLicenseCityid());
        oldCompanyDetail.setLicenseAreaid(newCompanyDetail.getLicenseAreaid());
        oldCompanyDetail.setLicenseAddr(newCompanyDetail.getLicenseAddr());
        oldCompanyDetail.setLicenseBusinessScope(newCompanyDetail.getLicenseBusinessScope());
        oldCompanyDetail.setLicenseStartDate(newCompanyDetail.getLicenseStartDate());
        oldCompanyDetail.setLicenseEndDate(newCompanyDetail.getLicenseEndDate());
        oldCompanyDetail.setLicensePic(newCompanyDetail.getLicensePic());

        ShopCompanyDetail save = shopCompanyDetailDao.saveAndFlush(oldCompanyDetail);
        if (save.getLicensePic().equals(newCompanyDetail.getLicensePic())) {
            flag = "1";
        } else {
            flag = "0";
        }
        return flag;
    }

    /**
     * 
     * @Title: 保存商家信息
     * @Description: TODO
     * @param @param newshopDetail
     * @param @return   
     * @return boolean 
     * @author zhujun 2016年8月30日 
     * @throws
     */
    public String saveShopDetailInfo(ShopDetail newShopDetail) {
        Date data = new Date();
        UsrRole usrRole = new UsrRole();
        ShopDetail oldShopdetail = shopDetailDao.findShopDetail(newShopDetail.getUserId());
        if (oldShopdetail == null) {
            throw new WebRequestException("商家不存在");
        }
//        UsrDetail usrDetail = this.userService.findUserById(newShopDetail.getUserId());
//        if (usrDetail == null) {
//            throw new WebRequestException("用户不存在");
//        }
//        usrDetail.setShopId(oldShopdetail.getShopId());
//        usrDetailDao.save(usrDetail);

        List<Role> roleList = roleDao.findRole("ROLE_SUPPLIER");// 添加供货商的权限
        for (int j = 0; j < roleList.size(); j++) {
            usrRole = usrRoleDao.findByUserId(newShopDetail.getUserId(), roleList.get(j).getId());
            if (usrRole == null) {
                usrRole = new UsrRole();
                usrRole.setUserId(newShopDetail.getUserId());
                usrRole.setRoleId(roleList.get(j).getId());
                usrRole.setAppNo(roleList.get(j).getAppNo());
                usrRoleDao.save(usrRole);
            }
        }

        oldShopdetail.setStatus(ShopStatusEnum.NORMAL.value());
        oldShopdetail.setSiteName(newShopDetail.getSiteName());
        oldShopdetail.setOpStatus(ShopOPstatusEnum.AUDITED.value());
        oldShopdetail.setLicenseBusinessScope(newShopDetail.getLicenseBusinessScope());
        oldShopdetail.setLogoPic(newShopDetail.getLogoPic());
        oldShopdetail.setShopPic2(newShopDetail.getLogoPic());
        oldShopdetail.setProvinceid(newShopDetail.getProvinceid());
        oldShopdetail.setCityid(newShopDetail.getCityid());
        oldShopdetail.setAreaid(newShopDetail.getAreaid());
        oldShopdetail.setShopAddr(newShopDetail.getShopAddr());
        oldShopdetail.setLicensePic(newShopDetail.getLicensePic());
        oldShopdetail.setLng(newShopDetail.getLng());
        oldShopdetail.setLat(newShopDetail.getLat());

        String[] cate = newShopDetail.getCategory().split(";");
        int cateGoryId = Integer.parseInt(cate[0]);
        String cateGory = cate[0];
        int i = 1;
        while (i < cate.length) {
            if (StringUtils.isNotBlank(cate[i])) {
                cateGoryId = Integer.parseInt(cate[i]);
                cateGory = cateGory + ";" + cate[i];
                i++;
            }
        }
        oldShopdetail.setCategoryId(cateGoryId);
        oldShopdetail.setCategory(cateGory);
        oldShopdetail.setModifyDate(data);
        oldShopdetail.setTransferDate(data);

        BigDecimal rebate = newShopDetail.getAdFeeRate().divide(new BigDecimal(0.16), 3, RoundingMode.HALF_UP);
        if (rebate.compareTo(new BigDecimal(0.625)) == 1) {
            rebate = new BigDecimal(0.625);
        }
        oldShopdetail.setAdFeeRate(newShopDetail.getAdFeeRate());
        oldShopdetail.setRebate(rebate);

        oldShopdetail = shopDetailDao.saveAndFlush(oldShopdetail);
        if (oldShopdetail == null) {
            throw new WebRequestException("店铺保存失败");
        }

        return "1";
    }

    /**
     * 
     * @Title: 修改商家信息
     * @Description: TODO
     * @param @param newshopDetail
     * @param @return   
     * @return boolean 
     * @author zhujun 2016年11月14日 
     * @throws
     */
    public String updateShopInfo(ShopDetail newShopDetail) {
        Date data = new Date();
        ShopDetail oldShopdetail = shopDetailDao.findShopDetail(newShopDetail.getUserId());
        if (oldShopdetail == null) {
            throw new WebRequestException("商家不存在");
        }
        if (!newShopDetail.getSiteName().equals(oldShopdetail.getSiteName())) {
            List<ShopDetail> list = shopDetailDao.findShopDetailBySiteName(newShopDetail.getSiteName());
            if (list.size() > 0) {
                throw new WebRequestException("商家名称不能和其他店铺相同");
            }
        }
        oldShopdetail.setSiteName(newShopDetail.getSiteName());
        oldShopdetail.setStatus(newShopDetail.getStatus());
        oldShopdetail.setAuditOpinion(newShopDetail.getAuditOpinion() == null ? oldShopdetail.getAuditOpinion()
                : newShopDetail.getAuditOpinion());
        oldShopdetail.setModifyDate(data);

        if (newShopDetail.getProvinceid() != null) {
            oldShopdetail.setProvinceid(newShopDetail.getProvinceid());
            oldShopdetail.setCityid(newShopDetail.getCityid());
            oldShopdetail.setAreaid(newShopDetail.getAreaid());
            oldShopdetail.setShopAddr(newShopDetail.getShopAddr());
            oldShopdetail.setLng(newShopDetail.getLng());
            oldShopdetail.setLat(newShopDetail.getLat());
            oldShopdetail.setAdFeeRate(newShopDetail.getAdFeeRate());
        }
        if (newShopDetail.getCategory() != null) {
            String[] cate = newShopDetail.getCategory().split(";");
            int cateGoryId = Integer.parseInt(cate[0]);
            String cateGory = cate[0];
            int i = 1;
            while (i < cate.length) {
                if (StringUtils.isNotBlank(cate[i])) {
                    cateGoryId = Integer.parseInt(cate[i]);
                    cateGory = cateGory + ";" + cate[i];
                    i++;
                }
            }
            oldShopdetail.setCategoryId(cateGoryId);
            oldShopdetail.setCategory(cateGory);
        }

        oldShopdetail = shopDetailDao.saveAndFlush(oldShopdetail);
        if (oldShopdetail == null) {
            throw new WebRequestException("店铺保存失败");
        }

        ShopAudit shopAudit = new ShopAudit();
        shopAudit.setShopId(oldShopdetail.getShopId());
        shopAudit.setStatus(newShopDetail.getStatus());
        shopAudit.setModifyDate(data);
        shopAudit.setAuditOpinion(newShopDetail.getAuditOpinion() == null ? "" : newShopDetail.getAuditOpinion());
        shopAuditDao.save(shopAudit);

        return oldShopdetail.getShopId().toString();
    }

    /**
     * 
     * @Title: 保存联系人（主方法）
     * @Description: TODO
     * @param @param shopDetail
     * @param @return   
     * @return String 
     * @author zhujun 2016年8月31日 
     * @throws
     */
    public String saveContact(ShopDetail newShopDetail) {
        ShopDetail oldShopDetail = shopDetailDao.findShopDetail(newShopDetail.getUserId());
        if (oldShopDetail == null) {
            return this.saveContactInfo(newShopDetail);
        } else {
            return this.updateContactInfo(newShopDetail, oldShopDetail);
        }
    }

    /**
     * 保存联系人
     * @Title: saveContactInfo
     * @Description: TODO
     * @param @param shopDetail
     * @param @return   
     * @return Boolean 
     * @author zhujun 2016年8月31日 
     * @throws
     */

    public String saveContactInfo(ShopDetail newShopDetail) {
        Date data = new Date();
        newShopDetail.setStatus(ShopStatusEnum.AUDITING.value());
        newShopDetail.setOpStatus(ShopOPstatusEnum.CONTACT_INFO_OK.value());
        newShopDetail.setRecDate(data);
        newShopDetail.setModifyDate(data);
        newShopDetail.setVisitTimes(0);
        newShopDetail.setOffProductNum(0);
        newShopDetail.setProductNum(0);
        newShopDetail.setCommNum(0);
        newShopDetail.setCapital(0d);
        newShopDetail.setCredit(0);
        newShopDetail.setGradeId(0);
        newShopDetail.setShopSystem(2);
        newShopDetail.setAgentState(2);
        newShopDetail.setShopState(2);
        newShopDetail.setTransfer(2);
        newShopDetail.setCoinSwitch(0);
        newShopDetail.setWhiteList(0);
        newShopDetail.setRebate(new BigDecimal(1.000));
        newShopDetail.setAdFeeRate(new BigDecimal(0.160));
        newShopDetail.setAdFeeBasicRate(new BigDecimal(0.160));

        UsrDetail usrDetail = userService.findUserById(newShopDetail.getUserId());
        if (usrDetail != null) {
            newShopDetail.setUserName(usrDetail.getUserName());
//            newShopDetail.setNickName(usrDetail.getNickName());
        }

        ShopDetail shopDetail = shopDetailDao.save(newShopDetail);

        if (newShopDetail.getUserId().equals(shopDetail.getUserId())) {
            return shopDetail.getShopId().toString();
        } else {
            return "Error";
        }

    }

    public String updateContactInfo(ShopDetail newShopDetail, ShopDetail oldShopDetail) {
        oldShopDetail.setContactName(newShopDetail.getContactName());
        oldShopDetail.setContactMobile(newShopDetail.getContactMobile());
        oldShopDetail.setContactMail(newShopDetail.getContactMail());
        oldShopDetail.setContact_QQ(newShopDetail.getContact_QQ());
        oldShopDetail.setIdCardPic(newShopDetail.getIdCardPic());
        oldShopDetail.setIdCardBackpic(newShopDetail.getIdCardBackpic());
        oldShopDetail.setIdHandCardPic(newShopDetail.getIdHandCardPic());
        oldShopDetail.setModifyDate(new Date());
        ShopDetail shopDetail = shopDetailDao.saveAndFlush(oldShopDetail);
        if (newShopDetail.getUserId().equals(shopDetail.getUserId())) {
            return shopDetail.getShopId().toString();
        } else {
            return "Error";
        }
    }

    /**
     * o2o店铺配置
     * @Title: saveO2oShop
     * @Description: TODO
     * @param @param 
     * @param @return   
     * @return  
     * @author zhujun 2016年11月23日 
     * @throws
     */

    public void saveO2oShop(int shopId, String contactTel, String contactTelSecond, String detailDesc,
            BigDecimal perCost, String smsPhone, String serviceTime, String installation, String story) {
        Date date = new Date();
        ShopDetail shopDetail = shopDetailDao.findOne(shopId);
        if (shopDetail == null) {
            throw new WebRequestException("商家不存在");
        }
        shopDetail.setContactTel(contactTel);
        shopDetail.setContactTelSecond(contactTelSecond);
        shopDetail.setDetailDesc(detailDesc);
        shopDetail.setModifyDate(date);
        shopDetailDao.save(shopDetail);

        O2oShopDetail o2oShopDetail = o2oShopDetailDao.findO2oShopDetailByshopId(shopId);
        if (o2oShopDetail == null) {
            o2oShopDetail = new O2oShopDetail();
            o2oShopDetail.setCreateTime(date);
        }
        o2oShopDetail.setShopId(shopId);
        o2oShopDetail.setPerCost(perCost);
        o2oShopDetail.setSmsPhone(smsPhone);
        o2oShopDetail.setServiceTime(serviceTime);
        o2oShopDetail.setInstallation(installation);
        o2oShopDetail.setStory(story);
        o2oShopDetail.setUpdateTime(date);
        o2oShopDetailDao.save(o2oShopDetail);
    }

    /**
     * o2o店铺图片上传
     * @Title: saveO2oPics
     * @Description: TODO
     * @param @param 
     * @param @return   
     * @return  
     * @author zhujun 2016年11月25日 
     * @throws
     */

    public void saveO2oPics(int shopId, String pictures) {

        if (StringUtils.isBlank(pictures)) {
            throw new WebRequestException("所传图片为空");
        }
        List<Map> picList = JsonUtils.parseList(pictures, Map.class);
        o2oShopPhotosDao.deleteO2oShopPhotosByShopId(shopId);
        Date date = new Date();
        O2oShopPhotos o2oShopPhotos = new O2oShopPhotos();

        for (Map<String, Object> picMap : picList) {
            o2oShopPhotos = new O2oShopPhotos();
            o2oShopPhotos.setShopId(shopId);
            o2oShopPhotos.setType(StringHelper.objectToInt(picMap.get("type"), 0));
            o2oShopPhotos.setPath(StringHelper.objectToString(picMap.get("path"), ""));
            o2oShopPhotos.setTitle(StringHelper.objectToString(picMap.get("title"), ""));
            o2oShopPhotos.setContent(StringHelper.objectToString(picMap.get("content"), ""));
            o2oShopPhotos.setCreate_time(date);
            o2oShopPhotosDao.save(o2oShopPhotos);
        }
    }

    /**
     * 获取商家列表（实体店）
     * @Title: unCheckedShopList
     * @Description: TODO
     * @param @param 
     * @param @return   
     * @return Page
     * @author zhujun 2016年8月31日
     * @throws
     */

    public Page<Map<String, Object>> checkShopList(String fromDate, String toDate, String provinceId, String cityId,
            String areaIds, String shopIds, String siteName, String shopState, String agentState, String status,
            int shopSystem, Page<Map<String, Object>> page, String contactName, String contactMobile, int whiteList,
            String agentDetail, String nickName, String shopType, String userMobile) {

        if (StringUtils.isNotBlank(userMobile)) {
            UsrDetail usrDetail = userService.findUserByMobile(userMobile);
            if (usrDetail == null) {
                shopIds = "0";
            } else {
                ShopDetail shopDetail = shopDetailDao.findShopDetail(usrDetail.getUserId());
                if (shopDetail == null) {
                    shopIds = "0";
                } else {
                    String searchShopId = shopDetail.getShopId().toString();
                    if (StringUtils.isBlank(shopIds) || shopIds.indexOf(searchShopId) >= 0) {
                        shopIds = searchShopId;
                    } else {
                        shopIds = "0";
                    }
                }
            }
        }
        List<String> userIdList = Lists.newArrayList();
        if (StringUtils.isNotBlank(nickName)) {
        	userIdList = userService.findUserIdByNickName(nickName);
        }
        
        List<Map<String, Object>> list = Lists.newArrayList();
        String[] area = stringToArray(areaIds);
        String[] shop = stringToArray(shopIds);
        Page<Map<String, Object>> pageData = checkShopDao.getCheckShopList(fromDate, toDate, provinceId, cityId, area,
                shop, siteName, shopState, agentState, status, shopSystem, page, contactName, contactMobile, whiteList,
                nickName, shopType, userIdList);
        // 根据category_id获取经营范围名称
        for (Map<String, Object> map : pageData.getResult()) {
            O2oCategory o2oCategory = o2oCategoryDao.findOne(StringHelper.objectToInt(map.get("category_id"), 0));
            Category category = categoryDao.findOne(StringHelper.objectToInt(map.get("category_id"), 0));
            if (o2oCategory != null) {
                map.put("license_business_scope", o2oCategory.getName());
            } else if (category != null) {
                map.put("license_business_scope", category.getName());
            }
            String shopId = StringHelper.objectToString(map.get("shop_id"), "");
            String userId = StringHelper.objectToString(map.get("user_id"), "");
            UsrDetail usrDetail = userService.findUserById(userId);
            map.put("nick_name", usrDetail==null?"":usrDetail.getNickName());

            // int prodOnlineCount = prodDao.countByShopIdAndStatus(Integer.parseInt(shopId), 1);
            // int prodOfflineCount = prodDao.countByShopIdAndStatus(Integer.parseInt(shopId), 0);
            // map.put("prodOnlineCount", prodOnlineCount);
            // map.put("prodOfflineCount", prodOfflineCount);

            if (StringUtils.isNotBlank(agentDetail)) {
                List<Map> agentList = JsonUtils.parseList(agentDetail, Map.class);
                for (Map<String, Object> agentMap : agentList) {

                    if (shopId.equals(StringHelper.objectToString(agentMap.get("shopId"), ""))) {
                        int agentProvinceId = StringHelper.objectToInt(agentMap.get("agentProvinceId"), 0);
                        int agentCityId = StringHelper.objectToInt(agentMap.get("agentCityId"), 0);
                        int agentAreaId = StringHelper.objectToInt(agentMap.get("agentAreaId"), 0);
                        Provinces provinces = provincesDao.findOne(agentProvinceId);
                        City city = cityDao.findOne(agentCityId);
                        Areas areas = areasDao.findOne(agentAreaId);
                        map.put("agentProvinceId", agentProvinceId);
                        map.put("agentCityId", agentCityId);
                        map.put("agentAreaId", agentAreaId);
                        map.put("agentProvinceName", provinces == null ? "" : provinces.getProvince());
                        map.put("agentCityName", city == null ? "" : city.getCity());
                        map.put("agentAreaName", areas == null ? "" : areas.getArea());
                        map.put("agentName", StringHelper.objectToString(agentMap.get("agentName"), ""));
                    }
                }
            }

            list.add(map);
        }
        pageData.setResult(list);
        return pageData;
    }

    /**
     * 获取商家详细信息
     * @Title: unCheckedShopList
     * @Description: TODO
     * @param @param 
     * @param @return   
     * @return Page
     * @author zhujun 2016年8月31日
     * @throws
     */

    public Map<String, Object> shopDetail(String shopId) {
        ShopDetail shop = shopDetailDao.findOne(Integer.parseInt(shopId));
        if (shop == null) {
            throw new WebRequestException("商家不存在");
        }
        Map<String, Object> shopData = checkShopDao.getShopDetail(shopId);

        String logoPic = StringHelper.objectToString(shopData.get("logo_pic"), "");
        if (StringUtils.isBlank(logoPic)) {
            logoPic = StringHelper.objectToString(shopData.get("shop_pic2"), "");
        }

        shopData.put("legal_id_card", this.buildImg(StringHelper.objectToString(shopData.get("legal_id_card"), "")));
        shopData.put("id_card_backpic",
                this.buildImg(StringHelper.objectToString(shopData.get("id_card_backpic"), "")));
        shopData.put("id_hand_card_pic",
                this.buildImg(StringHelper.objectToString(shopData.get("id_hand_card_pic"), "")));
        shopData.put("shop_license_pic",
                this.buildImg(StringHelper.objectToString(shopData.get("shop_license_pic"), "")));
        shopData.put("license_pic", this.buildImg(StringHelper.objectToString(shopData.get("license_pic"), "")));
        shopData.put("id_card_pic", this.buildImg(StringHelper.objectToString(shopData.get("id_card_pic"), "")));
        shopData.put("logo_pic", this.buildImg(logoPic));

        if (StringHelper.objectToInt(shopData.get("shop_type"), 0) == 1) {
            String licenseProvince = provincesDao
                    .findOne(StringHelper.objectToInt(shopData.get("license_provinceid"), 0)).getProvince();
            String licenseCity = cityDao.findOne(StringHelper.objectToInt(shopData.get("license_cityid"), 0)).getCity();
            String licenseArea = areasDao.findOne(StringHelper.objectToInt(shopData.get("license_areaid"), 0))
                    .getArea();
            shopData.put("licenseProvince", licenseProvince);
            shopData.put("licenseCity", licenseCity);
            shopData.put("licenseArea", licenseArea);
        }

        O2oCategory shopCategory = o2oCategoryDao.findOne(StringHelper.objectToInt(shopData.get("category_id"), 0)); // 根据category_id找到经营范围

        if (shopCategory != null) {
            shopData.put("shopCategory", shopCategory.getName());
        }

        List<O2oShopPhotos> o2oShopPhotos = o2oShopPhotosDao.findO2oShopPhotosByshopId(Integer.parseInt(shopId));
        for (O2oShopPhotos op : o2oShopPhotos) {
            op.setPath(this.buildImg(StringHelper.objectToString(op.getPath(), "")));
        }

        // 环境图片
        List<O2oShopPhotos> envPics = new ArrayList<O2oShopPhotos>();
        // 特色图片
        List<O2oShopPhotos> spePics = new ArrayList<O2oShopPhotos>();
        // 活动图片
        List<O2oShopPhotos> actPics = new ArrayList<O2oShopPhotos>();

        for (O2oShopPhotos ospt : o2oShopPhotos) {
            int type = ospt.getType();
            if (type == BasicConstant.O2O_SHOP_PCI_ENV) {
                envPics.add(ospt);
            } else if (type == BasicConstant.O2O_SHOP_PCI_SPE) {
                spePics.add(ospt);
            } else if (type == BasicConstant.O2O_SHOP_PCI_ACT) {
                actPics.add(ospt);
            }
        }
        shopData.put("envPics", envPics);
        shopData.put("spePics", spePics);
        shopData.put("actPics", actPics);

        String userId = StringHelper.objectToString(shopData.get("user_id"), "");
        UsrDetail usrDetail = userService.findUserById(userId);
        if (usrDetail != null) {
            shopData.put("user_name", usrDetail.getUserName());
            shopData.put("nick_name", usrDetail.getNickName());
            shopData.put("user_mobile", usrDetail.getUserMobile());
            shopData.put("user_mail", usrDetail.getUserMail());
        } else {
            shopData.put("user_name", "");
            shopData.put("nick_name", "");
            shopData.put("user_mobile", "");
            shopData.put("user_mail", "");
        }

        return shopData;
    }

    /**
     * 更新审核结果(包括下线)
     * @Title: updateShopStatus
     * @Description: TODO
     * @param @param 
     * @param @return   
     * @return void
     * @author zhujun 2016年8月31日
     * @throws
     */

    public void updateShopStatus(String shopId, String status, String reason, String transfer, BigDecimal adFeeRate) {
        String transferDate = "";
        Date date = new Date();
        ShopDetail shop = shopDetailDao.findOne(Integer.parseInt(shopId));
        if (shop == null) {
            throw new WebRequestException("商家不存在");
        }
        if (shop.getStatus() == -1 && "1".equals(status)) {
            transferDate = DateUtils.date2Str(date);
        }
        checkShopDao.updateShopStatus(shopId, status, reason, transfer, adFeeRate, transferDate);
    }

    /**
     * 获取商家订单列表
     * @Title: shopOrderList
     * @Description: TODO
     * @param @param 
     * @param @return   
     * @return Page
     * @author zhujun 2016年8月31日
     * @throws
     */

    public Map<String, Object> shopOrderList(String fromDate, String toDate, String provinceId, String cityId,
            String areaIds, String shopIds, String orderNum, String agentState, Page<Map<String, Object>> page) {
        Map<String, Object> result = Maps.newHashMap();
        List<Map<String, Object>> list = Lists.newArrayList();
        ShopDetail shopDetail = new ShopDetail();
        String[] area = stringToArray(areaIds);
        String[] shop = stringToArray(shopIds);
        double totalTransaction = 0;
        double totalAd = 0;
        double totalPay = 0;

        Page<Map<String, Object>> pageData = checkShopDao.getShopOrderList(fromDate, toDate, provinceId, cityId, area,
                shop, orderNum, agentState, page);

        list = pageData.getResult();
        if (pageData.getHjList().size() > 0) {
            totalTransaction = StringHelper.objectToDouble(pageData.getHjList().get(0).get("totalTransaction"), 0);
            totalAd = StringHelper.objectToDouble(pageData.getHjList().get(0).get("totalAd"), 0);
            totalPay = StringHelper.objectToDouble(pageData.getHjList().get(0).get("totalPay"), 0);
            result.put("totalTransaction", FormatUtils.format("0.00", totalTransaction));
            result.put("totalAd", FormatUtils.format("0.00", totalAd));
            result.put("totalPay", FormatUtils.format("0.00", totalPay));
        }
        if (list.size() > 0) {
            for (int i = 0; i < list.size(); i++) {
                Map<String, Object> orderMap = Maps.newHashMap();
                orderMap = list.get(i);
                orderMap.put("total_amount",
                        FormatUtils.format("0.00", StringHelper.objectToDouble(orderMap.get("total_amount"), 0)));
                orderMap.put("ad_amount",
                        FormatUtils.format("0.00", StringHelper.objectToDouble(orderMap.get("ad_amount"), 0)));
                orderMap.put("pay_amount",
                        FormatUtils.format("0.00", StringHelper.objectToDouble(orderMap.get("pay_amount"), 0)));
            }
        }

        if (StringUtils.isNotBlank(shop[0]) && !"0".equals(shop[0])) {
            shopDetail = shopDetailDao.findOne(Integer.parseInt(shop[0]));
            if (shopDetail != null) {
                result.put("provinceid", shopDetail.getProvinceid());
                result.put("cityid", shopDetail.getCityid());
                result.put("areaid", shopDetail.getAreaid());
                result.put("site_name", shopDetail.getSiteName());
                result.put("shop_addr", shopDetail.getShopAddr());

                if (shopDetail.getProvinceid() != null) {
                    Provinces provinces = provincesDao.findOne(shopDetail.getProvinceid());
                    String provinceName = provinces.getProvince();
                    result.put("province", provinceName);
                } else {
                    result.put("province", "");
                }
                if (shopDetail.getCityid() != null) {
                    City city = cityDao.findOne(shopDetail.getCityid());
                    String cityName = city.getCity();
                    result.put("city", cityName);
                } else {
                    result.put("city", "");
                }
                if (shopDetail.getAreaid() != null) {
                    Areas areas = areasDao.findOne(shopDetail.getAreaid());
                    String areaName = areas.getArea();
                    result.put("area", areaName);
                } else {
                    result.put("area", "");
                }
            }
        }
        result.put("list", list);
        result.put("pageNo", pageData.getPageNo());
        result.put("pageSize", pageData.getPageSize());
        result.put("totalPage", pageData.getTotalPage());
        result.put("totalCount", pageData.getTotalCount());

        return result;
    }

    /**
     * 移交店铺
     * @Title: transferShop
     * @Description: TODO
     * @param @param 
     * @param @return   
     * @return void
     * @author zhujun 2016年8月31日
     * @throws
     */

    public void transferShop(String shopIds, String transfer) {

        String[] shop = stringToArray(shopIds);
        if (StringUtils.isBlank(transfer)) {
            throw new WebRequestException("修改状态为空");
        }
        int transferState = Integer.parseInt(transfer);

        for (int i = 0; i < shop.length; i++) {
            ShopDetail shopDetail = shopDetailDao.findOne(Integer.parseInt(shop[i]));
            if ((shopDetail.getTransfer() == ShopTransferEnum.TRANSFER_CHECK.value()
                    && transferState == ShopTransferEnum.TRANSFER_CHECK.value())) { // 当transfer为1时，待移交审核的状态不可以移交
                throw new WebRequestException("当前状态不可以移交");
            }
        }
        checkShopDao.transferShop(shop, transfer);
    }

    /**
     * 获取o2o店铺主营范围
     * @Title: initO2oCategoryMap
     * @Description: TODO
     * @param @return
     * @return Map<Integer,Object>
     * @author Administrator 2016年7月23日
     * @throws
     */
    public Map<Integer, Object> getO2oCategory(int parentId) {
        List<O2oCategory> list = o2oCategoryDao.findO2oCategory(parentId);
        Map<Integer, Object> map = Maps.newHashMap();
        for (O2oCategory c : list) {
            map.put(c.getId(), c.getName());
        }
        return map;
    }

    /**
     * 获取商城店铺主营范围
     * @Title: initO2oCategoryMap
     * @Description: TODO
     * @param @return
     * @return Map<Integer,Object>
     * @author Administrator 2016年11月18日
     * @throws
     */
    public Map<Integer, Object> shopCategory(int parentId) {
        List<Category> list = categoryDao.findCategory(parentId);
        Map<Integer, Object> map = Maps.newHashMap();
        for (Category c : list) {
            map.put(c.getId(), c.getName());
        }
        return map;
    }

    /**
     * 判断多个商铺是否属于同一地区
     * @Title: getJudgeArea
     * @Description: TODO
     * @param @param String
     * @param @return String
     * @return ResponseDto 
     * @author zhujun 2016年9月6日 
     * @throws
     */
    public String getJudgeArea(String shopIds) {

        String[] shop = stringToArray(shopIds);
        String areaId = checkShopDao.getJudgeArea(shop);
        return areaId;
    }

    /**
     * 获取地区列表
     * @Title: initO2oCategoryMap
     * @Description: TODO
     * @param @return
     * @return Map<Integer,O2oCategory>
     * @author Administrator 2016年7月23日
     * @throws
     */
    public Map<Integer, Object> getArea(int id, int level) {
        Map<Integer, Object> map = Maps.newHashMap();
        if (level == 0) {
            List<Provinces> list = provincesDao.findProvinces();
            for (Provinces provinces : list) {
                map.put(provinces.getId(), provinces.getProvince());
            }
        } else if (level == 1) {
            List<City> list = cityDao.findCities(id);
            for (City city : list) {
                map.put(city.getId(), city.getCity());
            }
        } else if (level == 2) {
            List<Areas> list = areasDao.findAreas(id);
            for (Areas areas : list) {
                map.put(areas.getId(), areas.getArea());
            }
        }

        return map;
    }

    /**
     * 获取省市区的名称
     * @Title: getAreaName
     * @Description: TODO
     * @param @return
     * @return Map<Integer,O2oCategory>
     * @author zhujun 2016年9月21日
     * @throws
     */
    public Map<Integer, Object> getAreaName(String ids, int level) {
        Map<Integer, Object> map = Maps.newHashMap();
        String[] id = stringToArray(ids);
        // 根据省id查名称
        if (level == 0) {
            for (int i = 0; i < id.length; i++) {
                Provinces province = provincesDao.findOne(Integer.parseInt(id[i]));
                if (province != null) {
                    map.put(province.getId(), province.getProvince());
                }
            }
        }
        // 根据市id查名称
        else if (level == 1) {
            for (int i = 0; i < id.length; i++) {
                City city = cityDao.findOne(Integer.parseInt(id[i]));
                if (city != null) {
                    map.put(city.getId(), city.getCity());
                }
            }
        }
        // 根据区id查名称
        else if (level == 2) {
            for (int i = 0; i < id.length; i++) {
                Areas Area = areasDao.findOne(Integer.parseInt(id[i]));
                if (Area != null) {
                    map.put(Area.getId(), Area.getArea());
                }
            }
        }

        return map;
    }

    /**
     * 根据省获取所有的市和区
     * @Title: getAllAreas
     * @Description: TODO
     * @param @return
     * @return List<Map<String, Object>>
     * @author zhujun 2016年11月10日
     * @throws
     */
    public List<Map<String, Object>> getAllAreas(String provinceIds) {
        Map<String, Object> provinceMap = Maps.newHashMap();
        Map<String, Object> cityMap = Maps.newHashMap();
        Map<String, Object> areaMap = Maps.newHashMap();

        List<Map<String, Object>> provinceListRes = Lists.newArrayList();
        List<Map<String, Object>> cityListRes = Lists.newArrayList();
        List<Map<String, Object>> areaListRes = Lists.newArrayList();

        List<Provinces> provinceList = Lists.newArrayList();
        Provinces provinceTmp = new Provinces();
        if (StringUtils.isBlank(provinceIds)) {
            provinceList = provincesDao.findProvinces();
        } else {
            String[] provices = stringToArray(provinceIds);
            for (int i = 0; i < provices.length; i++) {
                provinceTmp = provincesDao.findOne(Integer.parseInt(provices[i]));
                provinceList.add(provinceTmp);
            }
        }
        for (Provinces provinces : provinceList) {
            provinceMap = Maps.newHashMap();
            cityListRes = Lists.newArrayList();
            List<City> cityList = cityDao.findCities(provinces.getId());
            for (City city : cityList) {
                cityMap = Maps.newHashMap();
                areaListRes = Lists.newArrayList();
                List<Areas> areaList = areasDao.findAreas(city.getId());
                for (Areas areas : areaList) {
                    areaMap = Maps.newHashMap();
                    areaMap.put("id", areas.getId());
                    areaMap.put("name", areas.getArea());
                    areaListRes.add(areaMap);
                }
                cityMap.put("id", city.getId());
                cityMap.put("name", city.getCity());
                cityMap.put("area", areaListRes);
                cityListRes.add(cityMap);
            }
            provinceMap.put("id", provinces.getId());
            provinceMap.put("name", provinces.getProvince());
            provinceMap.put("city", cityListRes);
            provinceListRes.add(provinceMap);
        }
        return provinceListRes;
    }

    /**
     * 更新代理状态
     * @Title: updateShopStatus
     * @Description: TODO
     * @param @param 
     * @param @return   
     * @return void
     * @author zhujun 2016年8月31日
     * @throws
     */

    public void updateAgentState(String shopIds) {

        String[] shopId = stringToArray(shopIds);
        checkShopDao.updateAgentState(shopId);

    }

    /**
     * 获取nhs_agent_admin所有数据
     * @Title: updateShopStatus
     * @Description: TODO
     * @param @param 
     * @param @return   
     * @return void
     * @author zhujun 2016年8月31日
     * @throws
     */

    public List<Map<String, Object>> getAgentAdmin() {

        return checkShopDao.getAgentAdmin();

    }

    /**
     * 根据手机号判断是否开店
     * @Title: judgeShopByPhone
     * @Description: TODO
     * @param @param 
     * @param @return   
     * @return String
     * @author zhujun 2016年9月26日
     * @throws
     */

    public Map<String, Object> judgeShopByPhone(String phone) {
        Map<String, Object> map = Maps.newHashMap();
        UsrDetail usrDetail = userService.findUserByMobile(phone);//usrDetailDao.findUserDetail(phone); //findUserByMobile(phone);
        
        if (usrDetail == null) {
            throw new WebRequestException("用户不存在");
        }
        ShopDetail shopDetail = shopDetailDao.findShopDetail(usrDetail.getUserId());
        if (shopDetail == null) {
            map.put("result", "0");// 0表示此用户没有开店
            map.put("user_id", usrDetail.getUserId());
            return map;
        }
        int companyCount = shopCompanyDetailDao.countByShopId(shopDetail.getShopId());
        if (companyCount <= 0) {
            map.put("result", "1");// 1表示此用户开店，但是没有企业信息
            map.put("user_id", usrDetail.getUserId());
            return map;
        }
        map.put("result", "2");// 2表示此用户开店并且有企业信息
        map.put("user_id", usrDetail.getUserId());
        return map;
    }

    /**
     * 更新广告费率
     * @Title: updateAdRate
     * @Description: TODO
     * @param @param 
     * @param @return   
     * @return void
     * @author zhujun 2016年10月26日
     * @throws
     */

    public void updateAdRate(String shopId, BigDecimal adFeeRate, int coinSwitch) {

        checkShopDao.updateAdRate(shopId, adFeeRate, coinSwitch);

    }

    /**
     * 更改黑白名单
     * @Title: updateWhiteList
     * @Description: TODO
     * @param @param 
     * @param @return   
     * @return void
     * @author zhujun 2016年10月26日
     * @throws
     */

    public void updateWhiteList(String shopId, int whiteList) {

        checkShopDao.updateWhiteList(shopId, whiteList);

    }

    /**
     * 获取ls_category表的一级目录
     * @Title: initO2oCategoryMap
     * @Description: TODO
     * @param @return
     * @return Map<Integer,O2oCategory>
     * @author Administrator 2016年7月23日
     * @throws
     */
    public Map<Integer, Object> lsCategory() {
        List<Category> list = categoryDao.findFirstCategory();
        Map<Integer, Object> map = Maps.newHashMap();
        for (Category c : list) {
            map.put(c.getId(), c.getName());
        }
        return map;
    }

    /**
     * 批量更改商家银币返还开关
     * @Title: updateBatchCoin
     * @Description: TODO
     * @param @param 
     * @param @return   
     * @return void
     * @author zhujun 2016年10月26日
     * @throws
     */

    public void updateBatchCoin(String category, int shopSystem, int coinSwitch) {

        checkShopDao.updateBatchCoin(category, shopSystem, coinSwitch);

    }

    /**
     * 检测店铺名称是否唯一
     * @Title: updateBatchCoin
     * @Description: TODO
     * @param @param 
     * @param @return   
     * @return void
     * @author zhujun 2016年10月26日
     * @throws
     */

    public String checkShopName(String siteName) {

        List<ShopDetail> list = shopDetailDao.findShopDetailBySiteName(siteName);
        if (list.size() > 0) {
            return "1";
        } else {
            return "0";
        }
    }

    /**
     * 商家分析统计
     * @Title: analyse
     * @Description: TODO
     * @param @param 
     * @param @return   
     * @return void
     * @author zhujun 2016年11月21日
     * @throws
     */

    public Map<String, Object> shopAnalyse(String shopIds) {
        String[] shop = stringToArray(shopIds);
        Map<String, Object> result = Maps.newHashMap();
        Map<String, Object> map = Maps.newHashMap();
        List<Map<String, Object>> list = Lists.newArrayList();

        Calendar calendar = Calendar.getInstance();
        int dayOfMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
        List<String> monthLabels = Lists.newArrayList();
        for (int i = 1; i <= dayOfMonth; i++) {
            monthLabels.add(Integer.toString(i));
        }

        List<String> shopCountWeekLabels = WEEKLABELS;
        List<String> shopCountWeekDatas = Lists.newArrayList();
        List<String> shopCountMonthLabels = monthLabels;
        List<String> shopCountMonthDatas = Lists.newArrayList();
        List<String> shopCountYearLabels = YEARLABELS;
        List<String> shopCountYearDatas = Lists.newArrayList();

        List<String> shopCateWeekLabels = Lists.newArrayList();
        List<String> shopCateWeekDatas = Lists.newArrayList();
        List<String> shopCateMonthLabels = Lists.newArrayList();
        List<String> shopCateMonthDatas = Lists.newArrayList();
        List<String> shopCateYearLabels = Lists.newArrayList();
        List<String> shopCateYearDatas = Lists.newArrayList();
        List<String> shopCateAllLabels = Lists.newArrayList();
        List<String> shopCateAllDatas = Lists.newArrayList();

        List<String> shopAreaWeekLabels = Lists.newArrayList();
        List<String> shopAreaWeekDatas = Lists.newArrayList();
        List<String> shopAreaMonthLabels = Lists.newArrayList();
        List<String> shopAreaMonthDatas = Lists.newArrayList();
        List<String> shopAreaYearLabels = Lists.newArrayList();
        List<String> shopAreaYearDatas = Lists.newArrayList();
        List<String> shopAreaAllLabels = Lists.newArrayList();
        List<String> shopAreaAllDatas = Lists.newArrayList();

        SimpleDateFormat sdfd = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat sdfm = new SimpleDateFormat("yyyy-MM");
        calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, 1);
        String dateStringTomorrow = sdfd.format(calendar.getTime());
        calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, 1);
        String dateStringNextMonth = sdfm.format(calendar.getTime());

        calendar = Calendar.getInstance();
        while (calendar.get(Calendar.DAY_OF_WEEK) != Calendar.MONDAY) {// 获取本周第一天
            calendar.add(Calendar.DATE, -1);
        }
        String firstDayOfWeek = sdfd.format(calendar.getTime());

        for (; !dateStringTomorrow.equals(sdfd.format(calendar.getTime())); calendar.add(Calendar.DATE, 1)) {
            String date = sdfd.format(calendar.getTime());
            map = checkShopDao.analyseByDay(shop, date);
            shopCountWeekDatas.add(StringHelper.objectToString(map.get("count"), ""));
        }

        calendar = Calendar.getInstance();
        calendar.set(Calendar.DAY_OF_MONTH, 1);// 获取本月第一天
        String firstDayOfMonth = sdfd.format(calendar.getTime());

        for (; !dateStringTomorrow.equals(sdfd.format(calendar.getTime())); calendar.add(Calendar.DATE, 1)) {
            String date = sdfd.format(calendar.getTime());
            map = checkShopDao.analyseByDay(shop, date);
            shopCountMonthDatas.add(StringHelper.objectToString(map.get("count"), ""));
        }

        calendar = Calendar.getInstance();
        calendar.set(Calendar.DAY_OF_YEAR, 1);// 获取本年第一天
        String firstDayOfYear = sdfd.format(calendar.getTime());

        for (; !dateStringNextMonth.equals(sdfm.format(calendar.getTime())); calendar.add(Calendar.MONTH, 1)) {
            String date = sdfm.format(calendar.getTime());
            map = checkShopDao.analyseByMonth(shop, date);
            shopCountYearDatas.add(StringHelper.objectToString(map.get("count"), ""));
        }

        list = checkShopDao.analyseByCategory(shop, firstDayOfWeek);
        for (Map<String, Object> cateMap : list) {
            shopCateWeekLabels.add(StringHelper.objectToString(cateMap.get("name"), ""));
            shopCateWeekDatas.add(StringHelper.objectToString(cateMap.get("count"), ""));
        }

        list = checkShopDao.analyseByCategory(shop, firstDayOfMonth);
        for (Map<String, Object> cateMap : list) {
            shopCateMonthLabels.add(StringHelper.objectToString(cateMap.get("name"), ""));
            shopCateMonthDatas.add(StringHelper.objectToString(cateMap.get("count"), ""));
        }

        list = checkShopDao.analyseByCategory(shop, firstDayOfYear);
        for (Map<String, Object> cateMap : list) {
            shopCateYearLabels.add(StringHelper.objectToString(cateMap.get("name"), ""));
            shopCateYearDatas.add(StringHelper.objectToString(cateMap.get("count"), ""));
        }

        list = checkShopDao.analyseByCategory(shop, "");
        for (Map<String, Object> cateMap : list) {
            shopCateAllLabels.add(StringHelper.objectToString(cateMap.get("name"), ""));
            shopCateAllDatas.add(StringHelper.objectToString(cateMap.get("count"), ""));
        }

        list = checkShopDao.analyseByArea(shop, firstDayOfWeek);
        for (Map<String, Object> cateMap : list) {
            shopAreaWeekLabels.add(StringHelper.objectToString(cateMap.get("province"), ""));
            shopAreaWeekDatas.add(StringHelper.objectToString(cateMap.get("count"), ""));
        }

        list = checkShopDao.analyseByArea(shop, firstDayOfMonth);
        for (Map<String, Object> cateMap : list) {
            shopAreaMonthLabels.add(StringHelper.objectToString(cateMap.get("province"), ""));
            shopAreaMonthDatas.add(StringHelper.objectToString(cateMap.get("count"), ""));
        }

        list = checkShopDao.analyseByArea(shop, firstDayOfYear);
        for (Map<String, Object> cateMap : list) {
            shopAreaYearLabels.add(StringHelper.objectToString(cateMap.get("province"), ""));
            shopAreaYearDatas.add(StringHelper.objectToString(cateMap.get("count"), ""));
        }

        list = checkShopDao.analyseByArea(shop, "");
        for (Map<String, Object> cateMap : list) {
            shopAreaAllLabels.add(StringHelper.objectToString(cateMap.get("province"), ""));
            shopAreaAllDatas.add(StringHelper.objectToString(cateMap.get("count"), ""));
        }

        // 在list上再套一个list，方便PHP解析
        List<List<String>> listWeek = Lists.newArrayList();
        List<List<String>> listMonth = Lists.newArrayList();
        List<List<String>> listYear = Lists.newArrayList();
        listWeek.add(shopCountWeekDatas);
        listMonth.add(shopCountMonthDatas);
        listYear.add(shopCountYearDatas);

        result.put("shopCountWeekLabels", shopCountWeekLabels);
        result.put("shopCountWeekDatas", listWeek);
        result.put("shopCountMonthLabels", shopCountMonthLabels);
        result.put("shopCountMonthDatas", listMonth);
        result.put("shopCountYearLabels", shopCountYearLabels);
        result.put("shopCountYearDatas", listYear);

        result.put("shopCateWeekLabels", shopCateWeekLabels);
        result.put("shopCateWeekDatas", shopCateWeekDatas);
        result.put("shopCateMonthLabels", shopCateMonthLabels);
        result.put("shopCateMonthDatas", shopCateMonthDatas);
        result.put("shopCateYearLabels", shopCateYearLabels);
        result.put("shopCateYearDatas", shopCateYearDatas);
        result.put("shopCateAllLabels", shopCateAllLabels);
        result.put("shopCateAllDatas", shopCateAllDatas);

        result.put("shopAreaWeekLabels", shopAreaWeekLabels);
        result.put("shopAreaWeekDatas", shopAreaWeekDatas);
        result.put("shopAreaMonthLabels", shopAreaMonthLabels);
        result.put("shopAreaMonthDatas", shopAreaMonthDatas);
        result.put("shopAreaYearLabels", shopAreaYearLabels);
        result.put("shopAreaYearDatas", shopAreaYearDatas);
        result.put("shopAreaAllLabels", shopAreaAllLabels);
        result.put("shopAreaAllDatas", shopAreaAllDatas);

        return result;
    }

    /**
     * 订单分析统计
     * @Title: analyse
     * @Description: TODO
     * @param @param 
     * @param @return   
     * @return void
     * @author zhujun 2016年11月21日
     * @throws
     */

    public Map<String, Object> orderAnalyse(String shopIds) {
        String[] shop = stringToArray(shopIds);
        Map<String, Object> result = Maps.newHashMap();
        Map<String, Object> map = Maps.newHashMap();
        List<Map<String, Object>> list = Lists.newArrayList();

        Calendar calendar = Calendar.getInstance();
        int dayOfMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
        List<String> monthLabels = Lists.newArrayList();
        for (int i = 1; i <= dayOfMonth; i++) {
            monthLabels.add(Integer.toString(i));
        }

        List<String> orderCountWeekLabels = WEEKLABELS;
        List<String> orderCountWeekDatas = Lists.newArrayList();
        List<String> orderCountMonthLabels = monthLabels;
        List<String> orderCountMonthDatas = Lists.newArrayList();
        List<String> orderCountYearLabels = YEARLABELS;
        List<String> orderCountYearDatas = Lists.newArrayList();

        List<String> orderAmountWeekLabels = WEEKLABELS;
        List<String> orderAmountWeekDatas = Lists.newArrayList();
        List<String> orderAmountMonthLabels = monthLabels;
        List<String> orderAmountMonthDatas = Lists.newArrayList();
        List<String> orderAmountYearLabels = YEARLABELS;
        List<String> orderAmountYearDatas = Lists.newArrayList();

        List<String> cateCountWeekLabels = Lists.newArrayList();
        List<String> cateCountWeekDatas = Lists.newArrayList();
        List<String> cateCountMonthLabels = Lists.newArrayList();
        List<String> cateCountMonthDatas = Lists.newArrayList();
        List<String> cateCountYearLabels = Lists.newArrayList();
        List<String> cateCountYearDatas = Lists.newArrayList();

        List<String> cateAmountWeekLabels = Lists.newArrayList();
        List<String> cateAmountWeekDatas = Lists.newArrayList();
        List<String> cateAmountMonthLabels = Lists.newArrayList();
        List<String> cateAmountMonthDatas = Lists.newArrayList();
        List<String> cateAmountYearLabels = Lists.newArrayList();
        List<String> cateAmountYearDatas = Lists.newArrayList();

        SimpleDateFormat sdfd = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat sdfm = new SimpleDateFormat("yyyy-MM");
        calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, 1);
        String dateStringTomorrow = sdfd.format(calendar.getTime());
        calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, 1);
        String dateStringNextMonth = sdfm.format(calendar.getTime());

        calendar = Calendar.getInstance();
        while (calendar.get(Calendar.DAY_OF_WEEK) != Calendar.MONDAY) {// 获取本周第一天
            calendar.add(Calendar.DATE, -1);
        }
        String firstDayOfWeek = sdfd.format(calendar.getTime());

        for (; !dateStringTomorrow.equals(sdfd.format(calendar.getTime())); calendar.add(Calendar.DATE, 1)) {
            String date = sdfd.format(calendar.getTime());
            map = checkShopDao.orderAnalyseCountByDay(shop, date);
            orderCountWeekDatas.add(StringHelper.objectToString(map.get("count"), ""));
            map = checkShopDao.orderAnalyseAmountByDay(shop, date);
            orderAmountWeekDatas.add(StringHelper.objectToString(map.get("amount"), ""));
        }

        calendar = Calendar.getInstance();
        calendar.set(Calendar.DAY_OF_MONTH, 1);// 获取本月第一天
        String firstDayOfMonth = sdfd.format(calendar.getTime());

        for (; !dateStringTomorrow.equals(sdfd.format(calendar.getTime())); calendar.add(Calendar.DATE, 1)) {
            String date = sdfd.format(calendar.getTime());
            map = checkShopDao.orderAnalyseCountByDay(shop, date);
            orderCountMonthDatas.add(StringHelper.objectToString(map.get("count"), ""));
            map = checkShopDao.orderAnalyseAmountByDay(shop, date);
            orderAmountMonthDatas.add(StringHelper.objectToString(map.get("amount"), ""));
        }

        calendar = Calendar.getInstance();
        calendar.set(Calendar.DAY_OF_YEAR, 1);// 获取本年第一天
        String firstDayOfYear = sdfd.format(calendar.getTime());

        for (; !dateStringNextMonth.equals(sdfm.format(calendar.getTime())); calendar.add(Calendar.MONTH, 1)) {
            String date = sdfm.format(calendar.getTime());
            map = checkShopDao.orderAnalyseCountByMonth(shop, date);
            orderCountYearDatas.add(StringHelper.objectToString(map.get("count"), ""));
            map = checkShopDao.orderAnalyseAmountByMonth(shop, date);
            orderAmountYearDatas.add(StringHelper.objectToString(map.get("amount"), ""));
        }

        list = checkShopDao.orderAnalyseCountByCategory(shop, firstDayOfWeek);
        for (Map<String, Object> cateMap : list) {
            cateCountWeekLabels.add(StringHelper.objectToString(cateMap.get("name"), ""));
            cateCountWeekDatas.add(StringHelper.objectToString(cateMap.get("count"), ""));
        }

        list = checkShopDao.orderAnalyseCountByCategory(shop, firstDayOfMonth);
        for (Map<String, Object> cateMap : list) {
            cateCountMonthLabels.add(StringHelper.objectToString(cateMap.get("name"), ""));
            cateCountMonthDatas.add(StringHelper.objectToString(cateMap.get("count"), ""));
        }

        list = checkShopDao.orderAnalyseCountByCategory(shop, firstDayOfYear);
        for (Map<String, Object> cateMap : list) {
            cateCountYearLabels.add(StringHelper.objectToString(cateMap.get("name"), ""));
            cateCountYearDatas.add(StringHelper.objectToString(cateMap.get("count"), ""));
        }

        list = checkShopDao.orderAnalyseAmountByCategory(shop, firstDayOfWeek);
        for (Map<String, Object> cateMap : list) {
            cateAmountWeekLabels.add(StringHelper.objectToString(cateMap.get("name"), ""));
            cateAmountWeekDatas.add(StringHelper.objectToString(cateMap.get("amount"), ""));
        }

        list = checkShopDao.orderAnalyseAmountByCategory(shop, firstDayOfMonth);
        for (Map<String, Object> cateMap : list) {
            cateAmountMonthLabels.add(StringHelper.objectToString(cateMap.get("name"), ""));
            cateAmountMonthDatas.add(StringHelper.objectToString(cateMap.get("amount"), ""));
        }

        list = checkShopDao.orderAnalyseAmountByCategory(shop, firstDayOfYear);
        for (Map<String, Object> cateMap : list) {
            cateAmountYearLabels.add(StringHelper.objectToString(cateMap.get("name"), ""));
            cateAmountYearDatas.add(StringHelper.objectToString(cateMap.get("amount"), ""));
        }

        // 在list上再套一个list，方便PHP解析
        List<List<String>> listCountWeek = Lists.newArrayList();
        List<List<String>> listCountMonth = Lists.newArrayList();
        List<List<String>> listCountYear = Lists.newArrayList();
        listCountWeek.add(orderCountWeekDatas);
        listCountMonth.add(orderCountMonthDatas);
        listCountYear.add(orderCountYearDatas);

        List<List<String>> listAmountWeek = Lists.newArrayList();
        List<List<String>> listAmountMonth = Lists.newArrayList();
        List<List<String>> listAmountYear = Lists.newArrayList();
        listAmountWeek.add(orderAmountWeekDatas);
        listAmountMonth.add(orderAmountMonthDatas);
        listAmountYear.add(orderAmountYearDatas);

        result.put("orderCountWeekLabels", orderCountWeekLabels);
        result.put("orderCountWeekDatas", listCountWeek);
        result.put("orderCountMonthLabels", orderCountMonthLabels);
        result.put("orderCountMonthDatas", listCountMonth);
        result.put("orderCountYearLabels", orderCountYearLabels);
        result.put("orderCountYearDatas", listCountYear);

        result.put("orderAmountWeekLabels", orderAmountWeekLabels);
        result.put("orderAmountWeekDatas", listAmountWeek);
        result.put("orderAmountMonthLabels", orderAmountMonthLabels);
        result.put("orderAmountMonthDatas", listAmountMonth);
        result.put("orderAmountYearLabels", orderAmountYearLabels);
        result.put("orderAmountYearDatas", listAmountYear);

        result.put("cateCountWeekLabels", cateCountWeekLabels);
        result.put("cateCountWeekDatas", numberToPercent(cateCountWeekDatas));
        result.put("cateCountMonthLabels", cateCountMonthLabels);
        result.put("cateCountMonthDatas", numberToPercent(cateCountMonthDatas));
        result.put("cateCountYearLabels", cateCountYearLabels);
        result.put("cateCountYearDatas", numberToPercent(cateCountYearDatas));

        result.put("cateAmountWeekLabels", cateAmountWeekLabels);
        result.put("cateAmountWeekDatas", numberToPercent(cateAmountWeekDatas));
        result.put("cateAmountMonthLabels", cateAmountMonthLabels);
        result.put("cateAmountMonthDatas", numberToPercent(cateAmountMonthDatas));
        result.put("cateAmountYearLabels", cateAmountYearLabels);
        result.put("cateAmountYearDatas", numberToPercent(cateAmountYearDatas));

        return result;
    }

    /**
     * list中的数字转为百分比
     * @Title: numberToPercent
     * @param List
     * @return List
     * @author zhujun 2016年12月2日
     */
    private List<String> numberToPercent(List<String> numberList) {
        List<String> percentList = Lists.newArrayList();
        double totalCount = 0;
        double num = 0;
        for (String numStr : numberList) {
            num = Double.parseDouble(numStr);
            totalCount = totalCount + num;
        }
        if (totalCount == 0) {
            return percentList;
        }
        for (String numStr : numberList) {
            num = Double.parseDouble(numStr);
            percentList.add(percentFormat(num / totalCount));
        }
        return percentList;
    }

    /**
     * double转为百分比
     * <p>如：0.22格式化后：22%</p>
     * @Title: percentFormat
     * @Description: TODO
     * @param @param value
     * @param @return   
     * @return String 
     * @author zhujun 2016年12月2日 
     * @throws
     */
    private String percentFormat(double value) {
        NumberFormat percentFormat = NumberFormat.getPercentInstance();
        percentFormat.setMaximumFractionDigits(1); // 最大小数位数
        percentFormat.setMaximumIntegerDigits(3);// 最大整数位数
        percentFormat.setMinimumFractionDigits(0); // 最小小数位数
        percentFormat.setMinimumIntegerDigits(1);// 最小整数位数

        return percentFormat.format(value);
    }

    /**
     * 字符串转数组
     * @Title: stringToArray
     * @param String
     * @return String[]
     * @author zhujun 2016年9月6日
     */
    private String[] stringToArray(String str) {
        str = str.replace(" ", "");
        str = str.replace("'", "");
        str = str.replace("[", "");
        str = str.replace("]", "");
        String[] ary = str.split(",");
        return ary;
    }

    /**
     * 初始化区域map
     * @Title: initAreaMap
     * @Description: TODO
     * @param @return
     * @return Map<Integer,Areas>
     * @author Administrator 2016年7月23日
     * @throws
     */
    private Map<Integer, Areas> initAreaMap() {
        List<Areas> areaList = areasDao.findAreas();
        Map<Integer, Areas> map = Maps.newHashMap();
        for (Areas area : areaList) {
            map.put(area.getId(), area);
        }
        return map;
    }

    /**
     * 初始化分类map
     * @Title: initO2oCategoryMap
     * @Description: TODO
     * @param @return
     * @return Map<Integer,O2oCategory>
     * @author Administrator 2016年7月23日
     * @throws
     */
    private Map<Integer, O2oCategory> initO2oCategoryMap() {
        List<O2oCategory> list = o2oCategoryDao.findO2oCategory();
        Map<Integer, O2oCategory> map = Maps.newHashMap();
        for (O2oCategory c : list) {
            map.put(c.getId(), c);
        }
        return map;
    }

    /**
     * 上传图片到店铺相册
     * @param shopId
     * @param photoPathList
     * @param type
     * @param title
     * @param content
     */
    @Transactional
    public void saveStorePhotos(int shopId, List<String> photoPathList, int type, String title, String content) {

        for (String photoPath : photoPathList) {
            O2oShopPhotos photos = new O2oShopPhotos();
            photos.setShopId(shopId);
            photos.setType(type);
            photos.setTitle(title);
            photos.setContent(content);
            photos.setPath(photoPath);
            photos.setCreate_time(new Date());
            photos.setUpdate_time(new Date());

            o2oShopPhotosDao.save(photos);
        }

    }

    /**
     * 获取店铺相册
     * @param shopId
     * @return
     */
    public Map<String, List<ShopPhotosDto>> getStorePhotos(Integer shopId) {

        ShopDetail shop = shopDetailDao.findOne(shopId);
        if (shop == null) {
            throw new WebRequestException("商家不存在");
        }

        Map<String, List<ShopPhotosDto>> map = new HashMap<>();

        List<O2oShopPhotos> o2oShopPhotos = o2oShopPhotosDao.findO2oShopPhotosByshopId(shopId);
        List<ShopPhotosDto> photoDtoList = new ArrayList<>();
        ShopPhotosDto shopPhoto = null;
        for (O2oShopPhotos op : o2oShopPhotos) {
            // 移动端上传的图片是存在7niu服务器的
            String imagePath = this.buildImg(SysPropsFactory.getProperty("imgServer"), op.getPath());

            shopPhoto = new ShopPhotosDto();
            shopPhoto.setId(op.getId());
            shopPhoto.setPath(imagePath);
            shopPhoto.setContent(op.getContent());
            shopPhoto.setShopId(op.getShopId());
            shopPhoto.setTitle(op.getTitle());
            shopPhoto.setCreate_time(op.getCreate_time());
            shopPhoto.setUpdate_time(op.getUpdate_time());

            shopPhoto.setType(op.getType());
            String width = "0";
            String height = "0";

            if (!StringUtils.isEmpty(op.getPath())) {
                Map<String, String> imageMap = ImageUtils.getImageWidthAndHeight(imagePath);
                width = imageMap.get("width");
                height = imageMap.get("height");
            }

            shopPhoto.setImgHeight(height);
            shopPhoto.setImgWidth(width);

            photoDtoList.add(shopPhoto);

        }

        // 环境图片
        List<ShopPhotosDto> envPics = new ArrayList<ShopPhotosDto>();
        // 特色图片
        List<ShopPhotosDto> spePics = new ArrayList<ShopPhotosDto>();
        // 活动图片
        List<ShopPhotosDto> actPics = new ArrayList<ShopPhotosDto>();

        for (ShopPhotosDto ospt : photoDtoList) {
            int type = ospt.getType();
            if (type == BasicConstant.O2O_SHOP_PCI_ENV) {
                envPics.add(ospt);
            } else if (type == BasicConstant.O2O_SHOP_PCI_SPE) {
                spePics.add(ospt);
            } else if (type == BasicConstant.O2O_SHOP_PCI_ACT) {
                actPics.add(ospt);
            }
        }

        map.put("envPics", envPics);
        map.put("actPics", actPics);
        map.put("spePics", spePics);

        return map;
    }

    /**
     * 构建O2o店铺浏览记录
     * @Title: buildGoodsHistory
     * @Description: TODO
     * @param @param shopId
     * @param @param userId   
     * @return void 
     * @author liangdanhua 2016年9月20日 
     * @throws
     */
    public void buildGoodsHistory(Integer shopId, String userId) {
        VitLog vitlog = vitLogDao.findVitlogByShopIdAndUserId(userId, shopId, "");
        if (vitlog == null) {
            VitLog vlg = new VitLog();
            UsrDetail usrDetail = this.userService.findUserById(userId);
            ShopDetail shopDetail = shopDetailDao.findOne(shopId);

            if (shopDetail == null)
                shopDetail = new ShopDetail();
            try {
                vlg.setUserName(usrDetail.getUserName() == null ? "" : usrDetail.getUserName());
                vlg.setShopName(shopDetail.getSiteName() == null ? "" : shopDetail.getSiteName());
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            vlg.setProductId("");
            vlg.setProductName("");
            vlg.setIp("");
            vlg.setPage("");
            vlg.setRecDate(new Date());
            vlg.setShopId(shopDetail.getShopId() == null ? 0 : shopDetail.getShopId());
            vlg.setUserId(userId);
            if (!(userId.trim()).equals(shopDetail.getUserId().trim())) {
                vitLogDao.saveAndFlush(vlg);
            }

        } else {
            vitlog.setRecDate(new Date());
            vitlog.setVisitNum(vitlog.getVisitNum() + 1);
            vitLogDao.saveAndFlush(vitlog);
        }
    }

    /**
     * 获取所有O2o分类
     * @Title: initO2oCategoryMap
     * @Description: TODO
     * @param @return
     * @return Map<Integer,O2oCategory>
     * @author Administrator 2016年7月23日
     * @throws
     */
    public List<O2oCategoryDto> getO2oAllCategory() {
        List<O2oCategory> list = o2oCategoryDao.findO2oCategory(0);
        List<O2oCategoryDto> categoryDtoList = new ArrayList<>();
        O2oCategoryDto categoryDto = null;
        for (O2oCategory category : list) {
            categoryDto = new O2oCategoryDto();
            categoryDto.setCategoryId(category.getId());
            categoryDto.setCategoryName(category.getName());
            String image = category.getIcon();
            if (StringUtils.isNotBlank(image) && image.indexOf("http:") < 0) {
                image = SysPropsFactory.getProperty("imgServer") + "/" + image;
            }
            categoryDto.setIcon(image);
            categoryDto.setSort(StringUtils.isEmpty(category.getSort()) ? 0 : Integer.parseInt(category.getSort()));
            List<O2oCategorySubDto> subCategoryDtoList = new ArrayList<>();
            O2oCategorySubDto subCategorySub = null;
            List<O2oCategory> listSub = o2oCategoryDao.findO2oCategory(category.getId());
            for (O2oCategory sub : listSub) {
                subCategorySub = new O2oCategorySubDto();
                subCategorySub.setSubCategoryId(sub.getId());
                subCategorySub.setSubCategoryName(sub.getName());
                subCategorySub.setSubSort(StringUtils.isEmpty(sub.getSort()) ? 0 : Integer.parseInt(sub.getSort()));
                subCategoryDtoList.add(subCategorySub);
            }
            categoryDto.setSubList(subCategoryDtoList);
            categoryDtoList.add(categoryDto);
        }

        return categoryDtoList;
    }

    public void addCategory(int parentId, String categoryName, int categoryId, int sort) {

        O2oCategory category = new O2oCategory();
        if (categoryId != 0) {
            category = o2oCategoryDao.findOne(categoryId);
            if (sort != 0) {
                category.setSort(String.valueOf(sort));
            }
        } else {
            if (sort == 0) {
                sort = o2oCategoryDao.getMaxSortByParentId(parentId) == null ? 0
                        : o2oCategoryDao.getMaxSortByParentId(parentId);
                sort += 1;
            }
            category.setSort(String.valueOf(sort));
            category.setParentId(parentId);
            if (parentId == 0) {
                category.setGrade(1);
            } else {
                category.setGrade(2);
            }
            category.setNavigationMenu((byte) 0);
            category.setStatus(1);
            category.setHeaderMenu((byte) 0);
            category.setCreateTime(new Date());
        }
        category.setName(categoryName);
        category.setModifyTime(new Date());

        o2oCategoryDao.save(category);

    }

    public void deleteCategory(int categoryId) {
        O2oCategory category = o2oCategoryDao.findOne(categoryId);
        if (category != null) {
            if (category.getParentId() != 0) {
                category.setStatus(0);
                category.setModifyTime(new Date());
                o2oCategoryDao.save(category);
            } else {
                List<O2oCategory> list = o2oCategoryDao.findByParentIdAndStatus(category.getId(), 1);
                for (O2oCategory oc : list) {
                    oc.setStatus(0);
                    oc.setModifyTime(new Date());
                    o2oCategoryDao.save(oc);
                }
                category.setModifyTime(new Date());
                category.setStatus(0);
                o2oCategoryDao.save(category);
            }
        }
    }

    /**
     * 获取所有查询出商品的分类
     * @Title: initO2oCategoryMap
     * @Description: TODO
     * @param @return
     * @return Map<Integer,O2oCategory>
     * @author Administrator 2016年7月23日
     * @throws
     */
    public List<O2oCategoryDto> getSearchStoreO2oCategory(List<ShopDto> list) {
        List<O2oCategoryDto> result = new ArrayList<>();
        List<O2oCategory> firstCategoryList = new ArrayList<>();
        List<String> firstCategoryIdList = new ArrayList<>();
        List<O2oCategory> subCategoryList = new ArrayList<>();
        List<String> subCategoryIdList = new ArrayList<>();
        List<O2oCategory> subNotExistList = new ArrayList<>();
        for (ShopDto shopDto : list) {
            O2oCategory category = o2oCategoryDao.findByStatusAndId(1, shopDto.getCategoryId());
            if (category != null && category.getParentId() == 0) {
                if (!firstCategoryIdList.contains(category.getId() + "")) {
                    firstCategoryIdList.add(category.getId() + "");
                    firstCategoryList.add(category);
                }
            } else if (category != null && category.getParentId() != 0) {
                if (!subCategoryIdList.contains(category.getId() + "")) {
                    subCategoryIdList.add(category.getId() + "");
                    subCategoryList.add(category);
                }
            }
        }

        // 店铺是1级分类跟店铺是二级分类的匹配封装起来
        for (O2oCategory firCat : firstCategoryList) {
            O2oCategoryDto categoryDto = convertToDto(firCat, subCategoryList);
            result.add(categoryDto);
        }

        // 查询结果的店铺分类属于二级分类，结果集中没有包含这二级分类得一级分类。统计出来
        for (O2oCategory subCat : subCategoryList) {
            boolean flag = false;
            for (O2oCategory firCat : firstCategoryList) {
                if (subCat.getParentId().intValue() == firCat.getId().intValue()) {
                    flag = true;
                    break;
                }
            }
            if (!flag) {
                subNotExistList.add(subCat);
            }

        }

        // 给二级分类匹配出对应的一级分类
        Map<Integer, List<O2oCategory>> map = new HashMap<>();
        List<O2oCategory> subCategoryList1 = new ArrayList<>();
        for (O2oCategory ca : subNotExistList) {
            if (map.containsKey(ca.getParentId())) {
                subCategoryList1 = map.get(ca.getParentId());
                subCategoryList1.add(ca);
            } else {
                subCategoryList1 = new ArrayList<>();
                subCategoryList1.add(ca);
                map.put(ca.getParentId(), subCategoryList1);
            }
        }

        for (Map.Entry<Integer, List<O2oCategory>> entry : map.entrySet()) {
            Integer parentId = entry.getKey();
            List<O2oCategory> sub = entry.getValue();
            O2oCategory category = o2oCategoryDao.findByStatusAndId(1, parentId);
            O2oCategoryDto categoryDto = convertToDto(category, sub);
            result.add(categoryDto);
        }

        return result;
    }

    private O2oCategoryDto convertToDto(O2oCategory firCat, List<O2oCategory> subCategoryList) {
        O2oCategoryDto categoryDto = new O2oCategoryDto();
        categoryDto.setCategoryId(firCat.getId());
        categoryDto.setCategoryName(firCat.getName());
        String image = firCat.getIcon();
        if (StringUtils.isNotBlank(image) && image.indexOf("http:") < 0) {
            image = SysPropsFactory.getProperty("imgServer") + "/" + image;
        }
        categoryDto.setIcon(image);
        categoryDto.setSort(StringUtils.isEmpty(firCat.getSort()) ? 0 : Integer.parseInt(firCat.getSort()));
        List<O2oCategorySubDto> currSubList = new ArrayList<>();
        O2oCategorySubDto subCategorySub = null;
        for (O2oCategory subCat : subCategoryList) {
            if (subCat.getParentId().intValue() == firCat.getId().intValue()) {
                subCategorySub = new O2oCategorySubDto();
                subCategorySub.setSubCategoryId(subCat.getId());
                subCategorySub.setSubCategoryName(subCat.getName());
                subCategorySub
                        .setSubSort(StringUtils.isEmpty(subCat.getSort()) ? 0 : Integer.parseInt(subCat.getSort()));
                currSubList.add(subCategorySub);
            }
        }
        categoryDto.setSubList(currSubList);

        return categoryDto;
    }

    public String judgeCollection(String type, Integer id, String userId) {
        String result = "";
        if ("0".equals(type)) {
            List<FavoriteShop> list = favoriteShopDao.findByShopIdAndUserId(id, userId);
            if (list.size() > 0) {
                result = "1";
            } else {
                result = "0";
            }
        } else if ("1".equals(type)) {
            List<Favorite> list2 = favoriteDao.findByProdIdAndUserId(id, userId);
            if (list2.size() > 0) {
                result = "1";
            } else {
                result = "0";
            }
        }
        return result;
    }
    
    
    
    /**
     * <pre>
     * 	<h1>查询商超记录</h1>
     * </pre>
     * @param page
     * @param user_id
     * @param tradeType
     * @return
     */
	public List<Map<String, Object>> queryStoreRecord(com.nhs.core.orm.Page<Map<String, Object>> page, String user_id) {
		com.nhs.core.orm.Page<Map<String, Object>> pageData = payDao.getTradeList(page, user_id);
		// 2018-08-08 cary 设置取现的中文状态
		List<Map<String, Object>> result = pageData.getResult();
		List<Map<String, Object>> list = Lists.newArrayList();
		if (result != null && result.size() > 0) {
			for (Map<String, Object> temp : result) {
				temp.put("status", Integer.parseInt(temp.get("paymentState").toString()));
                temp.put("paymentState",PayRecordStatusEnum.desc(Integer.parseInt(temp.get("paymentState").toString())));
                temp.put("recordType", "pay");
                if(temp.get("amount") != null){
                	temp.put("amount", "-"+temp.get("amount"));
                }
                if(temp.get("payAmount") != null){
                	temp.put("payAmount", "-"+temp.get("payAmount"));
                }
                if(temp.get("couponAmount") != null){
                	temp.put("couponAmount", "-"+temp.get("couponAmount"));
                }
                temp.put("addtime", DateUtils.date2Str((Date) temp.get("addtime")));
                temp.put("shopPic",this.buildImg(temp.get("shop_pic2") == null ? "" : temp.get("shop_pic2").toString()));
                list.add(temp);
			}
		}
		return list;
	}
	
	 /**
     * 商家详情 v1.9.3(计算规则改变)
     * @Title: getShopDetail
     * @Description: TODO
     * @param @param shopId
     * @param @return   
     * @return Map<String,Object> 
     * @author Li Guangrong 2016年8月27日
     * @throws
     */

     public O2oShopDetailDto getShopDetail(Integer shopId, String userId) {
         O2oShopDetailDto osdd = new O2oShopDetailDto();
         ShopDetail shop = shopDetailDao.findOne(shopId);
         if (shop == null) {
             throw new WebRequestException("商家不存在");
         }
         // 此部分逻辑来自shopservice.getShopDetail() begin
         Map<Integer, Areas> areaMap = initAreaMap();
         Map<Integer, O2oCategory> categoryMap = initO2oCategoryMap();
         osdd.setShopId(shop.getShopId());
         osdd.setBrief(shop.getDetailDesc());
         osdd.setShopTitle(shop.getSiteName());
         osdd.setAddress(shop.getShopAddr() == null ? "" : shop.getShopAddr());
         osdd.setStarNum(5); // 先写死5个星，后面在改
         osdd.setPic(this.buildImg(shop.getShopPic2()));
         osdd.setCategoryId(shop.getCategoryId());
         if (shop.getConsumePer() != null) {
             osdd.setConsumePer(shop.getConsumePer()); // 人均消费
         }

         Areas area = areaMap.get(shop.getAreaid());
         if (area != null) {
             osdd.setArea(area.getArea());
         }
         O2oCategory category = categoryMap.get(shop.getCategoryId());
         if (category != null) {
             osdd.setCategory(category.getName());
         }

         if (StringUtils.isNotBlank(shop.getContactTel())) {
             osdd.setMobile(shop.getContactTel() == null ? "" : shop.getContactTel());
         }
         if (StringUtils.isNotBlank(shop.getContactTelSecond())) {
             osdd.setMobile((shop.getContactTel() == null ? "" : shop.getContactTel()) + "、"
                     + (shop.getContactTelSecond() == null ? "" : shop.getContactTelSecond()));
         }
         osdd.setTasteScore(9.0);
         osdd.setEnvScore(9.1);
         osdd.setServiceScore(9.0);

         osdd.setLat(shop.getLat());
         osdd.setLng(shop.getLng());
         // 此部分逻辑来自shopservice.getShopDetail() end

         // 获取店铺所有订单数量
         long totalOrderNum = o2oServiceOrderDao.countByShopIdAndStatus(shop.getShopId());
         osdd.setTotalOrderNum(String.valueOf(totalOrderNum));

         calO2oPromotionService.calShopDetailCoupon(osdd, shop);
         

         // 店铺配置 信息

         O2oShopDetail o2oShopDetail2 = o2oShopDetailDao.findO2oShopDetailByshopId(shopId);

         if (o2oShopDetail2 != null) {
             osdd.setConsumePer(o2oShopDetail2.getPerCost() == null ? 0 : o2oShopDetail2.getPerCost().intValue());
             osdd.setSmsPhone(o2oShopDetail2.getSmsPhone());
             osdd.setServiceTime(o2oShopDetail2.getServiceTime());
             osdd.setInstallation(o2oShopDetail2.getInstallation());
             osdd.setStory(o2oShopDetail2.getStory());
         }

         List<O2oShopPhotos> o2oShopPhotos = o2oShopPhotosDao.findO2oShopPhotosByshopId(shopId);
         for (O2oShopPhotos op : o2oShopPhotos) {
             op.setPath(buildImg(StringHelper.objectToString(op.getPath(), "")));
         }

         // 环境图片
         List<O2oShopPhotos> envPics = new ArrayList<O2oShopPhotos>();
         // 特色图片
         List<O2oShopPhotos> spePics = new ArrayList<O2oShopPhotos>();
         // 活动图片
         List<O2oShopPhotos> actPics = new ArrayList<O2oShopPhotos>();

         for (O2oShopPhotos ospt : o2oShopPhotos) {
             // 获取图片的长与宽
             Map<String, String> map = ImageUtils.getImageWidthAndHeight(ospt.getPath());
             ospt.setWidth(map.get("width"));
             ospt.setHeight(map.get("height"));
             int type = ospt.getType();
             if (type == BasicConstant.O2O_SHOP_PCI_ENV) {
                 envPics.add(ospt);
             } else if (type == BasicConstant.O2O_SHOP_PCI_SPE) {
                 spePics.add(ospt);
             } else if (type == BasicConstant.O2O_SHOP_PCI_ACT) {
                 ospt.setWidth(map.get("width"));
                 ospt.setHeight(map.get("height"));
                 actPics.add(ospt);

             }
         }
         // buildImg(StringHelper.objectToString(map.get("pic"), ""))
         osdd.setPhotos(o2oShopPhotos.size());
         osdd.setEnvPics(envPics);
         osdd.setActPics(actPics);
         osdd.setSpePics(spePics);
         
         // 获取评价列表 - 3条 .评价显示规则：好评度高（优先级1），图片多（优先级2），评价内容多（优先级3）
         List<O2oShopCommentDto> dtoList = shopCommentService.getShopCommentListForShopDetail(shopId);
         if (dtoList != null) {
             if (dtoList.size() < 3) {
                 dtoList = shopCommentService.getShopCommentListForShopDetailAll(shopId);
             }
         }
         osdd.setCommentList(dtoList);
         long countAll = shopCommentService.countByType(shopId, 0);
         osdd.setCommentNum((int) countAll);
         // 获取商家平均分数
         String average = shopCommentService.getShopAveage(shopId);
         osdd.setAverage(average);
         List<FavoriteShop> favoriteShops = favoriteShopDao.findByShopIdAndUserId(shopId, userId);
         if (favoriteShops != null) {
             osdd.setCollection(favoriteShops.size() + "");
         }
         return osdd;
     }
}
