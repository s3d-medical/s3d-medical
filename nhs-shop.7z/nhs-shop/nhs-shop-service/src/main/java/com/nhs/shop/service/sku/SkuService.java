package com.nhs.shop.service.sku;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Maps;
import com.nhs.shop.dao.legend.shop.ProdPropDao;
import com.nhs.shop.dao.legend.shop.ProdPropValueDao;
import com.nhs.shop.dao.legend.shop.PropValueAliaDao;
import com.nhs.shop.dao.legend.shop.SkuDao;
import com.nhs.shop.entry.legend.shop.ProdProp;
import com.nhs.shop.entry.legend.shop.ProdPropValue;
import com.nhs.shop.entry.legend.shop.PropValueAlia;
import com.nhs.shop.entry.legend.shop.Sku;

/**
 * 商品SKU service
 * @Title: GoodsService.java
 * @Package com.nhs.shop.service.goods
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月16日 下午7:42:18
 * @version V1.0
 */
@Service
@Transactional
public class SkuService {

    @Autowired
    private SkuDao skuDao;

    @Autowired
    private ProdPropDao prodPropDao;

    @Autowired
    private ProdPropValueDao prodPropValueDao;
    
    @Autowired
    private PropValueAliaDao propValueAliaDao;

    /**
     * 根据skuId获取sku
     * @Title: getSkuBySkuId
     * @Description: TODO
     * @param @param skuId
     * @param @return   
     * @return Sku 
     * @author Administrator 2016年7月25日 
     * @throws
     */
    public Sku getSkuBySkuId(int skuId) {
        return skuDao.findOne(skuId);
    }
    
    public Sku getSkuBySkuId(Integer skuId) {
    	if(skuId == null){
    		return null;
    	}
        return skuDao.findOne(skuId);
    }
    
    /**
     * 根据产品ID获取sku列表
     * @Title: findSkuListByProdId
     * @Description: TODO
     * @param @param prodId
     * @param @return   
     * @return List<Sku> 
     * @author Administrator 2016年7月18日 
     * @throws
     */
    public List<Sku> findSkuListByProdId(Integer prodId) {
        return skuDao.findSkuListByProdId(prodId);
    }

    /**
     * 初始化skumap
     * @Title: initProdPropMap
     * @Description: TODO
     * @param @return   
     * @return Map<Integer,ProdProp> 
     * @author Administrator 2016年7月18日 
     * @throws
     */
    public Map<Integer, Sku> initSkuMap() {
        List<Sku> list = skuDao.findSkuList();
        Map<Integer, Sku> map = Maps.newHashMap();
        for (Sku p : list) {
            map.put(p.getSkuId(), p);
        }
        return map;
    }

    /**
     * 初始化sku属性map
     * @Title: initProdPropMap
     * @Description: TODO
     * @param @return   
     * @return Map<Integer,ProdProp> 
     * @author Administrator 2016年7月18日 
     * @throws
     */
    public Map<Integer, ProdProp> initProdPropMap() {
        List<ProdProp> list = prodPropDao.findProdProp();
        Map<Integer, ProdProp> map = Maps.newHashMap();
        for (ProdProp p : list) {
            map.put(p.getPropId(), p);
        }
        return map;
    }

    /**
     * 初始化sku属性值map
     * @Title: initProdPropValueMap
     * @Description: TODO
     * @param @return   
     * @return Map<Integer,ProdPropValue> 
     * @author Administrator 2016年7月18日 
     * @throws
     */
    public Map<Integer, ProdPropValue> initProdPropValueMap() {
        List<ProdPropValue> list = prodPropValueDao.findProdPropValue();
        Map<Integer, ProdPropValue> map = Maps.newHashMap();
        for (ProdPropValue p : list) {
            map.put(p.getValueId(), p);
        }
        return map;
    }
    
    /**
     * 获取sku描述信息
     * @Title: getSkuDesc
     * @Description: TODO
     * @param @param skuId
     * @param @return   
     * @return String 
     * @author wind.chen
     * @throws
     */
    public String getSkuDesc(Integer skuId){
    	Sku sku = this.skuDao.findOne(skuId); 
    	return this.getSkuDesc(sku);
    }
    
    /**
     * 获取sku属性描述信息
     * @Title: getSkuDesc
     * @param sku
     * @param @return   
     * @return String 
     * @author wind.chen 
     * @throws
     */
    public String getSkuDesc(Sku sku){
    	//get sku
        if(sku == null){
        	return "";
        }
        //获取
        Map<Integer, Integer> propKV = sku.getPropInKV();
        if(propKV.size() == 0){
        	return "";
        }
        //获取props, propvals
        Map<Integer, ProdProp> propsInMap = this.getPropsInMap(propKV.keySet());
        Map<Integer, ProdPropValue>  propValsInMap = this.getPropValsInMap(propKV.values());
        // get full desc
        StringBuilder desc = new StringBuilder();
        for(Iterator<Integer> it = propKV.keySet().iterator(); it.hasNext(); ){
        	Integer propId = it.next(); // prop id
        	ProdProp prop = propsInMap.get(propId); // prop
            ProdPropValue propValue = propValsInMap.get(propKV.get(propId)); // prop value
            if (prop != null && propValue != null) {
            	 List<PropValueAlia> propValueAilaList = propValueAliaDao.findByProdIdAndValueId(sku.getProdId(),propValue.getValueId());
                 String propName = propValue.getName();
            	 if(propValueAilaList != null && propValueAilaList.size() > 0){
                 	PropValueAlia propValueAlia = propValueAilaList.get(0);
                 	propName = propValueAlia.getAlias();
                 }
            	desc.append(prop.getMemo() + ":" + propName).append(" ");
            }
        }
        return desc.toString();
    }
    
    /**
     * 查询propvalues 
     * @param ids
     * @return
     */
    private Map<Integer, ProdPropValue> getPropValsInMap(Collection<Integer> ids){
    	Map<Integer, ProdPropValue> map =new HashMap<Integer, ProdPropValue>();
    	if(ids == null || ids.size() ==0){
    		return map;
    	}
        List<ProdPropValue> props = this.prodPropValueDao.findPropVals(ids);
        for(ProdPropValue propVal : props){
        	map.put(propVal.getValueId(), propVal);
        }
        return map;
    }
    
    /**
     * 查询props
     * @param ids
     * @return
     */
    private Map<Integer, ProdProp> getPropsInMap(Collection<Integer> ids){
    	Map<Integer, ProdProp> map =new HashMap<Integer, ProdProp>();
    	if(ids == null || ids.size() ==0){
    		return map;
    	}
        List<ProdProp> props = this.prodPropDao.findProdPropList(ids);
        for(ProdProp prop : props){
        	map.put(prop.getPropId(), prop);
        }
        return map;
    }
    
    /**
     * 获取商品sku描述信息
     * @Title: getSkuDesc
     * @Description: TODO
     * @param @param skuId
     * @param @param skuMap
     * @param @param propMap
     * @param @param propValueMap
     * @param @return   
     * @return String 
     * @author Administrator 2016年7月18日 
     * @throws
     */
    public String getSkuDesc(Integer skuId, Map<Integer, Sku> skuMap, Map<Integer, ProdProp> propMap,
            Map<Integer, ProdPropValue> propValueMap) {
        Sku sku = skuMap.get(skuId);
        if (sku == null) {
            return "";
        }

        String properties = sku.getProperties();
        String[] groups = properties.split(";");
        if (groups == null || groups.length == 0) {
            return "";
        }

        StringBuilder sb = new StringBuilder();
        for (String group : groups) {
            String[] values = group.split(":");
            if (values != null && values.length >= 2) {
                int k = Integer.parseInt(values[0]);
                int v = Integer.parseInt(values[1]);
                ProdProp prop = propMap.get(k);
                ProdPropValue propValue = propValueMap.get(v);
                if (prop != null && propValue != null) {
                    sb.append(prop.getMemo() + ":" + propValue.getName()).append(" ");
                }
            }
        }
        return sb.toString();
    }

    /**
     * 获取sku所有值的map
     * @Title: getSkuValueMap
     * @Description: TODO
     * @param @param skuId
     * @param @return   
     * @return Map<Integer,Object> 
     * @author Administrator 2016年7月25日 
     * @throws
     */
    public Map<Integer, Object> getSkuValueMap(Integer skuId) {
        Map<Integer, Object> map = Maps.newHashMap();
        if (skuId == null) {
            return map;
        }
        Sku sku = getSkuBySkuId(skuId);
        if (sku == null) {
            return map;
        }
        String properties = sku.getProperties();
        String[] groups = properties.split(";");
        for (String group : groups) {
            String[] values = group.split(":");
            if (values != null && values.length >= 2) {
                int v = Integer.parseInt(values[1]);
                map.put(v, null);
            }
        }
        return map;
    }

}
