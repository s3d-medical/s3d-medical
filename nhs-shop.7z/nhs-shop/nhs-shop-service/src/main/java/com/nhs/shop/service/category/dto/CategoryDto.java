package com.nhs.shop.service.category.dto;

import java.io.Serializable;
import java.util.List;

import com.google.common.collect.Lists;

/**
 * 商品分类节点
 * @Title: CategoryDto.java
 * @Package com.nhs.shop.service.category.dto
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月16日 下午5:30:22
 * @version V1.0
 */
public class CategoryDto implements Serializable {

	private static final long serialVersionUID = -1124860820505794845L;

	private Integer categoryId = 0;
	private String title = "";
	private List<SubCategoryDto> children = Lists.newArrayList();

	public Integer getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Integer categoryId) {
		this.categoryId = categoryId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public List<SubCategoryDto> getChildren() {
		return children;
	}

	public void setChildren(List<SubCategoryDto> children) {
		this.children = children;
	}

}
