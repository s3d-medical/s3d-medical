package com.nhs.shop.service.comment;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Lists;
import com.nhs.core.orm.Page;
import com.nhs.core.utils.common.ArithUtils;
import com.nhs.core.utils.common.DateUtils;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.shop.dao.legend.shop.CommentDao;
import com.nhs.shop.dao.legend.shop.ProdCommDao;
import com.nhs.shop.dao.legend.shop.ProdCommLikeDao;
import com.nhs.shop.dao.legend.shop.ProdDao;
import com.nhs.shop.dao.legend.shop.ProdPropDao;
import com.nhs.shop.dao.legend.shop.ProdPropValueDao;
import com.nhs.shop.dao.legend.shop.SkuDao;
import com.nhs.shop.dao.legend.shop.SubItemDao;
import com.nhs.shop.entry.legend.shop.Prod;
import com.nhs.shop.entry.legend.shop.ProdComm;
import com.nhs.shop.entry.legend.shop.ProdCommLike;
import com.nhs.shop.entry.legend.shop.ProdProp;
import com.nhs.shop.entry.legend.shop.ProdPropValue;
import com.nhs.shop.entry.legend.shop.Sku;
import com.nhs.shop.entry.legend.shop.SubItem;
import com.nhs.shop.entry.legend.user.UsrDetail;
import com.nhs.shop.service.BaseService;
import com.nhs.shop.service.comment.dto.CommentCategoryDto;
import com.nhs.shop.service.comment.dto.CommentDto;
import com.nhs.user.service.UserService;
import com.nhs.shop.service.sku.SkuService;

/**
 * 评价service
 * @Title: CommentService.java
 * @Package com.nhs.shop.service.comment
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月17日 下午4:01:03
 * @version V1.0
 */
@Service
@Transactional
public class CommentService extends BaseService {

    @Autowired
    private CommentDao commentDao;
    @Autowired
    private ProdCommDao prodCommDao;
    @Autowired
    private ProdCommLikeDao prodCommLikeDao;
    @Autowired
    private ProdDao prodDao;
    @Autowired
    private SubItemDao subItemDao;
    @Autowired
    private SkuDao skuDao;
    @Autowired
    private SkuService skuService;
    @Autowired
    private ProdPropValueDao prodPropValueDao;
    @Autowired
    private ProdPropDao prodPropDao;
    
    @Autowired
    private UserService userService;

    /**
     * 获取评价列表
     * @Title: getComment
     * @Description: TODO
     * @param @param prodId
     * @param @param type
     * @param @param page
     * @param @return   
     * @return CommentDto 
     * @author penghuaiyi 2016年7月17日 
     * @throws
     */
    public CommentDto getComment(Integer prodId, Integer type, Page<Map<String, Object>> page, String usrId,
            String findType) {
        CommentDto dto = new CommentDto();
        CommentCategoryDto commentCategoryDto = null;
        if (StringUtils.isBlank(findType)) {
            commentCategoryDto = initCommentCategory(prodId, "");
        } else {
            commentCategoryDto = initCommentCategory(prodId, usrId);
        }
        if (commentCategoryDto != null) {
            dto.setTotalNum(commentCategoryDto.getTotal());
            dto.setGoodNum(commentCategoryDto.getHigh());
            dto.setMediunNum(commentCategoryDto.getMedium());
            dto.setBadNum(commentCategoryDto.getLow());
            dto.setPhotoNum(commentCategoryDto.getPhoto());
        }

        List<CommentDto.CommentDetailDto> commentList = Lists.newArrayList();
        Page<Map<String, Object>> pageData = null;
        if (StringUtils.isBlank(findType)) {
            pageData = commentDao.queryCommentList(prodId, type, page);
        } else {
            pageData = commentDao.queryCommentListByUserId(usrId, type, page);
        }
        CommentDto.CommentDetailDto commentDetailDto = null;
        for (Map<String, Object> map : pageData.getResult()) {
            commentDetailDto = new CommentDto.CommentDetailDto();
//            commentDetailDto.setAvatar(buildImg(StringHelper.objectToString(map.get("portrait_pic"), "")));
            Date subDate = (Date) map.get("sub_item_date");
            commentDetailDto.setBuyTime(DateUtils.date2Str(subDate, "yyyy-MM-dd"));
            Date commentaDate = (Date) map.get("addtime");
            commentDetailDto.setCommentDate(DateUtils.date2Str(commentaDate, "yyyy-MM-dd"));
            commentDetailDto.setContent(StringHelper.objectToString(map.get("content"), ""));
            commentDetailDto.setScore(StringHelper.objectToInt(map.get("score"), 0));
            commentDetailDto.setUserId(StringHelper.objectToString(map.get("user_id"), ""));
            UsrDetail usrDetail = userService.findUserById(commentDetailDto.getUserId());
            if(usrDetail != null){
            	 commentDetailDto.setAvatar(buildImg(usrDetail.getPortraitPic()));
            }
            commentDetailDto.setNickname(StringHelper.objectToString(map.get("comment_by"), ""));
            commentDetailDto.setCommentId(StringHelper.objectToString(map.get("id"), ""));
            Integer prod_Id = StringHelper.objectToInt(map.get("prod_id"), 0);
            Prod prod = prodDao.findOne(prod_Id);
            // 设置商品的名字
            if (prod != null && prod.getName() != null) {
                commentDetailDto.setProdName(prod.getName());
            }
            // 设置商品的名字
            if (prod != null && prod.getPic() != null) {
                commentDetailDto.setProdUrl(buildImg(prod.getPic()));
            }
            Integer subItemId = StringHelper.objectToInt(map.get("sub_item_id"), 0);
            SubItem subItem = subItemDao.findOne(subItemId);
            Sku sku = null;
            if (subItem != null && subItem.getSkuId() != null) {
                sku = skuDao.findOne(subItem.getSkuId());
            }
            if (sku != null) {
                commentDetailDto.setSkuName(sku.getName());
                commentDetailDto.setSkuPerproties(getSkuProperties(sku));
            }
            if (StringUtils.isNotBlank(usrId)) {
                // 判断用户是否点赞
                ProdCommLike ProdCommLike = prodCommLikeDao.findProdCommLikeByUsrId(usrId,
                        StringHelper.objectToInt(map.get("id"), 0));
                if (ProdCommLike != null) {
                    commentDetailDto.setIslike("1");
                }
            }

            // 查询该评论被点赞的次数
            List<ProdCommLike> prodCommLikes = prodCommLikeDao
                    .findProdCommLikeByCommentId(StringHelper.objectToInt(map.get("id"), 0));
            if (prodCommLikes != null && prodCommLikes.size() > 0) {
                commentDetailDto.setTotallike(prodCommLikes.size() + "");
            } else {
                commentDetailDto.setTotallike("0");
            }

            List<String> images = Lists.newArrayList();
            String photoFile1 = StringHelper.objectToString(map.get("photo_file1"), "");
            if (StringUtils.isNotBlank(photoFile1)) {
                images.add(buildImg(photoFile1));
            }
            String photoFile2 = StringHelper.objectToString(map.get("photo_file2"), "");
            if (StringUtils.isNotBlank(photoFile2)) {
                images.add(buildImg(photoFile2));
            }
            String photoFile3 = StringHelper.objectToString(map.get("photo_file3"), "");
            if (StringUtils.isNotBlank(photoFile3)) {
                images.add(buildImg(photoFile3));
            }
            String photoFile4 = StringHelper.objectToString(map.get("photo_file4"), "");
            if (StringUtils.isNotBlank(photoFile4)) {
                images.add(buildImg(photoFile4));
            }
            String photoFile5 = StringHelper.objectToString(map.get("photo_file5"), "");
            if (StringUtils.isNotBlank(photoFile5)) {
                images.add(buildImg(photoFile5));
            }
            String photoFile6 = StringHelper.objectToString(map.get("photo_file6"), "");
            if (StringUtils.isNotBlank(photoFile6)) {
                images.add(buildImg(photoFile6));
            }
            String photoFile7 = StringHelper.objectToString(map.get("photo_file7"), "");
            if (StringUtils.isNotBlank(photoFile7)) {
                images.add(buildImg(photoFile7));
            }
            String photoFile8 = StringHelper.objectToString(map.get("photo_file8"), "");
            if (StringUtils.isNotBlank(photoFile8)) {
                images.add(buildImg(photoFile8));
            }
            String photoFile9 = StringHelper.objectToString(map.get("photo_file9"), "");
            if (StringUtils.isNotBlank(photoFile9)) {
                images.add(buildImg(photoFile9));
            }
            commentDetailDto.setImages(images);
            commentList.add(commentDetailDto);
        }
        dto.setCommentList(commentList);
        return dto;
    }

    /**
     * 初始化各个类型的评论数量
     * @Title: initCommentCategory
     * @Description: TODO
     * @param @param prodId
     * @param @return   
     * @return CommentCategoryDto 
     * @author penghuaiyi 2016年7月17日 
     * @throws
     */
    public CommentCategoryDto initCommentCategory(Integer prodId, String userId) {
        CommentCategoryDto pcc = new CommentCategoryDto();
        List<Map<String, Object>> result = null;
        if (StringUtils.isBlank(userId)) {
            result = commentDao.queryCommentStatList(prodId);
        } else {
            result = commentDao.queryCommentStatList(userId);
        }
        for (Map<String, Object> map : result) {
            int score = StringHelper.objectToInt(map.get("score"), 0);
            int count = StringHelper.objectToInt(map.get("result"), 0);

            // score : 0 -5
            if (score >= 3) {
                pcc.setHigh(pcc.getHigh() + count);
            } else if (score >= 2) {
                pcc.setMedium(pcc.getMedium() + count);
            } else {
                pcc.setLow(pcc.getLow() + count);
            }
        }

        int total = pcc.getHigh() + pcc.getMedium() + pcc.getLow();
        if (total > 0) {
            pcc.setTotal(total);
            pcc.setHighRate(ArithUtils.div(pcc.getHigh(), total));
            pcc.setMediumRate(ArithUtils.div(pcc.getMedium(), total));
            pcc.setLowRate(ArithUtils.div(pcc.getLow(), total));
        }
        pcc.setProdId(prodId);

        // 晒图的评论数量
        List<ProdComm> photoCommList = prodCommDao.findProdCommByPhotoFile(prodId);
        if (CollectionUtils.isNotEmpty(photoCommList)) {
            pcc.setPhoto(photoCommList.size());
        }
        return pcc;
    }

    public void addLike(String userId, int commentId) {
        ProdCommLike olduserLike = prodCommLikeDao.findProdCommLikeByUsrId(userId, commentId);
        if (olduserLike == null) {
            ProdCommLike userLike = new ProdCommLike();
            userLike.setUserId(userId);
            userLike.setCommentId(commentId);
            userLike.setAddTime(new Date());
            try {
                prodCommLikeDao.save(userLike);
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        } else {
            olduserLike.setAddTime(new Date());
            prodCommLikeDao.saveAndFlush(olduserLike);
        }
    }

    /**
     * 获取properties规格属性
     * @Title: getSkuProperties
     * @Description: TODO
     * @param @param sku
     * @param @return   
     * @return String 
     * @author liangdanhua 2016年10月25日 
     * @throws
     */
    public String getSkuProperties(Sku sku) {
        StringBuffer sb = new StringBuffer();
        String properties = sku.getProperties();
        String[] groups = properties.split(";");
        if (groups != null && groups.length > 0) {
            for (String group : groups) {
                String[] values = group.split(":");
                if (values != null && values.length >= 2) {
                    int k = Integer.parseInt(values[0]);
                    int v = Integer.parseInt(values[1]);
                    ProdProp prodProp = prodPropDao.findOne(k);
                    ProdPropValue prodPropValue = prodPropValueDao.findOne(v);
                    if (prodProp != null && prodPropValue != null) {
                        sb.append(prodProp.getMemo() + ":" + prodPropValue.getName()).append(",");
                    }else if(prodProp != null){
                    	sb.append(prodProp.getMemo() + ":" ).append(",");
                    }else{
                    	sb.append(",");
                    }
                }
            }
        }
        return sb.toString().substring(0, sb.length() - 1);
    }
}
