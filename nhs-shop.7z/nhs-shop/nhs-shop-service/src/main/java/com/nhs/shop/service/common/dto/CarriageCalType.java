package com.nhs.shop.service.common.dto;


/**
 * 运费计算方式.
 * @author wind.chen
 */
public enum CarriageCalType {
	template(0, "运费模板"), fixCost(1, "固定运费"), notSet(10, "未设置");
	
	//0:使用运费模板;1:固定运费;10:未设置
	private int code;
	private String desc;

	CarriageCalType(int code, String desc) {
		this.code = code;
		this.desc = desc;
	}

	public int getCode() {
		return code;
	}

	public String getDesc() {
		return desc;
	}
}
