package com.nhs.shop.service.collect;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.nhs.core.common.NhsConstant;
import com.nhs.core.context.SysPropsFactory;
import com.nhs.core.orm.Page;
import com.nhs.core.utils.common.ArithUtils;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.core.web.WebRequestException;
import com.nhs.shop.dao.legend.collect.CollectDao;
import com.nhs.shop.dao.legend.collect.MyCollectDao;
import com.nhs.shop.dao.legend.region.AreasDao;
import com.nhs.shop.dao.legend.region.CityDao;
import com.nhs.shop.dao.legend.region.ProvincesDao;
import com.nhs.shop.dao.legend.service.O2oCategoryDao;
import com.nhs.shop.dao.legend.service.O2oServiceOrderDao;
import com.nhs.shop.dao.legend.shop.FavoriteShopDao;
import com.nhs.shop.dao.legend.shop.O2oShopDetailDao;
import com.nhs.shop.dao.legend.shop.ProdDao;
import com.nhs.shop.dao.legend.shop.ShopDao;
import com.nhs.shop.dao.legend.shop.ShopDetailDao;
import com.nhs.shop.entry.legend.collect.Collect;
import com.nhs.shop.entry.legend.region.Areas;
import com.nhs.shop.entry.legend.region.City;
import com.nhs.shop.entry.legend.service.O2oCategory;
import com.nhs.shop.entry.legend.shop.FavoriteShop;
import com.nhs.shop.entry.legend.shop.O2oShopDetail;
import com.nhs.shop.entry.legend.shop.Prod;
import com.nhs.shop.entry.legend.shop.ShopDetail;
import com.nhs.shop.entry.legend.user.UsrDetail;
import com.nhs.shop.service.BaseService;
import com.nhs.shop.service.collect.dto.CollectDto;
import com.nhs.shop.service.goods.GoodsPromoService;
import com.nhs.shop.service.goods.GoodsService;
import com.nhs.shop.service.goods.GoodsTagsService;
import com.nhs.shop.service.goods.dto.GoodsTagDto;
import com.nhs.shop.service.o2o.calculate.CalO2oPromotionService;
import com.nhs.shop.service.shop.CalO2oShopPromotionService;
import com.nhs.shop.service.shop.ShopService;
import com.nhs.shop.service.shop.dto.ShopDto;
import com.nhs.shop.service.system.SystemParameterService;
import com.nhs.user.service.UserService;

/**
 * 我的收藏service
 * 
 * @Title: CollectService.java
 * @Package com.nhs.shop.service.collect.dto
 * @Description: TODO
 * @author liangdanhua
 * @date 2016年8月10日 下午11:14:52
 * @version V1.0
 */
@Service
@Transactional
public class CollectService extends BaseService {
	
    private final static Logger logger = LoggerFactory.getLogger(CollectService.class);
    
	@Autowired
    private CollectDao collectDao; // 分类dao

    @Autowired
    private MyCollectDao myCollectDao;

    @Autowired
    private ProdDao prodDao;

    @Autowired
 	private ShopService shopService;

    @Autowired
    private GoodsService goodsService;

    @Autowired
    private UserService userService;

    @Autowired
    private ShopDetailDao shopDetailDao;

    @Autowired
    private ProvincesDao provincesdao;

    @Autowired
    private CityDao cityDao;

    @Autowired
    private FavoriteShopDao favoriteShopDao;

    @Autowired
    private ShopDao shopDao;

    @Autowired
    private AreasDao areasDao;

    @Autowired
    private O2oServiceOrderDao o2oServiceOrderDao;

    @Autowired
    private O2oShopDetailDao o2oShopDetailDao;

    @Autowired
    private O2oCategoryDao o2oCategoryDao;

    @Autowired
    private SystemParameterService sysService;
    
    @Autowired
    private CalO2oShopPromotionService o2oPromotionService;

    @Autowired
    private GoodsTagsService goodsTagsService;
    
    @Autowired
    private GoodsPromoService goodsPromoService;
    
    @Autowired
    private CalO2oPromotionService calO2oPromotionService;
    
    /**
     * 查询我的收藏商品
     * @Title: getMyCollectList
     * @Description: TODO
     * @param @param page
     * @param @param userId
     * @param @return   
     * @return List<CollectDto> 
     * @author liangdanhua 2016年8月22日 
     * @throws
     */
    @Deprecated
    public List<CollectDto> getMyCollectList(Page<Map<String, Object>> page, String userId) {
        List<CollectDto> list = Lists.newArrayList();
        Page<Map<String, Object>> collectMap = collectDao.getMyCollectList(userId, page);
        CollectDto collectDto = null;
        for (Map<String, Object> map : collectMap.getResult()) {
            collectDto = new CollectDto();
            collectDto.setId(StringHelper.objectToInt(map.get("id"), 0));
            collectDto.setProdId(StringHelper.objectToInt(map.get("prod_id"), 0));
            collectDto.setUserId(StringHelper.objectToString(map.get("user_id"), ""));
            collectDto.setAddTime((Date) map.get("addtime"));
            collectDto.setUserName(StringHelper.objectToString(map.get("user_name"), ""));
            String isCar = (String) map.get("is_car");

            if (StringUtils.isBlank(isCar)) {
                collectDto.setDetailUrl(SysPropsFactory.getProperty("goodsDetailUrl")
                        + StringHelper.objectToInt(map.get("prod_id"), 0));
            } else {
                collectDto.setDetailUrl(
                        SysPropsFactory.getProperty("carDetailUrl") + StringHelper.objectToInt(map.get("prod_id"), 0));
            }
            Prod prop = prodDao.findOne(StringHelper.objectToInt(map.get("prod_id"), 0));
            if (prop == null) {
                continue;
            } else {
                collectDto.setName(prop.getName());
                collectDto.setPic(buildImg(prop.getPic()));
                ShopDetail shopDetail = shopDetailDao.findShopDetail(userId);
                if (shopDetail != null && shopDetail.getCityid() != null) {
                    City city = cityDao.findOne(shopDetail.getCityid());
                    if (city != null) {
                        collectDto.setShopaddr(city.getCity());
                    }
                }
                collectDto.setCash((prop.getCash().setScale(2, BigDecimal.ROUND_DOWN)).toString());
                if (prop.getCash().intValue() >= 10000) {
                    BigDecimal cash = (prop.getCash().divide(new BigDecimal(10000))).setScale(2, BigDecimal.ROUND_DOWN);
                    // 补贴
                    double rebate = StringHelper.objectToDouble(map.get("rebate"), 1.0);
                    collectDto.setRebate(new BigDecimal(ArithUtils.mul(cash.doubleValue(), rebate))
                            .setScale(2, BigDecimal.ROUND_DOWN).toString());
                    collectDto.setSubsidyStr(sysService.getSingleValueByType(NhsConstant.PARAM_PRESENT_SIGN)
                            + sysService.getSingleValueByType(NhsConstant.PARAM_RMB_ICON) + collectDto.getRebate());
                    collectDto.setCash(cash.toString());
                    collectDto.setLg("万");
                } else {
                    // 补贴
                    double rebate = StringHelper.objectToDouble(map.get("rebate"), 1.0);
                    collectDto.setCash((prop.getCash().setScale(2, BigDecimal.ROUND_DOWN)).toString());
                    collectDto.setLg("");
                    collectDto.setRebate(
                            new BigDecimal(ArithUtils.mul(StringHelper.objectToDouble(prop.getCash(), 0.0), rebate))
                                    .setScale(2, BigDecimal.ROUND_DOWN).toString());

                    collectDto.setSubsidyStr(sysService.getSingleValueByType(NhsConstant.PARAM_PRESENT_SIGN)
                            + sysService.getSingleValueByType(NhsConstant.PARAM_RMB_ICON) + collectDto.getRebate());
                }
                if (StringUtils.isNotBlank(isCar)) {
                    collectDto.setLg("万起");
                }
                collectDto.setBuys(prop.getBuys());
                // 补贴
                collectDto.setSupporttransportfree(prop.getSupportTransportFree());
                // TODO liangdanhua 获取真实运费
                String mailStatus = goodsService.calculatePostage(prop.getProdId().toString(), userId);
                collectDto.setMailStatus(mailStatus);
                list.add(collectDto);
            }
        }
        return list;
    }

    /**
     * 查询我的收藏商品
     * @Title: 
     * @param @param page
     * @param @param userId
     * @param @return   
     * @return List<CollectDto> 
     * @author wind.chen 2016年11月06日 
     * @throws
     */
    public List<CollectDto> getMyFavoriteProdList(Page<Map<String, Object>> page, String userId) {
    	 List<CollectDto> list = Lists.newArrayList();
         Page<Map<String, Object>> collectMap = collectDao.getMyCollectList(userId, page);
         CollectDto collectDto = null;
         for (Map<String, Object> map : collectMap.getResult()) {
             collectDto = new CollectDto();
             collectDto.setId(StringHelper.objectToInt(map.get("id"), 0));
             collectDto.setProdId(StringHelper.objectToInt(map.get("prod_id"), 0));
             collectDto.setUserId(StringHelper.objectToString(map.get("user_id"), ""));
             collectDto.setAddTime((Date) map.get("addtime"));
             collectDto.setUserName(StringHelper.objectToString(map.get("user_name"), ""));
             String isCar = (String) map.get("is_car");

             if (StringUtils.isBlank(isCar)) {
                 collectDto.setDetailUrl(SysPropsFactory.getProperty("goodsDetailUrl")
                         + StringHelper.objectToInt(map.get("prod_id"), 0));
             } else {
                 collectDto.setDetailUrl(
                         SysPropsFactory.getProperty("carDetailUrl") + StringHelper.objectToInt(map.get("prod_id"), 0));
             }
             Prod prop = prodDao.findOne(StringHelper.objectToInt(map.get("prod_id"), 0));
             if (prop == null) {
                 continue;
             } else {
                 collectDto.setName(prop.getName());
                 collectDto.setPic(buildImg(prop.getPic()));
                 ShopDetail shopDetail = shopDetailDao.findShopDetail(userId);
                 if (shopDetail != null && shopDetail.getCityid() != null) {
                     City city = cityDao.findOne(shopDetail.getCityid());
                     if (city != null) {
                         collectDto.setShopaddr(city.getCity());
                     }
                 }
                 //汽车设置 xxx万起
                 if (StringUtils.isNotBlank(isCar)) {
                	 logger.debug("收藏:处理汽车商品." + prop.getProdId());
                	 if (prop.getCash().intValue() >= 10000) {
                         BigDecimal cash = (prop.getCash().divide(new BigDecimal(10000))).setScale(2, BigDecimal.ROUND_DOWN);
                         collectDto.setCash(cash.toString());
                         collectDto.setLg("万起");
                     }
                 }else{
                	 logger.debug("收藏:普通商品." + prop.getProdId());
                	 collectDto.setCash((prop.getCash().setScale(2, BigDecimal.ROUND_DOWN)).toString());
                     collectDto.setLg("");
                 }
                 collectDto.setBuys(prop.getBuys());
                 BigDecimal rebate = this.goodsPromoService.getBRebate(prop, 2);
                 collectDto.setRebate(rebate.toString());                 
                 GoodsTagDto goodTag = this.goodsTagsService.getProdDimTag(prop, userId);
                 collectDto.setSubsidyStr(goodTag.getSubsidyTag());
                 collectDto.setMailStatus(goodTag.getPostageDesc());
                 collectDto.setReducedCashTag(goodTag.getReducedCashTag());
                 list.add(collectDto);
             }
         }
         return list;
    }

    /**
     * 收藏商品
     * 
     * @Title: getMyCollectList
     * @Description: TODO
     * @param prodid
     * @param userId
     * @param username
     * @author liangdanhua 2016年8月10日 @throws
     */
    public void saveMyCollect(int prodid, String userId, String username, String isCar) {
        Prod prod = prodDao.findOne(prodid);
        if (prod == null) {
            throw new WebRequestException("商品不存在");
        }
        UsrDetail user = this.userService.findUserById(userId);
        if (user == null) {
            throw new WebRequestException("用户不存在");
        }
        Collect collect = myCollectDao.findCollect(prodid, userId);
        if (collect == null) {
            collect = new Collect();
            collect.setAddTime(new Date());
            collect.setProdId(prodid);
            collect.setUserName(username);
            collect.setUserId(userId);
            collect.setIsCar(isCar);
            myCollectDao.save(collect);
        } else {
            myCollectDao.saveAndFlush(collect);
        }
    }

    /**
     * 收藏商品
     * 
     * @Title: deleteMyCollect
     * @Description: TODO
     * @param prodid
     * @param userId
     * @param username
     * @author liangdanhua 2016年8月11日 @throws
     */
    public void deleteMyCollect(int prodid, String userId, String username) {
        Prod prod = prodDao.findOne(prodid);
        if (prod == null) {
            throw new WebRequestException("商品不存在");
        }
        UsrDetail user = this.userService.findUserById(userId);
        if (user == null) {
            throw new WebRequestException("用户不存在");
        }
        Collect collect = myCollectDao.findCollect(prodid, userId);
        if (collect != null) {
            myCollectDao.delete(collect);
        }
    }

    /**
     * 收藏店铺
     * @param shopId
     * @param userId
     * @param username
     */
    public void saveStoreToFavorite(int shopId, String userId, String username) {
        List<FavoriteShop> favoriteShopList = favoriteShopDao.findByShopIdAndUserId(shopId, userId);
        if (favoriteShopList == null || favoriteShopList.size() == 0) {
            FavoriteShop shop = new FavoriteShop();
            shop.setRecDate(new Date());
            shop.setShopId(shopId);
            shop.setUserName(username);
            shop.setUserId(userId);
            favoriteShopDao.save(shop);
        }
    }

    /**
     * 移除店铺收藏
     * @param shopId
     * @param userId
     * @param username
     */
    public void deleteFavoriteStore(String[] shopIdList, String userId) {
        for (String shopId : shopIdList) {
            List<FavoriteShop> favoriteShopList = favoriteShopDao.findByShopIdAndUserId(Integer.parseInt(shopId),
                    userId);
            if (favoriteShopList != null && favoriteShopList.size() > 0) {
                for (FavoriteShop shop : favoriteShopList) {
                    favoriteShopDao.delete(shop);
                }
            }
        }
    }

    /**
     * 查询收藏得店铺列表
     * @param userId
     * @param cityId
     * @param lng
     * @param lat
     * @param page
     * @return
     */
    @Deprecated
    public List<ShopDto> searchFavoriteStore(String userId, Integer cityId, Double lng, Double lat,
            Page<Map<String, Object>> page) {
        List<FavoriteShop> favoriteShopList = favoriteShopDao.findByUserId(userId);
        List<Integer> shopIdList = new ArrayList<>();
        if (favoriteShopList != null && favoriteShopList.size() > 0) {
            for (FavoriteShop favoriteShop : favoriteShopList) {
                shopIdList.add(favoriteShop.getShopId());
            }
        }
        if (favoriteShopList == null || favoriteShopList.size() == 0) {
            return new ArrayList<ShopDto>();
        } else {
            Page<Map<String, Object>> pageData = shopDao.getMyFavoriteShop(shopIdList, lng, lat, page);
            List<Map<String, Object>> shopList = pageData.getResult();
            return getFavoriteStoreList(shopList,0);
        }

    }

    private List<ShopDto> getFavoriteStoreList(List<Map<String, Object>> shopList,int type) {
        List<ShopDto> list = Lists.newArrayList();
        ShopDto shopDto = null;
        Map<Integer, Areas> areaMap = initAreaMap();
        Map<Integer, O2oCategory> categoryMap = initO2oCategoryMap();
        for (Map<String, Object> shopMap : shopList) {
            shopDto = new ShopDto();
            shopDto.setShopId(StringHelper.objectToInt(shopMap.get("shop_id"), 0));
            shopDto.setShopTitle(StringHelper.objectToString(shopMap.get("site_name"), ""));
            shopDto.setAddress(StringHelper.objectToString(shopMap.get("shop_addr"), ""));
            long totalOrderNum = o2oServiceOrderDao
                    .countByShopIdAndStatus(StringHelper.objectToInt(shopMap.get("shop_id"), 0));
            shopDto.setTotalOrderNum(String.valueOf(totalOrderNum));

            O2oShopDetail o2oShopDetail2 = o2oShopDetailDao.findO2oShopDetailByshopId(shopDto.getShopId());

            if (o2oShopDetail2 != null) {
                shopDto.setConsumePer(o2oShopDetail2.getPerCost() == null ? 0 : o2oShopDetail2.getPerCost().intValue());
            } else {
                shopDto.setConsumePer(0);
            }
            // shopDto.setConsumePer(Integer.parseInt(String.valueOf(totalOrderNum)));
            shopDto.setAverage(StringHelper.objectToString(shopMap.get("ave"), ""));

            Double distance = StringHelper.objectToDouble(shopMap.get("distance"), 0);

            shopDto.setDistance(distance);

            if (distance >= 1000) {
                BigDecimal dis = new BigDecimal(distance).divide(new BigDecimal(1000), 2, BigDecimal.ROUND_HALF_UP);
                shopDto.setDistanceWithUnit(String.valueOf(dis) + "km");
            } else {
                shopDto.setDistanceWithUnit(String.valueOf(distance.intValue()) + "m");
            }

            ShopDetail shop = shopDetailDao.findOne(shopDto.getShopId());
            if (shop == null) {
               shop = new ShopDetail();
            }
            
            if(type == 0){
            	//兼容老版本
            	o2oPromotionService.calShopCoupon(shopDto, shop);
            }else{
            	//1.9.3的新计算规则
            	calO2oPromotionService.calShopCoupon(shopDto, shop);
            }
            
            shopDto.setStarNum(5);
            shopDto.setPic(this.buildImg(StringHelper.objectToString(shopMap.get("shop_pic2"), "")));

            Areas area = areaMap.get(StringHelper.objectToString(shopMap.get("areaid"), ""));
            if (area != null) {
                shopDto.setArea(area.getArea());
            }
            O2oCategory category = categoryMap.get(StringHelper.objectToInt((shopMap.get("category_id")), 0));
            if (category != null) {
                shopDto.setCategory(category.getName());
            }
            // 商家补贴暂时默认为100%
            // shopDto.setSubsidy("100%");
            shopDto.setSubsidyStr(
                    sysService.getSingleValueByType(NhsConstant.PARAM_PRESENT_SIGN) + shopDto.getSubsidy());
            shopDto.setLat(StringHelper.objectToDouble(shopMap.get("lat"), 0.0));
            shopDto.setLng(StringHelper.objectToDouble(shopMap.get("lng"), 0.0));
            list.add(shopDto);
        }
        return list;
    }

    /**
     * 初始化区域map
     * @Title: initAreaMap
     * @Description: TODO
     * @param @return   
     * @return Map<Integer,Areas> 
     * @author Administrator 2016年7月23日 
     * @throws
     */
    private Map<Integer, Areas> initAreaMap() {
        List<Areas> areaList = areasDao.findAreas();
        Map<Integer, Areas> map = Maps.newHashMap();
        for (Areas area : areaList) {
            map.put(area.getId(), area);
        }
        return map;
    }

    /**
     * 初始化分类map
     * @Title: initO2oCategoryMap
     * @Description: TODO
     * @param @return   
     * @return Map<Integer,O2oCategory> 
     * @author Administrator 2016年7月23日 
     * @throws
     */
    private Map<Integer, O2oCategory> initO2oCategoryMap() {
        List<O2oCategory> list = o2oCategoryDao.findO2oCategory();
        Map<Integer, O2oCategory> map = Maps.newHashMap();
        for (O2oCategory c : list) {
            map.put(c.getId(), c);
        }
        return map;
    }
    
    
    /**
     * 查询收藏得店铺列表(v1.9.3 计算规则变化)
     * @param userId
     * @param cityId
     * @param lng
     * @param lat
     * @param page
     * @return
     */
    public List<ShopDto> searchFavoriteStoreList(String userId, Integer cityId, Double lng, Double lat,
            Page<Map<String, Object>> page) {
        List<FavoriteShop> favoriteShopList = favoriteShopDao.findByUserId(userId);
        List<Integer> shopIdList = new ArrayList<>();
        if (favoriteShopList != null && favoriteShopList.size() > 0) {
            for (FavoriteShop favoriteShop : favoriteShopList) {
                shopIdList.add(favoriteShop.getShopId());
            }
        }
        if (favoriteShopList == null || favoriteShopList.size() == 0) {
            return new ArrayList<ShopDto>();
        } else {
            Page<Map<String, Object>> pageData = shopDao.getMyFavoriteShop(shopIdList, lng, lat, page);
            List<Map<String, Object>> shopList = pageData.getResult();
            return getFavoriteStoreList(shopList,1);
        }

    }

}
