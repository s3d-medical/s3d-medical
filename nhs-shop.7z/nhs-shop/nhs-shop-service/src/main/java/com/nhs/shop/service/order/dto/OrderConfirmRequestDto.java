package com.nhs.shop.service.order.dto;

import java.io.Serializable;
import java.util.List;

import com.google.common.collect.Lists;

/**
 * 订单确认请求数据DTO
 * @Title: OrderConfirmRequestDto.java
 * @Package com.nhs.o2o.dto
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月19日 下午3:56:15
 * @version V1.0
 */
public class OrderConfirmRequestDto implements Serializable {

    private static final long serialVersionUID = -2262374786071390288L;

    private String userId; // 用户id

    // 如果从商品详情点立即购买，需要传以下三个参数
    private Integer prodId;
    private Integer skuId;
    private Integer count;
    
    private String  transtype;

    public String getTranstype() {
		return transtype;
	}

	public void setTranstype(String transtype) {
		this.transtype = transtype;
	}

	// 如果从购物车结算需要传这个参数
    private List<Integer> basketIdList = Lists.newArrayList();

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Integer getProdId() {
        return prodId;
    }

    public void setProdId(Integer prodId) {
        this.prodId = prodId;
    }

    public Integer getSkuId() {
        return skuId;
    }

    public void setSkuId(Integer skuId) {
        this.skuId = skuId;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public List<Integer> getBasketIdList() {
        return basketIdList;
    }

    public void setBasketIdList(List<Integer> basketIdList) {
        this.basketIdList = basketIdList;
    }

}
