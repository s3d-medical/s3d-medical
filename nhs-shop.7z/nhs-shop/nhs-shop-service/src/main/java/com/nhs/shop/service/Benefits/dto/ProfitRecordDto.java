package com.nhs.shop.service.Benefits.dto;

import java.io.Serializable;
import java.math.BigDecimal;

public class ProfitRecordDto implements Serializable {

    private static final long serialVersionUID = 4280932843504788539L;

    private int id;

    private String shopName;

    private String shopOrder;

    private BigDecimal orderAmount;

    private BigDecimal bomengBrick;

    private String addTime;

    private String slaceId;

    private String slaceNum;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public String getShopOrder() {
        return shopOrder;
    }

    public void setShopOrder(String shopOrder) {
        this.shopOrder = shopOrder;
    }

    public BigDecimal getOrderAmount() {
        return orderAmount;
    }

    public void setOrderAmount(BigDecimal orderAmount) {
        this.orderAmount = orderAmount;
    }

    public BigDecimal getBomengBrick() {
        return bomengBrick;
    }

    public void setBomengBrick(BigDecimal bomengBrick) {
        this.bomengBrick = bomengBrick;
    }

    public String getAddTime() {
        return addTime;
    }

    public void setAddTime(String addTime) {
        this.addTime = addTime;
    }

    public String getSlaceId() {
        return slaceId;
    }

    public void setSlaceId(String slaceId) {
        this.slaceId = slaceId;
    }

    public String getSlaceNum() {
        return slaceNum;
    }

    public void setSlaceNum(String slaceNum) {
        this.slaceNum = slaceNum;
    }

}
