package com.nhs.shop.bindspreader.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;

import com.nhs.shop.bindspreader.entity.BindedSpreader;

/**
 * 代理商
 * @author wind.chen
 */
public interface BindedSpreaderDao extends JpaRepository<BindedSpreader, Integer>,
		PagingAndSortingRepository<BindedSpreader, Integer>, JpaSpecificationExecutor<BindedSpreader>{
	
	@Query(value="select a from BindedSpreader a where a.userMobile= :userMobile")
	public List<BindedSpreader> getBindedAgent(@Param("userMobile") String mobileNo);
	
	public BindedSpreader findByUserMobile(String userMobile);
	
	public BindedSpreader findByUserMobileAndSpreaderType(String userMobile, int spreaderType);
	
}