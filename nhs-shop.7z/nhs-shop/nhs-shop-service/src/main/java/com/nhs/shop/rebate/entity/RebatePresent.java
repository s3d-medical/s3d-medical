package com.nhs.shop.rebate.entity;

import java.math.BigDecimal;

public class RebatePresent {
	
	// 推广费的返回比例
	private BigDecimal fee = new BigDecimal("0.05");

	public BigDecimal getFee() {
		return fee;
	}

	public void setFee(BigDecimal fee) {
		this.fee = fee;
	}
	

}
