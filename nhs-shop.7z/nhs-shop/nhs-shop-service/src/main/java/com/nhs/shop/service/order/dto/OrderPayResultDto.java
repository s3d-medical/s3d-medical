package com.nhs.shop.service.order.dto;

import java.io.Serializable;

/**
 * 订单支付结果
 * @author wind.chen
 *
 */
public class OrderPayResultDto implements Serializable{
	private static final long serialVersionUID = 5674343107013668909L;
	private String orderno; // 支付平台订单号
	private String platformid; // 支付平台id [100-易宝PC,101-微信支付,102-支付宝支付，103-易宝一键支付]
	private String paymentmode; // 支付方式，[1-线上支付，2-pos支付]
	private String money;// 金额
	private String paystate;// 支付状态 1-成功 其他失败
	private String partnerorderno; // 商户自己的订单号
	private String sign; // 签名
	
	public String getOrderno() {
		return orderno;
	}
	public void setOrderno(String orderno) {
		this.orderno = orderno;
	}
	public String getPlatformid() {
		return platformid;
	}
	public void setPlatformid(String platformid) {
		this.platformid = platformid;
	}
	public String getPaymentmode() {
		return paymentmode;
	}
	public void setPaymentmode(String paymentmode) {
		this.paymentmode = paymentmode;
	}
	public String getMoney() {
		return money;
	}
	public void setMoney(String money) {
		this.money = money;
	}
	public String getPaystate() {
		return paystate;
	}
	public void setPaystate(String paystate) {
		this.paystate = paystate;
	}
	public String getPartnerorderno() {
		return partnerorderno;
	}
	public void setPartnerorderno(String partnerorderno) {
		this.partnerorderno = partnerorderno;
	}
	public String getSign() {
		return sign;
	}
	public void setSign(String sign) {
		this.sign = sign;
	}
	public boolean ifSuccessfulPay() {
		if ("1".equals(paystate)) {
			return true;
		}
		return false;
	}
}
