package com.nhs.shop.service.system;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nhs.core.common.NhsConstant;
import com.nhs.core.utils.common.MapUtils;
import com.nhs.shop.dao.system.SystemParameterDao;
import com.nhs.shop.entry.system.SystemParameter;
import com.nhs.shop.service.BaseService;
import com.nhs.shop.service.system.dto.sysconfig.AppServersConfigDto;
import com.nhs.shop.service.system.dto.sysconfig.GlLabelConfigDto;
import com.nhs.shop.service.system.dto.sysconfig.GlUpdateInfoDto;
import com.nhs.shop.service.system.dto.sysconfig.OrderConfigDto;
import com.nhs.shop.service.system.dto.sysconfig.PayConfigDto;
import com.nhs.shop.service.system.dto.sysconfig.RateConfigDto;
import com.nhs.shop.service.system.dto.sysconfig.SysConfigDto;

/**
 * 系统参数配置
 * @author wind.chen
 */
@Service
@Transactional
public class SystemParameterService extends BaseService {

    private SystemParameterDao sysDao;
    
    private PropFileParamService propService;
    
    /**
     * 获取单个的配置值
     * @param type
     * @return
     */
    public String getSingleValueByType(String type) {
        List<SystemParameter> paramList = sysDao.findByTypeAndState(type, 0);
        if(paramList != null && paramList.size() > 0){
        	SystemParameter param = paramList.get(0);
        	return param.getKeyValue();
        }
        return ""; 
    }
    
    private SysConfigDto getSysConfig(String os, String curVer){
    	SysConfigDto sysConfig = new SysConfigDto();
    	//全局参数
    	sysConfig.setGlUpdateInfo(this.getGlUpdateInfo(os, curVer));
    	//全局label配置.
    	sysConfig.setGlLabelConfig(this.getGlLabelConfig(os, curVer));
    	//订单配置. 
    	sysConfig.setOrderConfig(this.getOrderConfig(os, curVer));
    	//支付配置.
    	sysConfig.setPayConfig(this.getPayConfig(os, curVer));
    	//app连接的服务器列表
    	sysConfig.setAppServersConfig(this.getAppServersConfig(os, curVer));
    	sysConfig.setRateConfig(this.getRateConfig(os, curVer));
    	return sysConfig;
    }
    
    
    public Map<String, Object> getSysConfigInMap(String os, String curVer){
    	Map<String, Object> result = new HashMap<String, Object>();
    	SysConfigDto sysConfig = this.getSysConfig(os, curVer);
    	if(sysConfig != null){
    		result = MapUtils.toMap(sysConfig);
    	}
    	return result;
    }
    
    
    private RateConfigDto getRateConfig(String os, String curVer){
    	RateConfigDto rateConfigDto = new RateConfigDto();
    	rateConfigDto.setRmbGoldExchageRate(propService.getRmbExchageRate());
    	return rateConfigDto;
    }
    
    /**
     * 获取全局标签的配置.
     * @Title: getGlLabelConfig
     * @Desc: 
     * @author wind.chen 2016年11月24日 下午4:39:24
     *
     * @param os
     * @param curVer
     * @return
     * @throws
     */
    private GlLabelConfigDto getGlLabelConfig(String os, String curVer){
    	GlLabelConfigDto glLabelConfig = new GlLabelConfigDto();
    	glLabelConfig.setGoldName(getSingleValueByType(NhsConstant.PARAM_GOLD_NAME));
    	glLabelConfig.setSilverName(getSingleValueByType(NhsConstant.PARAM_SILVER_NAME));
    	return glLabelConfig;
    }
    /**
     * 获取app升级配置.
     * @Title: getGlUpdateInfo
     * @Desc: 
     * @author wind.chen 2016年11月24日 下午4:39:36
     *
     * @param os
     * @param curVer
     * @return
     * @throws
     */
    @Deprecated
    private GlUpdateInfoDto getGlUpdateInfo(String os, String curVer){
    	 GlUpdateInfoDto glUpdateInfo = null;
    	 // follow current logic. only care forceupdate or not. 
    	 String needUpdate = getSingleValueByType(NhsConstant.PARAM_IOS_NEED_UPDATE).toUpperCase();
    	 if("y".equals(needUpdate)){
    		 glUpdateInfo = new  GlUpdateInfoDto();
        	 glUpdateInfo.setUpdateWay("forceUpdate");
    		 glUpdateInfo.setNewAppVer("");
        	 glUpdateInfo.setUpdateUrl("");
    	 }
    	 return glUpdateInfo;
    }
    
    /**
     * 获取订单模块的配置.
     * @Title: getOrderConfig
     * @Desc: 
     * @author wind.chen 2016年11月24日 下午4:40:00
     *
     * @param os
     * @param curVer
     * @return
     * @throws
     */
    private OrderConfigDto getOrderConfig(String os, String curVer){
    	// handle order callback URL.
    	OrderConfigDto config = new OrderConfigDto();
    	OrderConfigDto.OrderCallBackUrls callbackUrls = new OrderConfigDto.OrderCallBackUrls();
    	callbackUrls.setHandleOrderAfterPay(propService.getCkUrlOfHandlePayedOrder());
    	config.setCallbackUrls(callbackUrls);
    	return config;
    }
    
    private PayConfigDto getPayConfig(String os, String curVer){
    	// pay result redirect URL.
    	PayConfigDto payConfig = new PayConfigDto();
    	PayConfigDto.PayRedirectUrls payRedirectUrls = new PayConfigDto.PayRedirectUrls();
    	payRedirectUrls.setPayOrderResult(propService.getRdUrlAfterPay());
    	payConfig.setRedirectUrls(payRedirectUrls);
    	return payConfig;
    }
    
    /**
     * 
     * @Title: getAppServersConfig
     * @Desc: 
     * @author wind.chen 2016年12月16日 下午2:57:10
     *
     * @param os
     * @param curVer
     * @return
     * @throws
     */
    private AppServersConfigDto getAppServersConfig(String os, String curVer){
    	AppServersConfigDto config = new AppServersConfigDto();
    	config.setHostApi(this.propService.getHostApi());
    	config.setHostH5(propService.getHostH5());
    	config.setHostMember(propService.getHostMember());
    	config.setHostPay(propService.getHostPay());
    	config.setHostSearch(propService.getHostSearch());
    	config.setHostImg(propService.getHostImg());
    	return config;
    }
    
    @Autowired
	public void setSysDao(SystemParameterDao sysDao) {
		this.sysDao = sysDao;
	}

    @Autowired
	public void setPropService(PropFileParamService propService) {
		this.propService = propService;
	}
}
