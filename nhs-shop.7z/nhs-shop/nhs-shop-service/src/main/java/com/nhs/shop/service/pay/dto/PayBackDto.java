package com.nhs.shop.service.pay.dto;

import java.math.BigDecimal;

public class PayBackDto {
	
	//支付平台订单号
	private String orderno;
	
	//支付平台id
	private Integer platformid;
	
	//支付方式
	private BigDecimal money;
	
	//金额
	private String paymentmode;
	
	//支付状态 1-成功 其他失败
	private String paystate;
	
	//商户自己的订单号
	private String partnerorderno;
	
	//签名
	private String sign;

	public String getOrderno() {
		return orderno;
	}

	public void setOrderno(String orderno) {
		this.orderno = orderno;
	}

	public Integer getPlatformid() {
		return platformid;
	}

	public void setPlatformid(Integer platformid) {
		this.platformid = platformid;
	}

	public BigDecimal getMoney() {
		return money;
	}

	public void setMoney(BigDecimal money) {
		this.money = money;
	}

	public String getPaymentmode() {
		return paymentmode;
	}

	public void setPaymentmode(String paymentmode) {
		this.paymentmode = paymentmode;
	}

	public String getPaystate() {
		return paystate;
	}

	public void setPaystate(String paystate) {
		this.paystate = paystate;
	}

	public String getPartnerorderno() {
		return partnerorderno;
	}

	public void setPartnerorderno(String partnerorderno) {
		this.partnerorderno = partnerorderno;
	}

	public String getSign() {
		return sign;
	}

	public void setSign(String sign) {
		this.sign = sign;
	}
	
	
	
}
