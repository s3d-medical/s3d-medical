package com.nhs.shop.service.o2oshop.comment;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import com.google.common.collect.Lists;
import com.nhs.core.context.SysPropsFactory;
import com.nhs.core.orm.Page;
import com.nhs.core.utils.common.DateUtils;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.shop.dao.legend.o2oshop.comment.O2oShopCommentDao;
import com.nhs.shop.dao.legend.o2oshop.comment.O2oShopCommentImageJPADao;
import com.nhs.shop.dao.legend.o2oshop.comment.O2oShopCommentJPADao;
import com.nhs.shop.dao.legend.o2oshop.comment.O2oShopCommentLikeJPADao;
import com.nhs.shop.dao.legend.service.O2oServiceOrderDao;
import com.nhs.shop.dao.legend.shop.ShopDetailDao;
import com.nhs.shop.entry.em.order.ServiceOrderStatusEnum;
import com.nhs.shop.entry.legend.o2oshop.comment.O2oShopComment;
import com.nhs.shop.entry.legend.o2oshop.comment.O2oShopCommentImage;
import com.nhs.shop.entry.legend.o2oshop.comment.O2oShopCommentLike;
import com.nhs.shop.entry.legend.service.O2oServiceOrder;
import com.nhs.shop.entry.legend.shop.ShopDetail;
import com.nhs.shop.entry.legend.user.UsrDetail;
import com.nhs.shop.service.BaseService;
import com.nhs.shop.service.o2oshop.comment.dto.O2oShopCommentDto;
import com.nhs.user.service.UserService;

/**
 * 
 * @author liguangrong
 *
 */
@Service
@Transactional
public class O2oShopCommentService extends BaseService {

    @Autowired
    private O2oShopCommentDao commonDao;

    @Autowired
    private O2oShopCommentImageJPADao commentImageDao;

    @Autowired
    private O2oShopCommentJPADao commentDao;

    @Autowired
    private O2oShopCommentLikeJPADao commentLikeDao;

    @Autowired
    private O2oServiceOrderDao o2oServiceOrderDao;

    @Autowired
    private ShopDetailDao shopDetailDao;

    @Autowired
    private UserService userService;

    @Transactional
    public void addComment(List<String> images, O2oShopCommentDto commentDto) {
        O2oShopComment o2oShopComment = new O2oShopComment();
        
        String userId = commentDto.getUserId();
        // TODO 将Nick保存到comments表中
        if (StringUtils.isNotBlank(userId)){
            UsrDetail usrDetail = this.userService.findUserById(userId);
            o2oShopComment.setCommentBy(StringUtils.isEmpty(usrDetail.getNickName()) ? usrDetail.getUserName() : usrDetail.getNickName());
        }
        o2oShopComment.setUserId(userId);
        
        o2oShopComment.setCommentContent(commentDto.getCommentContent());
        o2oShopComment.setCommentStatus(0);
        o2oShopComment.setCommentTime(new Date());
        o2oShopComment.setShopId(commentDto.getShopId());
        o2oShopComment.setScore(commentDto.getScore());
        o2oShopComment.setOrderNum(commentDto.getOrderNum());
        commentDao.save(o2oShopComment);

        if (images != null) {
            O2oShopCommentImage commentImage = null;
            for (String image : images) {
                commentImage = new O2oShopCommentImage();
                commentImage.setCommentId(o2oShopComment.getId());
                commentImage.setCommentImage(image);
                commentImage.setStatus(0);
                commentImage.setAddTime(new Date());
                commentImageDao.save(commentImage);
            }
        }
        O2oServiceOrder so = o2oServiceOrderDao.findO2oServiceOrderByOrderNum(commentDto.getOrderNum());
        so.setStatus(ServiceOrderStatusEnum.COMMENT.getStatus());
        o2oServiceOrderDao.save(so);
    }

    public void deleteLike(String userId, int commentId) {
        List<O2oShopCommentLike> userLikeList = commentLikeDao.findByCommentIdAndUserId(commentId, userId);
        for (O2oShopCommentLike userLike : userLikeList) {
            commentLikeDao.delete(userLike);
        }
    }

    public void addLike(String userId, int commentId) {
        O2oShopCommentLike userLike = new O2oShopCommentLike();
        userLike.setUserId(userId);
        userLike.setCommentId(commentId);
        userLike.setAddTime(new Date());
        commentLikeDao.save(userLike);
    }

    public boolean findLikeStatus(String userId, int commentId) {
        List<O2oShopCommentLike> userLikeList = commentLikeDao.findByCommentIdAndUserId(commentId, userId);
        if (userLikeList.size() > 0) {
            return true;
        }
        return false;
    }

    public long countByType(int shopId, int type) {
        Map<String, Object> map = commonDao.countCommentWithType(shopId, type);
        Long cnt = map.get("commentCount") == null ? 0 : (Long) map.get("commentCount");
        return cnt.longValue();
    }

    public long countByTypeAndUserId(String userId, int type) {
        Map<String, Object> map = commonDao.countCommentWithTypeByUserId(userId, type);
        Long cnt = map.get("commentCount") == null ? 0 : (Long) map.get("commentCount");
        return cnt.longValue();
    }

    /**
     * 获取评价列表
     * @param shopId
     * @param type
     * @param page
     * @param userId
     * @return
     */
    public List<O2oShopCommentDto> getShopCommentList(int shopId, int type, Page<Map<String, Object>> page,
            String userId, String findType) {

        Page<Map<String, Object>> pageData = null;
        if (StringUtils.isBlank(findType)) {
            pageData = commonDao.getCommentListByType(shopId, type, page);
        } else {
            pageData = commonDao.getCommentListByType(userId, type, page);
        }
        List<Map<String, Object>> commentList = pageData.getResult();
        List<O2oShopCommentDto> commentDtoList = Lists.newArrayList();
        for (Map<String, Object> map : commentList) {
            O2oShopCommentDto commentDto = new O2oShopCommentDto();

            String commentuserId = StringHelper.objectToString(map.get("user_id"), "");
            if (StringUtils.isNotBlank(commentuserId)) {
                UsrDetail usrDeail = this.userService.findUserById(commentuserId);
                String nickname = usrDeail.getNickName();
                String username = usrDeail.getRealName();
                commentDto.setUserName(nickname == null || "".equals(nickname) ? username : nickname);
                String userImage = usrDeail.getPortraitPic();
                commentDto.setUserImage(this.buildImg(userImage));
            }
            commentDto.setUserId(commentuserId);

            commentDto.setCommentContent(StringHelper.objectToString(map.get("comment_content"), ""));
            commentDto.setCommentTimeStr(DateUtils.date2Str((Date) map.get("comment_time"), DateUtils.DATE_FORMAT));
            commentDto.setHasLike(0); // 默认未点赞
            commentDto.setScore(StringHelper.objectToInt(map.get("score"), 1));
            commentDto.setShopId(StringHelper.objectToInt(map.get("shop_id"), 0));
            commentDto.setId(StringHelper.objectToInt(map.get("id"), 0));

            ShopDetail shopDetail = shopDetailDao.findOne(StringHelper.objectToInt(map.get("shop_id"), 0));
            if (shopDetail != null) {
                commentDto.setShopName(shopDetail.getSiteName());
                commentDto.setShopUrl(buildImg(shopDetail.getShopPic2()));
            } else {
                commentDto.setShopName("");
                commentDto.setShopUrl("");
            }

            // 获取评论的图片
            List<O2oShopCommentImage> imageList = commentImageDao.findByCommentIdAndStatus(commentDto.getId(), 0);
            List<String> imagePathList = new ArrayList<>();
            for (O2oShopCommentImage image : imageList) {
                String imagePath = image.getCommentImage();
                if (StringUtils.isNotBlank(imagePath) && imagePath.indexOf("http:") < 0) {
                    imagePath = SysPropsFactory.getProperty("imgServer") + "/" + imagePath;
                }
                if (StringUtils.isNotBlank(imagePath)) {
                    imagePathList.add(imagePath);
                }
            }
            commentDto.setImagesList(imagePathList);
            // 获取点赞数
            Long countLike = commentLikeDao.countByCommentId(commentDto.getId());
            commentDto.setLikeCount(countLike == null ? 0 : countLike.intValue());

            // 获取自己的点赞状态
            List<O2oShopCommentLike> likeList = commentLikeDao.findByCommentIdAndUserId(commentDto.getId(), userId);
            if (likeList != null && likeList.size() > 0) {
                commentDto.setHasLike(1); // 1代表已经点过赞
            }
            commentDtoList.add(commentDto);
        }
        return commentDtoList;
    }

    /**
     * 商家详情的评价 最多显示3条 - 评价显示规则：好评度高（优先级1），图片多（优先级2），评价内容多（优先级3）
     * @param shopId
     * @param type
     * @param page
     * @param userId
     * @return
     */
    public List<O2oShopCommentDto> getShopCommentListForShopDetail(int shopId) {

        List<Map<String, Object>> commentList = commonDao.getCommentListForShopDetail(shopId);
        List<O2oShopCommentDto> commentDtoList = Lists.newArrayList();
        for (Map<String, Object> map : commentList) {
            O2oShopCommentDto commentDto = new O2oShopCommentDto();
            String userId = StringHelper.objectToString(map.get("user_id"), "");
            if (StringUtils.isNotBlank(userId)) {
                UsrDetail usrDeail = this.userService.findUserById(userId);
                String nickname = usrDeail.getNickName();
                String username = usrDeail.getRealName();
                commentDto.setUserName(nickname == null || "".equals(nickname) ? username : nickname);
                String userImage = usrDeail.getPortraitPic();
                commentDto.setUserImage(this.buildImg(userImage));
            }
            commentDto.setCommentContent(StringHelper.objectToString(map.get("comment_content"), ""));
            commentDto.setCommentTimeStr(DateUtils.date2Str((Date) map.get("comment_time"), DateUtils.DATE_FORMAT));
            commentDto.setUserId(StringHelper.objectToString(map.get("user_id"), ""));
            commentDto.setScore(StringHelper.objectToInt(map.get("score"), 1));
            commentDto.setShopId(StringHelper.objectToInt(map.get("shop_id"), 0));
            commentDto.setId(StringHelper.objectToInt(map.get("id"), 0));
            commentDto.setUserId(userId);
            
            // 获取评论的图片
            List<O2oShopCommentImage> imageList = commentImageDao.findByCommentIdAndStatus(commentDto.getId(), 0);
            List<String> imagePathList = new ArrayList<>();
            for (O2oShopCommentImage image : imageList) {
                String imagePath = image.getCommentImage();
                if (StringUtils.isNotBlank(imagePath) && imagePath.indexOf("http:") < 0) {
                    imagePath = SysPropsFactory.getProperty("imgServer") + "/" + imagePath;
                }
                if (StringUtils.isNotBlank(imagePath)) {
                    imagePathList.add(imagePath);
                }
            }
            commentDto.setImagesList(imagePathList);
            commentDtoList.add(commentDto);
        }
        return commentDtoList;
    }

    /**
     * 最近一个月内评价数量小于等于3条，按评价时间，降序排序（最新评价显示第一位）。
     * @Title: getShopCommentListForShopDetail2
     * @Description: TODO
     * @param @param shopId
     * @param @return   
     * @return List<O2oShopCommentDto> 
     * @author Administrator 2016年10月14日 
     * @throws
     */
    public List<O2oShopCommentDto> getShopCommentListForShopDetailAll(int shopId) {

        List<Map<String, Object>> commentList = commonDao.getCommentListForShopDetailAll(shopId);
        List<O2oShopCommentDto> commentDtoList = Lists.newArrayList();
        for (Map<String, Object> map : commentList) {
            O2oShopCommentDto commentDto = new O2oShopCommentDto();

            String userId = StringHelper.objectToString(map.get("user_id"), "");
            if (StringUtils.isNotBlank(userId)) {
                UsrDetail usrDetail = this.userService.findUserById(userId);
//                String nickname = usrDetail.getNickName();
//                String username = usrDetail.getRealName();
//                commentDto.setUserName(nickname == null || "".equals(nickname) ? username : nickname);
            	commentDto.setUserName(StringHelper.objectToString(map.get("comment_by"), ""));
                String userImage = usrDetail.getPortraitPic();
                commentDto.setUserImage(this.buildImg(userImage));
            }
            commentDto.setUserId(userId);

            commentDto.setCommentContent(StringHelper.objectToString(map.get("comment_content"), ""));
            commentDto.setCommentTimeStr(DateUtils.date2Str((Date) map.get("comment_time"), DateUtils.DATE_FORMAT));
            commentDto.setScore(StringHelper.objectToInt(map.get("score"), 1));
            commentDto.setShopId(StringHelper.objectToInt(map.get("shop_id"), 0));
            commentDto.setId(StringHelper.objectToInt(map.get("id"), 0));

            // 获取评论的图片
            List<O2oShopCommentImage> imageList = commentImageDao.findByCommentIdAndStatus(commentDto.getId(), 0);
            List<String> imagePathList = new ArrayList<>();
            for (O2oShopCommentImage image : imageList) {
                String imagePath = image.getCommentImage();
                if (StringUtils.isNotBlank(imagePath) && imagePath.indexOf("http:") < 0) {
                    imagePath = SysPropsFactory.getProperty("imgServer") + "/" + imagePath;
                }
                if (StringUtils.isNotBlank(imagePath)) {
                    imagePathList.add(imagePath);
                }
            }
            commentDto.setImagesList(imagePathList);
            commentDtoList.add(commentDto);
        }
        return commentDtoList;
    }

    /**
     * 获取商家的平均分
     */
    public String getShopAveage(int shopId) {
        Map<String, Object> map = commonDao.getShopAveage(shopId);
        BigDecimal res = new BigDecimal("0.0");
        if (map.get("ave") != null) {
            res = (BigDecimal) map.get("ave");
        }
        res = res.setScale(1, BigDecimal.ROUND_HALF_UP);
        return res.toString();
    }

    /**
     * @Title: findCommentByCriteria
     * @Description: 后台评价管理
     * @param @param startDate
     * @param @param endDate
     * @param @param commentBy
     * @param @param shopName
     * @param @param page
     * @param @return   
     * @return List<O2oShopCommentDto> 
     * @author chushubin 2016年11月30日 
     * @throws
     */
    public List<O2oShopCommentDto> findCommentByCriteria(String startDate, String endDate, String commentBy,
            String shopName, Page<Map<String, Object>> page) {

        Page<Map<String, Object>> pageData = commonDao.findCommentByCriteria(startDate, endDate, commentBy, shopName,
                page);
        List<Map<String, Object>> commentList = pageData.getResult();
        List<O2oShopCommentDto> commentDtoList = Lists.newArrayList();
        for (Map<String, Object> map : commentList) {
            O2oShopCommentDto commentDto = new O2oShopCommentDto();

            String userId = StringHelper.objectToString(map.get("user_id"), "");
            if (StringUtils.isNotBlank(userId)) {
                // TODO 这个地方是要修改的，用批量查询用户信息的接口，或者使用cached用户信息，以后改进吧
//                UsrDetail usrDetail = this.userService.findUserById(userId);
//                String nickname = usrDetail.getNickName();
//                String username = usrDetail.getRealName();
//                commentDto.setUserName(nickname == null || "".equals(nickname) ? username : nickname);
                commentDto.setUserName(StringHelper.objectToString(map.get("comment_by"), ""));
            }
            commentDto.setUserId(userId);
            
            commentDto.setCommentContent(StringHelper.objectToString(map.get("comment_content"), ""));
            commentDto.setCommentTimeStr(DateUtils.date2Str((Date) map.get("comment_time"), DateUtils.DATE_FORMAT));
            commentDto.setHasLike(0); // 默认未点赞
            commentDto.setScore(StringHelper.objectToInt(map.get("score"), 1));
            commentDto.setShopId(StringHelper.objectToInt(map.get("shop_id"), 0));
            commentDto.setId(StringHelper.objectToInt(map.get("id"), 0));
            commentDto.setShopName(StringHelper.objectToString(map.get("site_name"), ""));

            // 获取评论的图片
            List<O2oShopCommentImage> imageList = commentImageDao.findByCommentIdAndStatus(commentDto.getId(), 0);
            List<String> imagePathList = new ArrayList<>();
            for (O2oShopCommentImage image : imageList) {
                String imagePath = image.getCommentImage();
                if (StringUtils.isNotBlank(imagePath) && imagePath.indexOf("http:") < 0) {
                    imagePath = SysPropsFactory.getProperty("imgServer") + "/" + imagePath;
                }
                if (StringUtils.isNotBlank(imagePath)) {
                    imagePathList.add(imagePath);
                }
            }
            commentDto.setImagesList(imagePathList);

            // 获取点赞数
            Long countLike = commentLikeDao.countByCommentId(commentDto.getId());
            commentDto.setLikeCount(countLike == null ? 0 : countLike.intValue());

            // 获取商家平均分数
            String average = getShopAveage(commentDto.getShopId());
            commentDto.setAverage(average);

            commentDtoList.add(commentDto);
        }
        return commentDtoList;
    }

    @Transactional
    public void deleteComment(int commentId) {
        List<O2oShopCommentImage> commentImageList = commentImageDao.findByCommentIdAndStatus(commentId, 0);
        for (O2oShopCommentImage commentImage : commentImageList) {
            commentImage.setStatus(1);
            commentImageDao.save(commentImage);
        }
        O2oShopComment o2oShopComment = commentDao.findOne(commentId);
        o2oShopComment.setCommentStatus(1);
        commentDao.save(o2oShopComment);

    }

    public boolean findByUserIdAndShopIdAndOrderNum(String userId, int shopId, String orderNum) {
        List<O2oShopComment> commentList = commentDao.findByUserIdAndShopIdAndOrderNum(userId, shopId, orderNum);
        if (commentList != null && commentList.size() > 0) {
            return true;
        }
        return false;
    }
}
