package com.nhs.shop.service.Benefits;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nhs.apiproxy.member.acc.dto.UserAllAccDto;
import com.nhs.apiproxy.member.acc.service.AccountTransferService;
import com.nhs.core.orm.Page;
import com.nhs.core.utils.common.DateUtils;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.core.web.WebRequestException;
import com.nhs.shop.dao.legend.region.CityDao;
import com.nhs.shop.dao.legend.service.O2oServiceOrderDao;
import com.nhs.shop.dao.legend.shop.BenefitsBandingDao;
import com.nhs.shop.dao.legend.shop.ProfitRecordDao;
import com.nhs.shop.dao.legend.shop.SalesShopOpeLogDao;
import com.nhs.shop.dao.legend.shop.SalesUtilDao;
import com.nhs.shop.dao.legend.shop.SalesclerkDao;
import com.nhs.shop.dao.legend.shop.ShopDetailDao;
import com.nhs.shop.entry.em.SalesclerkEnum;
import com.nhs.shop.entry.em.order.ServiceOrderStatusEnum;
import com.nhs.shop.entry.legend.region.City;
import com.nhs.shop.entry.legend.service.O2oServiceOrder;
import com.nhs.shop.entry.legend.shop.BenefitsBanding;
import com.nhs.shop.entry.legend.shop.ProfitRecord;
import com.nhs.shop.entry.legend.shop.SalesShopOpeLog;
import com.nhs.shop.entry.legend.shop.Salesclerk;
import com.nhs.shop.entry.legend.shop.ShopDetail;
import com.nhs.shop.entry.legend.user.UsrDetail;
import com.nhs.shop.service.BaseService;
import com.nhs.shop.service.Benefits.dto.CoinCommissionGoldLogDto;
import com.nhs.shop.service.Benefits.dto.ProfitRecordDto;
import com.nhs.shop.service.Benefits.dto.SalesDto;
import com.nhs.shop.service.Benefits.dto.SalesclerkDto;
import com.nhs.shop.service.sales.CalSalesCommissionService;
import com.nhs.shop.service.sales.dto.SalesCommissionDto;
import com.nhs.shop.util.Pinyin4jUtil;
import com.nhs.user.service.UserService;

import net.sourceforge.pinyin4j.format.exception.BadHanyuPinyinOutputFormatCombination;

/**
 * 
 * @Title: BenefitsService.java
 * @Package com.nhs.shop.service.Benefits
 * @Description: TODO
 * @author liangdanhua
 * @date 2016年11月3日 下午2:19:28
 * @version V1.0
 */
@Service
@Transactional
public class BenefitsService extends BaseService {

    @Autowired
    private BenefitsBandingDao benefitsBandingDao;

    @Autowired
    private O2oServiceOrderDao o2oServiceOrderDao;

    @Autowired
    private SalesclerkDao salesclerkDao;

    @Autowired
    private SalesUtilDao salesUtilDao;

    @Autowired
    private ProfitRecordDao profitRecordDao;

    @Autowired
    private ShopDetailDao shopDetailDao;

    @Autowired
    private CityDao cityDao;

    @Autowired
    private UserService userService;

    @Autowired
    private CalSalesCommissionService calSalesCommissionService;

    private static int benefits_status_Valid = 1;

    private static String operateType = "1";

    @Autowired
    private SalesShopOpeLogDao salesShopOpeLogDao;

    @Autowired
    private AccountTransferService accountService;

    /**
     * 营业员绑定的信息保存 
     * @Title: saveBenefits
     * @Description: TODO
     * @param @param benefitsBanding
     * @param @throws BadHanyuPinyinOutputFormatCombination   
     * @return void 
     * @author Administrator 2016年11月14日 
     * @throws
     */
    public void saveBenefits(BenefitsBanding benefitsBanding) throws BadHanyuPinyinOutputFormatCombination {
        // 检查绑定
        this.check(benefitsBanding);
        // 保存信息
        this.saveBenefit(benefitsBanding);
    }

    /**
     * 营业员绑定的更新
     * @Title: updateBenefits
     * @Description: TODO
     * @param @param benefitsBanding   
     * @return void 
     * @author liangdanhua 2016年11月14日 
     * @throws
     */
    public void updateBenefits(BenefitsBanding benefitsBanding) {
        String salesId = benefitsBanding.getSalesId();
        BenefitsBanding benefits = benefitsBandingDao.findBenefitsBandingBysalesIdAndshopId(salesId,
                benefitsBanding.getShopId());
        if (benefitsBanding.getShopId() != null) {
            benefits.setShopId(benefitsBanding.getShopId());
        }
        if (StringUtils.isNotBlank(benefitsBanding.getUserName())) {
            benefits.setUserName(benefitsBanding.getUserName());
        }
        if (StringUtils.isNotBlank(benefitsBanding.getUserMobile())) {
            benefits.setUserMobile(benefitsBanding.getUserMobile());
        }
        if (benefitsBanding.getShopName() != null) {
            benefits.setShopName(benefitsBanding.getShopName());
        }
        if (StringUtils.isNotBlank(benefitsBanding.getUserAccounts())) {
            benefits.setUserAccounts(benefitsBanding.getUserAccounts());
        }
        if (StringUtils.isNotBlank(benefitsBanding.getRemarks())) {
            benefits.setRemarks(benefitsBanding.getRemarks());
        }
        if (benefitsBanding.getStatus() != null) {
            benefits.setStatus(benefitsBanding.getStatus());
        }
        if (benefitsBanding.getLastStatus() != null) {
            benefits.setLastStatus(benefitsBanding.getLastStatus());
        }
        if (StringUtils.isNotBlank(benefitsBanding.getOperator())) {
            benefits.setOperator(benefitsBanding.getOperator());
        }
        Date date = new Date();
        // 保存店铺操作记录
        if (benefitsBanding.getStatus() != null) {
            saveSsol(benefits, date);
            if (benefitsBanding.getStatus() == 1) {
                benefits.setAddDate(date);
            }
        }

        benefits.setUpdateDate(date);
        benefitsBandingDao.saveAndFlush(benefits);
    }

    /**
     * 营业员绑定订单
     * @Title: saveBenefits
     * @Description: TODO
     * @param @param verificationId
     * @param @param userId   
     * @return void 
     * @author liangdanhua 2016年11月8日 
     * @throws
     */

    public void saveBenefits(String verificationId, String userId) {
        // 获取表单的信息
        List<O2oServiceOrder> o2oServiceOrderList = o2oServiceOrderDao
                .findO2oServiceOrderByValidateCode(verificationId);
        BenefitsBanding benefitsBanding = benefitsBandingDao.findBenefitsBandingByuserIdAndstatus(userId,
                benefits_status_Valid);
        O2oServiceOrder o2oServiceOrder = null;
        // TODO 存在性能问题.
        for (O2oServiceOrder order : o2oServiceOrderList) {
            if (order.getShopId() == benefitsBanding.getShopId()) {
                o2oServiceOrder = order;
                break;
            }
        }
        if (o2oServiceOrder == null) {
            if (o2oServiceOrderList != null && o2oServiceOrderList.size() > 0) {
                o2oServiceOrder = o2oServiceOrderList.get(0);
            } else {
                throw new WebRequestException("支付成功验证码有误!");
            }
        }
        BenefitsBanding benefits = benefitsBandingDao.findBenefitsBandingbuserIdAndshopId(userId,
                o2oServiceOrder.getShopId());

        if (benefits == null) {
            throw new WebRequestException("营业员没有绑定该店铺");
        }
        if (benefits.getStatus() == 0 || benefits.getStatus() == 3) {
            throw new WebRequestException("营业员已经解绑该店铺");
        }
        if (o2oServiceOrder.getUserId().equals(userId)) {
            throw new WebRequestException("营业员不可以领取自身订单的奖励");
        }
        // 查询该验证码是否被领取

        Salesclerk old = salesclerkDao.findSalesclerkByverificationCodeAndShopId(o2oServiceOrder.getValidateCode(),
                o2oServiceOrder.getShopId());
        if (old != null) {
            throw new WebRequestException("该支付成功验证码已被使用!");
        }
        // 营业员绑定订单
        Salesclerk sc = new Salesclerk();
        sc.setVerificationCode(o2oServiceOrder.getValidateCode());
        sc.setShopId(o2oServiceOrder.getShopId());
        sc.setShopName(o2oServiceOrder.getShopName());
        sc.setShopOrder(o2oServiceOrder.getOrderNum());
        sc.setOrderTime(o2oServiceOrder.getCreateTime());
        sc.setStatus(o2oServiceOrder.getStatus());
        sc.setPayType(o2oServiceOrder.getPayTypeName());
        sc.setOrderType("app订单");
        sc.setVerificationCode(o2oServiceOrder.getValidateCode());
        sc.setSalesId(benefits.getSalesId());
        UsrDetail usrDetail = userService.findUserById(o2oServiceOrder.getUserId());

        sc.setMemberId(usrDetail.getUserName());
        sc.setMemberPhone(usrDetail.getUserMobile());
        sc.setPayAmount(o2oServiceOrder.getTotalAmount());
        sc.setUserId(userId);

        salesclerkDao.saveAndFlush(sc);

        // 计算营业员佣金
        SalesCommissionDto dto = new SalesCommissionDto();
        dto.setUserId(userId);
        dto.setShopId(o2oServiceOrder.getShopId());
        dto.setAdFeeRate(o2oServiceOrder.getAdFeeRate());
        dto.setOrderPayAmount(o2oServiceOrder.getTotalAmount());
        dto.setOrderNum(o2oServiceOrder.getOrderNum());

        calSalesCommissionService.addSalesComission(dto);
        // 营业员收益记录
        ProfitRecord prd = new ProfitRecord();
        prd.setShopName(o2oServiceOrder.getShopName());
        prd.setShopOrder(o2oServiceOrder.getOrderNum());
        prd.setOrderAmount(o2oServiceOrder.getTotalAmount());
        prd.setBomengBrick(dto.getCommissionSilver());
        prd.setAddTime(o2oServiceOrder.getCreateTime());
        prd.setSalesId(benefits.getSalesId());
        profitRecordDao.saveAndFlush(prd);
    }

    /**
     *  营业员管理/营业员列表
     * @Title: findlist
     * @Description: TODO
     * @param @param startDate
     * @param @param endDate
     * @param @param shopName
     * @param @param name
     * @param @param phone
     * @param @param status
     * @param @param page
     * @param @return   
     * @return List<SalesclerkDto> 
     * @author liangdanhua 2016年11月14日 
     * @throws
     */
    public List<SalesclerkDto> findlist(String startDate, String endDate, String shopName, String name, String phone,
            Integer status, Page<Map<String, Object>> page) {
        Page<Map<String, Object>> pageData = salesUtilDao.getBenefitsbandingByParam(startDate, endDate, shopName, name,
                phone, status, page);
        List<SalesclerkDto> listScd = new ArrayList<SalesclerkDto>();
        for (Map<String, Object> map : pageData.getResult()) {
            SalesclerkDto scd = new SalesclerkDto();
            scd.setId(StringHelper.objectToInt(map.get("id"), 0));
            scd.setUserId(StringHelper.objectToString(map.get("user_id"), ""));
            scd.setShopId(StringHelper.objectToInt(map.get("shop_id"), 0));
            scd.setUserName(StringHelper.objectToString(map.get("user_name"), ""));
            scd.setUserMobile(StringHelper.objectToString(map.get("user_mobile"), ""));
            scd.setStatus(getStatusName(StringHelper.objectToInt(map.get("status"), 0)));
            scd.setStatusNum(StringHelper.objectToInt(map.get("status"), 0));
            scd.setShopName(StringHelper.objectToString(map.get("shop_name"), ""));
            scd.setAddDate(DateUtils.date2Str((Date) map.get("add_date")));
            scd.setUpdateDate(DateUtils.date2Str((Date) map.get("update_date")));
            scd.setUserAccounts(StringHelper.objectToString(map.get("user_accounts"), ""));
            scd.setSalesId(StringHelper.objectToString(map.get("sales_id"), ""));
            scd.setLastStatus(StringHelper.objectToInt(map.get("last_status"), 0));
            listScd.add(scd);
        }
        return listScd;
    }

    private String getStatusName(Integer status) {
        switch (status) {
            case 1:
                return SalesclerkEnum.SALESCLERK_STATUS_ONE.value();
            case 2:
                return SalesclerkEnum.SALESCLERK_STATUS_TWO.value();
            default:
                return SalesclerkEnum.SALESCLERK_STATUS_ZERO.value();
        }
    }

    /**
     * 营业员详细信息
     * @Title: salesData
     * @Description: TODO
     * @param @param salesId
     * @param @return   
     * @return SalesDto 
     * @author liangdanhua 2016年11月8日 
     * @throws
     */
    public SalesDto salesData(String userId, Integer id) {
        SalesDto sdo = new SalesDto();
        BenefitsBanding bbg = benefitsBandingDao.findOne(id);
        if (bbg == null) {
            bbg = benefitsBandingDao.findBenefitsBandingByuserId(userId);
        }
        if (bbg != null) {
            sdo.setSalesId(bbg.getSalesId());
            sdo.setName(bbg.getUserName());
            sdo.setPhone(bbg.getUserMobile());
            sdo.setShopName(bbg.getShopName());
            sdo.setShopId(bbg.getShopId());
            ShopDetail shopDetail = shopDetailDao.findOne(bbg.getShopId());
            sdo.setAddTime(DateUtils.date2Str(bbg.getAddDate()));
            if (bbg.getStatus() == 1) {
                sdo.setIsSales(operateType);
            }
            if (shopDetail != null) {
                sdo.setAddress(shopDetail.getShopAddr());
            }
            BenefitsBanding bfbg = benefitsBandingDao.findBenefitsBandingbuserIdAndshopId(userId, sdo.getShopId());
            if (bfbg != null) {
                sdo.setStatus(bfbg.getStatus());
            }
            sdo.setExceedterm(exceedterm(userId, bfbg.getStatus()));
        }

        UsrDetail usrDetail = userService.findUserById(userId);
        if (usrDetail != null) {
            sdo.setUserId(usrDetail.getUserId());
            sdo.setNickName(usrDetail.getNickName());
            sdo.setDetailPic(this.buildImg(usrDetail.getPortraitPic()));
            sdo.setRealName(usrDetail.getRealName());
            sdo.setSex(usrDetail.getSex() == "M" ? "男" : "女");
            sdo.setCardNo(usrDetail.getIdCard());
            sdo.setEmail(usrDetail.getUserMail());
            sdo.setQQ(usrDetail.getQq());
            sdo.setBirthday(usrDetail.getBirthDate());
            sdo.setHobby(usrDetail.getInterest());
            UserAllAccDto allAcc = this.accountService.findUserAllAcc(userId);
            sdo.setCommissionGold(allAcc.getEmCommissionGold().toString());
            sdo.setCommissionSilver(allAcc.getEmCommissionSliver().toString());
            sdo.setTotalGold((allAcc.getEmCommissionGold().add(allAcc.getPGold())).toString());
            sdo.setTotalSilver((allAcc.getEmCommissionSliver().add(allAcc.getPSliver())).toString());
            sdo.setUserName(usrDetail.getUserName());
        }
        return sdo;
    }

    /**
     * 获取订单列表
     * @Title: salesOrderList
     * @Description: TODO
     * @param @param startDate
     * @param @param endDate
     * @param @param shopName
     * @param @param orderNum
     * @param @param salesId
     * @param @param page
     * @param @return   
     * @return List<SalesclerkDto> 
     * @author liangdanhua 2016年11月8日 
     * @throws
     */
    public List<SalesclerkDto> salesOrderList(String startDate, String endDate, String shopName, String orderNum,
            String salesId, String memberId, String userId, Page<Map<String, Object>> page, Integer shopId) {
        Page<Map<String, Object>> pageData = salesUtilDao.getSalesclerkListByParam(startDate, endDate, shopName,
                orderNum, salesId, memberId, userId, page, shopId);
        List<SalesclerkDto> listScd = new ArrayList<SalesclerkDto>();
        for (Map<String, Object> map : pageData.getResult()) {
            SalesclerkDto scd = new SalesclerkDto();
            scd.setId(StringHelper.objectToInt(map.get("id"), 0));
            scd.setShopName(StringHelper.objectToString(map.get("shop_name"), ""));
            scd.setShopOrder(StringHelper.objectToString(map.get("shop_order"), ""));
            scd.setOrderTime(DateUtils.date2Str((Date) map.get("order_time")));
            scd.setStatus(ServiceOrderStatusEnum.desc(StringHelper.objectToInt(map.get("status"), 0)));
            scd.setPayType(StringHelper.objectToString(map.get("pay_type"), ""));
            scd.setOrderType(StringHelper.objectToString(map.get("order_type"), ""));
            scd.setVerificationCode(StringHelper.objectToString(map.get("verification_code"), ""));
            scd.setUserAccounts(StringHelper.objectToString(map.get("member_id"), ""));
            scd.setMemberPhone(StringHelper.objectToString(map.get("member_phone"), ""));
            scd.setShopId(StringHelper.objectToInt(map.get("shop_id"), 0));
            ShopDetail shopDetail = shopDetailDao.findOne(scd.getShopId());
            if (shopDetail != null) {
                scd.setShopUril(this.buildImg(shopDetail.getShopPic2()));
            }
            scd.setPayAmount(StringHelper.objectToString(map.get("pay_amount"), ""));
            scd.setSalesId(StringHelper.objectToString(map.get("sales_id"), ""));
            scd.setUserId(StringHelper.objectToString(map.get("user_id"), ""));
            listScd.add(scd);
        }
        return listScd;
    }

    /**
     * 
     * @Title: findParam
     * @Description: TODO
     * @param @param startDate
     * @param @param endDate
     * @param @param shopName
     * @param @param name
     * @param @param phone
     * @param @return   
     * @return Map<String,Object> 
     * @author liangdanhua 2016年11月10日 
     * @throws
     */
    public Map<String, Object> findParam(String startDate, String endDate, String shopName, String orderNum,
            String salesId, String userId, Integer shopId) {
        Map<String, Object> map = salesUtilDao.getSalesclerkParams(startDate, endDate, shopName, orderNum, salesId,
                userId, shopId);
        return map;
    }

    /**
     * 
     * @Title: profitReadecord
     * @Description: TODO
     * @param @param startDate
     * @param @param endDate
     * @param @param shopName
     * @param @param orderNum
     * @param @param page
     * @param @return   
     * @return List<ProfitRecordDto> 
     * @author Administrator 2016年11月8日 
     * @throws
     */
    public List<ProfitRecordDto> profitReadecord(String startDate, String endDate, String shopName, String orderNum,
            String salesId, Page<Map<String, Object>> page) {
        Page<Map<String, Object>> pageData = salesUtilDao.getProfitRecordListByParam(startDate, endDate, shopName,
                orderNum, salesId, page);
        List<ProfitRecordDto> profList = new ArrayList<ProfitRecordDto>();
        for (Map<String, Object> map : pageData.getResult()) {
            ProfitRecordDto prdo = new ProfitRecordDto();
            prdo.setShopName(StringHelper.objectToString(map.get("shop_name"), ""));
            prdo.setShopOrder(StringHelper.objectToString(map.get("shop_order"), ""));
            prdo.setOrderAmount(StringHelper.objectToBigDecimal(map.get("order_amount"), ""));
            prdo.setBomengBrick(StringHelper.objectToBigDecimal(map.get("bomeng_brick"), ""));
            prdo.setAddTime(DateUtils.date2Str((Date) map.get("add_time")));
            prdo.setSlaceId(StringHelper.objectToString(map.get("sales_id"), ""));
            prdo.setSlaceNum(StringHelper.objectToString(map.get("slace_num"), ""));
            profList.add(prdo);
        }
        return profList;
    }

    public List<SalesShopOpeLog> salesShopOpeLogBySalesId(String salesId) {
        List<SalesShopOpeLog> listSalesShopOpeLog = salesShopOpeLogDao.findSalesShopOpeLogBySalesId(salesId);
        return listSalesShopOpeLog;
    }

    public void check(BenefitsBanding benefitsBanding) {

        BenefitsBanding benefitsBandings = benefitsBandingDao.findBenefitsBandingByuserIdAndshopIdAndstatus(
                benefitsBanding.getUserId(), benefitsBanding.getShopId(), benefits_status_Valid);
        if (benefitsBandings != null) {
            throw new WebRequestException("该营业员账户已经绑定该店铺！");
        }
        ShopDetail shopDetail = shopDetailDao.findOne(benefitsBanding.getShopId());
        if (shopDetail == null) {
            throw new WebRequestException("该绑定店铺不存在！");
        }
        if (!benefitsBanding.getShopName().equals(shopDetail.getSiteName())) {
            throw new WebRequestException("店铺名称与店铺id不匹配!");
        }
        if (shopDetail.getShopSystem() != 2) {
            throw new WebRequestException("只能绑定线下实体店(o2o)");
        }
        if (shopDetail.getStatus() != 1) {
            throw new WebRequestException("上线店铺才可以绑定");
        }
        if (benefitsBanding.getUserId().equals(shopDetail.getUserId())) {
            throw new WebRequestException("无法绑定营业员自己的店铺！");
        }
        BenefitsBanding oldbenefitsBanding = benefitsBandingDao
                .findBenefitsBandingByuserId(benefitsBanding.getUserId());
        if (oldbenefitsBanding != null && StringUtils.isBlank(benefitsBanding.getOperator())) {
            // 判断三个月
            Calendar c = Calendar.getInstance();// 默认是当前日期
            int nowday = c.get(c.DAY_OF_YEAR);
            Calendar c1 = Calendar.getInstance();
            c1.setTime(oldbenefitsBanding.getAddDate());
            int oldday = c1.get(c1.DAY_OF_YEAR);
            if (Math.abs(nowday - oldday) < 90) {
                throw new WebRequestException("三个月之内，只能绑定一家店铺！");
            }
        }
    }

    public void saveBenefit(BenefitsBanding benefitsBanding) throws BadHanyuPinyinOutputFormatCombination {
        Date date = new Date();
        BenefitsBanding bfbg = benefitsBandingDao.findBenefitsBandingByuserId(benefitsBanding.getUserId());
        // 店铺操作记录
        String operator = benefitsBanding.getOperator();
        if (bfbg != null) {
            if (StringUtils.isNotBlank(benefitsBanding.getUserId())) {
                bfbg.setUserId(benefitsBanding.getUserId());
            }
            if (benefitsBanding.getShopId() != null) {
                bfbg.setShopId(benefitsBanding.getShopId());
            }
            if (StringUtils.isNotBlank(benefitsBanding.getUserName())) {
                bfbg.setUserName(benefitsBanding.getUserName());
            }
            if (StringUtils.isNotBlank(benefitsBanding.getUserMobile())) {
                bfbg.setUserMobile(benefitsBanding.getUserMobile());
            }
            bfbg.setStatus(benefits_status_Valid);
            if (StringUtils.isNotBlank(benefitsBanding.getShopName())) {
                bfbg.setShopName(benefitsBanding.getShopName());
            }
            bfbg.setAddDate(date);
            bfbg.setUpdateDate(date);
            if (StringUtils.isNotBlank(benefitsBanding.getUserAccounts())) {
                bfbg.setUserAccounts(benefitsBanding.getUserAccounts());
            }
            if (StringUtils.isNotBlank(benefitsBanding.getRemarks())) {
                bfbg.setRemarks(benefitsBanding.getRemarks());
            }
            if (benefitsBanding.getLastStatus() != null) {
                bfbg.setLastStatus(benefitsBanding.getLastStatus());
            }
            benefitsBanding = bfbg;
            benefitsBandingDao.saveAndFlush(bfbg);
        } else {
            benefitsBanding.setUpdateDate(date);
            benefitsBanding.setAddDate(date);
            ShopDetail shopDetail = shopDetailDao.findOne(benefitsBanding.getShopId());
            City city = cityDao.findOne(shopDetail.getCityid());
            BenefitsBanding sunm = benefitsBandingDao.findBenefitsBandingByregion(
                    Pinyin4jUtil.getPinYinHeadChar(city.getCity().replace("市", "")).toString());
            benefitsBanding.setRegion(Pinyin4jUtil.getPinYinHeadChar((city.getCity().replace("市", "")).toString()));
            benefitsBanding.setSalesNum(sunm == null || sunm.getSalesNum() == null ? 0 : sunm.getSalesNum() + 1);
            benefitsBanding.setSalesId(benefitsBanding.getRegion()
                    + String.format("%06d", sunm == null || sunm.getSalesNum() == null ? 0 : sunm.getSalesNum() + 1));
            benefitsBandingDao.save(benefitsBanding);
        }
        if (StringUtils.isBlank(operator)) {
            SalesShopOpeLog ssol = new SalesShopOpeLog();
            ssol.setCreateTime(date);
            ssol.setUpdateTime(date);
            ssol.setShopName(benefitsBanding.getShopName());
            ssol.setShopId(benefitsBanding.getShopId());
            ssol.setOperateType(operateType);
            ssol.setSalesId(benefitsBanding.getSalesId());
            ssol.setRemarks("用户申请绑定， 绑定店铺:" + ssol.getShopName() + "(" + ssol.getShopId() + ")" + "，备注：营业员APP申请绑定");
            salesShopOpeLogDao.saveAndFlush(ssol);
        } else {
            SalesShopOpeLog ssol = new SalesShopOpeLog();
            ssol.setCreateTime(date);
            ssol.setUpdateTime(date);
            ssol.setShopName(benefitsBanding.getShopName());
            ssol.setShopId(benefitsBanding.getShopId());
            ssol.setOperateType(operateType);
            ssol.setSalesId(benefitsBanding.getSalesId());
            ssol.setRemarks(
                    "管理员 :" + operator + "绑定店铺  :" + ssol.getShopName() + "(" + ssol.getShopId() + ")" + "，备注：管理员申请绑定");
            salesShopOpeLogDao.saveAndFlush(ssol);
        }
    }

    public void saveSsol(BenefitsBanding benefitsBanding, Date date) {
        String operator = benefitsBanding.getOperator();
        if (StringUtils.isBlank(operator)) {
            SalesShopOpeLog ssol = new SalesShopOpeLog();
            ssol.setCreateTime(date);
            ssol.setUpdateTime(date);
            ssol.setShopName(benefitsBanding.getShopName());
            ssol.setShopId(benefitsBanding.getShopId());
            ssol.setSalesId(benefitsBanding.getSalesId());
            if (benefitsBanding.getStatus() == 3) {
                ssol.setOperateType("0");
                ssol.setRemarks("用户申请解绑，解绑店铺  :" + ssol.getShopName() + "(" + ssol.getShopId() + ")" + "，备注：营业员已离职");
                salesShopOpeLogDao.saveAndFlush(ssol);
            }
        } else {
            SalesShopOpeLog ssol = new SalesShopOpeLog();
            ssol.setCreateTime(date);
            ssol.setUpdateTime(date);
            ssol.setShopName(benefitsBanding.getShopName());
            ssol.setShopId(benefitsBanding.getShopId());
            ssol.setSalesId(benefitsBanding.getSalesId());
            if (benefitsBanding.getStatus() == 0 && benefitsBanding.getLastStatus() == 1) {
                ssol.setOperateType("0");
                ssol.setRemarks("管理员 :" + operator + "解绑店铺  :" + ssol.getShopName() + "(" + ssol.getShopId() + ")"
                        + "，备注：营业员已离职");
                salesShopOpeLogDao.saveAndFlush(ssol);
            } else if (benefitsBanding.getStatus() == 2) {
                ssol.setOperateType("2");
                ssol.setRemarks("管理员:" + operator + "    禁用该营业员，禁用原因：该营业员存在违规行为");
                salesShopOpeLogDao.saveAndFlush(ssol);
            } else if (benefitsBanding.getLastStatus() == 2) {
                ssol.setOperateType("3");
                ssol.setRemarks("管理员:" + operator + "    重新启用店铺  : " + ssol.getShopName() + "(" + ssol.getShopId() + ")"
                        + "，营业员编号：" + ssol.getSalesId() + "，店铺启用状态  :" + getStatusName(benefitsBanding.getStatus()));
                salesShopOpeLogDao.saveAndFlush(ssol);
            }
        }
    }

    public String exceedterm(String usrId, Integer status) {
        String exceedterm = "";
        BenefitsBanding oldbenefitsBanding = benefitsBandingDao.findBenefitsBandingByuserId(usrId);
        if (oldbenefitsBanding != null) {
            // 判断三个月
            Calendar c = Calendar.getInstance();// 默认是当前日期
            int nowday = c.get(c.DAY_OF_YEAR);
            Calendar c1 = Calendar.getInstance();
            c1.setTime(oldbenefitsBanding.getAddDate());
            int oldday = c1.get(c1.DAY_OF_YEAR);
            if (Math.abs(nowday - oldday) < 90) {
                exceedterm = "0";
            } else {
                exceedterm = "1";
            }
        }
        return exceedterm;
    }

    /**
     * 营业员佰德券使用记录
     * @Title: coinCommissionGoldLogByuserId
     * @Description: TODO
     * @param @param userId
     * @param @param page
     * @param @return   
     * @return List<CoinCommissionGoldLogDto> 
     * @author liangdanhua 2016年11月17日 
     * @throws
     */
    public List<CoinCommissionGoldLogDto> coinCommissionGoldLogByuserId(String userId, Page<Map<String, Object>> page) {
        Page<Map<String, Object>> pageData = salesUtilDao.queryCoinCommissionGoldLogList(userId, page);
        List<CoinCommissionGoldLogDto> result = new ArrayList<CoinCommissionGoldLogDto>();
        for (Map<String, Object> map : pageData.getResult()) {
            CoinCommissionGoldLogDto cdt = new CoinCommissionGoldLogDto();
            cdt.setType((Integer) map.get("type"));
            cdt.setOrderNum((String) map.get("order_num"));
            if (cdt.getType() == 0) {

                cdt.setIncome("+" + StringHelper.objectToBigDecimal(map.get("gold_count"), "")
                        .setScale(2, BigDecimal.ROUND_HALF_UP).toString());
                cdt.setPayment("-0.00");
                cdt.setRemarks(" 营业收入的佰德钻转换为佰德券");
            } else if (cdt.getType() == 1) {
                cdt.setIncome("+0.00");
                cdt.setPayment("-" + StringHelper.objectToBigDecimal(map.get("gold_count"), "")
                        .setScale(2, BigDecimal.ROUND_HALF_UP).toString());
                cdt.setRemarks(" 提现佰德券，流水号: " + cdt.getOrderNum());
            } else if (cdt.getType() == 2) {
                cdt.setIncome("+0.00");
                cdt.setPayment("-" + StringHelper.objectToBigDecimal(map.get("gold_count"), "")
                        .setScale(2, BigDecimal.ROUND_HALF_UP).toString());
                cdt.setRemarks(" 交易抵用，订单流水号:  " + cdt.getOrderNum());
            } else if (cdt.getType() == 3) {
                cdt.setIncome("+" + StringHelper.objectToBigDecimal(map.get("gold_count"), "")
                        .setScale(2, BigDecimal.ROUND_HALF_UP).toString());
                cdt.setPayment("-0.00");
                cdt.setRemarks(" 交易抵用退还，订单流水号: " + cdt.getOrderNum());
            }
            cdt.setCreateTime(DateUtils.date2Str((Date) map.get("create_time")));
            result.add(cdt);
        }
        return result;
    }

}
