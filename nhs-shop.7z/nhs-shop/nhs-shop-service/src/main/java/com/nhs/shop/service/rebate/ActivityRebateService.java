package com.nhs.shop.service.rebate;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nhs.core.utils.common.StringHelper;
import com.nhs.shop.activity.dao.ActivitySchoolDao;
import com.nhs.shop.activity.entry.ActivitySchool;
import com.nhs.shop.dao.legend.coin.CoinRmbSilverLogDao;
import com.nhs.shop.dao.legend.msg.MessageDao;
import com.nhs.shop.dao.legend.msg.MsgTextDao;
import com.nhs.shop.dao.legend.service.O2oServiceOrderDao;
import com.nhs.shop.dao.legend.shop.ProdDao;
import com.nhs.shop.dao.legend.shop.SubItemDao;
import com.nhs.shop.entry.legend.coin.CoinRmbSilverLog;
import com.nhs.shop.entry.legend.service.O2oServiceOrder;
import com.nhs.shop.entry.legend.shop.Msg;
import com.nhs.shop.entry.legend.shop.MsgText;
import com.nhs.shop.entry.legend.shop.Prod;
import com.nhs.shop.entry.legend.shop.SubItem;
import com.nhs.shop.entry.legend.user.UsrDetail;
import com.nhs.shop.service.activity.dto.GoldSchoolRegsDto;
import com.nhs.user.service.UserService;

/**
 * 活动银币返回或者新增
 * @Title: ActivityRebateService.java
 * @Package com.nhs.shop.service.order
 * @Description: TODO
 * @author liguangrong
 * @date 2016年9月22日 上午7:52:36
 * @version V1.0
 */
@Service
public class ActivityRebateService {

    private static Logger logger = LoggerFactory.getLogger(CarRebateService.class);

    @Autowired
    private ProdDao prodDao;

    @Autowired
    private UserService userService;

    @Autowired
    private RebateService rebateService;

    @Autowired
    private CoinRmbSilverLogDao coinRmbSilverLogDao;

    @Autowired
    private O2oServiceOrderDao o2oServiceOrderDao;

    @Autowired
    private SubItemDao subItemDao;

    @Autowired
    private MessageDao msgDao;

    @Autowired
    private MsgTextDao msgTextDao;

    @Autowired
    private ActivitySchoolDao activitySchoolDao;

    public void saveActivityRebateProcess(int type, List<String> userIdList,
            List<Map<String, Object>> actConsumeOrderDtoList, Date nowTime, String silver, int activityId,
            String msgText) throws Exception {
        // 1 代表新注册用户返还银币； 其他代表活动订单返还的银币
        if (1 == type) {
            for (String userId : userIdList) {
                UsrDetail usrDetail = userService.findUserById(userId);
                if (usrDetail == null) {
                    logger.info("用户: " + userId + " 不存在。");
                    continue;
                }
                if (activityId != 0) {
                    List<CoinRmbSilverLog> silverLogList = coinRmbSilverLogDao.findByUserIdAndActivityId(userId,
                            activityId);
                    if (silverLogList == null || silverLogList.size() == 0) {
                        // 新注册用户返利
                        logger.info("处理新用户注册返还银币, 用户ID：" + userId);
                        rebateService.saveActivityUserRebate(usrDetail, "新用户注册活动", silver, null, 0, nowTime,
                                activityId);

                        sendMsgToUser(usrDetail.getUserName(), msgText, "参加新用户注册活动通知");
                    } else {
                        logger.info("该用户在本期新注册用户活动activityId为: " + activityId + " 中已返还过银币。");
                    }
                } else {
                    logger.info("本期活动activityId为0,传入参数有误。 ");
                    throw new RuntimeException("传入参数有误。");
                }
            }
        } else {
            for (Map<String, Object> map : actConsumeOrderDtoList) {
                UsrDetail usrDetail = this.userService.findUserById(StringHelper.objectToString(map.get("userId"), ""));
                if (usrDetail == null) {
                    logger.info("用户: " + StringHelper.objectToString(map.get("userId"), "") + " 不存在。");
                    continue;
                }
                if (StringUtils.isEmpty(StringHelper.objectToString(map.get("orderNum"), ""))
                        || StringHelper.objectToInt(map.get("actId"), 0) == 0) {
                    throw new RuntimeException("传入参数有误。");
                } else {
                    List<CoinRmbSilverLog> silverLogList = coinRmbSilverLogDao.findByUserIdAndSubNumberAndActivityId(
                            StringHelper.objectToString(map.get("userId"), ""),
                            StringHelper.objectToString(map.get("orderNum"), ""),
                            StringHelper.objectToInt(map.get("actId"), 0));
                    if (silverLogList == null || silverLogList.size() == 0) {
                        if ("shop".equals(StringHelper.objectToString(map.get("orderType"), ""))) {
                            rebateService.saveActivityUserRebate(usrDetail, "消费有礼活动商城订单活动",
                                    StringHelper.objectToString(map.get("needPresentSilver"), "0.00"),
                                    StringHelper.objectToString(map.get("orderNum"), ""), 0, nowTime,
                                    StringHelper.objectToInt(map.get("actId"), 0));
                        } else if ("o2oShop".equals(StringHelper.objectToString(map.get("orderType"), ""))) {
                            rebateService.saveActivityUserRebate(usrDetail, "消费有礼活动o2o订单活动",
                                    StringHelper.objectToString(map.get("needPresentSilver"), "0.00"),
                                    StringHelper.objectToString(map.get("orderNum"), ""), 0, nowTime,
                                    StringHelper.objectToInt(map.get("actId"), 0));
                        }
                        sendMsgToUser(usrDetail.getUserName(), StringHelper.objectToString(map.get("msgText"), ""),
                                "参加消费有礼返银币活动通知");
                    } else {
                        logger.info("该用户在本期消费有礼活动activityId为: " + StringHelper.objectToInt(map.get("actId"), 0)
                                + " 中该订单: " + StringHelper.objectToString(map.get("orderNum"), "") + " 已返还过银币。");
                    }
                }
            }
        }

    }

    public String getUserBaseSilver(String userId, String orderNum, String orderType, Date nowTime) throws Exception {
        // 1 代表新注册用户返还银币； 其他代表活动订单返还的银币
        BigDecimal silver = new BigDecimal("0.00");
        if ("shop".equals(orderType)) {
            List<SubItem> siList = subItemDao.findSubItem(orderNum);
            if (siList != null && siList.size() > 0) {
                UsrDetail usrDetail = this.userService.findUserById(userId);
                for (SubItem item : siList) {
                    Prod prod = prodDao.findOne(item.getProdId());
                    if (prod != null) {
                        // 个人用户账户的银币
                        BigDecimal rebate = item.getRebate();
                        if (rebate == null) {
                            rebate = prod.getRebate();
                        }
                        BigDecimal adFeeRate = item.getAdFeeRate();
                        if (adFeeRate == null) {
                            adFeeRate = prod.getAdFeeRate();
                        }
                        silver = silver.add(rebateService.getUserBasicRebate(usrDetail, "-商城订单-", rebate, adFeeRate,
                                prod.getProdId(), item.getProductTotalAmout(), prod.getCash(), prod.getPrice(),
                                item.getSubItemNumber(), item.getBasketCount(), nowTime));
                    }
                }
            }
        } else if ("o2oShop".equals(orderType)) {
            O2oServiceOrder sub = o2oServiceOrderDao.findO2oServiceOrderByOrderNum(orderNum);
            // 防止以前支付字段为空引起的问题
            if (sub.getPayAmount() == null) {
                sub.setPayAmount(sub.getTotalAmount());
            }
            UsrDetail usrDetail = this.userService.findUserById(userId);
            // 个人用户账户的银币
            silver = rebateService.getUserBasicRebate(usrDetail, "-服务订单-", sub.getRebate(), sub.getAdFeeRate(), 0,
                    sub.getPayAmount(), sub.getPayAmount(), sub.getTotalAmount(), sub.getOrderNum(), 1, nowTime);
        }

        return silver.toString();

    }

    private void sendMsgToUser(String userName, String msgText, String title) {
        try {
            MsgText msgT = new MsgText();
            msgT.setTitle(title);
            msgT.setText(msgText);
            msgT.setRecDate(new Date());
            msgTextDao.save(msgT);
            Msg msg = new Msg();
            msg.setSendName("home");
            msg.setTextId(msgT.getId());
            msg.setStatus(0);
            msg.setIsGlobal(0);
            msg.setDeleteStatus(0);
            msg.setDeleteStatus2(0);
            msg.setReceiveName(userName);
            msgDao.save(msg);
        } catch (Exception e) {
            logger.info("发送站内信给: " + userName + " 失败！");
        }
    }

    public void saveActivityGoldRebateProcess(List<Map<String, Object>> goldSchoolRegsDtoList, Date nowTime,
            int activityId, String msgText, String activityTitle) throws Exception {
        logger.info("#####开始处理校园活动返金币业务#######");
        for (Map<String, Object> map : goldSchoolRegsDtoList) {
            UsrDetail inviteeUsrDetail = this.userService
                    .findUserById(StringHelper.objectToString(map.get("inviteeUserId"), ""));
            UsrDetail inviterUsrDetail = this.userService
                    .findUserById(StringHelper.objectToString(map.get("inviterUserId"), ""));
            if (inviteeUsrDetail == null) {
                logger.info("用户: " + StringHelper.objectToString(map.get("inviteeUserId"), "") + " 不存在。");
                continue;
            }
            if (inviterUsrDetail == null) {
                logger.info("用户: " + StringHelper.objectToString(map.get("inviterUserId"), "") + " 不存在。");
                continue;
            }

            if (activityId != 0) {
                ActivitySchool activitySchool = activitySchoolDao
                        .findByInviteeUserMobile(inviteeUsrDetail.getUserMobile());
                if (activitySchool != null && activitySchool.getRebateStatus() == 0) {
                    logger.info("#####处理本期校园活动#######");
                    GoldSchoolRegsDto dto = new GoldSchoolRegsDto();
                    dto.setInviteeUserId(StringHelper.objectToString(map.get("inviteeUserId"), ""));
                    dto.setInviteeGold(StringHelper.objectToString(map.get("inviteeGold"), "0.00"));
                    dto.setInviterUserId(StringHelper.objectToString(map.get("inviterUserId"), ""));
                    dto.setInviterGold(StringHelper.objectToString(map.get("inviterGold"), "0.00"));
                    rebateService.saveActivityUserGoldRebate(dto, activityTitle, null, 0, nowTime, activityId);
                    sendMsgToUser(inviteeUsrDetail.getUserName(), msgText, "参加校园活动活动通知");
                    sendMsgToUser(inviterUsrDetail.getUserName(), msgText, "参加校园活动活动通知");

                } else if (activitySchool != null && activitySchool.getRebateStatus() == 1) {
                    logger.info("该用户在本期校园活动activityId为: " + activityId + " 中已返还过金币。");
                }
            } else {
                logger.info("本期活动activityId为0,传入参数有误。 ");
                throw new RuntimeException("传入参数有误。");
            }
        }
        logger.info("#####处理校园活动返金币业务结束#######");
    }
}
