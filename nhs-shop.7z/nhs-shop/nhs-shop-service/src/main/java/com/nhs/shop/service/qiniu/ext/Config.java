package com.nhs.shop.service.qiniu.ext;

import java.nio.charset.Charset;

public class Config {
    public static final Charset UTF_8 = Charset.forName("UTF-8");
}
