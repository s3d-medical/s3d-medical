package com.nhs.shop.service.banner;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nhs.core.web.WebRequestException;
import com.nhs.shop.dao.legend.banner.BannerDao;
import com.nhs.shop.entry.legend.banner.Banner;
import com.nhs.shop.service.BaseService;

/**
 * APP首页横幅广告
 * @Title: BannerService.java
 * @Package com.nhs.shop.service.banner
 * @Description: TODO
 * @author liangdanhua
 * @date 2016年9月13日 下午4:48:55
 * @version V1.0
 */
@Service
public class BannerService extends BaseService {

    @Autowired
    private BannerDao bannerDao;

    private static Integer banner_state = 1;

    /**
     * APP首页横幅广告列表
     * @Title: BannerList
     * @Description: TODO
     * @param @return   
     * @return List<Banner> 
     * @author liangdanhua 2016年9月13日 
     * @throws
     */
    public List<Banner> BannerList(String status) {
        List<Banner> bannerList = null;
        if (status.equals("status")) {
            bannerList = bannerDao.findAllBannerByState(banner_state);
        } else {
            bannerList = bannerDao.findAllBanners();
        }
        for (Banner banner : bannerList) {
            banner.setImg(this.buildBannerIcon(banner.getImg()));
        }
        return bannerList;
    }

    /**
     * 保存
     * @Title: BannerList
     * @Description: TODO
     * @param @return   
     * @return List<Banner> 
     * @author liangdanhua 2016年9月13日 
     * @throws
     */
    public String add(Banner banner) {
        String isSave = "";
        Banner bann = bannerDao.save(banner);
        if (bann == null) {
            isSave = "0";
        } else {
            isSave = "1";
        }
        return isSave;
    }

    /**
     * 删除
     * @Title: BannerList
     * @Description: TODO
     * @param @return   
     * @return List<Banner> 
     * @author liangdanhua 2016年9月13日 
     * @throws
     */
    public void delete(Integer id) {
        Banner banner = bannerDao.findOne(id);
        if (banner == null) {
            throw new WebRequestException("未找到该横幅广告");
        }
        bannerDao.delete(id);
    }

    /**
     * 查找
     * @Title: BannerList
     * @Description: TODO
     * @param @return   
     * @return List<Banner> 
     * @author liangdanhua 2016年9月13日 
     * @throws
     */
    public List<Banner> find(String title) {
        List<Banner> banner = bannerDao.findBannerBytitle(title);
        for (Banner br : banner) {
            br.setImg(this.buildBannerIcon(br.getImg()));
        }
        if (banner == null) {
            throw new WebRequestException("未找到该横幅广告");
        }
        return banner;
    }

    /**
     * 更新
     * @Title: BannerList
     * @Description: TODO
     * @param @return   
     * @return List<Banner> 
     * @author liangdanhua 2016年9月13日 
     * @throws
     */
    public String update(Banner banner) {
        String isSave = "0";
        Banner olbanner = bannerDao.findOne(banner.getId());
        if (olbanner == null) {
            olbanner.setRecDate(new Date());
            bannerDao.save(banner);
        } else {
            if (StringUtils.isNotBlank(banner.getImg())) {
                olbanner.setImg(banner.getImg());
            }
            olbanner.setRecDate(new Date());
            if (StringUtils.isNotBlank(banner.getSeq())) {
                olbanner.setSeq(banner.getSeq());
            }
            if (banner.getState() != null) {
                olbanner.setState(banner.getState());
            }
            if (StringUtils.isNotBlank(banner.getTitle())) {
                olbanner.setTitle(banner.getTitle());
            }
            if (StringUtils.isNotBlank(banner.getUserId())) {
                olbanner.setUserId(banner.getUserId());
            }
            if (StringUtils.isNotBlank(banner.getDescribtion())) {
                olbanner.setDescribtion(banner.getDescribtion());
            }
            olbanner.setPath(banner.getPath());

            bannerDao.saveAndFlush(olbanner);
            isSave = "1";
        }
        return isSave;
    }
}
