package com.nhs.shop.service.collect.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * 我的收藏列表
 * @Title: CollectDto.java
 * @Package com.nhs.shop.service.category.dto
 * @Description: TODO
 * @author liangdanhua
 * @date 2016年8月10日 下午11:3:20
 * @version V1.0
 */
public class CollectDto implements Serializable {

    private static final long serialVersionUID = 7254920986527049665L;
    private Integer id;
    private Integer prodId;
    private Date addTime;
    private String userId;
    private String userName;
    private String name;
    private String pic;
    private String shopaddr;
    private String cash;
    private Integer buys;
    private String rebate;
    private Integer supporttransportfree;
    private String detailUrl;
    private String mailStatus = "包邮";
    private String lg;
    /**
     * 补贴额度
     */
    private String subsidyStr = "";
    /**
     * 立减额度
     */
    private String reducedCashTag="";
    		
    public String getLg() {
        return lg;
    }

    public void setLg(String lg) {
        this.lg = lg;
    }

    public String getMailStatus() {
        return mailStatus;
    }

    public void setMailStatus(String mailStatus) {
        this.mailStatus = mailStatus;
    }

    public String getDetailUrl() {
        return detailUrl;
    }

    public void setDetailUrl(String detailUrl) {
        this.detailUrl = detailUrl;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getProdId() {
        return prodId;
    }

    public void setProdId(Integer prodId) {
        this.prodId = prodId;
    }

    public Date getAddTime() {
        return addTime;
    }

    public void setAddTime(Date addTime) {
        this.addTime = addTime;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public String getShopaddr() {
        return shopaddr;
    }

    public void setShopaddr(String shopaddr) {
        this.shopaddr = shopaddr;
    }

    public String getCash() {
        return cash;
    }

    public void setCash(String cash) {
        this.cash = cash;
    }

    public Integer getBuys() {
        return buys;
    }

    public void setBuys(Integer buys) {
        this.buys = buys;
    }

    public String getRebate() {
        return rebate;
    }

    public void setRebate(String rebate) {
        this.rebate = rebate;
    }

    public Integer getSupporttransportfree() {
        return supporttransportfree;
    }

    public void setSupporttransportfree(Integer supporttransportfree) {
        this.supporttransportfree = supporttransportfree;
    }

    public String getSubsidyStr() {
        return subsidyStr;
    }

    public void setSubsidyStr(String subsidyStr) {
        this.subsidyStr = subsidyStr;
    }

	public String getReducedCashTag() {
		return reducedCashTag;
	}

	public void setReducedCashTag(String reducedCashTag) {
		this.reducedCashTag = reducedCashTag;
	}

}
