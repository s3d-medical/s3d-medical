package com.nhs.shop.service.rebate;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.nhs.core.common.NhsConstant;
import com.nhs.shop.bindspreader.service.BindedSpreaderService;
import com.nhs.shop.dao.legend.service.O2oServiceOrderDao;
import com.nhs.shop.dao.legend.shop.ShopDetailDao;
import com.nhs.shop.entry.em.shop.EmRebateStatus;
import com.nhs.shop.entry.legend.service.O2oServiceOrder;
import com.nhs.shop.entry.legend.shop.ShopDetail;
import com.nhs.shop.entry.legend.user.UsrDetail;
import com.nhs.shop.ordercal.dao.OrderCalculationRuleDao;
import com.nhs.shop.ordercal.entity.OrderCalculationRule;
import com.nhs.shop.rebate.RebateType;
import com.nhs.shop.rebate.RebateTypeContext;
import com.nhs.shop.rebate.entity.RebatePresent;
import com.nhs.user.service.OperateUserAccountService;
import com.nhs.user.service.UserService;

/**
 * 清算o2o服务订单的返利
 * @Title: O2oRebateService.java
 * @Package com.nhs.shop.service.order
 * @Description: TODO
 * @author huxianjun
 * @date 2016年8月5日 上午10:58:29
 * @author Robin.chu 2016-11-18 modified
 * @version V1.0
 */
@Service
public class O2oRebateService {

    private static Logger logger = LoggerFactory.getLogger(O2oRebateService.class);

    @Autowired
    private O2oServiceOrderDao o2oServiceOrderDao;

    @Autowired
    private RebateService rebateService;

    @Autowired
    private ShopDetailDao shopDetailDao;

    @Autowired
    private UserService userService;
	@Autowired
    private OperateUserAccountService userAccountService;
    
    @Autowired
	private BindedSpreaderService bindedSpreaderService;
    
    @Resource
    private RebateTypeContext rebateTypeContext;
    
    @Autowired
   	private OrderCalculationRuleDao orderCalculationRuleDao;
 

    /**
     * 开始处理每一商品的订单的清算
     * @Title: saveRebate
     * @Description: TODO
     * @param @param sub
     * @param @param nowTime
     * @param @throws Exception   
     * @return void 
     * @author huxianjun 2016年7月29日 
     * @throws
     */
    @Async
    public void saveRebate(O2oServiceOrder sub, Date nowTime) throws Exception {
        logger.info("＝＝＝异步清算返利订单＝＝＝" + sub.getOrderNum());
        this.saveRebateProcess(sub, nowTime);
    }

    /**
     * 同步处理定时任务，因为数据库可能没有写入，所以不可异步
     * @Title: saveSynchronizeRebate
     * @Description: TODO
     * @param @param sub
     * @param @param nowTime
     * @param @throws Exception   
     * @return void 
     * @author huxianjun 2016年9月2日 
     * @throws
     */
    public void saveSynchronizeRebate(O2oServiceOrder sub, Date nowTime) throws Exception {
        logger.info("＝＝＝同步清算返利订单＝＝＝" + sub.getOrderNum());
        this.saveRebateProcess(sub, nowTime);
    }

    /**
     * @Title: saveRebateProcess
     * @Description: O2O订单的处理过程，在这个过程中有3个动作：
     *  1）给用户返利                     （佰德砖）
     *  2）判断是否给商户返利      （佰德砖）
     *  3）给商户充余额（好像是冻结的） （冻结商户余额，将一个账号的普通账户和商户账户是分开保存的） 
     * @param @param sub
     * @param @param nowTime
     * @param @throws Exception   
     * @return void 
     * @author chushubin 2016年11月18日 
     * @throws
     */
    private void saveRebateProcess(O2oServiceOrder sub, Date nowTime) throws Exception {
        logger.info("＝＝＝清算返利订单＝＝＝" + sub.getOrderNum());

        // 更新订单状态
        sub.setRebateStatus(EmRebateStatus.rebate.status);
        o2oServiceOrderDao.saveAndFlush(sub);

        // 用户信息
        UsrDetail usrDetail = this.userService.findUserById(sub.getUserId());
        if (usrDetail == null) {
            return;
        }
        // 商户信息
        // 根据ShopId获取UserId，然后再查询商户的UserDetail
        ShopDetail shopDetail = this.shopDetailDao.findByShopIdAndStatus(sub.getShopId(), ShopDetail.STATUS_ONLINE);
        if (shopDetail == null || StringUtils.isBlank(shopDetail.getUserId())) {
            return;
        }
        UsrDetail shopUserDetail = this.userService.findUserById(shopDetail.getUserId());
        if (shopUserDetail == null) {
            return;
        }

        // 防止以前支付字段为空引起的问题
        if (sub.getPayAmount() == null) {
            sub.setPayAmount(sub.getTotalAmount());
        }

		 // 判断是否是新规则
//        BindedSpreaderDto bindedSpread = bindedSpreaderService.findUserBindShop(usrDetail.getUserId());
        OrderCalculationRule orderCalculationRule = orderCalculationRuleDao.findByOrderNumAndRuleType(sub.getOrderNum(), NhsConstant.SYS_VERSION_V193);
        if(orderCalculationRule != null) {
        	RebateType rebateType = rebateTypeContext.getRebate(RebateTypeContext.REBATE_O2O_NEW);
        	Map<String, Object> inParams = new HashMap<String, Object>();
        	inParams.put("user", usrDetail);
        	inParams.put("order", sub);
        	inParams.put("shopUser", shopUserDetail);
        	RebatePresent rebatePresent = new RebatePresent(); // 计算规则，由于时间关系，时间充裕可以做成配置
        	                                                   // 该配置应该由rebateType查询出来
        	rebateType.doRebate(rebatePresent, inParams);
        } else {
        // 用户返利
        rebateService.saveUserRebate(usrDetail, "-服务订单-", sub.getRebate(), sub.getAdFeeRate(), 0, sub.getPayAmount(),
                sub.getPayAmount(), sub.getTotalAmount(), sub.getOrderNum(), 1, nowTime);

        boolean flag = false;
        if (shopDetail != null) {
            // 添加黑白名单，开关控制，决定需要不需要给商家返银币
            if (shopDetail.getWhiteList() != null && shopDetail.getWhiteList().intValue() == 1) {
                flag = true;
            } else if ((shopDetail.getWhiteList() == null || shopDetail.getWhiteList().intValue() == 0)
                    && (shopDetail.getCoinSwitch() != null && shopDetail.getCoinSwitch().intValue() == 1)) {
                flag = true;
            }
            logger.info(
                    "开关控制：白名单:" + shopDetail.getWhiteList() + ",开关：" + shopDetail.getCoinSwitch() + ",flag:" + flag);
            if (flag) {
                // 商户返利
                rebateService.saveShopRebate(shopUserDetail, "-服务订单-", sub.getRebate(), sub.getAdFeeRate(), 0,
                        sub.getTotalAmount(), sub.getTotalAmount(), sub.getTotalAmount(), sub.getOrderNum(), 1,
                        nowTime);
            }
        }

        // +商家的账户金额并记录日志
        rebateService.saveShopCash(shopUserDetail, "-服务订单-", sub.getRebate(), sub.getAdFeeRate(), sub.getTotalAmount(),
                sub.getOrderNum(), nowTime);
		}
    }
    
}
