package com.nhs.shop.service.activity.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nhs.shop.activity.dao.ActivityDao;
import com.nhs.shop.activity.dao.ActivitySchoolAgentDao;
import com.nhs.shop.activity.dao.ActivitySchoolDao;
import com.nhs.shop.activity.entry.ActivitySchool;
import com.nhs.shop.activity.entry.ActivitySchoolAgent;
import com.nhs.shop.entry.legend.user.UsrDetail;
import com.nhs.user.service.UserService;

@Service
@Transactional
public class ActivitySchoolService {
	
	private final Logger logger = LoggerFactory.getLogger(ActivitySchoolService.class);

	@Autowired
    private ActivitySchoolDao schoolDao;
	
	@Autowired
    private ActivityDao activityDao;
	
	@Autowired
    private ActivitySchoolAgentDao activitySchoolAgentDao;
	
	@Autowired
    private UserService userService;
	
	
	public ActivitySchool findByInviteeUserMobile(String userMobile){
		ActivitySchool school = schoolDao.findByInviteeUserMobile(userMobile);
		return school;
	}
	
	public void saveActivitySchool(String userMobile,String inviterUserId){
		ActivitySchool school = new ActivitySchool();
		school.setInviteeUserMobile(userMobile);
		school.setInviterUserId(inviterUserId);
		school.setRebateStatus(0);
		school.setCreateTime(new Date());
		schoolDao.save(school);
		
	}
	
	public long countByRebateStatus(int status,String userId,Date startDate,Date endDate){
		return schoolDao.countByRebateStatusAndInviterUserIdAndCreateTimeBetween(status,userId,startDate,endDate);
	}
	
	public long countAll(String userId,Date startDate,Date endDate){
		return schoolDao.countByInviterUserIdAndCreateTimeBetween(userId,startDate,endDate);
	}
	
	public String sumConsumeHistory(String startDate,String endDate,Date activityStartDate,Date activityEndDate,String userId){
		
		List<String> mobileList = activityDao.getAgentBindMobiles(activityStartDate,activityEndDate,userId);
		
		List<UsrDetail> list = userService.findUsersByRegtime(startDate, endDate,mobileList);
		List<String> userIdList = new ArrayList<>();
		for(UsrDetail usr : list){
			userIdList.add(usr.getUserId());
		}
		
		return activityDao.sumConsumeBySchoolAct(userIdList,activityStartDate,activityEndDate);
	}
	
	/**
	  * 查询某代理商下面所有绑定的手机号
	  * @param userIdList
	  * @param activityStartDate
	  * @param activityEndDate
	  * @param userId
	  * @return
	  */
	 public List<String> getAgentBindMobiles(Date activityStartDate,Date activityEndDate,String userId) {
		 List<String> mobileList = activityDao.getAgentBindMobiles(activityStartDate,activityEndDate,userId);
		 return mobileList;
	 }
	
	public List<ActivitySchoolAgent> getAllSchoolAgent(){
		return activitySchoolAgentDao.findAllAgent();
	}
	
	public void deleteBindUser(){
		List<ActivitySchool> schoolList = schoolDao.findAllActivitySchool();
		if(schoolList != null && schoolList.size() > 0){
			for(ActivitySchool school : schoolList){
				UsrDetail userDetail = userService.findUserByMobile(school.getInviteeUserMobile());
				if(userDetail == null){
					activityDao.deleteBindUser(school.getInviteeUserMobile());
				}
			}
		}
		
	}
	
	public void deleteByInviteeUserMobile(String inviteeUserMobile){
		schoolDao.deleteByInviteeUserMobile(inviteeUserMobile);
	}
}
