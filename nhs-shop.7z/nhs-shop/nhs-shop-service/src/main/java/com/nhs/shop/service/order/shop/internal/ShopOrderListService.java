package com.nhs.shop.service.order.shop.internal;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.nhs.core.common.NhsConstant;
import com.nhs.core.context.SysPropsFactory;
import com.nhs.core.orm.Page;
import com.nhs.core.utils.common.ArithUtils;
import com.nhs.core.utils.common.DateUtils;
import com.nhs.core.utils.common.FormatUtils;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.shop.activity.dao.ActivitySchoolDao;
import com.nhs.shop.activity.entry.ActivitySchool;
import com.nhs.shop.dao.legend.shop.ProdDao;
import com.nhs.shop.dao.legend.shop.ShopOrderDao;
import com.nhs.shop.dao.legend.shop.SkuDao;
import com.nhs.shop.dao.legend.shop.SubItemDao;
import com.nhs.shop.entry.em.order.ShopOrderStatusEnum;
import com.nhs.shop.entry.legend.shop.Prod;
import com.nhs.shop.entry.legend.shop.Sku;
import com.nhs.shop.entry.legend.shop.SubItem;
import com.nhs.shop.entry.legend.user.UsrDetail;
import com.nhs.shop.rebate.service.CalRebateService;
import com.nhs.shop.service.BaseService;
import com.nhs.shop.service.goods.GoodsService;
import com.nhs.shop.service.order.dto.ActivityOrderDto;
import com.nhs.shop.service.order.dto.OrderListDto;
import com.nhs.shop.service.order.dto.OrderListDto.OrderItemDto;
import com.nhs.shop.service.system.SystemParameterService;
import com.nhs.user.service.UserService;

/**
 * 商城订单列表service
 * @Title: GoodsService.java
 * @Package com.nhs.shop.service.goods
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月16日 下午7:42:18
 * @version V1.0
 */
@Service
public class ShopOrderListService extends BaseService {

    @Autowired
    private ShopOrderDao shopOrderDao;
    @Autowired
    private SubItemDao subItemDao;
    @Autowired
    private ProdDao prodDao;
    @Autowired
    private SkuDao SkuDao;
    @Autowired
    private GoodsService goodsService;
    @Autowired
    private ShopOrderAddService shopOrderAddService;

    @Autowired
    private SystemParameterService sysService;
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private ActivitySchoolDao activitySchoolDao;
    
    @Autowired
    private CalRebateService calRebateService;

    /**
     * 
     * @Title: getOrderList
     * @Description: TODO
     * @param @param userId
     * @param @param status
     * @param @param page
     * @param @return   
     * @return List<OrderListDto> 
     * @author Administrator 2016年10月28日 
     * @throws
     */
    public List<OrderListDto> getOrderList(String userId, Integer status, Page<Map<String, Object>> page) {
        List<OrderListDto> list = Lists.newArrayList();
        if (StringUtils.isBlank(userId)) {
            return list;
        }
        Page<Map<String, Object>> pageData = shopOrderDao.getOrderList(userId, status, page);
        OrderListDto dto = null;
        for (Map<String, Object> map : pageData.getResult()) {
            dto = new OrderListDto();
            dto.setOrderId(StringHelper.objectToInt(map.get("sub_id"), 0));
            dto.setShopId(StringHelper.objectToInt(map.get("shop_id"), 0));
            dto.setShopName(StringHelper.objectToString(map.get("shop_name"), ""));
            dto.setStatus(StringHelper.objectToInt(map.get("status"), 0));
            dto.setStatusName(ShopOrderStatusEnum.desc(dto.getStatus()));
            dto.setTotalNum(StringHelper.objectToInt(map.get("product_nums"), 0));
            // TODO 修改合计总价 liangdanhua
            dto.setFreightAmount(StringHelper.objectToDouble(map.get("freight_amount"), 0.0));
            dto.setTotalAmount(StringHelper.objectToDouble(map.get("actual_total"), 0.0));
            String subNumber = StringHelper.objectToString(map.get("sub_number"), "");
            dto.setOrderNum(subNumber); // freight_amount
            dto.setArriageShowUrl(
                    shopOrderAddService.findArriageShowUrl(StringHelper.objectToString(map.get("sub_id"), "")));
            // 订单明细
            List<SubItem> subItemList = subItemDao.findSubItem(subNumber);
            for (SubItem subItem : subItemList) {
                OrderItemDto itemDto = new OrderItemDto();
                itemDto.setProdId(subItem.getProdId());
                itemDto.setProdName(subItem.getProdName());
                itemDto.setSkuDesc(subItem.getAttribute());
                itemDto.setCount(subItem.getBasketCount());
                itemDto.setPic(this.buildImg(subItem.getPic()));

                itemDto.setPrice(subItem.getCash().doubleValue());

                if(subItem.getAdFeeRate() == null){
                	subItem.setAdFeeRate(new BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE));
                }
                if(subItem.getAdFeeBasicRate() == null){
                	subItem.setAdFeeBasicRate(new BigDecimal(NhsConstant.DEFAULT_AD_FEE_BASIC_RATE));
                }
                //商家推广费率<=10%时，按照之前规则赠送给用户佰德钻；商家推广费率>10%时，超出比例部分做立减
                if(subItem.getAdFeeRate().compareTo(new BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE_CRITICAL)) > 0){
                	itemDto.setDiscount(SysPropsFactory.getProperty(NhsConstant.SYS_CONSUME_REDUCE_LABEL));
//                	subItem.setRebate(new BigDecimal(NhsConstant.DEFAULT_REBATE));
                }else{
                	itemDto.setDiscount("");
//                	subItem.setRebate(ArithUtils.div2(subItem.getAdFeeRate(), subItem.getAdFeeBasicRate(), 3,BigDecimal.ROUND_DOWN));
                }
                itemDto.setCoupon(SysPropsFactory.getProperty(NhsConstant.SYS_COUPON_LABEL));
              
                subItem.setRebate(calRebateService.calRebate(subItem.getAdFeeRate(), subItem.getAdFeeBasicRate(), NhsConstant.DEFAULT_AD_FEE_RATE_NEW_MAX_SHOP));
                
                String mailStatus = goodsService.calculatePostage(subItem.getProdId().toString(), userId);
                itemDto.setMailStatus(mailStatus);
                
                itemDto.setSubsidy(FormatUtils
                        .formatMoney(ArithUtils.mul(subItem.getCash().doubleValue(), subItem.getRebate().doubleValue())));
                itemDto.setSubsidyStr(sysService.getSingleValueByType(NhsConstant.PARAM_PRESENT_SIGN)
                        + sysService.getSingleValueByType(NhsConstant.PARAM_RMB_ICON) + itemDto.getSubsidy());

                dto.addOrderItemDto(itemDto);
            }
            list.add(dto);
        }
        return list;
    }

    /**
     * 获取活动商城订单列表
     * @Title: getActivityOrderList
     * @Description: TODO
     * @param @param 
     * @param @param    
     * @param @param 
     * @param @return   
     * @return List<OrderListDto> 
     * @author Administrator 2016年7月20日 
     * @throws
     */
    public List<ActivityOrderDto> getActivityOrderList(String startTime, String endTime) {
        List<ActivityOrderDto> list = Lists.newArrayList();

        List<Map<String, Object>> result = shopOrderDao.getActivityOrderList(startTime, endTime);
        ActivityOrderDto dto = null;
        for (Map<String, Object> map : result) {
            dto = new ActivityOrderDto();
            dto.setUserId(StringHelper.objectToString(map.get("user_id"), ""));
            UsrDetail userDetail = userService.findUserById(dto.getUserId());
            if(userDetail == null){
            	continue;
            }
            
            String userMobile = userDetail.getUserMobile();
            
            List<ActivitySchool> activitySchoolList = activitySchoolDao.findAllActivitySchool();
            
            List<String> inviteeUserMobileList = new ArrayList<>();
            
            if(activitySchoolList != null && activitySchoolList.size() > 0){
            	for(ActivitySchool activitySchool : activitySchoolList){
            		inviteeUserMobileList.add(activitySchool.getInviteeUserMobile());
            	}
            }
            
            if(inviteeUserMobileList.contains(userMobile)){
            	continue;
            }
            
            dto.setOrderId(StringHelper.objectToInt(map.get("sub_id"), 0));
            dto.setOrderNum(StringHelper.objectToString(map.get("sub_number"), ""));
            
            BigDecimal payAmount = StringHelper.objectToBigDecimal(map.get("actual_total"), "");
            dto.setPayAmountStr(payAmount == null ? "0.00" : payAmount.setScale(2, BigDecimal.ROUND_DOWN).toString());
            Date payTime = (Date) map.get("pay_date");
            dto.setPayTimeStr(DateUtils.date2Str(payTime));
            list.add(dto);

        }
        return list;
    }

}
