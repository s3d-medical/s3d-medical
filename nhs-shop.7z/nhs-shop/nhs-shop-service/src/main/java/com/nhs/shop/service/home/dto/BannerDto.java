package com.nhs.shop.service.home.dto;

import java.io.Serializable;

/**
 * banner dto
 * @Title: BannerDto.java
 * @Package com.nhs.shop.service.home.dto
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月16日 下午5:31:15
 * @version V1.0
 */
public class BannerDto implements Serializable {

	private static final long serialVersionUID = -6431848563491993653L;

	private String type = "";
	private String image = "";
	private String typeId = "";
	private String link = "";

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getTypeId() {
		return typeId;
	}

	public void setTypeId(String typeId) {
		this.typeId = typeId;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}
	

}
