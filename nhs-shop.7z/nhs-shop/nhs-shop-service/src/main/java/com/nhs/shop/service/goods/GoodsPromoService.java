package com.nhs.shop.service.goods;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nhs.core.common.NhsConstant;
import com.nhs.shop.entry.legend.shop.Prod;
import com.nhs.shop.entry.legend.shop.Sku;
import com.nhs.shop.rebate.service.CalRebateService;
import com.nhs.shop.service.goods.dto.PromotionDto;

/**
 * 商品促销服务
 * 内部计算数据精度是4位, 对外提供服务是按照用户指定的精度.
 * @author wind.chen
 *
 */
@Service
@Transactional
public class GoodsPromoService {
	/**
	 * 内部用计算精度
	 */
	private int inPrecision = 4 ;
	/**
	 * 佰德钻和金钱的转换比例.
	 */
	private BigDecimal diamondExchangeRate = new BigDecimal("1");
	/**
	 * 立减的推广费率上限.
	 */
	private BigDecimal limitRate = new BigDecimal("0.10");
	
	@Autowired
	private CalRebateService calRebateService;
	
	/**
	 * 计算多个商品的总的促销数据: 补贴总额, 立减总额.
	 * 
	 * @param countList
	 * @param prodList
	 * @param scale
	 * @return
	 */
	public PromotionDto calMultiSkuProdPromo(List<Double> countList, List<Sku> skuList, List<Prod> prodList,
			int scale) {
		PromotionDto promotionDto = new PromotionDto();
		// 1 check....
		if (countList == null || prodList == null) {
			return promotionDto;
		}
		if (countList.size() != prodList.size()) {
			throw new RuntimeException("需要计算的产品没有对应的购买数量, 无法计算.");
		}
		if (skuList != null) {
			if (skuList.size() != prodList.size()) {
				throw new RuntimeException("参与计算的prod和sku不匹配, 无法计算.");
			}
		}
		// 2 calculate reduced cash, subsidy virtual currency
		BigDecimal totalReducedCash = new BigDecimal("0.00");
		BigDecimal totalSubsidy = new BigDecimal("0.00");
		for (int i = 0; i < countList.size(); i++) {
			BigDecimal subsidy = this.calSubsidy(countList.get(i), skuList.get(i), prodList.get(i), this.inPrecision);
			totalSubsidy = totalSubsidy.add(subsidy);
			BigDecimal reducedCash = this.calReducedCash(countList.get(i), skuList.get(i), prodList.get(i), this.inPrecision);
			totalReducedCash = totalReducedCash.add(reducedCash);
		}
		promotionDto.setReducedCash(totalReducedCash.setScale(scale, BigDecimal.ROUND_DOWN));
		promotionDto.setSubsidy(totalSubsidy.setScale(2, BigDecimal.ROUND_DOWN));
		// 3 subsidy real money. 
		if(totalSubsidy != null){
			BigDecimal subsidyMoney = totalSubsidy.divide(this.diamondExchangeRate);
			promotionDto.setSubsidyMoney(subsidyMoney.setScale(2, BigDecimal.ROUND_DOWN));	//补贴的现金
		}
		return promotionDto;
	}

	/**
	 * 计算产品sku的促销费.
	 * 
	 * @param sku
	 * @param prod
	 * @return
	 */
	public PromotionDto calSkuProdPromo(Double count, Sku sku, Prod prod, int scale) {
		PromotionDto promotionDto = new PromotionDto();
		// 计算立减
		BigDecimal reducedCash = this.calReducedCash(count, sku, prod, scale);
		promotionDto.setReducedCash(reducedCash);
		// 计算补贴(虚拟货币佰德钻)
		BigDecimal subsidy = this.calSubsidy(count, sku, prod, scale);
		promotionDto.setSubsidy(subsidy); 
		//计算补贴(真实货币)
		if(subsidy != null){
			promotionDto.setSubsidyMoney(subsidy.divide(this.diamondExchangeRate));	//补贴的现金
		}
		return promotionDto;
	}

	/**
	 * 计算立减
	 * 
	 * @param count
	 * @param sku
	 * @param prod
	 * @param scale
	 * @return
	 */
	public BigDecimal calReducedCash(Double count, Sku sku, Prod prod, int scale) {
		if (prod == null) {
			throw new RuntimeException("促销相关计算时, Prod对象不能为空.");
		}
		if (sku == null) {
			return this.calReducedCash(count, prod.getCash(), prod.getAdFeeRate(), scale);
		}
		BigDecimal price = sku.getPrice();
		if (price == null || price.doubleValue() == 0.0) {
			price = prod.getCash();
		}
		return this.calReducedCash(count, price, prod.getAdFeeRate(), scale);
	}

	/**
	 * 计算立减
	 * 
	 * @param count
	 *            总数
	 * @param price
	 *            单价
	 * @param userRate
	 * @param basicRate
	 * @return
	 */
	public BigDecimal calReducedCash(Double count, BigDecimal price, BigDecimal userRate, int scale) {
		if (userRate == null || userRate.doubleValue() <= 0.0) {
			return new BigDecimal("0.00");
		}
		if (count == null || count <= 0) {
			throw new RuntimeException("参与立减计算的商品数量必须大于0.00");
		}

		BigDecimal reducedCash = null;
		BigDecimal reducedRate = userRate.subtract(new BigDecimal("0.10"));
		if (reducedRate.doubleValue() > 0.0) {
			reducedCash = price.multiply(reducedRate);
			reducedCash = reducedCash.multiply(new BigDecimal(count));
			reducedCash = reducedCash.setScale(scale, BigDecimal.ROUND_DOWN);
		}else{
			reducedCash = new BigDecimal("0.00");
		}
		return reducedCash;
	}

	/**
	 * 去除立减额后的价格.
	 * @param price
	 * @param sellerRate  商家推广费率
	 * @return
	 */
	private BigDecimal calRealPrice(BigDecimal price, BigDecimal sellerRate, int scale) {
		// 计算精简后的价格 = 原价格 - 立减.
		BigDecimal unitReducedCash = this.calReducedCash(1.0, price, sellerRate, scale); // 单个立减多少钱.
		BigDecimal realUnitPrice = price.subtract(unitReducedCash); // 立减后的单价
		return realUnitPrice.setScale(scale, BigDecimal.ROUND_DOWN);
	}

	/**
	 * 计算补贴
	 * @param count 数量
	 * @param price 单价
	 * @param sellerRate  商家给定的推广费率
	 * @param basicRate   基本推广费率.
	 * @return
	 */
	public BigDecimal calSubsidy(Double count, BigDecimal price, 
			BigDecimal sellerRate, BigDecimal basicRate, int scale) {
		if (count == null || count <= 0) {
			throw new RuntimeException("参与补贴计算的商品数量必须大于0.00");
		}
		// unit price after reducing cash.
		BigDecimal realUnitPrice = this.calRealPrice(price, sellerRate, 4);
		
		//计算补贴率
//		BigDecimal rebate = this.getBRebate(sellerRate, basicRate, 4); // 补贴率
		BigDecimal rebate = calRebateService.calRebate(sellerRate, basicRate, NhsConstant.DEFAULT_AD_FEE_RATE_NEW_MAX_O2O);
		BigDecimal unitSubsidy = realUnitPrice.multiply(rebate);     //单个补贴多少钱.
		BigDecimal totalSubsidy = unitSubsidy.multiply(BigDecimal.valueOf(count)); //
		totalSubsidy = totalSubsidy.multiply(this.diamondExchangeRate);
		totalSubsidy = totalSubsidy.setScale(scale, BigDecimal.ROUND_DOWN);
		return totalSubsidy;
	}

	/**
	 * 计算补贴
	 * @param count
	 * @param sku
	 * @param prod
	 * @param scale
	 * @return
	 */
	public BigDecimal calSubsidy(Double count, Sku sku, Prod prod, int scale) {
		if (prod == null) {
			throw new RuntimeException("促销相关计算时, Prod对象不能为空.");
		}
		if (sku == null) {
			return this.calSubsidy(count, prod.getCash(), prod.getAdFeeRate(), prod.getAdFeeBasicRate(), scale);
		}
		BigDecimal price = sku.getPrice();
		if (price == null || price.doubleValue() == 0.0) {
			price = prod.getCash();
		}
		return this.calSubsidy(count, price, prod.getAdFeeRate(), prod.getAdFeeBasicRate(), scale);
	}

	/**
	 * 计算补贴率(最好是放在Prod对象上.)
	 * @param userGivenRate
	 * @param basicRate
	 * @param scale
	 * @return
	 */
	public BigDecimal getBRebate(BigDecimal userGivenRate, BigDecimal basicRate, int scale) {
		if (userGivenRate == null || userGivenRate.doubleValue() <= 0.0 || basicRate == null || basicRate.doubleValue() <= 0.0) {
			return new BigDecimal("0.00");
		}
		BigDecimal realGivenRate =  new BigDecimal("0.00");
		if(userGivenRate != null && userGivenRate.doubleValue() > this.limitRate.doubleValue()){
			realGivenRate = new BigDecimal(this.limitRate.toString());
		}else{
			realGivenRate = userGivenRate;
		}
		BigDecimal rebate = realGivenRate.divide(basicRate, 3, BigDecimal.ROUND_DOWN);
		return rebate;
	}
	
	/**
	 * 计算补贴率
	 * @param userRate
	 * @param basicRate
	 * @param scale
	 * @return
	 */
	public BigDecimal getBRebate(Prod prod, int scale) {
		return this.getBRebate(prod.getAdFeeRate(), prod.getAdFeeBasicRate(), scale);
	}
	
	/**
	 * 计算补贴率
	 * 获取产品的rebate , 以double类型返回.
	 * @param prod
	 * @return
	 */
	public Double getDRebate(Prod prod) {
		return this.getBRebate(prod.getAdFeeRate(), prod.getAdFeeBasicRate(), 2).doubleValue();
	}
}
