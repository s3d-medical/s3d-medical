package com.nhs.shop.service.order.dto;

import java.io.Serializable;
import java.math.BigDecimal;

public class StoreOrderItemDto implements Serializable {

    private static final long serialVersionUID = 1L;
    
    private String prodNo;
    private String prodName = "";
    private double prodNum = 0;
    private String prodPrimePrice = "";			//商品单价
    private String prodSalePrice = "";			//商品零售价
    private String prodTotalPrice = "";			//商品总金额
    private String couponAmountStr;
    private BigDecimal prodAdFeeRate = new BigDecimal("0.00");
    private BigDecimal prodAdFeeBasicRate = new BigDecimal("0.16");;
    private String giveSilver = "0.00";
    private String giveGold = "0.00";
    private String prodAdFee = "0";
    private String prodAdFeeRateStr = "0.00";
    private String shopGiveSilver = "0.00";
	
	public String getProdNo() {
		return prodNo;
	}
	public void setProdNo(String prodNo) {
		this.prodNo = prodNo;
	}
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public double getProdNum() {
		return prodNum;
	}
	public void setProdNum(double prodNum) {
		this.prodNum = prodNum;
	}
	public String getProdPrimePrice() {
		return prodPrimePrice;
	}
	public void setProdPrimePrice(String prodPrimePrice) {
		this.prodPrimePrice = prodPrimePrice;
	}
	public String getProdSalePrice() {
		return prodSalePrice;
	}
	public void setProdSalePrice(String prodSalePrice) {
		this.prodSalePrice = prodSalePrice;
	}
	public String getProdTotalPrice() {
		return prodTotalPrice;
	}
	public void setProdTotalPrice(String prodTotalPrice) {
		this.prodTotalPrice = prodTotalPrice;
	}
	public String getCouponAmountStr() {
		return couponAmountStr;
	}
	public void setCouponAmountStr(String couponAmountStr) {
		this.couponAmountStr = couponAmountStr;
	}
	public BigDecimal getProdAdFeeRate() {
		return prodAdFeeRate;
	}
	public void setProdAdFeeRate(BigDecimal prodAdFeeRate) {
		this.prodAdFeeRate = prodAdFeeRate;
	}
	public BigDecimal getProdAdFeeBasicRate() {
		return prodAdFeeBasicRate;
	}
	public void setProdAdFeeBasicRate(BigDecimal prodAdFeeBasicRate) {
		this.prodAdFeeBasicRate = prodAdFeeBasicRate;
	}
	public String getGiveSilver() {
		return giveSilver;
	}
	public void setGiveSilver(String giveSilver) {
		this.giveSilver = giveSilver;
	}
	public String getGiveGold() {
		return giveGold;
	}
	public void setGiveGold(String giveGold) {
		this.giveGold = giveGold;
	}
	public String getProdAdFee() {
		return prodAdFee;
	}
	public void setProdAdFee(String prodAdFee) {
		this.prodAdFee = prodAdFee;
	}
	public String getProdAdFeeRateStr() {
		return prodAdFeeRateStr;
	}
	public void setProdAdFeeRateStr(String prodAdFeeRateStr) {
		this.prodAdFeeRateStr = prodAdFeeRateStr;
	}
	public String getShopGiveSilver() {
		return shopGiveSilver;
	}
	public void setShopGiveSilver(String shopGiveSilver) {
		this.shopGiveSilver = shopGiveSilver;
	}
	
	

}
