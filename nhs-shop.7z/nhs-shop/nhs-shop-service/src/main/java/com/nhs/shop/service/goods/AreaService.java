package com.nhs.shop.service.goods;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.nhs.core.persistence.DynamicSpecifications;
import com.nhs.core.persistence.SearchFilter;
import com.nhs.core.persistence.SearchFilter.Operator;
import com.nhs.shop.dao.core.area.AreaDao;
import com.nhs.shop.dao.core.area.shql.AreaSqlDao;
import com.nhs.shop.entry.core.area.Area;

@Service
public class AreaService {

    @Resource
    AreaSqlDao areaSqlDao;

    @Resource
    AreaDao areaDao;

    public List<Area> getAreaByPage(String parent, int begin, int size) {

        return areaSqlDao.getAreaHqlByParent(parent, begin, size);
    }

    // 根据parentId获取当前Area
    public Area findAreaByAreaId(int areaId) {
        return areaDao.findOne(areaId);
    }

    public Page<Area> getAreaPage(Map<String, Object> params, Integer parentId, int pageNo, int pageSize) {
        PageRequest request = new PageRequest(pageNo - 1, pageSize, new Sort(new Sort.Order(Sort.Direction.ASC, "id")));
        Map<String, SearchFilter> filters = SearchFilter.parse(params);
        if (filters.get("EQ_parentId") == null) {
            SearchFilter parent_Id = new SearchFilter("parentId", Operator.EQ, parentId);
            filters.put("EQ_parentId", parent_Id);
        }
        if (filters.get("LIKE_name") != null) {
            SearchFilter name = new SearchFilter("name", Operator.LIKE, filters.get("LIKE_name").value.toString());
            filters.put("LIKE_name", name);
        }
        if (filters.get("EQ_service") != null) {
            SearchFilter isService = new SearchFilter("isService", Operator.EQ,
                    Integer.parseInt(filters.get("EQ_service").value.toString()));
            filters.put("EQ_service", isService);
        }
        Specification<Area> spec = DynamicSpecifications.bySearchFilter(filters.values(), Area.class);
        Page<Area> page = areaDao.findAll(spec, request);

        return page;
    }

    /**
     * 查找所有的服务城市
     * @param params
     * @param pageNo
     * @param pageSize
     * @return
     */
    public Page<Area> getServiceAreaPage(int pageNo, int pageSize) {
        PageRequest request = new PageRequest(pageNo - 1, pageSize, new Sort(new Sort.Order(Sort.Direction.ASC, "id")));
        Page<Area> page = areaDao.findServiceArea(request);

        return page;
    }

    public List<Area> findAreaListByParentId(int parentId) {
        return areaDao.findAreaListByParentId(parentId);
    }

    // 根据ID获取Area信息
    public Area findAreaById(int id) {
        return areaDao.findOne(id);
    }

    // 根据Id删除Area信息
    public void deleteAreaById(int id) {
        areaDao.delete(id);
    }

    public Area saveArea(Area area) {
        return areaDao.save(area);
    }

    public Area saveUpdateArea(Area area) {
        return areaDao.save(area);
    }
}
