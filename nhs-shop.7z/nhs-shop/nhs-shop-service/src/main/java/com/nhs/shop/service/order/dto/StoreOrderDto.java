package com.nhs.shop.service.order.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import com.google.common.collect.Lists;


public class StoreOrderDto  implements Serializable {

    private static final long serialVersionUID = 2308053677959309156L;
    private Integer orderId;
    private String orderNum;
    private Integer shopId;
    private String shopName;
    private String address;
    private String pic;
    private Integer status;
    private String statusName;
    private String createTime;
    private String couponAmount = "";
    private String payAmountStr = "";
    private String totalAmountStr = "";
    private String appPayAmountStr = "";
    private String otherPayAmountStr = "";
    private String coupon;
    private String couponStr;
    private long containsProdNum;
    private Integer excetpionStatus;
    private BigDecimal orderEffectiveAmount;	//异常订单 - 其他付款方式金额； 正常订单 - 总金额
    private List<StoreOrderItemDto> itemList = Lists.newArrayList();
    private String giveSilver = "0.00";
    private String giveGold = "0.00";
    private String totalProdAdFee = "0.00";
    private String payTime = "";
    private String tradeNo;
    private String shopGiveSilver = "0.00";
    
    
    public List<StoreOrderItemDto> getItemList() {
        return itemList;
    }

    public void setItemList(List<StoreOrderItemDto> itemList) {
        this.itemList = itemList;
    }

    public void addStoreOrderItemDto(StoreOrderItemDto orderItemDto) {
        this.itemList.add(orderItemDto);
    }
    
	public Integer getOrderId() {
		return orderId;
	}
	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}
	public String getOrderNum() {
		return orderNum;
	}
	public void setOrderNum(String orderNum) {
		this.orderNum = orderNum;
	}
	public Integer getShopId() {
		return shopId;
	}
	public void setShopId(Integer shopId) {
		this.shopId = shopId;
	}
	public String getShopName() {
		return shopName;
	}
	public void setShopName(String shopName) {
		this.shopName = shopName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPic() {
		return pic;
	}
	public void setPic(String pic) {
		this.pic = pic;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public String getStatusName() {
		return statusName;
	}
	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}
	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	
	public String getCouponAmount() {
		return couponAmount;
	}
	public void setCouponAmount(String couponAmount) {
		this.couponAmount = couponAmount;
	}
	public String getPayAmountStr() {
		return payAmountStr;
	}
	public void setPayAmountStr(String payAmountStr) {
		this.payAmountStr = payAmountStr;
	}
	public String getTotalAmountStr() {
		return totalAmountStr;
	}
	public void setTotalAmountStr(String totalAmountStr) {
		this.totalAmountStr = totalAmountStr;
	}
	public String getCoupon() {
		return coupon;
	}
	public void setCoupon(String coupon) {
		this.coupon = coupon;
	}
	public String getCouponStr() {
		return couponStr;
	}
	public void setCouponStr(String couponStr) {
		this.couponStr = couponStr;
	}

	public long getContainsProdNum() {
		return containsProdNum;
	}
	public void setContainsProdNum(long containsProdNum) {
		this.containsProdNum = containsProdNum;
	}
	public String getAppPayAmountStr() {
		return appPayAmountStr;
	}
	public void setAppPayAmountStr(String appPayAmountStr) {
		this.appPayAmountStr = appPayAmountStr;
	}
	public String getOtherPayAmountStr() {
		return otherPayAmountStr;
	}
	public void setOtherPayAmountStr(String otherPayAmountStr) {
		this.otherPayAmountStr = otherPayAmountStr;
	}
	public Integer getExcetpionStatus() {
		return excetpionStatus;
	}
	public void setExcetpionStatus(Integer excetpionStatus) {
		this.excetpionStatus = excetpionStatus;
	}
	public BigDecimal getOrderEffectiveAmount() {
		return orderEffectiveAmount;
	}
	public void setOrderEffectiveAmount(BigDecimal orderEffectiveAmount) {
		this.orderEffectiveAmount = orderEffectiveAmount;
	}

	public String getGiveSilver() {
		return giveSilver;
	}

	public void setGiveSilver(String giveSilver) {
		this.giveSilver = giveSilver;
	}

	public String getGiveGold() {
		return giveGold;
	}

	public void setGiveGold(String giveGold) {
		this.giveGold = giveGold;
	}

	public String getTotalProdAdFee() {
		return totalProdAdFee;
	}

	public void setTotalProdAdFee(String totalProdAdFee) {
		this.totalProdAdFee = totalProdAdFee;
	}

	public String getPayTime() {
		return payTime;
	}

	public void setPayTime(String payTime) {
		this.payTime = payTime;
	}

	public String getTradeNo() {
		return tradeNo;
	}

	public void setTradeNo(String tradeNo) {
		this.tradeNo = tradeNo;
	}

	public String getShopGiveSilver() {
		return shopGiveSilver;
	}

	public void setShopGiveSilver(String shopGiveSilver) {
		this.shopGiveSilver = shopGiveSilver;
	}
    
	
    

}
