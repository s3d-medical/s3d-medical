package com.nhs.shop.service.order.shop.internal;

import java.math.BigDecimal;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nhs.core.common.NhsConstant;
import com.nhs.core.context.SysPropsFactory;
import com.nhs.core.utils.common.ArithUtils;
import com.nhs.core.utils.common.DateUtils;
import com.nhs.core.utils.common.FormatUtils;
import com.nhs.core.web.WebRequestException;
import com.nhs.shop.dao.legend.shop.ProdDao;
import com.nhs.shop.dao.legend.shop.SkuDao;
import com.nhs.shop.dao.legend.shop.SubDao;
import com.nhs.shop.dao.legend.shop.SubItemDao;
import com.nhs.shop.dao.legend.shop.TransportDao;
import com.nhs.shop.dao.legend.shop.UsrAddrSubDao;
import com.nhs.shop.entry.em.order.ShopOrderStatusEnum;
import com.nhs.shop.entry.legend.shop.Prod;
import com.nhs.shop.entry.legend.shop.Sub;
import com.nhs.shop.entry.legend.shop.SubItem;
import com.nhs.shop.entry.legend.shop.Transfee;
import com.nhs.shop.entry.legend.shop.Transport;
import com.nhs.shop.entry.legend.user.UsrAddrSub;
import com.nhs.shop.rebate.service.CalRebateService;
import com.nhs.shop.service.BaseService;
import com.nhs.shop.service.goods.GoodsService;
import com.nhs.shop.service.order.dto.OrderDetailDto;
import com.nhs.shop.service.order.dto.UserAddressDto;
import com.nhs.shop.service.system.SystemParameterService;
import com.nhs.shop.util.TransportHelper;

/**
 * 商城订单详情service
 * @Title: GoodsService.java
 * @Package com.nhs.shop.service.goods
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月16日 下午7:42:18
 * @version V1.0
 */
@Service
public class ShopOrderDetailService extends BaseService {

    @Autowired
    private SubDao subDao;
    @Autowired
    private SubItemDao subItemDao;
    @Autowired
    private UsrAddrSubDao usrAddrSubDao;
    @Autowired
    private ProdDao prodDao;
    @Autowired
    private SkuDao skuDao;
    @Autowired
    private TransportDao transportDao;
    @Autowired
    private TransportHelper transportHelper;
    @Autowired
    private ShopOrderAddService shopOrderAddService;
    @Autowired
    private GoodsService goodsService;

    @Autowired
    private SystemParameterService sysService;
    
    @Autowired
    private CalRebateService calRebateService;


    /**
     * 获取订单列表
     * @Title: getOrderList
     * @Description: TODO
     * @param @param userId
     * @param @param status
     * @param @param page
     * @param @return   
     * @return List<OrderListDto> 
     * @author Administrator 2016年7月20日 
     * @throws
     */
    public OrderDetailDto getOrderDetail(String userId, Integer orderId) {

        Sub sub = subDao.findOne(orderId);
        if (sub == null) {
            throw new WebRequestException("订单不存在");
        }
        OrderDetailDto dto = new OrderDetailDto();
        dto.setOrderId(sub.getSubId());
        dto.setShopId(sub.getShopId());
        dto.setShopName(sub.getShopName());
        dto.setStatus(sub.getStatus());
        dto.setStatusName(ShopOrderStatusEnum.desc(dto.getStatus()));
        dto.setTotalNum(sub.getProductNums());
        // TODO 修改订单总价总价和付款总价
        dto.setTotalAmount(sub.getTotal().doubleValue());
        dto.setCreateTime(DateUtils.date2Str(sub.getSubDate()));
        dto.setOrderNum(sub.getSubNumber());
//        dto.setPayAmount(sub.getActualTotal().doubleValue());
        dto.setFreightAmount(sub.getFreightAmount());
        dto.setCancelTime(DateUtils.date2Str(sub.getCancelDate()));
        dto.setSuccessTime(DateUtils.date2Str(sub.getSuccessDate()));
        if (sub.getPayDate() != null) {
            dto.setPayTime(DateUtils.date2Str(sub.getPayDate()));
        }
        dto.setArriageShowUrl(shopOrderAddService.findArriageShowUrl(sub.getSubId().toString()));
        // 订单明细
        List<SubItem> subItemList = subItemDao.findSubItem(sub.getSubNumber());
        BigDecimal silverNum = new BigDecimal("0.00");
        for (SubItem subItem : subItemList) {
            OrderDetailDto.OrderItemDto itemDto = new OrderDetailDto.OrderItemDto();
            itemDto.setProdId(subItem.getProdId());
            itemDto.setProdName(subItem.getProdName());
            itemDto.setSkuDesc(subItem.getAttribute());
            itemDto.setCount(subItem.getBasketCount());
            itemDto.setPic(this.buildImg(subItem.getPic()));
            itemDto.setPrice(subItem.getCash() == null ? 0.00 : subItem.getCash().doubleValue());
            itemDto.setDetailUrl(SysPropsFactory.getProperty("goodsDetailUrl") + subItem.getProdId());
            if(subItem.getAdFeeRate() == null){
            	subItem.setAdFeeRate(new BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE));
            }
            if(subItem.getAdFeeBasicRate() == null){
            	subItem.setAdFeeBasicRate(new BigDecimal(NhsConstant.DEFAULT_AD_FEE_BASIC_RATE));
            }
            //商家推广费率<=10%时，按照之前规则赠送给用户佰德钻；商家推广费率>10%时，超出比例部分做立减
            if(subItem.getAdFeeRate().compareTo(new BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE_CRITICAL)) > 0){
            	itemDto.setDiscount(SysPropsFactory.getProperty(NhsConstant.SYS_CONSUME_REDUCE_LABEL));
//            	subItem.setRebate(new BigDecimal(NhsConstant.DEFAULT_REBATE));
            }else{
            	itemDto.setDiscount("");
//            	subItem.setRebate(ArithUtils.div2(subItem.getAdFeeRate(), subItem.getAdFeeBasicRate(), 3,BigDecimal.ROUND_DOWN));
            }
            subItem.setRebate(calRebateService.calRebate(subItem.getAdFeeRate(), subItem.getAdFeeBasicRate(), NhsConstant.DEFAULT_AD_FEE_RATE_NEW_MAX_SHOP));
            silverNum = silverNum.add(ArithUtils.mul2(subItem.getProductTotalAmout(), subItem.getRebate(), 4, BigDecimal.ROUND_DOWN).multiply(new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE)).setScale(2, BigDecimal.ROUND_DOWN));
            itemDto.setCoupon(SysPropsFactory.getProperty(NhsConstant.SYS_COUPON_LABEL));
            
            String mailStatus = goodsService.calculatePostage(subItem.getProdId().toString(), userId);
            itemDto.setMailStatus(mailStatus);
            
            itemDto.setSubsidy(FormatUtils
                    .formatMoney(ArithUtils.mul(subItem.getCash().doubleValue(), subItem.getRebate().doubleValue())));
            itemDto.setSubsidyStr(sysService.getSingleValueByType(NhsConstant.PARAM_PRESENT_SIGN)
                    + sysService.getSingleValueByType(NhsConstant.PARAM_RMB_ICON) + itemDto.getSubsidy());
            dto.addOrderItemDto(itemDto);
        }
        
        String couponFont = SysPropsFactory.getProperty(NhsConstant.SYS_COUPON_ORDER_FONT);
    	if(StringUtils.isEmpty(couponFont)){
    		dto.setCouponStr("");
    	}else{
    		couponFont = couponFont.replace("#", silverNum.toString());
    		dto.setCouponStr(couponFont);
    	}
    	dto.setCoupon(SysPropsFactory.getProperty(NhsConstant.SYS_COUPON_LABEL));
    	
    	 if(sub.getReduceAmount().compareTo(new BigDecimal("0")) > 0){
         	dto.setReduceAmount("-"+sysService.getSingleValueByType(NhsConstant.PARAM_RMB_ICON)+sub.getReduceAmount());
    	 }else{
    		 dto.setReduceAmount("");
    	 }
         if(sub.getCouponAmount().compareTo(new BigDecimal("0")) > 0){
         	dto.setCouponAmount("-"+sysService.getSingleValueByType(NhsConstant.PARAM_RMB_ICON)+sub.getCouponAmount());
         }else{
    		 dto.setCouponAmount("");
    	 }
         
//         dto.setTotalAmount(sub.getTotal().add(sub.getReduceAmount()).add(sub.getCouponAmount()).doubleValue());
         dto.setPayAmount(sub.getTotal().add(sub.getFreightAmount()).doubleValue());
         dto.setActualPayAmountStr(sub.getActualTotal().toString());
        dto.setAddress(getUserAddressDto(sub.getAddrOrderId()));
        dto.setSendTime(DateUtils.date2Str(sub.getDvyDate(), "yyyy-MM-dd HH:mm:ss"));
        return dto;
    }

    /**
     * 保存用户地址
     * @Title: saveUserAddressSub
     * @Description: TODO
     * @param @param addressId
     * @param @return   
     * @return UsrAddrSub 
     * @author Administrator 2016年7月20日 
     * @throws
     */
    private UserAddressDto getUserAddressDto(Integer addressId) {

        UsrAddrSub usrAddr = usrAddrSubDao.findOne(addressId);
        if (usrAddr == null) {
            throw new WebRequestException("用户地址不存在");
        }

        UserAddressDto dto = new UserAddressDto();
        dto.setAdderssId(addressId);
        dto.setContact(usrAddr.getReceiver());
        dto.setMobile(usrAddr.getMobile());
        dto.setAddress(usrAddr.getSubAdds());
        dto.setDetailAddress(usrAddr.getProvince() + usrAddr.getCity() + usrAddr.getArea() + usrAddr.getSubAdds());
        return dto;
    }

    /**
     * 
     * @Title: clacCartDeleivery
     * @Description: TODO
     * @param @param cityId
     * @param @param prodId
     * @param @param count
     * @param @param deliveType
     * @param @return   
     * @return Double 
     * @author liangdanhua 2016年8月22日 
     * @throws
     */
    public Double clacCartDeleivery(int cityId, int prodId, int count, String deliveType) {
        double sportFree = 0.0;
        Prod prod = prodDao.findOne(prodId);
        // 是否承担运费[1:商家承担运费;0: 买家承担运费;10:未设置]
        int stf = prod.getSupportTransportFree() == null ? 10 : prod.getSupportTransportFree();
        if (stf == 1) {
            sportFree = 0.0;
        } else if (stf == 0) {
            // 是否固定运费[0:使用运费模板;1:固定运费;10:未设置]
            int tsi = prod.getTransportType() == null ? 10 : prod.getTransportType();
            if (tsi == 1) {
                sportFree = prod.getExpressTransFee().doubleValue();
            } else if (tsi == 0) {
                int transportId = prod.getTransportId();
                Transport transport = transportDao.findOne(transportId);
                Transfee transfee = null;
                transfee = transportHelper.getTransport(transportId, cityId, deliveType);
                if (transfee != null) {
                    sportFree = transportHelper.clacCartDeleivery(transport.getTransType(), transfee, count,
                            count * (prod.getWeight() == null ? 0 : prod.getWeight()),
                            count * (prod.getVolume() == null ? 0 : prod.getVolume()));
                }
            }
        }
        return sportFree;
    }
}
