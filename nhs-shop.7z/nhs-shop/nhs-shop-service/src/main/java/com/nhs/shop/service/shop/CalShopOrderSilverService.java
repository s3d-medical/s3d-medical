package com.nhs.shop.service.shop;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nhs.core.common.NhsConstant;
import com.nhs.core.utils.common.ArithUtils;
import com.nhs.shop.entry.legend.shop.SubItem;
import com.nhs.shop.rebate.service.CalRebateService;

/**
 * 计算商城订单赠送银币数
 * @author Administrator
 *
 */
@Service
@Transactional
public class CalShopOrderSilverService {
	
		@Autowired
	    private CalRebateService calRebateService;
	
		public BigDecimal getShopOrderSilverNum(SubItem subItem){
			BigDecimal silverNum = new BigDecimal("0.00");
			if(subItem.getAdFeeRate() == null){
            	subItem.setAdFeeRate(new BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE));
            }
            if(subItem.getAdFeeBasicRate() == null){
            	subItem.setAdFeeBasicRate(new BigDecimal(NhsConstant.DEFAULT_AD_FEE_BASIC_RATE));
            }
            //商家推广费率<=10%时，按照之前规则赠送给用户佰德钻；商家推广费率>10%时，超出比例部分做立减
//            if(subItem.getAdFeeRate().compareTo(new BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE_CRITICAL)) > 0){
//            	subItem.setRebate(new BigDecimal(NhsConstant.DEFAULT_REBATE));
//            }else{
//            	subItem.setRebate(ArithUtils.div2(subItem.getAdFeeRate(), subItem.getAdFeeBasicRate(), 3,BigDecimal.ROUND_DOWN));
//            }
            subItem.setRebate(calRebateService.calRebate(subItem.getAdFeeRate(), subItem.getAdFeeBasicRate(), NhsConstant.DEFAULT_AD_FEE_RATE_NEW_MAX_SHOP));
            silverNum = silverNum.add(ArithUtils.mul2(subItem.getProductTotalAmout(), subItem.getRebate(), 4, BigDecimal.ROUND_DOWN).multiply(new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE))).setScale(2, BigDecimal.ROUND_DOWN);
            return silverNum;
		}
}
