package com.nhs.shop.service.goods;

import java.math.BigDecimal;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import com.nhs.shop.dao.legend.shop.ProdDao;
import com.nhs.shop.dao.legend.shop.TransportDao;
import com.nhs.shop.entry.legend.shop.Prod;
import com.nhs.shop.entry.legend.shop.Transfee;
import com.nhs.shop.entry.legend.shop.Transport;
import com.nhs.shop.service.common.dto.CarriageType;
import com.nhs.shop.service.goods.dto.CarriageDto;
import com.nhs.shop.service.goods.dto.CarriageItemDto;
import com.nhs.shop.util.TransportHelper;
import com.nhs.user.service.MemberService;

/**
 * 商品运费计算服务
 * 
 * @author wind.chen
 */
@Service
@Transactional
public class GoodCarriageService {
	private static Logger logger = LoggerFactory.getLogger(GoodCarriageService.class);


	@Autowired
	private ProdDao prodDao;

	@Autowired
	private TransportDao transportDao;

	@Autowired
	private TransportHelper transportHelper;

	@Autowired
	private MemberService memberService;

	/**
	 * 产品是否免运费
	 * 
	 * @param prodId
	 *            如果not null, 按照prodId计算是否包邮.
	 * @return
	 */
	public boolean ifDefaultProdPostFree(Integer prodId) {
		Assert.isTrue(prodId != null, "产品id不能为null");
		Prod prod = prodDao.findOne(prodId);
		int stf = prod.getSupportTransportFree() == null ? 10 : prod.getSupportTransportFree();
		if (stf == 1) {
			return true;
		}
		return false;
	}

	/**
	 * 产品是否免运费.
	 * 
	 * @param prod
	 * @return
	 */
	public boolean ifDefaultProdPostFree(Prod prod) {
		int stf = prod.getSupportTransportFree() == null ? 10 : prod.getSupportTransportFree();
		if (stf == 1) {
			return true;
		}
		return false;
	}

	/**
	 * 获取1种商品的运费 优先级: express, ems, mail 只会返回1种类型的运费.
	 * 
	 * @param prodId
	 * @param cityId
	 * @return
	 */
	public CarriageItemDto calDefaultPostageByCity(Prod prod, Integer cityId) {
		CarriageDto carriage = this.calAllKindsOfPostage(prod, 1.0, cityId);
		return carriage.getFirstNone0PostageItem(CarriageType.getAllTypes());
	}
	
	/**
	 * 
	 * @param prodList
	 * @param countList
	 * @param cityId
	 * @param carriageType
	 * @return
	 */
	public BigDecimal calOneKindsOfPostageVal(List<Prod> prodList, List<Double> countList, 
			int cityId, CarriageType carriageType){
		CarriageDto carriageDto = this.calAllKindsOfPostage(prodList, countList, cityId);
		CarriageItemDto item = carriageDto.getPostageItem(carriageType);
		if(item != null){
			return item.getVal();
		}
		return new BigDecimal("0.00");
	}

	/**
	 * 计算购买的多款商品的运费之和. 
	 * @param prodList
	 * @param count
	 * @param cityId
	 * @return
	 */
	public CarriageDto calAllKindsOfPostage(List<Prod> prodList,
					List<Double> countList, int cityId){
		if(prodList == null || countList == null || prodList.size() != countList.size()){
			throw new RuntimeException("参与计算的商品和每种商品的购买量必须一一对应.");
		}
		CarriageDto sum = new CarriageDto();
		for(int i=0; i< prodList.size(); i++){
			CarriageDto one = this.calAllKindsOfPostage(prodList.get(i), countList.get(i), cityId);
			sum.addPostage(CarriageType.express, one.getPostage(CarriageType.express));
			sum.addPostage(CarriageType.ems, one.getPostage(CarriageType.ems));
			sum.addPostage(CarriageType.mail, one.getPostage(CarriageType.mail));
		}
		//3种类型的运费都为0.0, 则为免邮.
		this.resetFreePostage(sum);
		return sum;
	}

	/**
	 * 计算同1款商品的各种运费.
	 * 
	 * @param prod
	 * @param cityId
	 * @param count
	 */
	public CarriageDto calAllKindsOfPostage(Prod prod, Double count, int cityId) {
		CarriageDto carriage = new CarriageDto();
		carriage.addPostage(CarriageType.express, new BigDecimal("0.00"));
		carriage.addPostage(CarriageType.ems, new BigDecimal("0.00"));
		carriage.addPostage(CarriageType.mail, new BigDecimal("0.00"));
		
		// 是否承担运费[0: 买家承担运费;1:商家承担运费;10:未设置]
		int stf = prod.getSupportTransportFree() == null ? 10 : prod.getSupportTransportFree();
		// 0: 买家承担运费
		if(stf == 0){
			carriage.setFreePostage(false);
			int tsi = prod.getTransportType() == null ? 10 : prod.getTransportType();
			// 1:固定运费
			if (tsi == 1) {
				carriage.addPostage(CarriageType.express, prod.getExpressTransFee());
				carriage.addPostage(CarriageType.ems, prod.getEmsTransFee());
				carriage.addPostage(CarriageType.mail, prod.getMailTransFee());
				this.resetFreePostage(carriage);
				return carriage;
			}
			//0:使用运费模板
			if (tsi == 0) {
				Transport transport = transportDao.findOne(prod.getTransportId());			// 运输模板
				List<String> types = CarriageType.getCodes();
				for (int i = 0; i < types.size(); i++) {
					BigDecimal postage = this.calPostageByTemplate( transport, prod, 
							count,cityId, types.get(i));
					carriage.addPostage(CarriageType.parse(types.get(i)), postage);
				}
				this.resetFreePostage(carriage);
				return carriage;
			}
		}
		// 1:商家承担运费
		if (stf == 1) {
			carriage.setFreePostage(true);
			return carriage;
		}
		//TODO  没有设置按照包邮处理  (此处有些矛盾.)
		carriage.setFreePostage(true);
		return carriage;
	}
	
	/**
	 * 根据计算出来的各种运费, 重新设置是否免费, 
	 * 有时商家虽然设置了用户付费， 
	 * 如果没有设置费用或者设置的费用计算出来各种费用为0. 则人认为是免费的.
	 * @param carriage
	 * @return
	 */
	private void resetFreePostage(CarriageDto carriage){
		boolean free =true;
		for(CarriageType type : CarriageType.getAllTypes()){
			BigDecimal val = carriage.getPostage(type);
			if(val != null && val.doubleValue() > 0.0){
				free = false;
				break;
			}
		}
		carriage.setFreePostage(free);
	}
	
	/**
	 * 按照模板计算1中运费
	 * @param transport
	 * @param prod
	 * @param count
	 * @param cityId
	 * @param mailType
	 * @return
	 */
	private BigDecimal calPostageByTemplate(Transport transport, 
			Prod prod, Double count,  Integer cityId, String mailType) {
		// 运费标准
		Transfee transfee = transportHelper.getTransport(transport.getId(), cityId, mailType);
		Double sportFree = null;
		if (transfee != null) {
			sportFree = transportHelper.clacCartDeleivery(transport.getTransType(), transfee, count,
					count * (prod.getWeight() == null ? 0 : prod.getWeight()),
					count * (prod.getVolume() == null ? 0 : prod.getVolume()));
		}
		if(sportFree != null){
			return new BigDecimal(sportFree.toString());
		}
		return new BigDecimal("0.00");
	}

}
