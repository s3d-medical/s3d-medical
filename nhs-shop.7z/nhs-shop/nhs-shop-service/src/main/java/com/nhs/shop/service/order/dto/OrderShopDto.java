package com.nhs.shop.service.order.dto;

import java.io.Serializable;
import java.util.List;

import com.google.common.collect.Lists;
/**
 * 订单中的商家DTO
 * @Title: OrderShopDto.java
 * @Package com.nhs.shop.service.order.dto
 * @Description: TODO
 * @author Administrator
 * @date 2016年7月19日 下午8:22:16
 * @version V1.0
 */
public class OrderShopDto implements Serializable{
    private static final long serialVersionUID = -2849261189549498294L;
    private Integer shopId;
    private String shopName;
    private List<ShopProdDto> prodList = Lists.newArrayList();

    public Integer getShopId() {
        return shopId;
    }

    public void setShopId(Integer shopId) {
        this.shopId = shopId;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public List<ShopProdDto> getProdList() {
        return prodList;
    }

    public void setProdList(List<ShopProdDto> prodList) {
        this.prodList = prodList;
    }

    public void addShopProdDto(ShopProdDto shopProdDto) {
        this.prodList.add(shopProdDto);
    }

}
