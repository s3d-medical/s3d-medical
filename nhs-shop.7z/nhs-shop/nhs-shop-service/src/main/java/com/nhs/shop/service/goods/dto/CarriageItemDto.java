package com.nhs.shop.service.goods.dto;

import java.io.Serializable;
import java.math.BigDecimal;

import com.nhs.shop.service.common.dto.CarriageType;

public class CarriageItemDto implements Serializable{

	private static final long serialVersionUID = 7061294054207902003L;
	/**
	 * 运费类型
	 */
	private CarriageType type;
	/**
	 * 运费值.
	 */
	private BigDecimal val = new BigDecimal("0.00");
	
	
	public CarriageItemDto(CarriageType type, BigDecimal val) {
		super();
		this.type = type;
		this.val = val;
	}
	
	public CarriageItemDto() {
		super();
	}

	public CarriageType getType() {
		return type;
	}

	public void setType(CarriageType type) {
		this.type = type;
	}

	public BigDecimal getVal() {
		return val;
	}

	public void setVal(BigDecimal val) {
		this.val = val;
	}
	
}
