package com.nhs.shop.service.goods.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import com.nhs.shop.service.common.dto.CarriageType;

/**
 * 商品运费结果: 包含各种类型的运费
 * (计算逻辑放入此处)
 * @author wind.chen
 *
 */
public class CarriageDto implements Serializable {
	private static final long serialVersionUID = 8711859053869046862L;
	
	/**
	 * 是否包邮
	 */
	private boolean freePostage;

	private Map<CarriageType, CarriageItemDto> carriagesInMap = new HashMap<CarriageType, CarriageItemDto>(); 
	
	public boolean isFreePostage() {
		return freePostage;
	}

	public void setFreePostage(boolean freePostage) {
		this.freePostage = freePostage;
	}

	public CarriageDto() {
		for(CarriageType type : CarriageType.getAllTypes()){
			CarriageItemDto item = new CarriageItemDto(type, new BigDecimal("0.00"));
			this.carriagesInMap.put(type, item);
		}
	}

	/**
	 * 设置用费.
	 * @param carriageType   运费类型
	 * @param cost    运费
	 */
	public CarriageDto addPostage(CarriageType carriageType, BigDecimal cost){
		if(carriageType == null){
			return this;
		}
		CarriageItemDto curCost = carriagesInMap.get(carriageType);
		if(curCost == null){
			curCost = new CarriageItemDto(carriageType, new BigDecimal("0.00"));
		}
		if(cost != null){
			BigDecimal newVal = curCost.getVal().add(cost);
			curCost.setVal(newVal);
		}
		carriagesInMap.put(carriageType, curCost);
		return this;
	}

	public BigDecimal getEms(){
		return this.getPostage(CarriageType.ems);
	}
	
	public BigDecimal getExpress(){
		return this.getPostage(CarriageType.express);
	}
	public BigDecimal getMail(){
		return this.getPostage(CarriageType.mail);
	}

	public CarriageItemDto getFirstNone0PostageItem(CarriageType ... sortedTypes){
		if(sortedTypes == null ){
			return null;
		}
		for(CarriageType type : sortedTypes){
			CarriageItemDto item = carriagesInMap.get(type);
			if(item != null && item.getVal().doubleValue() > 0.0){
				return item;
			}
		}
		return null;
	}

	public CarriageItemDto getPostageItem(CarriageType carriageType){
		if(carriageType == null){
			return null;
		}
		CarriageItemDto curCost = carriagesInMap.get(carriageType);
		return curCost;
	}
	
	/**
	 * 获取运费.
	 * @param carriageType
	 * @return
	 */
	public BigDecimal getPostage(CarriageType carriageType){
		CarriageItemDto curCost = this.getPostageItem(carriageType);
		if(curCost != null){
			return curCost.getVal();
		}
		return new BigDecimal("0.00");
	}
	
}
