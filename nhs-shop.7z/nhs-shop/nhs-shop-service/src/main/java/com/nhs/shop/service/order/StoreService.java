package com.nhs.shop.service.order;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nhs.core.common.NhsConstant;
import com.nhs.core.context.SysPropsFactory;
import com.nhs.core.orm.Page;
import com.nhs.core.utils.common.DateUtils;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.shop.dao.legend.store.StoreJdbcDao;
import com.nhs.shop.service.BaseService;
import com.nhs.shop.service.order.dto.StoreItemDto;
import com.nhs.shop.service.shop.CalStoreOrderPromotionService;
import com.nhs.shop.service.system.SystemParameterService;

@Service
public class StoreService extends BaseService {

    @Autowired
    private StoreJdbcDao storeJdbcDao;

    @Autowired
    private CalStoreOrderPromotionService calStoreOrderPromotionService;

    @Autowired
    private SystemParameterService sysService;

    /**
     * 
     * @Title: list
     * @Description: TODO
     * @param @param params
     * @param @param page
     * @param @return   
     * @return List<SalesclerkDto> 
     * @author liangdanhua 2016年11月18日 
     * @throws
     */
    public List<StoreItemDto> list(Map<String, Object> params, Page<Map<String, Object>> page) {
        List<StoreItemDto> list = new ArrayList<StoreItemDto>();
        Page<Map<String, Object>> pageData = storeJdbcDao.queryStoreItemList(params, page);
        List<Map<String, Object>> result = pageData.getResult();
        for (Map<String, Object> map : result) {
            StoreItemDto dto = new StoreItemDto();
            dto.setShopId(StringHelper.objectToInt(map.get("shop_id"), 0));
            dto.setItemCode(StringHelper.objectToString(map.get("item_code"), ""));
            dto.setItemName(StringHelper.objectToString(map.get("item_name"), ""));
            // TODO 商品原价
            dto.setProdPrimePrice("");
            dto.setSalePrice(StringHelper.objectToBigDecimal(map.get("sale_price"), "0.00")
                    .setScale(2, BigDecimal.ROUND_DOWN).toString());
            dto.setAdFeeRate(StringHelper.objectToBigDecimal(map.get("ad_fee_rate"), "0.000"));
            dto.setCreatedTime(DateUtils.date2Str((Date) map.get("created_time")));
            dto.setLastModifiedTime(DateUtils.date2Str((Date) map.get("last_modified_time")));
            calStoreOrderPromotionService.calStoreOrderProdPromotion(dto);
            dto.setCoupon(SysPropsFactory.getProperty(NhsConstant.SYS_COUPON_LABEL));

            list.add(dto);
        }
        return list;
    }

    /**
     * 
     * @Title: list
     * @Description: TODO
     * @param @param params
     * @param @param page
     * @param @return   
     * @return List<SalesclerkDto> 
     * @author liangdanhua 2016年11月18日 
     * @throws
     */
    public List<StoreItemDto> detail(String itemCode) {
        List<Map<String, Object>> mapList = storeJdbcDao.queryStoreItem(itemCode);
        List<StoreItemDto> list = new ArrayList<StoreItemDto>();
        if (mapList == null || mapList.size() == 0) {
            return list;
        }
        Map<String, Object> map = mapList.get(0);
        StoreItemDto dto = new StoreItemDto();
        dto.setShopId(StringHelper.objectToInt(map.get("shop_id"), 0));
        dto.setItemCode(StringHelper.objectToString(map.get("item_code"), ""));
        dto.setItemName(StringHelper.objectToString(map.get("item_name"), ""));
        // TODO 商品原价
        dto.setProdPrimePrice("");
        dto.setSalePrice(StringHelper.objectToBigDecimal(map.get("sale_price"), "0.00")
                .setScale(2, BigDecimal.ROUND_DOWN).toString());
        dto.setAdFeeRate(StringHelper.objectToBigDecimal(map.get("ad_fee_rate"), "0.000"));
        dto.setCreatedTime(DateUtils.date2Str((Date) map.get("created_time")));
        dto.setLastModifiedTime(DateUtils.date2Str((Date) map.get("last_modified_time")));
        calStoreOrderPromotionService.calStoreOrderProdPromotion(dto);
        dto.setCoupon(SysPropsFactory.getProperty(NhsConstant.SYS_COUPON_LABEL));
        list.add(dto);
        return list;
    }
}
