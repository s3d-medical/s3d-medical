package com.nhs.shop.service.common.dto;

import java.io.Serializable;

/**
 * 自定义的 标签和值的字段
 * @author wind.chen
 *
 */
public class CustFieldDto implements Serializable {

	private static final long serialVersionUID = -484462074332438732L;
	private String label;
	private String desc;
	private String val;
	
	public CustFieldDto() {
		super();
	}
	public CustFieldDto(String label, String desc, String val) {
		super();
		this.label = label;
		this.desc = desc;
		this.val = val;
	}
	
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String getVal() {
		return val;
	}
	public void setVal(String val) {
		this.val = val;
	}
	
}
