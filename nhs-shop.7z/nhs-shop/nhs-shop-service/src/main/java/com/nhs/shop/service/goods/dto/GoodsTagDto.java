package com.nhs.shop.service.goods.dto;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 商品标签:  prod, sku都可以可以使用该标签.
 * @author wind.chen
 */
public class GoodsTagDto implements Serializable{

	private static final long serialVersionUID = 5413825969884085882L;
	//商品补贴
	/**
	 * 补贴标签  比如  减
	 */
	private String subsidyTag;
	/**
	 * 补贴额度钻石
	 */
	private BigDecimal subsidy;

	/**
	 * 补贴描述 比如 补贴1000 ， 或者补贴 50%等.
	 */ 
	private String subsidyDesc;
	
	/**
	 * 补贴额度
	 */
	private BigDecimal subsidyMoney;
	
	// 商品立减
	private BigDecimal reducedCash;
	
	private String reducedCashTag;
	
	private String reducedCashDesc;
	
	/**
	 * 运费设置
	 */
	private String postageTag;
	
	private String postage;
	
	private String postageDesc;
	
	public BigDecimal getSubsidy() {
		return subsidy;
	}
	public void setSubsidy(BigDecimal subsidy) {
		this.subsidy = subsidy;
	}
	public String getSubsidyTag() {
		return subsidyTag;
	}
	public void setSubsidyTag(String susidyTag) {
		this.subsidyTag = susidyTag;
	}
	public String getSubsidyDesc() {
		return subsidyDesc;
	}
	public void setSubsidyDesc(String susidyDesc) {
		this.subsidyDesc = susidyDesc;
	}
	public BigDecimal getReducedCash() {
		return reducedCash;
	}
	public void setReducedCash(BigDecimal reducedCash) {
		this.reducedCash = reducedCash;
	}
	public String getReducedCashTag() {
		return reducedCashTag;
	}
	public void setReducedCashTag(String reducedCashTag) {
		this.reducedCashTag = reducedCashTag;
	}
	public String getReducedCashDesc() {
		return reducedCashDesc;
	}
	public void setReducedCashDesc(String reducedCashDesc) {
		this.reducedCashDesc = reducedCashDesc;
	}
	public String getPostage() {
		return postage;
	}
	public void setPostage(String postage) {
		this.postage = postage;
	}
	public String getPostageTag() {
		return postageTag;
	}
	public void setPostageTag(String postageTag) {
		this.postageTag = postageTag;
	}
	public String getPostageDesc() {
		return postageDesc;
	}
	public void setPostageDesc(String postageDesc) {
		this.postageDesc = postageDesc;
	}
	public BigDecimal getSubsidyMoney() {
		return subsidyMoney;
	}
	public void setSubsidyMoney(BigDecimal subsidyMoney) {
		this.subsidyMoney = subsidyMoney;
	}
	
}
