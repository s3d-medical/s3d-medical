package com.nhs.shop.service.goods;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.nhs.core.common.NhsConstant;
import com.nhs.core.context.SysPropsFactory;
import com.nhs.core.mapper.JsonMapper;
import com.nhs.core.orm.Page;
import com.nhs.core.utils.common.ArithUtils;
import com.nhs.core.utils.common.DateUtils;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.core.web.WebRequestException;
import com.nhs.shop.dao.legend.car.CarBrandDao;
import com.nhs.shop.dao.legend.collect.CollectDao;
import com.nhs.shop.dao.legend.recommend.VitLogDao;
import com.nhs.shop.dao.legend.recommend.VitLogSaveDao;
import com.nhs.shop.dao.legend.shop.CommentDao;
import com.nhs.shop.dao.legend.shop.FavoriteShopDao;
import com.nhs.shop.dao.legend.shop.GoodsDao;
import com.nhs.shop.dao.legend.shop.ImgFileDao;
import com.nhs.shop.dao.legend.shop.ProdCommDao;
import com.nhs.shop.dao.legend.shop.ProdCommStatDao;
import com.nhs.shop.dao.legend.shop.ProdDao;
import com.nhs.shop.dao.legend.shop.PropValueAliaDao;
import com.nhs.shop.dao.legend.shop.SearchDao;
import com.nhs.shop.dao.legend.shop.ShopDetailDao;
import com.nhs.shop.dao.legend.shop.TransportDao;
import com.nhs.shop.entry.em.shop.CommScoreEnum;
import com.nhs.shop.entry.legend.shop.ImgFile;
import com.nhs.shop.entry.legend.shop.Prod;
import com.nhs.shop.entry.legend.shop.ProdComm;
import com.nhs.shop.entry.legend.shop.ProdCommStat;
import com.nhs.shop.entry.legend.shop.ProdProp;
import com.nhs.shop.entry.legend.shop.ProdPropValue;
import com.nhs.shop.entry.legend.shop.PropValueAlia;
import com.nhs.shop.entry.legend.shop.Search;
import com.nhs.shop.entry.legend.shop.ShopDetail;
import com.nhs.shop.entry.legend.shop.Sku;
import com.nhs.shop.entry.legend.shop.Transfee;
import com.nhs.shop.entry.legend.shop.Transport;
import com.nhs.shop.entry.legend.shop.VitLog;
import com.nhs.shop.entry.legend.user.UsrDetail;
import com.nhs.shop.service.BaseService;
import com.nhs.shop.service.goods.assist.GoodCustDataConvertor;
import com.nhs.shop.service.goods.dto.GoodsDetailDto;
import com.nhs.shop.service.goods.dto.GoodsDetailDto.SpecificationDto;
import com.nhs.shop.service.goods.dto.GoodsDto;
import com.nhs.shop.service.goods.dto.GoodsTagDto;
import com.nhs.shop.service.goods.dto.SkuDto;
import com.nhs.shop.service.goods.dto.SkuNameDto;
import com.nhs.shop.service.goods.dto.SkuProdDto;
import com.nhs.shop.service.goods.dto.SkuValueDto;
import com.nhs.shop.service.order.dto.UserAddressDto;
import com.nhs.shop.service.order.shop.internal.ShopOrderConfirmService;
import com.nhs.shop.service.sku.SkuService;
import com.nhs.shop.service.system.SystemParameterService;
import com.nhs.shop.util.BasicConstant;
import com.nhs.shop.util.TransportHelper;
import com.nhs.user.service.UserService;

/**
 * 商品service
 * @Title: GoodsService.java
 * @Package com.nhs.shop.service.goods
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月16日 下午7:42:18
 * @version V1.0
 */
@Service
@Transactional
public class GoodsService extends BaseService {

    @Autowired
    private GoodsDao goodsDao;

    @Autowired
    private ImgFileDao imgFileDao;

    @Autowired
    private ProdCommDao prodCommDao;

    @Autowired
    private ProdCommStatDao prodCommStatDao;

    @Autowired
    private ShopDetailDao shopDetailDao;

    @Autowired
    private SkuService skuService;

    @Autowired
    private ProdDao prodDao;

    @Autowired
    private TransportDao transportDao;

    @Autowired
    private TransportHelper transportHelper;

    @Autowired
    private CollectDao collectDao;

    @Autowired
    private SearchDao searchDao;

    @Autowired
    private ShopOrderConfirmService shopOrderConfirmService;

    @Autowired
    private UserService userService;

    @Autowired
    private VitLogDao vitLogDao;

    @Autowired
    private VitLogSaveDao vitLogSaveDao;

    @Autowired
    private FavoriteShopDao favoriteShopDao;

    @Autowired
    private CommentDao commentDao;

    @Autowired
    private SystemParameterService sysService;

    @Autowired
    private CarBrandDao carBrandDao;

    @Autowired
    private GoodCustDataConvertor goodCustDataSerivce;

    @Autowired
    private GoodsTagsService goodsTagsService;
    
    @Autowired
    private PropValueAliaDao propValueAliaDao;

    private static String[] mail_Type = { "express", "ems", "mail" };

    private static Integer[] pic_num_type = { 9, 8, 7, 6, 5, 4, 3, 2, 1, 0 };

    private final Logger logger = LoggerFactory.getLogger(GoodsService.class);

    /**
     * 获取商品列表
     * @Title: getGoodsList
     * @Description: TODO
     * @param @param categoryId
     * @param @param keyword
     * @param @param sortType
     * @param @param serve
     * @param @param beginPrice
     * @param @param endPrice
     * @param @param address
     * @param @param area
     * @param @param provinceId
     * @param @param page
     * @param @return   
     * @return List<GoodsDto> 
     * @author Administrator 2016年7月17日 
     * @throws      
     */
    @Deprecated
    public List<GoodsDto> getGoodsList(Integer categoryId, String keyword, Integer sortType, Integer serve,
            Integer beginPrice, Integer endPrice, String address, String area, Integer provinceId, String userId,
            Page<Map<String, Object>> page) {
        // TODO liangdanhua 添加logger日记
        logger.info("********************开始执行getGoodsList方法**************");
        List<GoodsDto> list = Lists.newArrayList();
        long t1 = System.currentTimeMillis();
        logger.info("********************查询getGoodsListDAO**************");
        Page<Map<String, Object>> pageData = goodsDao.getGoodsList(categoryId, sortType, beginPrice, endPrice, keyword,
                page);
        long t2 = System.currentTimeMillis();
        logger.info("********************goodsDao.getGoodsList 执行时间" + (t2 - t1) + "**************");

        GoodsDto dto = null;
        for (Map<String, Object> map : pageData.getResult()) {
            dto = new GoodsDto();
            dto.setProdId(StringHelper.objectToInt(map.get("prod_id"), 0));
            dto.setTitle(StringHelper.objectToString(map.get("name"), ""));
            dto.setCity(StringHelper.objectToString(map.get("city"), ""));
            dto.setImage(buildImg(StringHelper.objectToString(map.get("pic"), "")));
            dto.setPrice(
                    StringHelper.objectToBigDecimal(map.get("cash"), "").setScale(2, BigDecimal.ROUND_DOWN).toString());
            dto.setPayNum(StringHelper.objectToInt(map.get("buys"), 0));
            if (carBrandDao.findCarBrandByCateId(StringHelper.objectToInt(map.get("category_id"), 0)) != null
                    && carBrandDao.findCarBrandByCateId(StringHelper.objectToInt(map.get("category_id"), 0))
                            .size() > 0) {
                dto.setDetailUrl(SysPropsFactory.getProperty("carDetailUrl") + dto.getProdId());
            } else {
                dto.setDetailUrl(SysPropsFactory.getProperty("goodsDetailUrl") + dto.getProdId());

            }

            // 计算补贴
            double rebate = StringHelper.objectToDouble(map.get("rebate"), 1.0);
            dto.setSubsidy(
                    new BigDecimal(ArithUtils.mul(StringHelper.objectToDouble(map.get("cash"), 0.0), rebate) + "")
                            .setScale(2, BigDecimal.ROUND_DOWN).toString());
            dto.setSubsidyStr(sysService.getSingleValueByType(NhsConstant.PARAM_PRESENT_SIGN)
                    + sysService.getSingleValueByType(NhsConstant.PARAM_RMB_ICON) + dto.getSubsidy());
            // TODO liangdanhua 计算邮费

            String mailStatus = StringHelper.objectToString(map.get("prod_id"), "");
            // 未登录就默认为空
            // 判断是否包邮
            dto.setMailStatus(isPostage(mailStatus));

            list.add(dto);
        }
        // TODO liangdanhua 搜索完成之后再搜索热度里面添加1
        if ("".equals(keyword) || keyword == null) {

        } else {
            Search search = searchDao.findSearch(keyword);
            if (search == null || !keyword.equalsIgnoreCase(search.getSearchKey())) {
                search = new Search();
                search.setSearchKey(keyword);
                search.setCount(1);
                searchDao.save(search);
            } else if (keyword.equals(search.getSearchKey())) {
                search.setCount(search.getCount() + 1);
                searchDao.saveAndFlush(search);
            }
        }
        logger.info("********************开始执行getGoodsList方法**************");
        return list;
    }

    @SuppressWarnings("deprecation")
    public List<GoodsDto> getGoodsListWithTag(Integer categoryId, String keyword, Integer sortType, Integer serve,
            Integer beginPrice, Integer endPrice, String address, String area, Integer provinceId, String userId,
            Page<Map<String, Object>> page) {

        List<GoodsDto> list = Lists.newArrayList();
        Page<Map<String, Object>> pageData = goodsDao.getGoodsList(categoryId, sortType, beginPrice, endPrice, keyword,
                page);

        GoodsDto dto = null;
        for (Map<String, Object> map : pageData.getResult()) {
            dto = new GoodsDto();
            dto.setProdId(StringHelper.objectToInt(map.get("prod_id"), 0));
            dto.setTitle(StringHelper.objectToString(map.get("name"), ""));
            dto.setCity(StringHelper.objectToString(map.get("city"), ""));
            dto.setImage(buildImg(StringHelper.objectToString(map.get("pic"), "")));

            dto.setPrice(StringHelper.objectToBigDecimal(map.get("cash"), "0.00").setScale(2, BigDecimal.ROUND_DOWN)
                    .toString());

            dto.setPayNum(StringHelper.objectToInt(map.get("buys"), 0));
            if (carBrandDao.findCarBrandByCateId(StringHelper.objectToInt(map.get("category_id"), 0)) != null
                    && carBrandDao.findCarBrandByCateId(StringHelper.objectToInt(map.get("category_id"), 0))
                            .size() > 0) {
                dto.setDetailUrl(SysPropsFactory.getProperty("carDetailUrl") + dto.getProdId());
            } else {
                dto.setDetailUrl(SysPropsFactory.getProperty("goodsDetailUrl") + dto.getProdId());
            }
            // 计算补贴
            GoodsTagDto tag = this.goodsTagsService.getProdDimTag(dto.getProdId());
            dto.setSubsidy(tag.getSubsidyMoney().toString());
            dto.setSubsidyStr(tag.getSubsidyTag());
            dto.setSubsidyTag(tag.getSubsidyTag());
            dto.setMailStatus(tag.getPostageTag());
            dto.setReducedCashTag(tag.getReducedCashTag());
            list.add(dto);
        }
        // TODO liangdanhua 搜索完成之后再搜索热度里面添加1
        if ("".equals(keyword) || keyword == null) {

        } else {
            Search search = searchDao.findSearch(keyword);
            if (search == null || !keyword.equalsIgnoreCase(search.getSearchKey())) {
                search = new Search();
                search.setSearchKey(keyword);
                search.setCount(1);
                searchDao.save(search);
            } else if (keyword.equals(search.getSearchKey())) {
                search.setCount(search.getCount() + 1);
                searchDao.saveAndFlush(search);
            }
        }
        logger.info("********************开始执行getGoodsList方法**************");
        return list;
    }

    /**
     * 获取某款具体的型号的产品.
     * @param prod
     * @param sku
     * @return
     */
    public SkuProdDto getSkuProd(Prod prod, Sku sku) {
        // 商家的商品列表
        SkuProdDto skuProdDto = new SkuProdDto();
        skuProdDto.setPic(this.buildImg(prod.getPic()));
        skuProdDto.setPrice(sku != null ? sku.getPrice().doubleValue() : prod.getCash().doubleValue());
        skuProdDto.setProdId(prod.getProdId());
        skuProdDto.setProdName(prod.getName());
        skuProdDto.setHasInvoice(prod.getHasInvoice());
        if (sku != null) {
            skuProdDto.setSkuId(sku.getSkuId());
            skuProdDto.setSkuDesc(skuService.getSkuDesc(sku));
        }
        skuProdDto.setDetailUrl(SysPropsFactory.getProperty("goodsDetailUrl")
                + (sku == null || sku.getProdId() == null ? prod.getProdId() : sku.getProdId()));

        // 计算补贴和立减
        GoodsTagDto goodsTagDto = this.goodsTagsService.getSkuProdDetailTag(sku, prod);
        skuProdDto.setGoodsTag(goodsTagDto);
        return skuProdDto;
    }

    /**
     * 
     * @Title: calculatePostage
     * @Description: TODO
     * @param @param prodId
     * @param @param userId
     * @param @return   
     * @return String 
     * @author liangdanhua 2016年8月24日 
     * @throws
     */
    public String calculatePostage(String prodId, String userId) {

        String postage = "";
        int city = 247;
        Prod prod = prodDao.findOne(Integer.parseInt(prodId));
        if (prod == null) {
            return "包邮";
        }
        UserAddressDto udt = shopOrderConfirmService.getDefaultUserAddress(userId);
        if (udt != null) {
            city = udt.getCityId();
        }
        // 是否承担运费[1:商家承担运费;0: 买家承担运费;10:未设置]
        int stf = prod.getSupportTransportFree() == null ? 10 : prod.getSupportTransportFree();
        if (stf == 1) {
            postage = "包邮";
        } else if (stf == 0) {
            // 是否固定运费[0:使用运费模板;1:固定运费;10:未设置]
            int tsi = prod.getTransportType() == null ? 10 : prod.getTransportType();
            if (tsi == 1) {
                postage = "快递:" + prod.getExpressTransFee().toString();
            } else if (tsi == 0) {
                int transportId = prod.getTransportId();
                Transport transport = transportDao.findOne(transportId);
                Transfee transfee = null;
                for (int i = 0; i < mail_Type.length; i++) {
                    String mailtype = mail_Type[i];
                    transfee = transportHelper.getTransport(transportId, city, mailtype);
                    if (transfee != null)
                        break;
                }

                if (transfee != null) {
                    double sportFree = transportHelper.clacCartDeleivery(transport.getTransType(), transfee, 1,
                            1 * (prod.getWeight() == null ? 0 : prod.getWeight()),
                            1 * (prod.getVolume() == null ? 0 : prod.getVolume()));
                    postage = "快递:" + new BigDecimal(sportFree).setScale(2, BigDecimal.ROUND_HALF_UP);
                }
            }
        }
        return postage;
    }

    /**
     * 判断商品是否包邮
     * @Title: isPostage
     * @Description: TODO
     * @param @param prodId
     * @param @return   
     * @return String 
     * @author liangdanhua 2016年9月5日 
     * @throws
     */
    public String isPostage(String prodId) {
        String postage = "";
        Prod prod = prodDao.findOne(Integer.parseInt(prodId));
        int stf = prod.getSupportTransportFree() == null ? 10 : prod.getSupportTransportFree();
        if (stf == 1) {
            postage = "包邮";
        } else {
            postage = "不包邮";
        }
        return postage;
    }

    /**
     * 获取商品详情
     * @Title: getGoodsDetail
     * @Description: TODO
     * @param @param goodsId
     * @param @return   
     * @return GoodsDetailDto 
     * @author Administrator 2016年7月17日 
     * @throws
     */
    public GoodsDetailDto getGoodsDetail(Integer prodId, Integer cityId, String userId) {
        GoodsDetailDto dto = new GoodsDetailDto();
        // 构建商品信息
        dto.setGoods(buildGoodsDetail(prodId, cityId, userId));
        // 构建评价信息
        dto.setComment(buildGoodsComment(prodId));
        // 构建店铺信息
        dto.setShop(buildGoodsShop(dto.getGoods().getShopId()));

        dto.setUserId(userId);
        return dto;
    }

    /**
     * 获取商品SKU
     * @Title: getGoodsSku
     * @Description: TODO
     * @param @param prodId
     * @param @return   
     * @return Map<String,Object> 
     * @author Administrator 2016年7月21日 
     * @throws
     */
    public Map<String, Object> getGoodsSku(Integer prodId, Integer skuId) {
        Map<String, Object> map = Maps.newHashMap();
        // 构建商品sku
        List<Sku> skus = skuService.findSkuListByProdId(prodId);

        map.put("skus", buildSkuDto(skus));
        map.put("skuNames", buildSkuNameDto(skus, skuId));

        return map;
    }

    /**
     * 构建商品详情
     * @Title: buildGoodsDetail
     * @Description: TODO
     * @param @param goodsId
     * @param @return   
     * @return GoodsDetailDto.GoodsDto 
     * @author Administrator 2016年7月17日 
     * @throws
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    private GoodsDetailDto.GoodsDto buildGoodsDetail(Integer prodId, Integer cityId, String userId) {

        GoodsDetailDto.GoodsDto dto = new GoodsDetailDto.GoodsDto();
        Map<String, Object> map = goodsDao.getGoodsDetail(prodId);
        List<Map<String, Object>> collections = collectDao.getCollectByPrdId(prodId.toString(), userId);
        if (map != null) {
            dto.setProdId(prodId);
            dto.setShopId(StringHelper.objectToInt(map.get("shop_id"), 0));
            dto.setTitle(StringHelper.objectToString(map.get("name"), ""));
            dto.setAddress(StringHelper.objectToString(map.get("province"), "")
                    + StringHelper.objectToString(map.get("city"), ""));
            dto.setPrice(
                    StringHelper.objectToBigDecimal(map.get("cash"), "").setScale(2, BigDecimal.ROUND_DOWN).toString());
            dto.setSaleNum(StringHelper.objectToInt(map.get("buys"), 0));
            // TODO liangdanhua 如果用户使用运费模板 就选择用户模板来计算运费
            Prod prod = prodDao.findOne(dto.getProdId());
            if (prod == null) {
                throw new WebRequestException("商品不存在");
            }
            if (prod.getStatus() != 1) {
                dto.setIsdown("down");
            }
            dto.setBrief(StringHelper.objectToString(map.get("brief"), ""));
            dto.setContent(StringHelper.objectToString(map.get("content"), ""));

            // 计算商品标签. wind.chen 20161104
            GoodsTagDto tag = this.goodsTagsService.getProdDetailTag(prod, cityId);
            dto.setPromotion(this.goodCustDataSerivce.toSpecialFormat(tag));
            dto.setSubsidy(tag.getSubsidy().toString());
            dto.setSubsidyStr(tag.getSubsidyDesc());
            dto.setExpressFee(tag.getPostage());
            // 是否被收藏
            if (null != collections && collections.size() > 0) {
                dto.setIsCollected(BasicConstant.FLAG_VALID.toString());
            } else {
                dto.setIsCollected(BasicConstant.FLAG_INVALID.toString());
            }
            dto.setStocks(StringHelper.objectToInt(map.get("stocks"), 0));
        }

        // 商品详情图片
        List<String> images = Lists.newArrayList();
        List<ImgFile> imgFileList = imgFileDao.findImgFile(prodId);
        for (ImgFile imgFile : imgFileList) {
            images.add(this.buildImg(imgFile.getFilePath()));
        }
        dto.setImages(images);

        List<SpecificationDto> specifications = Lists.newArrayList();
        // 规格参数
        String parameter = StringHelper.objectToString(map.get("parameter"), "");
        if (StringUtils.isNoneBlank(parameter)) {
            List<Map> parameters = JsonMapper.nonEmptyMapper().fromJson(parameter, List.class);
            for (Map p : parameters) {
                SpecificationDto s = new SpecificationDto();
                s.setName(StringHelper.objectToString(p.get("paramName"), ""));
                s.setValue(StringHelper.objectToString(p.get("paramValueName"), ""));
                specifications.add(s);
            }
        }

        // 用户自定义规格参数
        String userParameter = StringHelper.objectToString(map.get("user_parameter"), "");
        if (StringUtils.isNoneBlank(userParameter)) {
            List<Map> parameters = JsonMapper.nonEmptyMapper().fromJson(userParameter, List.class);
            for (Map p : parameters) {
                SpecificationDto s = new SpecificationDto();
                s.setName(StringHelper.objectToString(p.get("key"), ""));
                s.setValue(StringHelper.objectToString(p.get("value"), ""));
                specifications.add(s);
            }
        }
        dto.setSpecifications(specifications);

        // 构建商品sku
        List<Sku> skus = skuService.findSkuListByProdId(prodId);
        dto.setSkus(buildSkuDto(skus));
        dto.setSkuNames(buildSkuNameDto(skus, null));
        return dto;
    }

    /**
     * 构建商品评价信息
     * @Title: buildGoodsComment
     * @Description: TODO
     * @param @param goodsId
     * @param @return   
     * @return GoodsDetailDto.CommentDto 
     * @author Administrator 2016年7月17日 
     * @throws
     */
    private GoodsDetailDto.CommentDto buildGoodsComment(Integer goodsId) {
        GoodsDetailDto.CommentDto dto = new GoodsDetailDto.CommentDto();
        List<ProdCommStat> prodCommStatList = prodCommStatDao.findProdCommStat(goodsId);
        // 获取评价详情
        List<GoodsDetailDto.CommentDetailDto> details = Lists.newArrayList();
        // 获取最近一个月评价信息
        List<ProdComm> prodCommList = prodCommDao.findByProdCommAndDate(goodsId);
        prodCommList = orderByScoreAndPicAndContent(prodCommList);
        if (prodCommList.size() < 3) {
            // 当评价数目小于3的时候，按评价时间，降序排序（最新评价显示第一位）
            prodCommList = prodCommDao.findProdComm(goodsId);
        }
        // 总评数
        Integer total = 0;
        Integer high = 0;
        int i = 1;
        for (ProdComm prodComm : prodCommList) {
            GoodsDetailDto.CommentDetailDto detail = new GoodsDetailDto.CommentDetailDto();
            detail.setUserId(prodComm.getUserId());
            UsrDetail usrDetail = userService.findUserById(prodComm.getUserId());//usrDetailDao.findUserById(prodComm.getUserId());
            if (usrDetail == null) {
                continue;
            }
            if (i > 3) { // 只取3个评价显示
                continue;
            }
            detail.setUsername(usrDetail.getNickName() == null || "".equals(usrDetail.getNickName())
                    ? prodComm.getUserName() : usrDetail.getNickName());
            detail.setContent(prodComm.getContent());
            detail.setScore(prodComm.getScore());
            detail.setAddtime(DateUtils.date2Str(prodComm.getAddtime()));
            detail.setUserImage(this.buildImg(usrDetail.getPortraitPic()));
            List<String> images = Lists.newArrayList();
            if (StringUtils.isNotBlank(prodComm.getPhotoFile1())) {
                images.add(buildImg(prodComm.getPhotoFile1()));
            }
            if (StringUtils.isNotBlank(prodComm.getPhotoFile2())) {
                images.add(buildImg(prodComm.getPhotoFile2()));
            }
            if (StringUtils.isNotBlank(prodComm.getPhotoFile3())) {
                images.add(buildImg(prodComm.getPhotoFile3()));
            }
            if (StringUtils.isNotBlank(prodComm.getPhotoFile4())) {
                images.add(buildImg(prodComm.getPhotoFile4()));
            }
            if (StringUtils.isNotBlank(prodComm.getPhotoFile5())) {
                images.add(buildImg(prodComm.getPhotoFile5()));
            }
            if (StringUtils.isNotBlank(prodComm.getPhotoFile6())) {
                images.add(buildImg(prodComm.getPhotoFile6()));
            }
            if (StringUtils.isNotBlank(prodComm.getPhotoFile7())) {
                images.add(buildImg(prodComm.getPhotoFile7()));
            }
            if (StringUtils.isNotBlank(prodComm.getPhotoFile8())) {
                images.add(buildImg(prodComm.getPhotoFile8()));
            }
            if (StringUtils.isNotBlank(prodComm.getPhotoFile9())) {
                images.add(buildImg(prodComm.getPhotoFile9()));
            }
            detail.setImages(images);
            details.add(detail);
            i++;
            if (prodComm.getScore() >= 4) {
                high++;
            }
            total++;
        }
        // TODO liangdanhua 修改总评价数目
        if (prodCommList != null) {
            dto.setNum(prodCommList.size());
        } else {
            dto.setNum(0);
        }
        if (high == 0) {
            dto.setDegree("0%");
        } else {
            dto.setDegree(Math.round(div(high, total) * 100) + "%");

        }
        dto.setList(details);
        return dto;
    }

    /**
     * 构建商品店铺信息
     * @Title: buildGoodsShop
     * @Description: TODO
     * @param @param shopId
     * @param @return   
     * @return GoodsDetailDto.ShopDto 
     * @author Administrator 2016年7月17日 
     * @throws
     */
    private GoodsDetailDto.ShopDto buildGoodsShop(Integer shopId) {
        GoodsDetailDto.ShopDto dto = new GoodsDetailDto.ShopDto();
        ShopDetail shopDetail = shopDetailDao.findOne(shopId);
        if (shopDetail != null) {
            dto.setShopId(shopId);
            dto.setTitle(shopDetail.getSiteName()); // 商店名称
            dto.setImage(buildImg(shopDetail.getShopPic2())); // 商店头像
            dto.setTotalNum(shopDetail.getProductNum()); // 全部商品数
            dto.setAttentionNum(favoriteShopDao.countFavoriteByShopId(shopId)); // 关注人数
            dto.setSpeed(4.9); // 发货速度
            dto.setAttitude(4.9);// 服务态度
            dto.setDescribe(4.9); // 描述相符
        }
        return dto;
    }

    /**
     * 构建商品sku
     * @Title: buildSkuDto
     * @Description: TODO
     * @param @param skus
     * @param @return   
     * @return List<SkuDto> 
     * @author Administrator 2016年7月18日 
     * @throws
     */
    private List<SkuDto> buildSkuDto(List<Sku> skus) {
        List<SkuDto> list = Lists.newArrayList();
        SkuDto dto = null;
        for (Sku sku : skus) {
            dto = new SkuDto();
            dto.setSkuId(sku.getSkuId());
            dto.setSkuValue(convertProperties(sku.getProperties()));
            dto.setPrice(sku.getPrice().toString());
            dto.setProdId(sku.getProdId());
            dto.setStocks(sku.getStocks());
            Prod prod = prodDao.findOne(sku.getProdId());
            GoodsTagDto tag = this.goodsTagsService.getSkuProdDetailTag(sku, prod);
            dto.setPromotion(this.goodCustDataSerivce.toSpecialFormat(tag));
            // 兼容老版本.
            // dto.setSubsidy(tag.getSubsidyMoney().toString());
            // dto.setSubsidyStr(tag.getSubsidyMoney().toString());
            list.add(dto);
        }
        return list;
    }

    /**
     * 构建SKU Name
     * @Title: buildSkuNameDto
     * @Description: TODO
     * @param @param skus
     * @param @return   
     * @return List<SkuNameDto> 
     * @author Administrator 2016年7月18日 
     * @throws
     */
    private List<SkuNameDto> buildSkuNameDto(List<Sku> skus, Integer skuId) {

        // 获取sku value map
        Map<Integer, Object> skuValueMap = skuService.getSkuValueMap(skuId);
        
        // 合并properties
        Map<Integer, List<Integer>> skuMap = mergeProperties(skus);
        
        int prodId = 0;
        for(Sku sku : skus){
        	prodId = sku.getProdId();
        	break;
        }
        
        // 初始化sku属性map
        Map<Integer, ProdProp> propMap = skuService.initProdPropMap();
        // 初始化sku属性值map
        Map<Integer, ProdPropValue> propValueMap = skuService.initProdPropValueMap();
        List<SkuNameDto> list = Lists.newArrayList();
        for (Entry<Integer, List<Integer>> entry : skuMap.entrySet()) {
            int key = entry.getKey();
            List<Integer> set = entry.getValue();
            ProdProp prop = propMap.get(key);
            if (prop == null) {
                continue;
            }
            SkuNameDto nameDto = new SkuNameDto();
            nameDto.setSkuNameId(key);
            nameDto.setSkuName(prop.getMemo());

            for (Integer valueId : set) {
                ProdPropValue propValue = propValueMap.get(valueId);
                if (propValue == null) {
                    continue;
                }
                String propName = propValue.getName();
                List<PropValueAlia> propValueAilaList = propValueAliaDao.findByProdIdAndValueId(prodId,valueId);
                if(propValueAilaList != null && propValueAilaList.size() > 0){
                	PropValueAlia propValueAlia = propValueAilaList.get(0);
                	propName = propValueAlia.getAlias();
                }
                
                SkuValueDto valueDto = new SkuValueDto();
                valueDto.setSkuValueId(valueId);
                valueDto.setSkuValue(propName);
                if (skuValueMap.containsKey(valueId)) {
                    valueDto.setSelected(true);
                }
                nameDto.addSkuValueDto(valueDto);
            }
            list.add(nameDto);
        }

        return list;
    }

    /**
     * 合并sku
     * @Title: mergeProperties
     * @Description: TODO
     * @param @param skus
     * @param @return   
     * @return Map<Integer,Set<Integer>> 
     * @author Administrator 2016年7月18日 
     * @throws
     */
    private Map<Integer, List<Integer>> mergeProperties(List<Sku> skus) {
        Map<Integer, List<Integer>> map = new TreeMap<Integer, List<Integer>>();
        for (Sku sku : skus) {
            String properties = sku.getProperties();
            String[] groups = properties.split(";");
            if (groups == null || groups.length == 0) {
                continue;
            }
            for (String group : groups) {
                String[] values = group.split(":");
                if (values != null && values.length >= 2) {
                    int k = Integer.parseInt(values[0]);
                    int v = Integer.parseInt(values[1]);
                    if (map.containsKey(k)) {
                        List<Integer> list = map.get(k);
                        if (!list.contains(v)) {
                            list.add(v);
                        }
                    } else {
                        List<Integer> list = new ArrayList();
                        list.add(v);
                        map.put(k, list);
                    }
                }
            }
        }
        return map;
    }

    /**
     * 转换sku properties，比如: 268:816;269:831 -> 816-831
     * @Title: convertProperties
     * @Description: TODO
     * @param @param properties
     * @param @return   
     * @return String 
     * @author Administrator 2016年7月18日 
     * @throws
     */
    private String convertProperties(String properties) {
        if (StringUtils.isBlank(properties)) {
            return "";
        }
        String[] groups = properties.split(";");
        if (groups == null || groups.length == 0) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for (String group : groups) {
            String[] values = group.split(":");
            if (values != null && values.length >= 2) {
                sb.append(values[1]).append("-");
            }
        }
        String value = "";
        if (sb.length() > 0) {
            value = sb.substring(0, sb.length() - 1);
        }
        return value;
    }

    /**
     * 热门搜索列表
     * @Title: list
     * @Description: TODO
     * @param @return   
     * @return List<Map<String, Object>> 
     * @author liangdanhua 2016年8月10日 
     * @throws
     */
    public List<Map<String, Object>> getHotGoodsList() {
        return goodsDao.getHotGoodsList();
    }

    /**
     * 推荐产品列表
     * @Title: getRecommendList
     * @Description: TODO
     * @param @return   
     * @return List<Map<String,Object>> 
     * @author Administrator 2016年8月22日 
     * @throws
     */
    @SuppressWarnings("deprecation")
    public List<GoodsDto> getRecommendList() {
        List<GoodsDto> list = Lists.newArrayList();
        GoodsDto dto = null;
        for (Map<String, Object> map : goodsDao.getRecommendList()) {
            dto = new GoodsDto();
            dto.setProdId(StringHelper.objectToInt(map.get("prod_id"), 0));
            dto.setTitle(StringHelper.objectToString(map.get("name"), ""));
            dto.setCity(StringHelper.objectToString(map.get("city"), ""));
            dto.setImage(buildImg(StringHelper.objectToString(map.get("pic"), "")));
            dto.setPrice(
                    StringHelper.objectToBigDecimal(map.get("cash"), "").setScale(2, BigDecimal.ROUND_DOWN).toString());

            dto.setPayNum(StringHelper.objectToInt(map.get("buys"), 0));
            dto.setDetailUrl(SysPropsFactory.getProperty("goodsDetailUrl") + dto.getProdId());
            // 计算补贴
            double rebate = StringHelper.objectToDouble(map.get("rebate"), 1.0);
            dto.setSubsidy(new BigDecimal(ArithUtils.mul(StringHelper.objectToDouble(map.get("cash"), 0.0), rebate))
                    .setScale(2, BigDecimal.ROUND_DOWN).toString());
            dto.setSubsidyStr(sysService.getSingleValueByType(NhsConstant.PARAM_PRESENT_SIGN)
                    + sysService.getSingleValueByType(NhsConstant.PARAM_RMB_ICON) + dto.getSubsidy());
            // tag
            Prod prod = prodDao.findOne(dto.getProdId());
            if (prod != null) {
                GoodsTagDto tag = this.goodsTagsService.getProdDimTag(prod);
                dto.setSubsidyStr(tag.getSubsidyTag());
                dto.setMailStatus(tag.getPostageDesc());
                dto.setReducedCashTag(tag.getReducedCashTag());
            }
            list.add(dto);
        }
        logger.info("********************开始执行getGoodsList方法**************");
        return list;
    }

    /**
     * 构建浏览记录
     * @Title: buildGoodsHistory
     * @Description: TODO
     * @param @param prodId
     * @param @param cityId
     * @param @param userId   
     * @return void 
     * @author liangdanhua 2016年8月25日 
     * @throws
     */
    public void buildGoodsHistory(Integer prodId, Integer cityId, String userId) {
        // VitLog vitlog = vitLogDao.findVitlogByuserIdAndproId(userId, prodId.toString());
        List<VitLog> vitLogList = vitLogDao.findVitlogHistory(userId, prodId.toString());

        if (vitLogList == null || vitLogList.size() == 0) {
            VitLog vlg = new VitLog();
            // UsrDetail usrDetail = usrDetailDao.findUserById(userId);
            UsrDetail usrDetail = this.userService.findUserById(userId);

            Prod prod = prodDao.findOne(prodId);
            ShopDetail shopDetail = shopDetailDao.findOne(prod.getShopId());
            if (shopDetail == null)
                shopDetail = new ShopDetail();
            vlg.setUserName(usrDetail.getUserName() == null ? "" : usrDetail.getUserName());
            vlg.setShopName(shopDetail.getSiteName() == null ? "" : shopDetail.getSiteName());
            vlg.setProductId(prodId.toString());
            vlg.setProductName(prod.getName());
            vlg.setIp("");
            vlg.setPage("");
            vlg.setRecDate(new Date());
            vlg.setShopId(shopDetail.getShopId() == null ? 0 : shopDetail.getShopId());
            vlg.setUserId(userId);
            vlg.setVisitNum(1);
            vlg.setIsCar("");
            // vitLogSaveDao.save(vlg);
            vitLogDao.saveAndFlush(vlg);

        } else {
            VitLog vitlog = vitLogList.get(0);
            vitlog.setRecDate(new Date());
            vitlog.setVisitNum(vitlog.getVisitNum() + 1);
            vitLogDao.saveAndFlush(vitlog);
        }
    }

    /**
     * 提供（相对）精确的除法运算，当发生除不尽的情况时，精确到 小数点以后10位，以后的数字四舍五入。.
     * @Title: div
     * @Description: TODO
     * @param @param v1
     * @param @param v2
     * @param @return   
     * @return double 
     * @author liangdanhua 2016年9月7日 
     * @throws
     */
    public static Double div(double v1, double v2) {
        return div(v1, v2, 10);
    }

    /**
     * 提供（相对）精确的除法运算。当发生除不尽的情况时，由scale参数指 定精度，以后的数字四舍五入。.
     * @Title: div
     * @Description: TODO
     * @param @param v1
     * @param @param v2
     * @param @param scale
     * @param @return   
     * @return double 
     * @author Administrator 2016年9月7日 
     * @throws
     */
    public static double div(double v1, double v2, int scale) {
        if (scale < 0) {
            throw new IllegalArgumentException("The scale must be a positive integer or zero");
        }
        BigDecimal b1 = new BigDecimal(Double.toString(v1));
        BigDecimal b2 = new BigDecimal(Double.toString(v2));
        return b1.divide(b2, scale, BigDecimal.ROUND_HALF_UP).doubleValue();
    }

    /**
     * 
     * @Title: orderBy
     * @Description: TODO 最近一个月内，评分值高（优先级1），图片多（优先级2），评价内容多（优先级3）的放此页面，点击单个评价进入"全部评价"页面
     * @param @param oldList
     * @param @return   
     * @return List<ProdComm> 
     * @author liangdanhua 2016年10月13日 
     * @throws
     */
    public static List<ProdComm> orderByScoreAndPicAndContent(List<ProdComm> oldList) {
        List<ProdComm> prodCommList = new ArrayList<ProdComm>();
        List<ProdComm> prodCommList2 = new ArrayList<ProdComm>();
        List<ProdComm> prodCommList3 = new ArrayList<ProdComm>();
        List<ProdComm> prodCommList4 = new ArrayList<ProdComm>();
        List<ProdComm> prodCommList5 = new ArrayList<ProdComm>();

        List<ProdComm> totalList = new ArrayList<ProdComm>();

        // 根据评分排序 5 4 3 2 1
        for (ProdComm prodComm : oldList) {
            if (prodComm.getScore() == CommScoreEnum.high_five.value)
                prodCommList5.add(prodComm);
        }
        for (ProdComm prodComm : oldList) {
            if (prodComm.getScore() == CommScoreEnum.high_four.value)
                prodCommList4.add(prodComm);
        }
        for (ProdComm prodComm : oldList) {
            if (prodComm.getScore() == CommScoreEnum.high_three.value)
                prodCommList3.add(prodComm);
        }
        for (ProdComm prodComm : oldList) {
            if (prodComm.getScore() == CommScoreEnum.middle.value)
                prodCommList2.add(prodComm);
        }
        for (ProdComm prodComm : oldList) {
            if (prodComm.getScore() == CommScoreEnum.low.value)
                prodCommList.add(prodComm);
        }
        for (int i = 0; i < pic_num_type.length; i++) {
            totalList.addAll(orderByLength(orderByPic(pic_num_type[i], prodCommList5)));
        }
        for (int i = 0; i < pic_num_type.length; i++) {
            totalList.addAll(orderByLength(orderByPic(pic_num_type[i], prodCommList4)));
        }
        for (int i = 0; i < pic_num_type.length; i++) {
            totalList.addAll(orderByLength(orderByPic(pic_num_type[i], prodCommList3)));
        }
        for (int i = 0; i < pic_num_type.length; i++) {
            totalList.addAll(orderByLength(orderByPic(pic_num_type[i], prodCommList2)));
        }
        for (int i = 0; i < pic_num_type.length; i++) {
            totalList.addAll(orderByLength(orderByPic(pic_num_type[i], prodCommList)));
        }

        return totalList;
    }

    /**
     * 
     * @Title: orderByPic
     * @Description: TODO 根据图片的数量排序
     * @param @param score
     * @param @param oldList
     * @param @return   
     * @return List<ProdComm> 
     * @author Administrator 2016年10月13日 
     * @throws
     */
    public static List<ProdComm> orderByPic(int num, List<ProdComm> prodCommList) {
        List<ProdComm> newList = new ArrayList<ProdComm>();
        if (num == 9) {
            for (ProdComm prodComm : prodCommList) {
                if (StringUtils.isNotBlank(prodComm.getPhotoFile9()))
                    newList.add(prodComm);
            }
        } else if (num == 8) {
            for (ProdComm prodComm : prodCommList) {
                if (StringUtils.isNotBlank(prodComm.getPhotoFile8()) && StringUtils.isBlank(prodComm.getPhotoFile9()))
                    newList.add(prodComm);
            }
        } else if (num == 7) {
            for (ProdComm prodComm : prodCommList) {
                if (StringUtils.isNotBlank(prodComm.getPhotoFile7()) && StringUtils.isBlank(prodComm.getPhotoFile8()))
                    newList.add(prodComm);
            }
        } else if (num == 6) {
            for (ProdComm prodComm : prodCommList) {
                if (StringUtils.isNotBlank(prodComm.getPhotoFile6()) && StringUtils.isBlank(prodComm.getPhotoFile7()))
                    newList.add(prodComm);
            }
        } else if (num == 5) {
            for (ProdComm prodComm : prodCommList) {
                if (StringUtils.isNotBlank(prodComm.getPhotoFile5()) && StringUtils.isBlank(prodComm.getPhotoFile6()))
                    newList.add(prodComm);
            }
        } else if (num == 4) {
            for (ProdComm prodComm : prodCommList) {
                if (StringUtils.isNotBlank(prodComm.getPhotoFile4()) && StringUtils.isBlank(prodComm.getPhotoFile5()))
                    newList.add(prodComm);
            }
        } else if (num == 3) {
            for (ProdComm prodComm : prodCommList) {
                if (StringUtils.isNotBlank(prodComm.getPhotoFile3()) && StringUtils.isBlank(prodComm.getPhotoFile4()))
                    newList.add(prodComm);
            }
        } else if (num == 2) {
            for (ProdComm prodComm : prodCommList) {
                if (StringUtils.isNotBlank(prodComm.getPhotoFile2()) && StringUtils.isBlank(prodComm.getPhotoFile3()))
                    newList.add(prodComm);
            }
        } else if (num == 1) {
            for (ProdComm prodComm : prodCommList) {
                if (StringUtils.isNotBlank(prodComm.getPhotoFile1()) && StringUtils.isBlank(prodComm.getPhotoFile2()))
                    newList.add(prodComm);
            }
        } else if (num == 0) {
            for (ProdComm prodComm : prodCommList) {
                if (StringUtils.isBlank(prodComm.getPhotoFile1()) && StringUtils.isBlank(prodComm.getPhotoFile2()))
                    newList.add(prodComm);
            }
        }
        return newList;
    }

    /**
     * 
     * @Title: orderByLength
     * @Description: TODO 评论的长度进行排序
     * @param @param oldList
     * @param @return   
     * @return List<ProdComm> 
     * @author liangdanhua 2016年10月13日 
     * @throws
     */
    public static List<ProdComm> orderByLength(List<ProdComm> oldList) {
        List<ProdComm> newList = new ArrayList<ProdComm>();

        int[] params = new int[oldList.size()];
        for (int i = 0; i < oldList.size(); i++) {
            ProdComm prodComm = oldList.get(i);
            int a = prodComm.getContent().length();
            params[i] = a;
        }

        int temp = 0;
        // 定义一个变量来供两个数的转换
        for (int i = 0; i < params.length - 1; i++) {
            for (int j = i + 1; j < params.length; j++) {
                if (params[i] < params[j]) {
                    temp = params[j];
                    params[j] = params[i];
                    params[i] = temp;
                }
            }
        }
        for (int i = 0; i < params.length; i++) {
            for (int j = 0; j < oldList.size(); j++) {
                ProdComm prodComm = oldList.get(j);
                int b = prodComm.getContent().length();
                if (b == params[i]) {
                    oldList.remove(j);
                    newList.add(prodComm);
                }
            }
        }
        return newList;
    }
}
