package com.nhs.shop.rebate;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * <pre>
 *  <h1>获取返利规则类型</h1>
 *  1.新规则
 *  2.老规则由于时间原因没有抽，可以考虑实现
 * </pre>
 * @author sungs
 *
 */
@Service
public class RebateTypeContext {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	public final static String REBATE_O2O_NEW = "o2oNew";
	
	public final static String REBATE_O2O_OLD = "o2oOld";
	
	@Resource
	private RebateType rebateType_o2o;
	
	@Resource
	private RebateType rebateType_o2o_old;
	
	public RebateType getRebate(String type) {
		if("o2oNew".equals(type)) {
			return rebateType_o2o;
		} else if("o2oOld".equals(type)){
			return rebateType_o2o_old;
		}else {
			logger.info("返利规则类型不合法, type:" + type);
			return null;
		}
	}

}
