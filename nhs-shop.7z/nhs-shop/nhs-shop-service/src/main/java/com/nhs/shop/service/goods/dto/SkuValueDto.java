package com.nhs.shop.service.goods.dto;

import java.io.Serializable;

/**
 * SKU Value DTO
 * @Title: SkuValueDto.java
 * @Package com.nhs.shop.service.goods.dto
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月18日 下午2:35:05
 * @version V1.0
 */
public class SkuValueDto implements Serializable{

    private static final long serialVersionUID = -1141083302663738797L;
    private Integer skuValueId;
    private String  skuValue;
    private boolean isSelected;
    public Integer getSkuValueId() {
        return skuValueId;
    }
    public void setSkuValueId(Integer skuValueId) {
        this.skuValueId = skuValueId;
    }
    public String getSkuValue() {
        return skuValue;
    }
    public void setSkuValue(String skuValue) {
        this.skuValue = skuValue;
    }
    public boolean isSelected() {
        return isSelected;
    }
    public void setSelected(boolean isSelected) {
        this.isSelected = isSelected;
    }
    
    
    
    
}
