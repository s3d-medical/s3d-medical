package com.nhs.shop.service.system.dto.sysconfig;

import java.io.Serializable;

/**
 * label的配置参数.
 * @author wind.chen
 */
public class GlLabelConfigDto implements Serializable{

	private static final long serialVersionUID = -1189110143343011133L;

	private String goldName;
	
    private String silverName;
    
	public String getGoldName() {
		return goldName;
	}
	public void setGoldName(String goldName) {
		this.goldName = goldName;
	}
	public String getSilverName() {
		return silverName;
	}
	public void setSilverName(String silverName) {
		this.silverName = silverName;
	}
}
