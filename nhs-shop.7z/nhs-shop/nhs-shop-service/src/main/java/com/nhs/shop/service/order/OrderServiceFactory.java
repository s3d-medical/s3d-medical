package com.nhs.shop.service.order;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nhs.core.web.WebRequestException;
import com.nhs.shop.entry.em.order.OrderCodeEnum;
import com.nhs.shop.service.BaseOrderService;
import com.nhs.shop.service.order.shop.internal.ShopOrderAddService;
import com.nhs.shop.service.pay.PayRecordService;

@Service
public class OrderServiceFactory {

	private static ShopOrderAddService shopOrderAddService;

	private static O2oServiceOrderService o2oServiceOrderService;

	private static CarOrderService carOrderService;
	
    private static PayRecordService payRecordService;

	/**
	 * 获取订单service
	 * 
	 * @Title: getOrderService
	 * @Description: TODO
	 * @param @param orderNum
	 * @param @return
	 * @return BaseOrderService
	 * @author Administrator 2016年7月28日
	 * @throws
	 */
	public static BaseOrderService getOrderServiceByOrderNum(String orderNum) {
		BaseOrderService service = null;
		String orderCode = orderNum.substring(orderNum.length() - 2,
				orderNum.length());
		OrderCodeEnum e = OrderCodeEnum
				.getInstance(Integer.parseInt(orderCode));
		switch (e) {
		case SHOP_ORDER:
			service = shopOrderAddService; // 商城订单
			break;
		case O2O_SERVICE_ORDER:
			service = o2oServiceOrderService; // 服务订单
			break;
		case CAR_ORDER:
			service = carOrderService; // 汽车订单
			break;
		case STORE_PAY_RECORD_ORDER:
            service = payRecordService; // 支付流水订单
            break;
		default:
			throw new WebRequestException("订单号不正确");
		}
		return service;
	}

	@Autowired
	public void setShopOrderAddService(ShopOrderAddService shopOrderAddService) {
		OrderServiceFactory.shopOrderAddService = shopOrderAddService;
	}

	@Autowired
	public void setO2oServiceOrderService(
			O2oServiceOrderService o2oServiceOrderService) {
		OrderServiceFactory.o2oServiceOrderService = o2oServiceOrderService;
	}

	@Autowired
	public void setCarOrderService(CarOrderService carOrderService) {
		OrderServiceFactory.carOrderService = carOrderService;
	}
	
	@Autowired
	public void setPayRecordService(PayRecordService payRecordService) {
		this.payRecordService = payRecordService;
	}

}
