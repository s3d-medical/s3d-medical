package com.nhs.shop.service.rebate;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.nhs.core.utils.common.DateUtils;
import com.nhs.shop.dao.legend.shop.ProdDao;
import com.nhs.shop.dao.legend.shop.ShopDetailDao;
import com.nhs.shop.dao.legend.shop.SubDao;
import com.nhs.shop.dao.legend.shop.SubItemDao;
import com.nhs.shop.entry.em.EmFlagTag;
import com.nhs.shop.entry.em.shop.EmRebateStatus;
import com.nhs.shop.entry.legend.shop.Prod;
import com.nhs.shop.entry.legend.shop.ShopDetail;
import com.nhs.shop.entry.legend.shop.Sub;
import com.nhs.shop.entry.legend.shop.SubItem;
import com.nhs.shop.entry.legend.user.UsrDetail;
import com.nhs.user.service.UserService;

/**
 * 确认收货后，开始将每个订单中的每个商品中送的银币冻结
 * @Title: ShopRebateService.java
 * @Package com.nhs.shop.service.rebate
 * @Description: TODO
 * @author huxianjun
 * @date 2016年11月8日 上午11:51:56
 * @version V1.0
 */
@Service
public class ShopRebateService {

    private static Logger logger = LoggerFactory.getLogger(ShopRebateService.class);

    // 确认收货后，开始解冻的天数
    private static final Integer rebate_unfreeze_days = 7;

    @Autowired
    private SubDao subDao;

    @Autowired
    private SubItemDao subItemDao;

    @Autowired
    private ProdDao prodDao;

    @Autowired
    private ShopDetailDao shopDetailDao;

    @Autowired
    private RebateFreezeService rebateFreezeService;

    @Autowired
    private RebateService rebateService;

    @Autowired
    private UserService userService;

    /**
     * 开始处理每一商品的订单的清算
     * @Title: saveRebate
     * @Description: TODO
     * @param @param sub
     * @param @param nowTime
     * @param @throws Exception   
     * @return void 
     * @author huxianjun 2016年7月29日 
     * @throws
     */
    @Async
    public void saveRebate(Sub sub, Date nowTime) throws Exception {
        logger.info("===+++===异步清算商品返利" + sub.getSubNumber());
        this.saveRebateProcess(sub, nowTime);
    }

    /**
     * 同步处理定时任务，因为数据库可能没有写入，所以不可异步
     * @Title: saveSynchronizeRebate
     * @Description: TODO
     * @param @param sub
     * @param @param nowTime
     * @param @throws Exception   
     * @return void 
     * @author huxianjun 2016年9月2日 
     * @throws
     */
    public void saveSynchronizeRebate(Sub sub, Date nowTime) throws Exception {
        logger.info("===+++===同步清算商品冻结返利" + sub.getSubNumber());
        this.saveRebateProcess(sub, nowTime);
    }

    private void saveRebateProcess(Sub sub, Date nowTime) throws Exception {
        logger.info("=========开始清算商品冻结返利" + sub.getSubNumber());
        // 更新订单状态
        sub.setRebateStatus(EmRebateStatus.rebate.status);
        subDao.saveAndFlush(sub);

        // 解冻的时间
        Timestamp ts = new Timestamp(System.currentTimeMillis());
        Date unfreezeTime = DateUtils.addDays(ts, rebate_unfreeze_days);

        List<SubItem> siList = subItemDao.findSubItem(sub.getSubNumber());
        if (siList != null && siList.size() > 0) {

            // 用户信息
            UsrDetail usrDetail = this.userService.findUserById(sub.getUserId());
            if (usrDetail == null) {
                return;
            }
            // 商户信息
            // 根据ShopId获取UserId，然后再查询商户的UserDetail
            ShopDetail shopDetail = this.shopDetailDao.findByShopIdAndStatus(sub.getShopId(), ShopDetail.STATUS_ONLINE);
            if (shopDetail == null || StringUtils.isBlank(shopDetail.getUserId())) {
                return;
            }
            UsrDetail shopUserDetail = this.userService.findUserById(shopDetail.getUserId());
            if (shopUserDetail == null) {
                return;
            }

            for (SubItem item : siList) {
                Prod prod = prodDao.findOne(item.getProdId());
                if (prod != null) {
                    // 新增字段totalAmout，老数据取productTotalAmout的值
                    if (item.getTotalAmount() == null || item.getTotalAmount().compareTo(new BigDecimal(0)) <= 0) {
                        item.setTotalAmount(item.getProductTotalAmout());
                    }
                    // 个人用户账户的银币
                    if (item.getRebate() == null) {
                        item.setRebate(prod.getRebate());
                    }
                    if (item.getAdFeeRate() == null) {
                        item.setAdFeeRate(prod.getAdFeeRate());
                    }
                    // 用户返利
                    rebateFreezeService.saveUserRebate(usrDetail, "-商城订单-", item.getRebate(), item.getAdFeeRate(),
                            item.getProdId(), item.getProductTotalAmout(), item.getCash(), item.getPrice(),
                            item.getSubItemNumber(), item.getBasketCount(), unfreezeTime, nowTime,
                            EmFlagTag.valid.value);

                    // 商家账户的银币
                    ShopDetail shop = shopDetailDao.findOne(sub.getShopId());
                    boolean flag = false;
                    if (shop != null) {
                        if (shop.getWhiteList() != null && shop.getWhiteList().intValue() == 1) {
                            flag = true;
                        } else if ((shop.getWhiteList() == null || shop.getWhiteList().intValue() == 0)
                                && (shop.getCoinSwitch() != null && shop.getCoinSwitch().intValue() == 1)) {
                            flag = true;
                        }
                        if (flag) {
                            // 商户返利
                            rebateFreezeService.saveShopRebate(shopUserDetail, "-商城订单-", item.getRebate(),
                                    item.getAdFeeRate(), item.getProdId(), item.getTotalAmount(), item.getCash(),
                                    item.getPrice(), item.getSubItemNumber(), item.getBasketCount(), unfreezeTime,
                                    nowTime, EmFlagTag.valid.value);
                        }
                        // 商家的账户金额
                        rebateService.saveShopCash(shopUserDetail, "-商城订单-", item.getRebate(), item.getAdFeeRate(),
                                item.getTotalAmount(), item.getSubItemNumber(), nowTime);
                    }
                }
            }

            // TODO hxj 商家的钱必须加上运费，商家运费在确认收货后不再退回，直接反馈到商家的账户中
            rebateFreezeService.saveFreight(shopUserDetail, sub.getFreightAmount(), sub.getSubNumber(), nowTime);
        }
    }
}
