package com.nhs.shop.service.areas;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nhs.core.web.WebRequestException;
import com.nhs.shop.dao.legend.region.AreasDao;
import com.nhs.shop.dao.legend.region.CityDao;
import com.nhs.shop.dao.legend.region.ProvincesDao;
import com.nhs.shop.entry.legend.region.Areas;
import com.nhs.shop.entry.legend.region.City;
import com.nhs.shop.entry.legend.region.Provinces;
import com.nhs.shop.service.BaseService;
import com.nhs.shop.service.areas.dto.AddresNameDto;

/**
 * 查询地址
 * @Title: AreasService.java
 * @Package com.nhs.shop.service.areas
 * @Description: TODO
 * @author liangdanhua
 * @date 2016年10月26日 上午9:34:52
 * @version V1.0
 */
@Service
public class AreasService extends BaseService {

    @Autowired
    private ProvincesDao provincesDao;

    @Autowired
    private CityDao cityDao;

    @Autowired
    private AreasDao areasDao;

    /**
     * 查询所有的省份
     * @Title: queryProvinces
     * @Description: TODO
     * @param @return   
     * @return List<Provinces> 
     * @author liangdanhua 2016年10月26日 
     * @throws
     */
    public List<Provinces> queryProvinces() {
        return provincesDao.findProvinces();
    }

    /**
     * 根省份查找城市
     * @Title: queryCitysByProvince
     * @Description: TODO
     * @param @param province
     * @param @return   
     * @return List<City> 
     * @author Administrator 2016年10月26日 
     * @throws
     */
    public List<City> queryCitysByProvince(Integer province) {
        return cityDao.findCities(province);
    }

    /**
     * 根据城市查询区
     * @Title: queryAreasByCity
     * @Description: TODO
     * @param @return   
     * @return List<Areas> 
     * @author Administrator 2016年10月26日 
     * @throws
     */
    public List<Areas> queryAreasByCity(Integer cityid) {
        return areasDao.findAreas(cityid);
    }

    public AddresNameDto addresName(Integer provinceId, Integer cityId, Integer areaId) {
        Provinces province = provincesDao.findOne(provinceId);
        if (province == null) {
            throw new WebRequestException("省不存在！");
        }
        City city = cityDao.findOne(cityId);
        if (city == null) {
            throw new WebRequestException("市不存在！");
        }
        Areas area = areasDao.findOne(areaId);
        if (area == null) {
            throw new WebRequestException("区不存在！");
        }
        AddresNameDto and = new AddresNameDto();
        and.setProvinceName(province.getProvince());
        and.setCityName(city.getCity());
        and.setAreaName(area.getArea());
        return and;
    }
}
