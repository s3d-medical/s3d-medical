package com.nhs.shop.service.rebate;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.nhs.core.common.NhsConstant;
import com.nhs.core.utils.common.DateUtils;
import com.nhs.shop.dao.legend.shop.ShopDetailDao;
import com.nhs.shop.dao.legend.store.StoreOrderDao;
import com.nhs.shop.dao.legend.store.StoreOrderItemDao;
import com.nhs.shop.entry.em.EmFlagTag;
import com.nhs.shop.entry.em.shop.EmRebateStatus;
import com.nhs.shop.entry.legend.shop.ShopDetail;
import com.nhs.shop.entry.legend.store.StoreOrder;
import com.nhs.shop.entry.legend.store.StoreOrderItem;
import com.nhs.shop.entry.legend.user.UsrDetail;
import com.nhs.user.service.UserService;

/**
 * 商超开始清算返利
 * @Title: StoreRebateService.java
 * @Package com.nhs.shop.service.rebate
 * @Description: TODO
 * @author huxianjun
 * @date 2016年9月20日 上午9:20:38
 * @version V1.0
 */
@Service
public class StoreRebateService {

    private static Logger logger = LoggerFactory.getLogger(StoreRebateService.class);

    // 确认收货后，开始解冻的天数
    private static final Integer rebate_unfreeze_days = 7;

    @Autowired
    private StoreOrderDao storeOrderDao;
    @Autowired
    private StoreOrderItemDao storeOrderItemDao;

    @Autowired
    private UserService userService;

    @Autowired
    private ShopDetailDao shopDetailDao;

    @Autowired
    private RebateFreezeService rebateFreezeService;

    /**
     * 异步开始处理每一商品的订单的清算
     * @Title: saveRebate
     * @Description: TODO
     * @param @param sub
     * @param @param nowTime
     * @param @throws Exception   
     * @return void 
     * @author huxianjun 2016年7月29日 
     * @throws
     */
    @Async
    public void saveRebate(StoreOrder sub, Date nowTime) throws Exception {
        logger.info("===异步处理商超订单的冻结结算，订单号：" + sub.getOrderNum());
        this.saveRebateProcess(sub, nowTime);
    }

    /**
     * 同步处理定时任务，因为数据库可能没有写入，所以不可异步
     * @Title: saveSynchronizeRebate
     * @Description: TODO
     * @param @param sub
     * @param @param nowTime
     * @param @throws Exception   
     * @return void 
     * @author huxianjun 2016年9月20日 
     * @throws
     */
    public void saveSynchronizeRebate(StoreOrder sub, Date nowTime) throws Exception {
        logger.info("===同步处理商超订单的冻结结算，订单号：" + sub.getOrderNum());
        this.saveRebateProcess(sub, nowTime);
    }

    private void saveRebateProcess(StoreOrder sub, Date nowTime) throws Exception {
        logger.info("处理商超订单的结算，订单号：" + sub.getOrderNum());
        sub.setRebateStatus(EmRebateStatus.rebate.status);
        storeOrderDao.saveAndFlush(sub);

        // 解冻的时间
        Timestamp ts = new Timestamp(System.currentTimeMillis());
        Date unfreezeTime = DateUtils.addDays(ts, rebate_unfreeze_days);

        List<StoreOrderItem> siList = storeOrderItemDao.findStoreOrderItem(sub.getOrderNum());
        if (siList != null && siList.size() > 0) {

            // 用户信息
            UsrDetail usrDetail = this.userService.findUserById(sub.getUserId());
            if (usrDetail == null) {
                return;
            }
            // 商户信息
            // 根据ShopId获取UserId，然后再查询商户的UserDetail
            ShopDetail shopDetail = this.shopDetailDao.findByShopIdAndStatus(sub.getShopId(), ShopDetail.STATUS_ONLINE);
            if (shopDetail == null || StringUtils.isBlank(shopDetail.getUserId())) {
                return;
            }
            UsrDetail shopUserDetail = this.userService.findUserById(shopDetail.getUserId());
            if (shopUserDetail == null) {
                return;
            }
            for (StoreOrderItem item : siList) {
                // 个人用户账户的银币
                rebateFreezeService.saveUserRebateOfStoreOrder(usrDetail, item, unfreezeTime,
                        nowTime, EmFlagTag.invalid.value);
                // 商家账户的银币
                ShopDetail shop = shopDetailDao.findOne(sub.getShopId());
                boolean flag = false;
                if (shop != null) {
                    if (shop.getWhiteList() != null && shop.getWhiteList().intValue() == 1) {
                        flag = true;
                    } else if ((shop.getWhiteList() == null || shop.getWhiteList().intValue() == 0)
                            && (shop.getCoinSwitch() != null && shop.getCoinSwitch().intValue() == 1)) {
                        flag = true;
                    }
                    if (flag) {
                    	if(item.getProdAdFeeRate() == null || (item.getProdAdFeeRate() != null && item.getProdAdFeeRate().compareTo(new BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE)) > 0)){
                    		item.setProdAdFeeRate(new BigDecimal("0.00"));
                    	}
                        rebateFreezeService.saveShopRebateOfStoreOrder(shopUserDetail, item, unfreezeTime,
                                nowTime, EmFlagTag.invalid.value);
                    }
                }
            }
			
        }
    }
}
