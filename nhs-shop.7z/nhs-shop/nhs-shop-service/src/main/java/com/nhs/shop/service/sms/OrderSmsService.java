package com.nhs.shop.service.sms;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nhs.core.web.WebExceptionCode;
import com.nhs.core.web.WebRequestException;
import com.nhs.shop.dao.legend.sms.SmsTemplateDao;
import com.nhs.shop.entry.em.EmSmsType;
import com.nhs.shop.entry.legend.sms.SmsTemplate;
import com.nhs.shop.service.BaseService;
import com.nhs.sms.service.SmsService;

/**
 * o2o商家服务订单service
 * 
 * @Title: O2oServiceOrderService.java
 * @Package com.nhs.shop.service.order
 * @Description: TODO
 * @author Administrator
 * @date 2016年7月25日 下午2:44:10
 * @version V1.0
 */
@Service
public class OrderSmsService extends BaseService {

    private final Logger logger = LoggerFactory.getLogger(OrderSmsService.class);

    @Autowired
    private SmsService smsService;

    @Autowired
    private SmsTemplateDao smsTemplateDao;

    /**
     * 短信提醒 
     * @Title: smsAfterOrder
     * @Description: TODO 
     * @param phone1  客户手机
     * @param phone2  商家手机
     * @param remark
     * @param smsType
     * @param args {商家名字}
     * @param args2{订单号,金额}
     * @return void 
     * @author liangdanhua 2016年8月12日
     * @throws
     */

    public void smsAfterOrder(String phone1, String phone2, String remark, String[] args, String[] args2) {
        logger.debug("--------------------开始发送短信----------------");
        SmsTemplate customertemplate = smsTemplateDao.findSmsTemplate(10002);
        try {
            if (customertemplate == null) {
                throw new WebRequestException("客户模板不存在");
            }
            smsService.saveSmsYtx(customertemplate, phone1, remark, EmSmsType.VAL.value, args);
            SmsTemplate shoptemplate = smsTemplateDao.findSmsTemplate(10003);
            if (shoptemplate == null) {
                throw new WebRequestException("商家模板不存在");
            }
            smsService.saveSmsYtx(shoptemplate, phone2, remark, EmSmsType.VAL.value, args2);
        } catch (Exception e) {
            logger.error(e.getMessage());
            throw new WebRequestException(WebExceptionCode.ERROR.errorMsg);
        }
        logger.debug("--------------------发送短信结束----------------");
    }
}
