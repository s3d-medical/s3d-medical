package com.nhs.shop.rebate.service;

import java.math.BigDecimal;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nhs.core.common.NhsConstant;

/**
 * 计算用户返利比率
 * @author Administrator
 *
 */
@Service
@Transactional
public class CalRebateService {
	
	/**
	 * 
	 * @param adFeeRate
	 * @param adFeeBasicRate
	 * @param maxRate
	 * @return
	 */
	public BigDecimal calRebate(BigDecimal adFeeRate, BigDecimal adFeeBasicRate,String maxAdFeeRate){
		BigDecimal rebate = new BigDecimal("0");
		if(adFeeRate == null){
			adFeeRate = new BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE);
		}
		if(adFeeBasicRate == null){
			adFeeBasicRate = new BigDecimal(NhsConstant.DEFAULT_AD_FEE_BASIC_RATE);
		}
		
		if(adFeeRate.compareTo(new BigDecimal(maxAdFeeRate)) >= 0){
			adFeeRate = new BigDecimal(maxAdFeeRate);
		}
		
		rebate = adFeeRate.divide(adFeeBasicRate).setScale(4, BigDecimal.ROUND_DOWN);
		
		return rebate;
		
	}
	
}
