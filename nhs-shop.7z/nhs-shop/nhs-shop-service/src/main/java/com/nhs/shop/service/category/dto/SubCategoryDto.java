package com.nhs.shop.service.category.dto;

import java.io.Serializable;

/**
 * 商品分类子节点
 * @Title: SubCategoryDto.java
 * @Package com.nhs.shop.service.category.dto
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月16日 下午5:30:36
 * @version V1.0
 */
public class SubCategoryDto implements Serializable {

    private static final long serialVersionUID = 1858144023532293672L;
    private Integer categoryId = 0;
    private String title = "";
    private String icon = "";

    public Integer getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Integer categoryId) {
        this.categoryId = categoryId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

}
