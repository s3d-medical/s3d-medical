package com.nhs.shop.service.goods.assist;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.nhs.shop.service.common.dto.CustFieldDto;
import com.nhs.shop.service.goods.dto.GoodsTagDto;
import com.nhs.shop.service.goods.dto.PromotionDto;

/**
 * 主要是针对ui处理, 辅助处理一些特殊的返回值:比如包含自定义标签, 自定义值. 
 * @author wind
 *
 */
@Service
public class GoodCustDataConvertor {
	
	/**
	 * 转换为Map格式的promotion
	   "promotion": { "reducedCash": {"label": "减",  "desc": "立减389" , "val":"389"}，        
 
			"subsidy": {"label": "送",  "desc": "送钻石1000" , "val":"1000"}
			}
	 * @param promotion
	 * @return
	 */
	public Map<String, CustFieldDto> toSpecialFormat(GoodsTagDto tag){
		Map<String, CustFieldDto> promoInMap = new HashMap<String, CustFieldDto>();
    	if(tag != null){	
    		CustFieldDto cash = new CustFieldDto(tag.getReducedCashTag(), 
    				tag.getReducedCashDesc(), tag.getReducedCash().toString());
    		promoInMap.put("reducedCash", cash);
    		CustFieldDto subsidy = new CustFieldDto(tag.getSubsidyTag(), 
    				tag.getSubsidyDesc(), tag.getSubsidy().toString());
    		promoInMap.put("subsidy", subsidy);    		
    		CustFieldDto postage = new CustFieldDto(tag.getPostageTag(), 
    				tag.getPostageDesc(), tag.getPostage().toString());
    		promoInMap.put("postage", postage);
    	}
    	return promoInMap;
	}
}
