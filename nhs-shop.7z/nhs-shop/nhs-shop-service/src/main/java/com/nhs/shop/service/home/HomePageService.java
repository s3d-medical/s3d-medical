package com.nhs.shop.service.home;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.nhs.core.common.NhsConstant;
import com.nhs.core.context.SysPropsFactory;
import com.nhs.core.orm.Page;
import com.nhs.core.utils.common.ArithUtils;
import com.nhs.core.utils.common.FormatUtils;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.shop.dao.legend.msg.MsgDao;
import com.nhs.shop.dao.legend.region.AreasDao;
import com.nhs.shop.dao.legend.region.CityDao;
import com.nhs.shop.dao.legend.service.O2oCategoryDao;
import com.nhs.shop.dao.legend.service.O2oServiceOrderDao;
import com.nhs.shop.dao.legend.shop.CategoryDao;
import com.nhs.shop.dao.legend.shop.HomeCategoryConfigDao;
import com.nhs.shop.dao.legend.shop.HotProdDao;
import com.nhs.shop.dao.legend.shop.IndexJpgDao;
import com.nhs.shop.dao.legend.shop.O2oHotCategoryConfigDao;
import com.nhs.shop.dao.legend.shop.O2oHotCategoryDao;
import com.nhs.shop.dao.legend.shop.O2oShopDetailDao;
import com.nhs.shop.dao.legend.shop.ProdDao;
import com.nhs.shop.dao.legend.shop.ShopDao;
import com.nhs.shop.dao.legend.shop.ShopDetailDao;
import com.nhs.shop.entry.em.HotPordCategoryEnum;
import com.nhs.shop.entry.legend.region.Areas;
import com.nhs.shop.entry.legend.region.City;
import com.nhs.shop.entry.legend.service.O2oCategory;
import com.nhs.shop.entry.legend.shop.Category;
import com.nhs.shop.entry.legend.shop.HomeCategoryConfig;
import com.nhs.shop.entry.legend.shop.HotProd;
import com.nhs.shop.entry.legend.shop.IndexJpg;
import com.nhs.shop.entry.legend.shop.O2oHotCategory;
import com.nhs.shop.entry.legend.shop.O2oHotCategoryConfig;
import com.nhs.shop.entry.legend.shop.O2oShopDetail;
import com.nhs.shop.entry.legend.shop.Prod;
import com.nhs.shop.entry.legend.shop.ShopDetail;
import com.nhs.shop.service.BaseService;
import com.nhs.shop.service.category.dto.O2oHotCategoryDto;
import com.nhs.shop.service.home.dto.BannerDto;
import com.nhs.shop.service.home.dto.CategoryDto;
import com.nhs.shop.service.home.dto.HotProdDto;
import com.nhs.shop.service.shop.ShopService;
import com.nhs.shop.service.shop.dto.ShopDto;
import com.nhs.shop.service.system.SystemParameterService;

/**
 * 首页数据service
 * @Title: HomePageService.java
 * @Package com.nhs.shop.service.home
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月16日 下午5:31:00
 * @version V1.0
 */
@Service
@Transactional
public class HomePageService extends BaseService {

    private final Logger logger = LoggerFactory.getLogger(HomePageService.class);

    private static final String SUZHOU_CITY_ID = "215000";

    @Autowired
    private IndexJpgDao indexJpgDao; // banner dao

    @Autowired
    private HomeCategoryConfigDao homeCategoryConfigDao; // 分类dao

    @Autowired
    private ShopDetailDao shopDetailDao; // 附近商家dao

    @Autowired
    private HotProdDao hotProdDao; // 最热商品dao

    @Autowired
    private CategoryDao categoryDao; // 分类dao

    @Autowired
    private O2oCategoryDao o2oCategoryDao; // O2o分类dao

    @Autowired
    private ProdDao prodDao; // 商品dao

    @Autowired
    private CityDao cityDao;

    @Autowired
    private ShopService shopService;

    @Autowired
    private MsgDao msgDao;

    @Autowired
    private O2oHotCategoryDao o2oHotCategoryDao;

    @Autowired
    private O2oHotCategoryConfigDao o2oHotCategoryConfigDao;

    @Autowired
    private ShopDao shopDao;

    @Autowired
    private AreasDao areasDao;

    @Autowired
    private O2oShopDetailDao o2oShopDetailDao;

    @Autowired
    private O2oServiceOrderDao o2oServiceOrderDao;

    @Autowired
    private SystemParameterService sysService;

    private String System_subsidy = "100%";

    /**
     * 获取首页数据
     * 
     * @param lng
     *            经度
     * @param lat
     *            纬度
     * @return
     */
    public Map<String, Object> getHomePageData(double lng, double lat) {
        // 结果map
        Map<String, Object> map = Maps.newLinkedHashMap();

        // banner
        List<IndexJpg> banners = indexJpgDao.findIndexJpg();
        map.put("banner", buildBannerList(banners));

        // 分类
        List<HomeCategoryConfig> categorys = homeCategoryConfigDao.findHomeCategoryConfigByVersion("1");
        map.put("category", buildCategoryList(categorys));

        // 附近商家
        List<ShopDetail> shops = null;
        if (lng == 0 || lat == 0) {
            // 如果客户端没有定位到经纬度，默认显示苏州市的商家
            City city = cityDao.findCityByCityId(SUZHOU_CITY_ID);
            if (city != null) {
                shops = shopDetailDao.findShopDetail(city.getId());
            }
        } else {
            shops = shopDetailDao.findShopDetail();
        }

        map.put("shop", shopService.buildShopList(shops, lng, lat, 10));

        // 热卖商品
        List<HotProd> prods = hotProdDao.findHotProd(HotPordCategoryEnum.HOT_GOODS.getCategory());
        map.put("hotGoods", buildHotProdList(prods));

        return map;
    }

    /**
     * 初始化区域map
     * @Title: initAreaMap
     * @Description: TODO
     * @param @return   
     * @return Map<Integer,Areas> 
     * @author Administrator 2016年7月23日 
     * @throws
     */
    private Map<Integer, Areas> initAreaMap() {
        List<Areas> areaList = areasDao.findAreas();
        Map<Integer, Areas> map = Maps.newHashMap();
        for (Areas area : areaList) {
            map.put(area.getId(), area);
        }
        return map;
    }

    private List<ShopDto> getNearByShopList(List<Map<String, Object>> shopList) {
        List<ShopDto> list = Lists.newArrayList();
        ShopDto shopDto = null;
        Map<Integer, Areas> areaMap = initAreaMap();
        Map<Integer, O2oCategory> categoryMap = initO2oCategoryMap();
        for (Map<String, Object> shopMap : shopList) {
            shopDto = new ShopDto();
            shopDto.setShopId(StringHelper.objectToInt(shopMap.get("shop_id"), 0));
            shopDto.setShopTitle(StringHelper.objectToString(shopMap.get("site_name"), ""));
            shopDto.setAddress(StringHelper.objectToString(shopMap.get("shop_addr"), ""));
            long totalOrderNum = o2oServiceOrderDao
                    .countByShopIdAndStatus(StringHelper.objectToInt(shopMap.get("shop_id"), 0));
            shopDto.setTotalOrderNum(String.valueOf(totalOrderNum));

            Double distance = StringHelper.objectToDouble(shopMap.get("distance"), 0);

            shopDto.setDistance(distance);

            if (distance >= 1000) {
                BigDecimal dis = new BigDecimal(distance).divide(new BigDecimal(1000), 2, BigDecimal.ROUND_HALF_UP);
                shopDto.setDistanceWithUnit(String.valueOf(dis) + "km");
            } else {
                shopDto.setDistanceWithUnit(String.valueOf(distance.intValue()) + "m");
            }

            shopDto.setStarNum(5);
            shopDto.setPic(this.buildImg(StringHelper.objectToString(shopMap.get("shop_pic2"), "")));
            O2oShopDetail o2oShopDetail = o2oShopDetailDao
                    .findO2oShopDetailByshopId(StringHelper.objectToInt(shopMap.get("shop_id"), 0));
            if (o2oShopDetail != null) {
                shopDto.setConsumePer(o2oShopDetail.getPerCost().intValue());
                if (o2oShopDetail.getRebate() == null) {

                    o2oShopDetail.setRebate(new BigDecimal(NhsConstant.DEFAULT_REBATE));
                }
                ShopDetail shop = shopDetailDao.findOne(o2oShopDetail.getShopId());
                if (shop != null) {
                    if (shop.getRebate() == null) {
                        shop.setRebate(new BigDecimal(NhsConstant.DEFAULT_REBATE));
                    }
                    shopDto.setSubsidy(
                            shop.getRebate().multiply(new BigDecimal("100")).setScale(0, BigDecimal.ROUND_DOWN) + "%");
                }
            }
            Areas area = areaMap.get(StringHelper.objectToString(shopMap.get("areaid"), ""));
            if (area != null) {
                shopDto.setArea(area.getArea());
            }
            O2oCategory category = categoryMap.get(StringHelper.objectToInt((shopMap.get("category_id")), 0));
            if (category != null) {
                shopDto.setCategory(category.getName());
            }
            // 商家补贴暂时默认为100%
            // shopDto.setSubsidy("100%");
            if (shopDto.getSubsidy() == null || shopDto.getSubsidy().equals("") || shopDto.getSubsidy().equals("0")) {
                shopDto.setSubsidyStr(sysService.getSingleValueByType(NhsConstant.PARAM_PRESENT_SIGN) + System_subsidy);
            } else {
                shopDto.setSubsidyStr(
                        sysService.getSingleValueByType(NhsConstant.PARAM_PRESENT_SIGN) + shopDto.getSubsidy());
            }
            shopDto.setLat(StringHelper.objectToDouble(shopMap.get("lat"), 0.0));
            shopDto.setLng(StringHelper.objectToDouble(shopMap.get("lng"), 0.0));
            list.add(shopDto);
        }
        return list;
    }

    private Page<Map<String, Object>> createPage(int pageNo, int pageSize) {
        Page<Map<String, Object>> page = new Page<Map<String, Object>>();
        page.setPageNo(pageNo);
        page.setPageSize(pageSize);
        return page;
    }

    public Map<String, Object> getHomePageDataA20(double lng, double lat, String userName, int cityId) {
        // 结果map
        Map<String, Object> map = Maps.newLinkedHashMap();
        // banner
        List<IndexJpg> banners = indexJpgDao.findIndexJpg();
        map.put("banner", buildBannerList(banners));
        // 分类
        long startTime = System.currentTimeMillis();
        List<HomeCategoryConfig> categorys = homeCategoryConfigDao.findHomeCategoryConfigByVersion("2.0");
        map.put("category", buildCategoryListA20(categorys));
        long endTime = System.currentTimeMillis();
        logger.info("categorys spend time: " + (endTime - startTime));

        // 附近商家
        // List<ShopDetail> shops = null;
        // if (lng == 0 || lat == 0) {
        // // 如果客户端没有定位到经纬度，默认显示苏州市的商家
        // City city = cityDao.findCityByCityId(SUZHOU_CITY_ID);
        // if (city != null) {
        // shops = shopDetailDao.findShopDetail(city.getId());
        // }
        // } else {
        // shops = shopDetailDao.findShopDetail();
        // }
        List<Map<String, Object>> shopList = new ArrayList<>();
        Page<Map<String, Object>> page = createPage(0, 10);
        if (lng == 0 || lat == 0) {
            // 如果客户端没有定位到经纬度，默认显示苏州市的商家
            // City city = cityDao.findCityByCityId(SUZHOU_CITY_ID);
        	lat = NhsConstant.DEFAULT_LAT;
            lng = NhsConstant.DEFAULT_LNG;
            cityId = NhsConstant.DEFAULT_CITY_ID;
            // if (city != null) {
            Page<Map<String, Object>> pageData = shopDao.getShopNearByList(cityId, lng, lat, null, page);
            shopList = pageData.getResult();
            // }
        } else {
            Page<Map<String, Object>> pageData = shopDao.getShopNearByList(null, lng, lat, null, page);
            shopList = pageData.getResult();
        }

        List<ShopDto> shopDtoList = getNearByShopList(shopList);
        map.put("shop", shopDtoList);

        // long endTime1 = System.currentTimeMillis();
        // logger.info("附近商家查询 spend time: "+(endTime1-startTime1));
        //
        // long startTime2 = System.currentTimeMillis();
        // map.put("shop", shopService.buildShopList(shops, lng, lat, 10));
        // long endTime2 = System.currentTimeMillis();
        // logger.info("附近商家构建 spend time: "+(endTime2-startTime2));
        long startTime3 = System.currentTimeMillis();
        if (StringUtils.isNotBlank(userName)) {
            Map<String, Object> count = msgDao.getUnReadCount(userName);
            int unReadMsgCount = ((Long) count.get("count")).intValue();
            map.put("unReadMsgCount", unReadMsgCount);
        } else {
            map.put("unReadMsgCount", 0);
        }
        long endTime3 = System.currentTimeMillis();
        logger.info("未读信息 spend time: " + (endTime3 - startTime3));

        return map;
    }
    
    /**
     * 获取1.9.1的新首页
     * @param lng
     * @param lat
     * @param userName
     * @param cityId
     * @return
     */
    public Map<String, Object> getNewHomePageDataA20(double lng, double lat, String userName, int cityId) {
        // 结果map
        Map<String, Object> map = Maps.newLinkedHashMap();
        // banner
        List<IndexJpg> banners = indexJpgDao.findIndexJpg();
        map.put("banner", buildBannerList(banners));
        // 分类
        List<HomeCategoryConfig> categorys = homeCategoryConfigDao.findHomeCategoryConfigByVersion("2.0");
        map.put("category", buildCategoryListA20(categorys));

        if (StringUtils.isNotBlank(userName)) {
            Map<String, Object> count = msgDao.getUnReadCount(userName);
            int unReadMsgCount = ((Long) count.get("count")).intValue();
            map.put("unReadMsgCount", unReadMsgCount);
        } else {
            map.put("unReadMsgCount", 0);
        }

        return map;
    }


    /**
     * 构建首页banner图片列表
     * 
     * @param banners
     * @return
     */
    private List<BannerDto> buildBannerList(List<IndexJpg> banners) {
        List<BannerDto> list = Lists.newArrayList();
        BannerDto bannerDto = null;
        for (IndexJpg indexJpg : banners) {
            bannerDto = new BannerDto();
            bannerDto.setImage(this.buildImg(indexJpg.getImg()));
            bannerDto.setLink(indexJpg.getLink());
            list.add(bannerDto);
        }
        return list;
    }

    /**
     * 构建首页分类列表
     * 
     * @param categorys
     * @return
     */
    /**
     * 构建首页分类列表
     * 
     * @param categorys
     * @return
     */

    private List<CategoryDto> buildCategoryList(List<HomeCategoryConfig> categorys) {
        // 先找出主分类(parentId=0)
        List<HomeCategoryConfig> mainCategorys = Lists.newArrayList();
        for (HomeCategoryConfig category : categorys) {
            if (category.getParentId() != null && category.getParentId() == 0) {
                mainCategorys.add(category);
            }
        }
        List<CategoryDto> dtos = Lists.newArrayList();
        // 构建主分类，子分类数据
        for (HomeCategoryConfig mainCategory : mainCategorys) {
            CategoryDto mainDto = new CategoryDto();
            mainDto.setCategoryId(mainCategory.getCategoryId());
            mainDto.setTitle(mainCategory.getName());
            mainDto.setImage(this.buildImg(mainCategory.getIcon()));
            mainDto.setColor(mainCategory.getColor());
            List<CategoryDto> subList = Lists.newArrayList();
            switch (mainCategory.getType()) {
                case 1: // 商城
                    Map<Integer, Category> categoryMap = initCategoryMap(); // 初始化分类map
                    subList = this.getSubCategoryList(mainCategory.getId(), categorys, categoryMap);
                    break;
                case 2: // 附近商家
                    Map<Integer, O2oCategory> o2oCategoryMap = initO2oCategoryMap();
                    subList = this.getO2oSubCategoryList(mainCategory.getId(), categorys, o2oCategoryMap);
                    break;
                default:
                    break;
            }

            mainDto.setList(subList);
            dtos.add(mainDto);
        }
        return dtos;
    }

    /**
     * for Android2.0版本
     * @Title: buildCategoryListA20
     * @Description: TODO
     * @param @param categorys
     * @param @return   
     * @return List<CategoryDto> 
     * @author Cary 2016年8月24日 
     * @throws
     */
    private List<CategoryDto> buildCategoryListA20(List<HomeCategoryConfig> categorys) {
        List<CategoryDto> dtos = Lists.newArrayList();
        for (HomeCategoryConfig category : categorys) {
            CategoryDto mainDto = new CategoryDto();
            mainDto.setCategoryId(category.getCategoryId());
            mainDto.setTitle(category.getName());
            mainDto.setImage(this.buildIcon(category.getIcon()));
            dtos.add(mainDto);
        }
        return dtos;
    }

    /**
     * 获取子分类列表
     * 
     * @param mainCategoryId
     *            主分类id
     * @param categorys
     *            分类列表
     * @param categoryMap
     *            分类map
     * @return
     */
    private List<CategoryDto> getSubCategoryList(int mainCategoryId, List<HomeCategoryConfig> categorys,
            Map<Integer, Category> categoryMap) {
        List<CategoryDto> subList = Lists.newArrayList();
        for (HomeCategoryConfig category : categorys) {
            if (category.getParentId() > 0 && category.getParentId() == mainCategoryId) {
                CategoryDto subDto = new CategoryDto();
                subDto.setCategoryId(category.getCategoryId());
                Category c = categoryMap.get(category.getCategoryId());
                if (c != null) {
                    subDto.setTitle(c.getName());
                }
                subDto.setImage(this.buildImg(category.getIcon()));
                subList.add(subDto);
            }
        }
        return subList;
    }

    private List<CategoryDto> getO2oSubCategoryList(int mainCategoryId, List<HomeCategoryConfig> categorys,
            Map<Integer, O2oCategory> categoryMap) {
        List<CategoryDto> subList = Lists.newArrayList();
        for (HomeCategoryConfig category : categorys) {
            if (category.getParentId() > 0 && category.getParentId() == mainCategoryId) {
                CategoryDto subDto = new CategoryDto();
                subDto.setCategoryId(category.getCategoryId());
                O2oCategory c = categoryMap.get(category.getCategoryId());
                if (c != null) {
                    subDto.setTitle(c.getName());
                }
                subDto.setImage(this.buildImg(category.getIcon()));
                subList.add(subDto);
            }
        }
        return subList;
    }

    /**
     * 初始化分类map
     * 
     * @return
     */
    private Map<Integer, Category> initCategoryMap() {
        List<Category> list = categoryDao.findCategory();
        Map<Integer, Category> map = Maps.newHashMap();
        for (Category category : list) {
            map.put(category.getId(), category);
        }
        return map;
    }

    /**
     * 初始化附近商家的分类
     * @Title: initO2oCategoryMap
     * @Description: TODO
     * @param @return   
     * @return Map<Integer,Category> 
     * @author huxianjun 2016年8月8日 
     * @throws
     */
    private Map<Integer, O2oCategory> initO2oCategoryMap() {
        List<O2oCategory> list = o2oCategoryDao.findO2oCategory();
        Map<Integer, O2oCategory> map = Maps.newHashMap();
        for (O2oCategory category : list) {
            map.put(category.getId(), category);
        }
        return map;
    }

    /**
     * 构建热卖商品列表
     * 
     * @param prods
     * @return
     */
    private List<HotProdDto> buildHotProdList(List<HotProd> prods) {
        Map<Integer, Prod> prodMap = initProdMap(); // 初始化商品map
        List<HotProdDto> list = Lists.newArrayList();
        HotProdDto hotProdDto = null;
        for (HotProd hotProd : prods) {
            Prod prod = prodMap.get(hotProd.getProdId());
            if (prod == null) {
                continue;
            }
            hotProdDto = new HotProdDto();
            hotProdDto.setProdId(prod.getProdId());
            hotProdDto.setTitle(prod.getName());
            if (prod.getCash() != null) {
                hotProdDto.setPrice(FormatUtils.formatMoney(prod.getCash().doubleValue()));
            }
            hotProdDto.setImage(this.buildImg(prod.getPic()));
            hotProdDto.setBuys(prod.getBuys());
            hotProdDto.setDetailUrl(SysPropsFactory.getProperty("goodsDetailUrl") + prod.getProdId());

            // 计算补贴
            double rebate = prod.getRebate().doubleValue();
            hotProdDto.setSubsidy(FormatUtils.formatMoney(ArithUtils.mul(prod.getCash().doubleValue(), rebate)));
            hotProdDto.setSubsidyStr(sysService.getSingleValueByType(NhsConstant.PARAM_PRESENT_SIGN)
                    + sysService.getSingleValueByType(NhsConstant.PARAM_RMB_ICON) + hotProdDto.getSubsidy());
            list.add(hotProdDto);
        }
        return list;
    }

    /**
     * 初始商品map
     * 
     * @return
     */
    private Map<Integer, Prod> initProdMap() {
        List<Prod> list = prodDao.findProd();
        Map<Integer, Prod> map = Maps.newHashMap();
        for (Prod prod : list) {
            map.put(prod.getProdId(), prod);
        }
        return map;
    }

    private List<HotProdDto> get(List<HotProd> prods) {
        Map<Integer, Prod> prodMap = initProdMap(); // 初始化商品map
        List<HotProdDto> list = Lists.newArrayList();
        HotProdDto hotProdDto = null;
        for (HotProd hotProd : prods) {
            Prod prod = prodMap.get(hotProd.getProdId());
            if (prod == null) {
                continue;
            }
            hotProdDto = new HotProdDto();
            hotProdDto.setProdId(prod.getProdId());
            hotProdDto.setTitle(prod.getName());
            if (prod.getCash() != null) {
                hotProdDto.setPrice(FormatUtils.formatMoney(prod.getCash().doubleValue()));
            }
            hotProdDto.setImage(this.buildImg(prod.getPic()));
            hotProdDto.setBuys(prod.getBuys());
            hotProdDto.setDetailUrl(SysPropsFactory.getProperty("goodsDetailUrl") + prod.getProdId());

            // 计算补贴
            double rebate = prod.getRebate().doubleValue();
            hotProdDto.setSubsidy(FormatUtils.formatMoney(ArithUtils.mul(prod.getCash().doubleValue(), rebate)));
            hotProdDto.setSubsidyStr(sysService.getSingleValueByType(NhsConstant.PARAM_PRESENT_SIGN)
                    + sysService.getSingleValueByType(NhsConstant.PARAM_RMB_ICON) + hotProdDto.getSubsidy());
            list.add(hotProdDto);
        }
        return list;
    }

    public List<O2oHotCategoryDto> getCategoryhotData(int type) {
        List<O2oHotCategory> hotCategoryParams = o2oHotCategoryDao.findO2oHotCategoryStatus(2);
        List<O2oHotCategoryDto> returnParams = Lists.newArrayList();
        if (hotCategoryParams != null && hotCategoryParams.size() != 0) {
            for (O2oHotCategory hotCategory : hotCategoryParams) {
                O2oHotCategoryDto returnParam = new O2oHotCategoryDto();
                returnParam.setApplyCout(hotCategory.getApplynumber());
                returnParam.setGroupId(hotCategory.getId());
                returnParam.setName(hotCategory.getName());
                returnParam.setReleaseCout(hotCategory.getReleaseNumber());
                returnParam.setReleaseTime(hotCategory.getReleaseTime().toString());
                returnParam.setUpdateTime(hotCategory.getUpdateTime().toString());
                returnParam.setStatus(hotCategory.getStatus());
                List<O2oHotCategoryConfig> o2oHotCategoryConfigList = o2oHotCategoryConfigDao
                        .findO2oHotCategoryConfigByGroupId(hotCategory.getId());
                if (o2oHotCategoryConfigList != null && o2oHotCategoryConfigList.size() != 0) {
                    for (O2oHotCategoryConfig ohcc : o2oHotCategoryConfigList) {
                        ohcc.setIcon(this.buildBannerIcon(ohcc.getIcon()));
                        if (type == 0) {
                            if (ohcc.getCategoryId() == 0) {
                                ohcc.setCategoryId(ohcc.getParentId());
                            }
                        }
                    }
                    returnParam.setO2oHotCategoryConfig(o2oHotCategoryConfigList);
                    returnParam.setCount(o2oHotCategoryConfigList.size());
                } else {
                    continue;
                }
                returnParams.add(returnParam);
            }
        }
        return returnParams;
    }

    public List<O2oHotCategoryDto> getCategoryhotData() {
        List<O2oHotCategory> hotCategoryParams = o2oHotCategoryDao.findO2oHotCategoryStatus(2);
        List<O2oHotCategoryDto> returnParams = Lists.newArrayList();
        if (hotCategoryParams != null && hotCategoryParams.size() != 0) {
            for (O2oHotCategory hotCategory : hotCategoryParams) {
                O2oHotCategoryDto returnParam = new O2oHotCategoryDto();
                returnParam.setApplyCout(hotCategory.getApplynumber());
                returnParam.setGroupId(hotCategory.getId());
                returnParam.setName(hotCategory.getName());
                returnParam.setReleaseCout(hotCategory.getReleaseNumber());
                returnParam.setReleaseTime(hotCategory.getReleaseTime().toString());
                returnParam.setUpdateTime(hotCategory.getUpdateTime().toString());
                returnParam.setStatus(hotCategory.getStatus());
                List<O2oHotCategoryConfig> o2oHotCategoryConfigList = o2oHotCategoryConfigDao
                        .findO2oHotCategoryConfigByGroupId(hotCategory.getId());
                if (o2oHotCategoryConfigList != null && o2oHotCategoryConfigList.size() != 0) {
                    for (O2oHotCategoryConfig ohcc : o2oHotCategoryConfigList) {
                        ohcc.setIcon(this.buildBannerIcon(ohcc.getIcon()));
                    }
                    returnParam.setO2oHotCategoryConfig(o2oHotCategoryConfigList);
                    returnParam.setCount(o2oHotCategoryConfigList.size());
                } else {
                    continue;
                }
                returnParams.add(returnParam);
            }
        }
        return returnParams;
    }
}
