package com.nhs.shop.bindspreader.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * 商家代理
 * @author wind.chen
 */
@Entity
@Table(name="ls_binded_spreader")
public class BindedSpreader implements Serializable{

	private static final long serialVersionUID = -1186978740933629957L;
	
	/**
	 * 类型 - 商家 - 0
	 */
	public static final int SPREADERTYPE_SHOP = 0;
	
	@Id
    @GeneratedValue
    @Column(name = "id")
	private Integer id;
	
	/**
	 * 推广类型. 
	 */
	@Column(name="spreader_type")
	private int spreaderType;
	
	/**
	 * 绑定的o2o商家的所有人id
	 */
	@Column(name="user_id")
	private String shopOwerId;
	
	/**
	 * 绑定的商家店铺的id
	 */
	@Column(name="shop_id")
	private Integer shopId;
	
	/**
	 * 绑定用户的手机号
	 */
	@Column(name="user_mobile")
	private String userMobile;
	
	@Column(name="created_time")
	private Date createdTime;
	
	@Column(name="updated_time")
	private Date updatedTime;

	public BindedSpreader() {
		super();
	}
	
	public BindedSpreader(Integer shopId, String shopOwerId, String userMobile, int type) {
		super();
		this.shopId = shopId;
		this.shopOwerId = shopOwerId;
		this.userMobile = userMobile;
		this.createdTime = new Date();
		this.updatedTime = this.createdTime;
		this.spreaderType= type;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getShopOwerId() {
		return shopOwerId;
	}

	public void setShopOwerId(String shopOwerId) {
		this.shopOwerId = shopOwerId;
	}

	public Integer getShopId() {
		return shopId;
	}

	public void setShopId(Integer shopId) {
		this.shopId = shopId;
	}

	public String getUserMobile() {
		return userMobile;
	}

	public void setUserMobile(String userMobile) {
		this.userMobile = userMobile;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Date getUpdatedTime() {
		return updatedTime;
	}

	public void setUpdatedTime(Date updatedTime) {
		this.updatedTime = updatedTime;
	}

	public int getSpreaderType() {
		return spreaderType;
	}

	public void setSpreaderType(int spreaderType) {
		this.spreaderType = spreaderType;
	}
	
}
