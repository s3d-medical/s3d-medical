package com.nhs.shop.service.car;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.nhs.core.common.NhsConstant;
import com.nhs.core.context.SysPropsFactory;
import com.nhs.core.mapper.JsonMapper;
import com.nhs.core.orm.Page;
import com.nhs.core.utils.common.ArithUtils;
import com.nhs.core.utils.common.DateUtils;
import com.nhs.core.utils.common.FormatUtils;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.shop.dao.legend.car.CarBrandDao;
import com.nhs.shop.dao.legend.car.CarDao;
import com.nhs.shop.dao.legend.car.CarSeriesDao;
import com.nhs.shop.dao.legend.car.CarTypeDao;
import com.nhs.shop.dao.legend.collect.CollectDao;
import com.nhs.shop.dao.legend.recommend.VitLogDao;
import com.nhs.shop.dao.legend.recommend.VitLogSaveDao;
import com.nhs.shop.dao.legend.shop.GoodsDao;
import com.nhs.shop.dao.legend.shop.HotProdDao;
import com.nhs.shop.dao.legend.shop.ImgFileDao;
import com.nhs.shop.dao.legend.shop.ProdCommDao;
import com.nhs.shop.dao.legend.shop.ProdCommStatDao;
import com.nhs.shop.dao.legend.shop.ProdDao;
import com.nhs.shop.dao.legend.shop.ShopDetailDao;
import com.nhs.shop.entry.em.HotPordCategoryEnum;
import com.nhs.shop.entry.legend.car.CarBrand;
import com.nhs.shop.entry.legend.car.CarSeries;
import com.nhs.shop.entry.legend.car.CarType;
import com.nhs.shop.entry.legend.shop.HotProd;
import com.nhs.shop.entry.legend.shop.ImgFile;
import com.nhs.shop.entry.legend.shop.Prod;
import com.nhs.shop.entry.legend.shop.ProdComm;
import com.nhs.shop.entry.legend.shop.ProdCommStat;
import com.nhs.shop.entry.legend.shop.ProdProp;
import com.nhs.shop.entry.legend.shop.ProdPropValue;
import com.nhs.shop.entry.legend.shop.ShopDetail;
import com.nhs.shop.entry.legend.shop.Sku;
import com.nhs.shop.entry.legend.shop.VitLog;
import com.nhs.shop.entry.legend.user.UsrDetail;
import com.nhs.shop.service.BaseService;
import com.nhs.shop.service.car.dto.CarBrandDto;
import com.nhs.shop.service.car.dto.CarBrandDto.BrandDto;
import com.nhs.shop.service.car.dto.CarDetailDto;
import com.nhs.shop.service.car.dto.CarDto;
import com.nhs.shop.service.car.dto.CarShopDetailDto;
import com.nhs.shop.service.goods.dto.SkuDto;
import com.nhs.shop.service.goods.dto.SkuNameDto;
import com.nhs.shop.service.goods.dto.SkuValueDto;
import com.nhs.shop.service.sku.SkuService;
import com.nhs.shop.service.system.SystemParameterService;
import com.nhs.shop.util.BasicConstant;
import com.nhs.user.service.UserService;

@Service
@Transactional
public class CarService extends BaseService {
    @Autowired
    private CarBrandDao carBrandDao;
    @Autowired
    private CarSeriesDao carSeriesDao;
    @Autowired
    private CarTypeDao carTypeDao;
    @Autowired
    private HotProdDao hotProdDao; // 最热商品dao
    @Autowired
    private ProdDao prodDao; // 商品dao
    @Autowired
    private CarDao carDao; // 商品dao
    @Autowired
    private GoodsDao goodsDao;
    @Autowired
    private ImgFileDao imgFileDao;
    @Autowired
    private ProdCommDao prodCommDao;
    @Autowired
    private ProdCommStatDao prodCommStatDao;
    @Autowired
    private ShopDetailDao shopDetailDao;
    @Autowired
    private SkuService skuService;
    @Autowired
    private CollectDao collectDao;
    @Autowired
    private VitLogDao vitLogDao;

    @Autowired
    private UserService userService;

    @Autowired
    private VitLogSaveDao vitLogSaveDao;

    @Autowired
    private SystemParameterService sysService;

    private String car_log_type = "isCar";

    /**
     * 热门汽车品牌
     * @Title: getHotBrand
     * @Description: TODO
     * @param @return   
     * @return List<Map<String,Object>> 
     * @author Administrator 2016年7月26日 
     * @throws
     */
    public List<Map<String, Object>> getHotBrand() {
        List<Map<String, Object>> list = Lists.newArrayList();
        List<CarBrand> ret = carBrandDao.findCarBrandHot();
        if (ret != null && ret.size() > 0) {
            for (CarBrand brand : ret) {
                Map<String, Object> cb = Maps.newHashMap();
                cb.put("brandId", brand.getId());
                cb.put("name", brand.getName());
                cb.put("image", this.buildImg(brand.getTagPic()));
                cb.put("firstChar", brand.getFirstChar());
                list.add(cb);
            }
        }
        return list;
    }

    /**
     * 热销车型
     * @Title: getHotCar
     * @Description: TODO
     * @param @return   
     * @return List<HotProd> 
     * @author Administrator 2016年7月26日 
     * @throws
     */
    public List<CarDto> getHotCar(String channel) {
        // 热卖商品
        List<HotProd> prods = hotProdDao.findHotProd(HotPordCategoryEnum.HOT_CAR.getCategory());
        return buildCarDtoList(prods, channel);
    }

    /**
     * 获取所有热销车型
     * @Title: getHotCar
     * @Description: TODO
     * @param @return   
     * @return List<HotProd> 
     * @author Administrator 2016年7月26日 
     * @throws
     */
    public List<CarDto> getAllHotCar(Integer sort, Page<Map<String, Object>> page, String channel) {
        Page<Map<String, Object>> pageData = carDao.getHotCarList(sort, page);
        return buildCarDtoList(pageData, channel);
    }

    /**
     * 获取所有热销车型
     * @Title: getHotCar
     * @Description: TODO
     * @param @return   
     * @return List<HotProd> 
     * @author Administrator 2016年7月26日 
     * @throws
     */
    public List<CarDto> getCarList(Integer brandId, String keyword, Integer sort, Page<Map<String, Object>> page,
            String channel) {
        Page<Map<String, Object>> pageData = carDao.getCarList(brandId, keyword, sort, page);
        return buildCarDtoList(pageData, channel);
    }

    /**
     * 构建热卖商品列表
     * @Title: buildHotProdList
     * @Description: TODO
     * @param @param pageData
     * @param @return   
     * @return List<HotProdDto> 
     * @author Administrator 2016年7月26日 
     * @throws
     */
    private List<CarDto> buildCarDtoList(Page<Map<String, Object>> pageData, String channel) {
        List<CarDto> list = Lists.newArrayList();
        for (Map<String, Object> map : pageData.getResult()) {
            CarDto dto = new CarDto();
            dto.setBuys(StringHelper.objectToInt(map.get("buys"), 0));
            dto.setProdId(StringHelper.objectToInt(map.get("prod_id"), 0));
            dto.setImage(this.buildImg(StringHelper.objectToString(map.get("pic"), "")));
            // 2016-08-18 cary 汽车价格统一格式化成万元，拼接好单位返回
            if ("android".equals(channel)) {
                dto.setPrice(new BigDecimal(StringHelper.objectToDouble(map.get("cash"), 0.0) / 10000)
                        .setScale(2, BigDecimal.ROUND_DOWN).toString());
            } else {
                dto.setPrice(new BigDecimal(StringHelper.objectToDouble(map.get("cash"), 0.0) / 10000)
                        .setScale(2, BigDecimal.ROUND_DOWN).toString() + "万起");
            }

            dto.setTitle(StringHelper.objectToString(map.get("name"), ""));
            dto.setDetailUrl(SysPropsFactory.getProperty("carDetailUrl") + dto.getProdId());
            double rebate = StringHelper.objectToDouble(map.get("rebate"), 1.0);
            if ("android".equals(channel)) {
                dto.setSubsidy(FormatUtils.formatMoney(
                        ArithUtils.mul(StringHelper.objectToDouble(map.get("cash"), 0.0), rebate) / 10000));
                dto.setSubsidyStr(sysService.getSingleValueByType(NhsConstant.PARAM_PRESENT_SIGN)
                        + sysService.getSingleValueByType(NhsConstant.PARAM_RMB_ICON) + dto.getSubsidy());
            } else {
                dto.setSubsidy(FormatUtils.formatMoney(
                        ArithUtils.mul(StringHelper.objectToDouble(map.get("cash"), 0.0), rebate) / 10000) + "万");
                dto.setSubsidyStr(sysService.getSingleValueByType(NhsConstant.PARAM_PRESENT_SIGN)
                        + sysService.getSingleValueByType(NhsConstant.PARAM_RMB_ICON) + dto.getSubsidy());
            }
            list.add(dto);
        }
        return list;
    }

    /**
     * 构建热卖商品列表
     * @Title: buildHotProdList
     * @Description: TODO
     * @param @param prods
     * @param @return   
     * @return List<HotProdDto> 
     * @author Administrator 2016年7月26日 
     * @throws
     */
    private List<CarDto> buildCarDtoList(List<HotProd> prods, String channel) {
        Map<Integer, Prod> prodMap = initProdMap(); // 初始化商品map
        List<CarDto> list = Lists.newArrayList();
        CarDto dto = null;
        for (HotProd hotProd : prods) {
            Prod prod = prodMap.get(hotProd.getProdId());
            if (prod == null) {
                continue;
            }
            dto = new CarDto();
            dto.setProdId(prod.getProdId());
            dto.setTitle(prod.getName());
            if (prod.getCash() != null) {
                // 2016-08-18 cary 汽车价格统一格式化成万元，拼接好单位返回(android 暂不拼接，下个版本改)
                if ("android".equals(channel)) {
                    dto.setPrice(new BigDecimal(prod.getCash().doubleValue() / 10000).setScale(2, BigDecimal.ROUND_DOWN)
                            .toString());
                } else {
                    dto.setPrice(new BigDecimal(prod.getCash().doubleValue() / 10000).setScale(2, BigDecimal.ROUND_DOWN)
                            .toString() + "万起");
                }

            }
            dto.setImage(this.buildImg(prod.getPic()));
            dto.setBuys(prod.getBuys());
            dto.setDetailUrl(SysPropsFactory.getProperty("carDetailUrl") + dto.getProdId());
            // 计算补贴
            if (prod.getRebate() != null) {
                double rebate = prod.getRebate().doubleValue();
                // 2016-08-18 cary 汽车价格统一格式化成万元，拼接好单位返回(android 暂不拼接，下个版本改)
                if ("android".equals(channel)) {
                    dto.setSubsidy("");
                    dto.setSubsidyStr("");
                } else {
                    dto.setSubsidy("");
                    dto.setSubsidyStr("");
                }

            }
            list.add(dto);
        }
        return list;
    }

    /**
     * 初始商品map
     * 
     * @return
     */
    private Map<Integer, Prod> initProdMap() {
        List<Prod> list = prodDao.findProd();
        Map<Integer, Prod> map = Maps.newHashMap();
        for (Prod prod : list) {
            map.put(prod.getProdId(), prod);
        }
        return map;
    }

    /**
     * 获取所有的一级品牌
     * @Title: getTopBrand
     * @Description: TODO
     * @param @param pageNo
     * @param @param pageSize
     * @param @return   
     * @return List<Map<String,Object>> 
     * @author huxianjun 2016年7月19日 
     * @throws
     */
    public Collection<CarBrandDto> getAllBrand() {

        List<CarBrand> carBrandList = carBrandDao.findCarBrand();
        Map<String, CarBrandDto> map = Maps.newLinkedHashMap();
        for (CarBrand brand : carBrandList) {
            String letter = brand.getFirstChar().toUpperCase();
            CarBrandDto dto = map.get(letter);
            if (dto == null) {
                dto = new CarBrandDto();
                dto.setLetter(letter);
                map.put(letter, dto);
            }
            BrandDto brandDto = new BrandDto();
            brandDto.setBrandId(brand.getId());
            brandDto.setImage(this.buildImg(brand.getTagPic()));
            brandDto.setName(brand.getName());
            brandDto.setLetter(letter);
            dto.addBrandDto(brandDto);
        }
        return map.values();
    }

    public List<Map<String, Object>> getTopBrand() {
        List<String> carGroup = carBrandDao.findCarBrandGroup();
        List<Map<String, Object>> list = Lists.newArrayList();
        if (carGroup != null && carGroup.size() > 0) {
            for (String firtChar : carGroup) {
                Map<String, Object> brand = Maps.newHashMap();
                brand.put(firtChar, this.getBrandByChar(firtChar));
                list.add(brand);
            }
        }
        return list;
    }

    public List<Map<String, Object>> getBrandByChar(String firstChar) {
        List<Map<String, Object>> list = Lists.newArrayList();
        List<CarBrand> ret = carBrandDao.findCarBrand(0, firstChar);
        if (ret != null && ret.size() > 0) {
            for (CarBrand brand : ret) {
                Map<String, Object> cb = Maps.newHashMap();
                cb.put("brandId", brand.getId());
                cb.put("name", brand.getName());
                cb.put("image", brand.getTagPic());
                cb.put("firstChar", brand.getFirstChar());
                list.add(cb);
            }
        }
        return list;
    }

    public List<Map<String, Object>> getSeriesByBrand(Integer brandId) {
        List<Map<String, Object>> list = Lists.newArrayList();
        List<CarSeries> ret = carSeriesDao.findCarSeriesByBrandId(brandId);
        if (ret != null && ret.size() > 0) {
            for (CarSeries cs : ret) {
                Map<String, Object> cb = Maps.newHashMap();
                cb.put("seriesId", cs.getId());
                cb.put("name", cs.getName());
                list.add(cb);
            }
        }
        return list;
    }

    public List<Map<String, Object>> getCarTypeBySeries(Integer seriesId) {
        List<Map<String, Object>> list = Lists.newArrayList();
        List<CarType> ret = carTypeDao.findCarTypeBySeriesId(seriesId);
        if (ret != null && ret.size() > 0) {
            for (CarType cs : ret) {
                Map<String, Object> cb = Maps.newHashMap();
                cb.put("carTypeId", cs.getId());
                cb.put("name", cs.getMotorcycleType());
                list.add(cb);
            }
        }
        return list;
    }

    /**
     * 获取商品详情
     * @Title: getGoodsDetail
     * @Description: TODO
     * @param @param goodsId
     * @param @return   
     * @return CarDetailDto 
     * @author Administrator 2016年7月17日 
     * @throws
     */
    public CarDetailDto getCarDetail(Integer prodId, String userId, String channel) {
        CarDetailDto dto = new CarDetailDto();
        // 构建商品信息
        dto.setCar(buildGoodsDetail(prodId, userId, channel));
        // 构建评价信息
        dto.setComment(buildGoodsComment(prodId));
        // 构建店铺信息
        dto.setShop(buildGoodsShop(dto.getCar().getShopId()));
        
        return dto;
    }

    /**
     * 获取商品SKU
     * @Title: getGoodsSku
     * @Description: TODO
     * @param @param prodId
     * @param @return   
     * @return Map<String,Object> 
     * @author Administrator 2016年7月21日 
     * @throws
     */
    public Map<String, Object> getGoodsSku(Integer prodId, Integer skuId) {
        Map<String, Object> map = Maps.newHashMap();
        // 构建商品sku
        List<Sku> skus = skuService.findSkuListByProdId(prodId);
        map.put("skus", buildSkuDto(skus));
        map.put("skuNames", buildSkuNameDto(skus, skuId));
        return map;
    }

    /**
     * 构建商品详情
     * @Title: buildGoodsDetail
     * @Description: TODO
     * @param @param goodsId
     * @param @return   
     * @return CarDetailDto.GoodsDto 
     * @author Administrator 2016年7月17日 
     * @throws
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    private CarDetailDto.GoodsDto buildGoodsDetail(Integer prodId, String userId, String channel) {
        CarDetailDto.GoodsDto dto = new CarDetailDto.GoodsDto();
        Map<String, Object> map = goodsDao.getGoodsDetail(prodId);
        if (map != null) {
            dto.setProdId(prodId);
            dto.setShopId(StringHelper.objectToInt(map.get("shop_id"), 0));
            dto.setAddress(StringHelper.objectToString(map.get("province"), "")
                    + StringHelper.objectToString(map.get("city"), ""));
            dto.setTitle(StringHelper.objectToString(map.get("name"), ""));
            dto.setSaleNum(StringHelper.objectToInt(map.get("buys"), 0));
            dto.setBrief(StringHelper.objectToString(map.get("brief"), ""));
            dto.setContent(StringHelper.objectToString(map.get("content"), ""));

            dto.setPrice((StringHelper.objectToBigDecimal(map.get("cash"), "").divide(new BigDecimal(10000)))
                    .setScale(2, BigDecimal.ROUND_DOWN).toString() + "万起");

            // 车价>40万，定金为2万， 车价<40万，定金为1万
            // 计算补贴
            double rebate = StringHelper.objectToDouble(map.get("rebate"), 1.0);
            double cash = StringHelper.objectToDouble(map.get("cash"), 0.0);
            if (cash > 400000) {
                dto.setDeposit("5,000");
                dto.setBalancePayment(
                        (new BigDecimal(cash).subtract(new BigDecimal(20000))).divide(new BigDecimal(10000)).toString()
                                + "万起");
            } else {
                dto.setDeposit("3,000");
                dto.setBalancePayment(
                        (new BigDecimal(cash).subtract(new BigDecimal(10000))).divide(new BigDecimal(10000)).toString()
                                + "万起");
            }
            dto.setSubsidy((new BigDecimal(ArithUtils.mul(StringHelper.objectToDouble(map.get("cash"), 0.0), rebate))
                    .divide(new BigDecimal(10000))).setScale(2, BigDecimal.ROUND_DOWN).toString() + "万");
            dto.setSubsidyStr(sysService.getSingleValueByType(NhsConstant.PARAM_PRESENT_SIGN)
                    + sysService.getSingleValueByType(NhsConstant.PARAM_RMB_ICON) + dto.getSubsidy());
        }
        dto.setStocks(StringHelper.objectToInt(map.get("stocks"), 0));
        // 商品详情图片
        List<String> images = Lists.newArrayList();
        List<ImgFile> imgFileList = imgFileDao.findImgFile(prodId);
        for (ImgFile imgFile : imgFileList) {
            images.add(this.buildImg(imgFile.getFilePath()));
        }
        dto.setImages(images);

        List<CarDetailDto.SpecificationDto> specifications = Lists.newArrayList();
        // 规格参数
        String parameter = StringHelper.objectToString(map.get("parameter"), "");
        if (StringUtils.isNoneBlank(parameter)) {
            List<Map> parameters = JsonMapper.nonEmptyMapper().fromJson(parameter, List.class);
            for (Map p : parameters) {
                CarDetailDto.SpecificationDto s = new CarDetailDto.SpecificationDto();
                s.setName(StringHelper.objectToString(p.get("paramName"), ""));
                s.setValue(StringHelper.objectToString(p.get("paramValueName"), ""));
                specifications.add(s);
            }
        }

        // 用户自定义规格参数
        String userParameter = StringHelper.objectToString(map.get("user_parameter"), "");
        if (StringUtils.isNoneBlank(userParameter)) {
            List<Map> parameters = JsonMapper.nonEmptyMapper().fromJson(userParameter, List.class);
            for (Map p : parameters) {
                CarDetailDto.SpecificationDto s = new CarDetailDto.SpecificationDto();
                s.setName(StringHelper.objectToString(p.get("key"), ""));
                s.setValue(StringHelper.objectToString(p.get("value"), ""));
                specifications.add(s);
            }
        }

        dto.setSpecifications(specifications);

        // 构建商品sku
        List<Sku> skus = skuService.findSkuListByProdId(prodId);
        dto.setSkus(buildSkuDto(skus));
        dto.setSkuNames(buildSkuNameDto(skus, null));

        // 是否被收藏
        List<Map<String, Object>> collections = collectDao.getCollectByPrdId(prodId.toString(), userId);
        if (null != collections && collections.size() > 0) {
            dto.setIsCollected(BasicConstant.FLAG_VALID.toString());
        } else {
            dto.setIsCollected(BasicConstant.FLAG_INVALID.toString());
        }
        return dto;
    }

    /**
     * 构建商品评价信息
     * @Title: buildGoodsComment
     * @Description: TODO
     * @param @param goodsId
     * @param @return   
     * @return CarDetailDto.CommentDto 
     * @author Administrator 2016年7月17日 
     * @throws
     */
    private CarDetailDto.CommentDto buildGoodsComment(Integer goodsId) {
        CarDetailDto.CommentDto dto = new CarDetailDto.CommentDto();
        List<ProdCommStat> prodCommStatList = prodCommStatDao.findProdCommStat(goodsId);
        if (CollectionUtils.isNotEmpty(prodCommStatList)) {
            ProdCommStat prodCommStat = prodCommStatList.get(0);
            if (prodCommStat != null) {
                dto.setNum(prodCommStat.getComments());
            }
        } else {
            dto.setNum(0);
        }

        // 获取评价详情
        List<CarDetailDto.CommentDetailDto> details = Lists.newArrayList();
        List<ProdComm> prodCommList = prodCommDao.findProdComm(goodsId);
        int i = 1;
        for (ProdComm prodComm : prodCommList) {
            if (i > 3) { // 只取3个评价显示
                continue;
            }
            CarDetailDto.CommentDetailDto detail = new CarDetailDto.CommentDetailDto();
            detail.setUserId(prodComm.getUserId());
            detail.setUsername(prodComm.getUserName());
            detail.setContent(prodComm.getContent());
            detail.setScore(prodComm.getScore());
            List<String> images = Lists.newArrayList();
            if (StringUtils.isNotBlank(prodComm.getPhotoFile1())) {
                images.add(buildImg(prodComm.getPhotoFile1()));
            }
            if (StringUtils.isNotBlank(prodComm.getPhotoFile2())) {
                images.add(buildImg(prodComm.getPhotoFile2()));
            }
            if (StringUtils.isNotBlank(prodComm.getPhotoFile3())) {
                images.add(buildImg(prodComm.getPhotoFile3()));
            }
            if (StringUtils.isNotBlank(prodComm.getPhotoFile4())) {
                images.add(buildImg(prodComm.getPhotoFile4()));
            }
            if (StringUtils.isNotBlank(prodComm.getPhotoFile5())) {
                images.add(buildImg(prodComm.getPhotoFile5()));
            }
            detail.setImages(images);
            details.add(detail);
            i++;
        }

        dto.setList(details);
        return dto;
    }

    /**
     * 构建商品店铺信息
     * @Title: buildGoodsShop
     * @Description: TODO
     * @param @param shopId
     * @param @return   
     * @return CarDetailDto.ShopDto 
     * @author Administrator 2016年7月17日 
     * @throws
     */
    private CarDetailDto.ShopDto buildGoodsShop(Integer shopId) {
        CarDetailDto.ShopDto dto = new CarDetailDto.ShopDto();
        ShopDetail shopDetail = shopDetailDao.findOne(shopId);
        if (shopDetail != null) {
            dto.setShopId(shopId);
            dto.setTitle(shopDetail.getSiteName()); // 商店名称
            dto.setImage(buildImg(shopDetail.getLogoPic())); // 商店头像
            dto.setAddress(shopDetail.getShopAddr());
            dto.setMobile(shopDetail.getContactTel());
            dto.setLat(shopDetail.getLat());
            dto.setLng(shopDetail.getLng());
        }
        return dto;
    }

    /**
     * 构建商品sku
     * @Title: buildSkuDto
     * @Description: TODO
     * @param @param skus
     * @param @return   
     * @return List<SkuDto> 
     * @author Administrator 2016年7月18日 
     * @throws
     */
    private List<SkuDto> buildSkuDto(List<Sku> skus) {
        List<SkuDto> list = Lists.newArrayList();
        SkuDto dto = null;
        for (Sku sku : skus) {
            dto = new SkuDto();
            dto.setSkuId(sku.getSkuId());
            dto.setSkuValue(convertProperties(sku.getProperties()));
            dto.setPrice((StringHelper.objectToBigDecimal(sku.getPrice(), "").divide(new BigDecimal(10000)))
                    .setScale(2, BigDecimal.ROUND_DOWN).toString() + "万");
            dto.setProdId(sku.getProdId());
            dto.setStocks(sku.getStocks());
            Prod prop = prodDao.findOne(sku.getProdId());
            if (prop != null) {
                double rebate = StringHelper.objectToDouble(prop.getRebate(), 1.0);
                dto.setSubsidy((new BigDecimal(ArithUtils.mul(StringHelper.objectToDouble(sku.getPrice(), 0.0), rebate))
                        .divide(new BigDecimal(10000))).setScale(2, BigDecimal.ROUND_DOWN).toString() + "万");
                dto.setSubsidyStr(sysService.getSingleValueByType(NhsConstant.PARAM_PRESENT_SIGN)
                        + sysService.getSingleValueByType(NhsConstant.PARAM_RMB_ICON) + dto.getSubsidy());
            }
            list.add(dto);
        }
        return list;
    }

    /**
     * 构建SKU Name
     * @Title: buildSkuNameDto
     * @Description: TODO
     * @param @param skus
     * @param @return   
     * @return List<SkuNameDto> 
     * @author Administrator 2016年7月18日 
     * @throws
     */
    private List<SkuNameDto> buildSkuNameDto(List<Sku> skus, Integer skuId) {

        // 获取sku value map
        Map<Integer, Object> skuValueMap = skuService.getSkuValueMap(skuId);
        // 合并properties
        Map<Integer, Set<Integer>> skuMap = mergeProperties(skus);
        // 初始化sku属性map
        Map<Integer, ProdProp> propMap = skuService.initProdPropMap();
        // 初始化sku属性值map
        Map<Integer, ProdPropValue> propValueMap = skuService.initProdPropValueMap();
        List<SkuNameDto> list = Lists.newArrayList();
        for (Entry<Integer, Set<Integer>> entry : skuMap.entrySet()) {
            int key = entry.getKey();
            Set<Integer> set = entry.getValue();
            ProdProp prop = propMap.get(key);
            if (prop == null) {
                continue;
            }
            SkuNameDto nameDto = new SkuNameDto();
            nameDto.setSkuNameId(key);
            nameDto.setSkuName(prop.getMemo());

            for (Integer valueId : set) {
                ProdPropValue propValue = propValueMap.get(valueId);
                if (propValue == null) {
                    continue;
                }
                SkuValueDto valueDto = new SkuValueDto();
                valueDto.setSkuValueId(valueId);
                valueDto.setSkuValue(propValue.getName());
                if (skuValueMap.containsKey(valueId)) {
                    valueDto.setSelected(true);
                }
                nameDto.addSkuValueDto(valueDto);
            }
            list.add(nameDto);
        }

        return list;
    }

    /**
     * 合并sku
     * @Title: mergeProperties
     * @Description: TODO
     * @param @param skus
     * @param @return   
     * @return Map<Integer,Set<Integer>> 
     * @author Administrator 2016年7月18日 
     * @throws
     */
    private Map<Integer, Set<Integer>> mergeProperties(List<Sku> skus) {
        Map<Integer, Set<Integer>> map = Maps.newHashMap();
        for (Sku sku : skus) {
            String properties = sku.getProperties();
            String[] groups = properties.split(";");
            if (groups == null || groups.length == 0) {
                continue;
            }
            for (String group : groups) {
                String[] values = group.split(":");
                if (values != null && values.length >= 2) {
                    int k = Integer.parseInt(values[0]);
                    int v = Integer.parseInt(values[1]);
                    if (map.containsKey(k)) {
                        Set<Integer> set = map.get(k);
                        set.add(v);
                    } else {
                        Set<Integer> set = new HashSet<Integer>();
                        set.add(v);
                        map.put(k, set);
                    }
                }
            }
        }
        return map;
    }

    /**
     * 转换sku properties，比如: 268:816;269:831 -> 816-831
     * @Title: convertProperties
     * @Description: TODO
     * @param @param properties
     * @param @return   
     * @return String 
     * @author Administrator 2016年7月18日 
     * @throws
     */
    private String convertProperties(String properties) {
        if (StringUtils.isBlank(properties)) {
            return "";
        }
        String[] groups = properties.split(";");
        if (groups == null || groups.length == 0) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for (String group : groups) {
            String[] values = group.split(":");
            if (values != null && values.length >= 2) {
                sb.append(values[1]).append("-");
            }
        }
        String value = "";
        if (sb.length() > 0) {
            value = sb.substring(0, sb.length() - 1);
        }
        return value;
    }

    /**
     * 获取汽车店铺详情
     * @Title: getShopDetail
     * @Description: TODO
     * @param @param shopId
     * @param @return   
     * @return CarShopDetailDto 
     * @author Administrator 2016年7月27日 
     * @throws
     */
    public CarShopDetailDto getShopDetail(Integer shopId) {
        CarShopDetailDto dto = new CarShopDetailDto();
        ShopDetail shopDetail = shopDetailDao.findOne(shopId);
        if (shopDetail != null) {
            dto.setShopId(shopId);
            dto.setTitle(shopDetail.getSiteName()); // 商店名称
            dto.setImage(buildImg(shopDetail.getLogoPic())); // 商店头像
            dto.setAddress(shopDetail.getShopAddr());
            dto.setCreateTime(DateUtils.date2Str(shopDetail.getRecDate()));
            dto.setMobile(shopDetail.getContactMobile());
            dto.setDeposit("20000");
            dto.setProdNum(shopDetail.getProductNum());
        }

        List<Prod> prodList = prodDao.findProdByShopId(shopId);
        List<CarDto> list = Lists.newArrayList();
        CarDto carDto = null;
        for (Prod prod : prodList) {
            carDto = new CarDto();
            carDto.setProdId(prod.getProdId());
            carDto.setTitle(prod.getName());
            if (prod.getCash() != null) {
                carDto.setPrice(FormatUtils.formatMoney(prod.getCash().doubleValue()));
            }
            carDto.setImage(this.buildImg(prod.getPic()));
            carDto.setBuys(prod.getBuys());
            list.add(carDto);
        }

        dto.setList(list);
        return dto;
    }

    /**
     * 构建浏览记录
     * @Title: buildGoodsHistory
     * @Description: TODO
     * @param @param prodId
     * @param @param cityId
     * @param @param userId
     * @return void
     * @author liangdanhua 2016年8月25日
     * @throws
     */
    public void buildGoodsHistory(Integer prodId, String userId) {
        VitLog vitlog = vitLogDao.findVitlogByuserIdAndproId(userId, prodId.toString());
        if (vitlog == null) {
            VitLog vlg = new VitLog();
            // UsrDetail usrDetail = this.usrDetailDao.findUserById(userId);
            UsrDetail usrDetail = this.userService.findUserById(userId);

            Prod prod = prodDao.findOne(prodId);
            ShopDetail shopDetail = shopDetailDao.findOne(prod.getShopId());
            if (shopDetail == null)
                shopDetail = new ShopDetail();
            try {
                vlg.setUserName(usrDetail.getUserName() == null ? "" : usrDetail.getUserName());
                vlg.setShopName(shopDetail.getSiteName() == null ? "" : shopDetail.getSiteName());
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            vlg.setProductId(prodId.toString());
            vlg.setProductName(prod.getName());
            vlg.setIp("");
            vlg.setPage("");
            vlg.setRecDate(new Date());
            vlg.setShopId(shopDetail.getShopId() == null ? 0 : shopDetail.getShopId());
            vlg.setUserId(userId);
            vlg.setIsCar(car_log_type);
            vitLogDao.saveAndFlush(vlg);
        } else {
            vitlog.setRecDate(new Date());
            vitlog.setVisitNum(vitlog.getVisitNum() == null ? 0 : vitlog.getVisitNum() + 1);
            vitlog.setIsCar(car_log_type);
            vitLogDao.saveAndFlush(vitlog);
        }
    }

}
