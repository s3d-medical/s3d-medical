package com.nhs.shop.service.car.dto;

import java.io.Serializable;
import java.util.List;

import com.google.common.collect.Lists;
import com.nhs.shop.service.goods.dto.SkuDto;
import com.nhs.shop.service.goods.dto.SkuNameDto;

/**
 * 商品详情DTO
 * @Title: GoodsDetailDto.java
 * @Package com.nhs.shop.service.goods.dto
 * @Description: TODO
 * @author Administrator
 * @date 2016年7月17日 下午4:44:17
 * @version V1.0
 */
public class CarDetailDto implements Serializable {

    private static final long serialVersionUID = -6961788699638117407L;
    private GoodsDto car;
    private CommentDto comment;
    private ShopDto shop;

    public GoodsDto getCar() {
        return car;
    }

    public void setCar(GoodsDto car) {
        this.car = car;
    }

    public CommentDto getComment() {
        return comment;
    }

    public void setComment(CommentDto comment) {
        this.comment = comment;
    }

    public ShopDto getShop() {
        return shop;
    }

    public void setShop(ShopDto shop) {
        this.shop = shop;
    }

    // 商品信息
    public static class GoodsDto implements Serializable {
        private static final long serialVersionUID = -2191933300540998366L;
        private Integer prodId;
        private Integer shopId;
        private String address;
        private String title;
        private List<String> images = Lists.newArrayList();
        private String price;
        private String deposit;
        private Integer saleNum;
        private String brief;
        private String content;
        private String subsidy = "";
        private List<SpecificationDto> specifications = Lists.newArrayList();
        private List<SkuNameDto> skuNames = Lists.newArrayList();
        private List<SkuDto> skus = Lists.newArrayList();
        private String isCollected;
        private String balancePayment;
        private String subsidyStr = "";
        private String unit = "万起";
        private Integer stocks = 0;

        public Integer getStocks() {
            return stocks;
        }

        public void setStocks(Integer stocks) {
            this.stocks = stocks;
        }

        public String getUnit() {
            return unit;
        }

        public void setUnit(String unit) {
            this.unit = unit;
        }

        public String getBalancePayment() {
            return balancePayment;
        }

        public void setBalancePayment(String balancePayment) {
            this.balancePayment = balancePayment;
        }

        public Integer getProdId() {
            return prodId;
        }

        public void setProdId(Integer prodId) {
            this.prodId = prodId;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public List<String> getImages() {
            return images;
        }

        public void setImages(List<String> images) {
            this.images = images;
        }

        public String getPrice() {
            return price;
        }

        public void setPrice(String price) {
            this.price = price;
        }

        public String getDeposit() {
            return deposit;
        }

        public void setDeposit(String deposit) {
            this.deposit = deposit;
        }

        public Integer getSaleNum() {
            return saleNum;
        }

        public void setSaleNum(Integer saleNum) {
            this.saleNum = saleNum;
        }

        public String getBrief() {
            return brief;
        }

        public void setBrief(String brief) {
            this.brief = brief;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }

        public Integer getShopId() {
            return shopId;
        }

        public void setShopId(Integer shopId) {
            this.shopId = shopId;
        }

        public List<SpecificationDto> getSpecifications() {
            return specifications;
        }

        public void setSpecifications(List<SpecificationDto> specifications) {
            this.specifications = specifications;
        }

        public List<SkuNameDto> getSkuNames() {
            return skuNames;
        }

        public void setSkuNames(List<SkuNameDto> skuNames) {
            this.skuNames = skuNames;
        }

        public List<SkuDto> getSkus() {
            return skus;
        }

        public void setSkus(List<SkuDto> skus) {
            this.skus = skus;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String getSubsidy() {
            return subsidy;
        }

        public void setSubsidy(String subsidy) {
            this.subsidy = subsidy;
        }

        public String getIsCollected() {
            return isCollected;
        }

        public void setIsCollected(String isCollected) {
            this.isCollected = isCollected;
        }

        public String getSubsidyStr() {
            return subsidyStr;
        }

        public void setSubsidyStr(String subsidyStr) {
            this.subsidyStr = subsidyStr;
        }

    }

    // 评价信息
    public static class CommentDto implements Serializable {
        private static final long serialVersionUID = 8219127108729542206L;
        private int num = 0; // 评价数量
        private List<CommentDetailDto> list = Lists.newArrayList();

        public int getNum() {
            return num;
        }

        public void setNum(int num) {
            this.num = num;
        }

        public List<CommentDetailDto> getList() {
            return list;
        }

        public void setList(List<CommentDetailDto> list) {
            this.list = list;
        }

    }

    // 评论详情
    public static class CommentDetailDto implements Serializable {
        private static final long serialVersionUID = -6696559499370464701L;
        private String userId;
        private String username;
        private String content;
        private int score;
        private List<String> images = Lists.newArrayList();

        public String getUserId() {
            return userId;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }

        public int getScore() {
            return score;
        }

        public void setScore(int score) {
            this.score = score;
        }

        public List<String> getImages() {
            return images;
        }

        public void setImages(List<String> images) {
            this.images = images;
        }

    }

    // 店铺信息
    public static class ShopDto implements Serializable {
        private int shopId;
        private String title;
        private String image;
        private String address;
        private String mobile;
        private Double lng;
        private Double lat;

        public Double getLng() {
            return lng;
        }

        public void setLng(Double lng) {
            this.lng = lng;
        }

        public Double getLat() {
            return lat;
        }

        public void setLat(Double lat) {
            this.lat = lat;
        }

        public String getMobile() {
            return mobile;
        }

        public void setMobile(String mobile) {
            this.mobile = mobile;
        }

        public int getShopId() {
            return shopId;
        }

        public void setShopId(int shopId) {
            this.shopId = shopId;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getImage() {
            return image;
        }

        public void setImage(String image) {
            this.image = image;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

    }

    // 规格参数
    public static class SpecificationDto implements Serializable {

        private static final long serialVersionUID = 6794802488406773432L;
        private String name;
        private String value;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }

    }

}
