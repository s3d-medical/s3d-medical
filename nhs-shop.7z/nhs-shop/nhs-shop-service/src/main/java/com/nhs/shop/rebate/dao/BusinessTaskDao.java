package com.nhs.shop.rebate.dao;

import java.util.Date;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.nhs.shop.rebate.entity.BusinessTask;

public interface BusinessTaskDao extends JpaRepository<BusinessTask, Long>,
		PagingAndSortingRepository<BusinessTask, Long>, JpaSpecificationExecutor<BusinessTask> {
	
	   @Query("select a from BusinessTask a where a.updateDate < ?1 and a.state='0' and a.type=?2")
	   Page<BusinessTask> findSpreaderRebateQueues(Date startTime, String type, Pageable pageable);
	   
	   BusinessTask findBusinessTaskByTypeAndRelationId(String type, Long relationId);
}
