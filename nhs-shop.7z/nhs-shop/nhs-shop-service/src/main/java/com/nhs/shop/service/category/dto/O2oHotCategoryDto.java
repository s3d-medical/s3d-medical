package com.nhs.shop.service.category.dto;

import java.util.List;

import com.nhs.shop.entry.legend.shop.O2oHotCategoryConfig;

public class O2oHotCategoryDto {
    private Integer groupId;
    private String name;
    private Integer applyCout;
    private Integer releaseCout;
    private Integer status;
    private String releaseTime;
    private String updateTime;
    private Integer count; // 分类数目

    private List<O2oHotCategoryConfig> o2oHotCategoryConfig;

    public Integer getGroupId() {
        return groupId;
    }

    public void setGroupId(Integer groupId) {
        this.groupId = groupId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getApplyCout() {
        return applyCout;
    }

    public void setApplyCout(Integer applyCout) {
        this.applyCout = applyCout;
    }

    public Integer getReleaseCout() {
        return releaseCout;
    }

    public void setReleaseCout(Integer releaseCout) {
        this.releaseCout = releaseCout;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getReleaseTime() {
        return releaseTime;
    }

    public void setReleaseTime(String releaseTime) {
        this.releaseTime = releaseTime;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    public List<O2oHotCategoryConfig> getO2oHotCategoryConfig() {
        return o2oHotCategoryConfig;
    }

    public void setO2oHotCategoryConfig(List<O2oHotCategoryConfig> o2oHotCategoryConfig) {
        this.o2oHotCategoryConfig = o2oHotCategoryConfig;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

}
