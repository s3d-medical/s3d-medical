package com.nhs.shop.service.order;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.nhs.core.common.NhsConstant;
import com.nhs.core.context.SysPropsFactory;
import com.nhs.core.orm.Page;
import com.nhs.core.utils.common.ArithUtils;
import com.nhs.core.utils.common.DateUtils;
import com.nhs.core.utils.common.FormatUtils;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.core.web.WebRequestException;
import com.nhs.shop.dao.legend.car.CarDao;
import com.nhs.shop.dao.legend.car.CarOrderDao;
import com.nhs.shop.dao.legend.car.CarOrderItemDao;
import com.nhs.shop.dao.legend.shop.ProdDao;
import com.nhs.shop.dao.legend.shop.ShopDetailDao;
import com.nhs.shop.entry.em.order.CarOrderOperateEnum;
import com.nhs.shop.entry.em.order.CarOrderStatusEnum;
import com.nhs.shop.entry.em.order.OrderCodeEnum;
import com.nhs.shop.entry.em.order.ShopOrderStatusEnum;
import com.nhs.shop.entry.em.shop.EmRebateStatus;
import com.nhs.shop.entry.legend.car.CarOrder;
import com.nhs.shop.entry.legend.car.CarOrderItem;
import com.nhs.shop.entry.legend.shop.Prod;
import com.nhs.shop.entry.legend.shop.ShopDetail;
import com.nhs.shop.entry.legend.user.UsrDetail;
import com.nhs.shop.generator.OrderNumGenerator;
import com.nhs.shop.service.BaseOrderDto;
import com.nhs.shop.service.BaseOrderService;
import com.nhs.shop.service.order.dto.CarOrderDetailDto;
import com.nhs.shop.service.order.dto.CarOrderListDto;
import com.nhs.shop.service.rebate.CarRebateService;
import com.nhs.shop.service.sku.SkuService;
import com.nhs.shop.service.system.SystemParameterService;
import com.nhs.shop.util.BasicConstant;
import com.nhs.user.service.UserService;

/**
 * 汽车订单service
 * @Title: O2oServiceOrderService.java
 * @Package com.nhs.shop.service.order
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月25日 下午2:44:10
 * @version V1.0
 */
@Service
public class CarOrderService extends BaseOrderService {

    private static final Logger LOG = LoggerFactory.getLogger(CarOrderService.class);

    // 车价>40万，定金为5000， 车价<40万，定金为3000
    private static final double DEFAULT_CAR_PRICE_40W = 400000;

    private static final double DEFAULT_CAR_PRICE_30K = 3000;

    private static final double DEFAULT_CAR_PRICE_50K = 5000;

    @Autowired
    private CarDao carDao;

    @Autowired
    private CarOrderDao carOrderDao;

    @Autowired
    private CarOrderItemDao carOrderItemDao;

    @Autowired
    private ShopDetailDao shopDetailDao;

    @Autowired
    private UserService userService;

    @Autowired
    private ProdDao prodDao;

    @Autowired
    private SkuService skuService;

    @Autowired
    private CarRebateService carRebateService;

    @Autowired
    private SystemParameterService sysService;

    /**
     * 创建汽车订单
     * @Title: saveO2oServiceOrder
     * @Description: TODO
     * @param @param userId
     * @param @param shopId
     * @param @param totalAmount   
     * @return void 
     * @author Administrator 2016年7月25日 
     * @throws
     */
    public Map<String, Object> saveCarOrder(Map<String, Object> map, String platformType) {
        String userId = StringHelper.objectToString(map.get("userId"), "");
        Integer shopId = StringHelper.objectToInt(map.get("shopId"), 0);
        Integer prodId = StringHelper.objectToInt(map.get("prodId"), 0);
        Integer skuId = StringHelper.objectToInt(map.get("skuId"), 0);
        String contact = StringHelper.objectToString(map.get("contact"), "");
        String mobile = StringHelper.objectToString(map.get("mobile"), "");
        String carWay = StringHelper.objectToString(map.get("carWay"), "");
        String carCity = StringHelper.objectToString(map.get("carCity"), "");

        UsrDetail user = userService.findUserById(userId);
        if (user == null) {
            throw new WebRequestException("userId不存在");
        }

        ShopDetail shop = shopDetailDao.findOne(shopId);
        if (shop == null) {
            throw new WebRequestException("商家不存在");
        }

        Prod prod = prodDao.findOne(prodId);
        if (prod == null || prod.getStatus() != 1) {
            throw new WebRequestException("商品已下架");
        }

        // 订单号
        String orderNum = OrderNumGenerator.getOrderNumber(user.getUserMobile(), OrderCodeEnum.CAR_ORDER);
        if (LOG.isDebugEnabled()) {
            LOG.debug("orderNum : " + orderNum);
        }
        // 保存汽车订单表
        CarOrder order = new CarOrder();
        order.setOrderNum(orderNum);
        order.setPlatformType(platformType);
        order.setShopId(shopId);
        order.setShopName(shop.getSiteName());

        // 车价>40万，定金为5000， 车价<40万，定金为3000
        double deposit = DEFAULT_CAR_PRICE_30K;
        double cash = prod.getCash().doubleValue();
        if (cash > DEFAULT_CAR_PRICE_40W) {
            deposit = DEFAULT_CAR_PRICE_50K;
        }
        order.setTotalAmount(BigDecimal.valueOf(deposit));

        order.setUserId(userId);
        order.setContact(contact);
        order.setMobile(mobile);
        order.setCarWay(carWay);
        order.setCarCity(carCity);
        order.setProdName(prod.getName());
        order.setStatus(CarOrderStatusEnum.UNPAY.getStatus());
        order.setDeleteStatus(0);
        order.setCreateTime(new Date());
        CarOrder neworder = carOrderDao.save(order);

        // 保存汽车订单Item表
        CarOrderItem item = new CarOrderItem();
        item.setOrderNum(orderNum);
        item.setProdId(prodId);
        item.setSkuId(skuId);
        item.setSnapshotId(null);
        item.setProdName(prod.getName());
        item.setAttribute(skuService.getSkuDesc(skuId));
        item.setPic(prod.getPic());
        item.setPrice(prod.getPrice());
        item.setCash(prod.getCash());
        item.setDeposit(BigDecimal.valueOf(deposit));
        item.setCreateTime(new Date());
        item.setCommSts(0);
        item.setRebate(prod.getRebate());
        item.setAdFeeRate(prod.getAdFeeRate());
        item.setAdFeeBasicRate(prod.getAdFeeBasicRate());

        carOrderItemDao.save(item);

        // 返回结果
        Map<String, Object> data = Maps.newHashMap();
        data.put("orderId", neworder.getId());
        data.put("orderNum", orderNum);
        data.put("totalAmount", order.getTotalAmount());
        return data;
    }

    /**
     * 获取汽车订单列表
     * @Title: getOrderList
     * @Description: TODO
     * @param @param userId
     * @param @param status
     * @param @param page
     * @param @return   
     * @return List<ServiceOrderListDto> 
     * @author Administrator 2016年7月25日 
     * @throws
     */
    public List<CarOrderListDto> getOrderList(String userId, Integer status, Page<Map<String, Object>> page) {
        List<CarOrderListDto> list = Lists.newArrayList();
        if (StringUtils.isBlank(userId)) {
            return list;
        }
        Page<Map<String, Object>> pageData = carDao.getOrderList(userId, status, page);
        List<Map<String, Object>> result = pageData.getResult();
        for (Map<String, Object> map : result) {
            CarOrderListDto dto = new CarOrderListDto();
            dto.setOrderId(StringHelper.objectToInt(map.get("id"), 0));
            dto.setOrderNum(StringHelper.objectToString(map.get("order_num"), ""));
            dto.setShopId(StringHelper.objectToInt(map.get("shop_id"), 0));
            ShopDetail shop = shopDetailDao.findOne(dto.getShopId());
            if (shop != null) {
                dto.setPic(buildImg(shop.getShopPic2()));
                dto.setShopName(shop.getSiteName());
            }
            dto.setTotalAmount(StringHelper.objectToBigDecimal(map.get("total_amount"), "")
                    .setScale(2, BigDecimal.ROUND_HALF_UP).toString());
            dto.setStatus(StringHelper.objectToInt(map.get("status"), 0));
            dto.setStatusName(CarOrderStatusEnum.desc(dto.getStatus()));
            dto.setCreateTime(DateUtils.date2Str((Date) map.get("create_time")));

            CarOrderItem item = carOrderItemDao.findCarOrderItem(dto.getOrderNum());
            if (item != null) {
                dto.setProdName(item.getProdName());
                dto.setPic(this.buildImg(item.getPic()));
                dto.setSkuDesc(item.getAttribute());
            }

            Prod prod = prodDao.findOne(item.getProdId());
            if (prod != null && prod.getRebate() != null) {
                // 计算补贴
                // double rebate = prod.getRebate().doubleValue();
                BigDecimal rebate = item.getRebate();
                if (rebate == null) {
                    rebate = prod.getRebate();
                }
                dto.setSubsidy(FormatUtils
                        .formatMoney(ArithUtils.mul(prod.getCash().doubleValue() / 10000, rebate.doubleValue())) + "万");
                dto.setSubsidyStr(sysService.getSingleValueByType(NhsConstant.PARAM_PRESENT_SIGN)
                        + sysService.getSingleValueByType(NhsConstant.PARAM_RMB_ICON) + dto.getSubsidy());
            }

            list.add(dto);
        }
        return list;
    }

    /**
     * 获取订单列表
     * @Title: getOrderList
     * @Description: TODO
     * @param @param userId
     * @param @param status
     * @param @param page
     * @param @return   
     * @return List<OrderListDto> 
     * @author Administrator 2016年7月20日 
     * @throws
     */
    public CarOrderDetailDto getOrderDetail(String userId, Integer orderId) {
        CarOrder sub = carOrderDao.findOne(orderId);
        if (sub == null) {
            throw new WebRequestException("订单不存在");
        }
        CarOrderDetailDto dto = new CarOrderDetailDto();
        dto.setOrderId(sub.getId());
        dto.setOrderNum(sub.getOrderNum());
        dto.setShopId(sub.getShopId());
        dto.setStatus(sub.getStatus());
        dto.setStatusName(ShopOrderStatusEnum.desc(dto.getStatus()));
        dto.setCreateTime(DateUtils.date2Str(sub.getCreateTime()));
        if (sub.getPayTime() != null) {
            dto.setPayTime(DateUtils.date2Str(sub.getPayTime()));
        }
        dto.setContact(sub.getContact());
        dto.setMobile(sub.getMobile());
        dto.setCarCity(sub.getCarCity());
        dto.setCarWay(sub.getCarWay());
        dto.setCancelDate(DateUtils.date2Str(sub.getCancelDate()));

        ShopDetail shop = shopDetailDao.findOne(sub.getShopId());
        if (shop != null) {
            dto.setShopName(shop.getSiteName());
        }

        CarOrderItem item = carOrderItemDao.findCarOrderItem(dto.getOrderNum());
        if (item != null) {
            dto.setProdName(item.getProdName());
            dto.setProdId(item.getProdId());
            dto.setPic(this.buildImg(item.getPic()));
            dto.setSkuDesc(item.getAttribute());

            if (item.getCash() != null && item.getCash().intValue() > 400000) {
                dto.setDeposit(FormatUtils.formatMoney(5000.00));
            } else {
                dto.setDeposit(FormatUtils.formatMoney(3000.00));
            }
            // TODO 添加一个值TotalAmount
            dto.setTotalAmount(item.getDeposit().doubleValue());
            dto.setPrice(StringHelper.objectToBigDecimal(item.getCash(), "").divide(new BigDecimal(10000)).toString()
                    + "万起");
            dto.setDetailUrl(SysPropsFactory.getProperty("carDetailUrl") + item.getProdId());

            Prod prod = prodDao.findOne(item.getProdId());
            if (prod != null && prod.getRebate() != null) {
                // 计算补贴
                BigDecimal rebate = item.getRebate();
                if (rebate == null) {
                    rebate = prod.getRebate();
                }
                dto.setSubsidy(FormatUtils
                        .formatMoney(ArithUtils.mul(prod.getCash().doubleValue() / 10000, rebate.doubleValue())) + "万");
                dto.setSubsidyStr(sysService.getSingleValueByType(NhsConstant.PARAM_PRESENT_SIGN)
                        + sysService.getSingleValueByType(NhsConstant.PARAM_RMB_ICON) + dto.getSubsidy());
            }
        }
        return dto;
    }

    /**
     * 订单操作
     * @Title: doOrderOperate
     * @Description: TODO
     * @param @param operate   
     * @return void 
     * @author Administrator 2016年7月22日 
     * @throws
     */
    public void dealOrderOperate(String userId, Integer orderId, String operate) {
        CarOrder sub = carOrderDao.findOne(orderId);
        if (sub == null) {
            throw new WebRequestException("订单不存在");
        }
        if (!sub.getUserId().equals(userId)) {
            throw new WebRequestException("没有权限操作订单");
        }

        CarOrderOperateEnum e = CarOrderOperateEnum.getInstance(operate);
        if (e == null) {
            throw new WebRequestException("opearte错误");
        }
        switch (e) {
            case CONTACT:
                contact(sub); // 联系
                break;
            case CONFIRM: // 确认已付尾款
                confirm(sub);
                break;
            case CANCEL: // 取消订单
                cancel(sub);
                break;
            case DELETE: // 删除订单
                delete(sub);
                break;
            default:
                throw new WebRequestException("opearte错误");
        }
    }

    /**
     * 取消订单
     * @Title: cancel
     * @Description: TODO
     * @param @param sub   
     * @return void 
     * @author Administrator 2016年7月22日 
     * @throws
     */
    private void cancel(CarOrder sub) {
        // 只有未付款订单才能取消
        if (sub.getStatus() != CarOrderStatusEnum.UNPAY.getStatus()) {
            throw new WebRequestException("订单无法取消");
        }
        sub.setCancelDate(new Date());
        saveOrderStatus(sub, CarOrderStatusEnum.CANCELD.getStatus());
    }

    /**
     * 联系
     * @Title: cancel
     * @Description: TODO
     * @param @param sub   
     * @return void 
     * @author Administrator 2016年7月22日 
     * @throws
     */
    private void contact(CarOrder sub) {
        if (sub.getStatus() != CarOrderStatusEnum.PADYED.getStatus()) {
            throw new WebRequestException("订单无法联系");
        }
        saveOrderStatus(sub, CarOrderStatusEnum.WAIT_PAY_REMAIN_MONEY.getStatus());
    }

    /**
     * 联系
     * @Title: cancel
     * @Description: TODO
     * @param @param sub   
     * @return void 
     * @author Administrator 2016年7月22日 
     * @throws
     */
    private void confirm(CarOrder sub) {
        if (sub.getStatus() != CarOrderStatusEnum.WAIT_PAY_REMAIN_MONEY.getStatus()) {
            throw new WebRequestException("订单无法确认");
        }
        saveOrderStatus(sub, CarOrderStatusEnum.WAIT_FETCH_CAR.getStatus());

        // TODO hxj 汽车付完尾款后，开始清算
        try {
            if (sub.getRebateStatus() == null || sub.getRebateStatus() == EmRebateStatus.not_rebate.status) {
                carRebateService.saveRebate(sub, new Date());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 删除订单
     * @Title: delete
     * @Description: TODO
     * @param @param sub   
     * @return void 
     * @author Administrator 2016年7月22日 
     * @throws
     */
    private void delete(CarOrder sub) {
        sub.setDeleteStatus(1);
        carOrderDao.saveAndFlush(sub);
    }

    /**
     * 更新订单状态
     * @Title: updateOrderStatus
     * @Description: TODO
     * @param @param sub
     * @param @param status   
     * @return void 
     * @author Administrator 2016年7月22日 
     * @throws
     */
    private void saveOrderStatus(CarOrder sub, int status) {
        sub.setStatus(status);
        carOrderDao.saveAndFlush(sub);
    }

    /**
     * 获取订单支付金额
     * <p>Description:TODO </p>
     * @author Administrator 2016年7月28日 
     * @param orderNum
     * @return
     * @see com.nhs.shop.service.base.BaseOrderService#getOrderPayAmount(java.lang.String)
     */
    public double getOrderPayAmount(String orderNum) {
        CarOrder order = carOrderDao.findCarOrderByOrderNum(orderNum);
        if (order == null) {
            throw new WebRequestException("订单不存在");
        }
        return order.getTotalAmount().doubleValue();
    }

    /**
     * 处理支付成功
     * <p>Description:TODO </p>
     * @author Administrator 2016年7月28日 
     * @param orderNum
     * @param payAmount
     * @param payTypeName
     * @see com.nhs.shop.service.base.BaseOrderService#handleOrderPay(java.lang.String, java.lang.String, java.lang.String)
     */
    @Override
    public void handleOrderPay(String orderNum, String payAmount, String payTypeName, int payType, String payNo) {
        CarOrder order = carOrderDao.findCarOrderByOrderNum(orderNum);
        if (order == null) {
            throw new WebRequestException("订单不存在");
        }
        // add by sungs 汽车订单特殊处理 ，支付完成后更改订单状态为 支付成功
        // if (orderNum.endsWith(OrderCodeEnum.CAR_ORDER.getCode().toString())) {
        // order.setStatus(CarOrderStatusEnum.PAY_COMPLETE.getStatus());
        // } else {
        order.setStatus(CarOrderStatusEnum.PADYED.getStatus());
        // }
        order.setPayAmount(StringHelper.objectToBigDecimal(payAmount, "0"));
        order.setPayTime(new Date());
        order.setUpdateTime(new Date());
        order.setPayTypeName(payTypeName);
        order.setRebateStatus(0);
        carOrderDao.saveAndFlush(order);

        // 定金订单支付成功之后月销量+1
        CarOrderItem item = carOrderItemDao.findCarOrderItem(orderNum);
        Prod prod = prodDao.findOne(item.getProdId());
        prod.setBuys((prod.getBuys() == null ? 0 : prod.getBuys()) + 1);
        prodDao.saveAndFlush(prod);

    }

    @Override
    public void verifyOrder(String userId, String orderNum) {
        CarOrder order = carOrderDao.findCarOrderByOrderNum(orderNum);
        if (order == null) {
            throw new WebRequestException("订单不存在");
        }
        if (!order.getUserId().equals(userId)) {
            throw new WebRequestException("无权限支付该订单");
        }
        if (order.getStatus() != CarOrderStatusEnum.UNPAY.getStatus()) {
            throw new WebRequestException("订单不是待付款状态");
        }
    }

    /**
     * 
     * @Title: confirm
     * @Description: TODO
     * @param @param userId
     * @param @param orderNum
     * @param @return   
     * @return Map<String,Object> 
     * @author Administrator 2016年8月23日 
     * @throws
     */
    public Map<String, Object> confirm(String userId, String orderNum) {
        CarOrder order = carOrderDao.findCarOrderByOrderNum(orderNum);
        Map<String, Object> map = new HashMap<String, Object>();
        if (order == null) {
            throw new WebRequestException("订单不存在");
        }
        if (!order.getUserId().equals(userId)) {
            throw new WebRequestException("无权限支付该订单");
        }
        if (order.getStatus() != CarOrderStatusEnum.UNPAY.getStatus()) {
            throw new WebRequestException("订单不是待付款状态");
        }
        int confirm = order.getConfirm();
        if (confirm == BasicConstant.NEGATIVE_1 || confirm == BasicConstant.FLAG_INVALID) {
            order.setConfirm(1);
            carOrderDao.saveAndFlush(order);
        }
        return map;
    }

    @Override
    public BaseOrderDto getBaseOrderDto(String orderNum) {
        CarOrder order = carOrderDao.findCarOrderByOrderNum(orderNum);
        if (order == null) {
            throw new WebRequestException("订单不存在");
        }
        BaseOrderDto baseOrderDto = new BaseOrderDto();
        baseOrderDto.setOrderNum(orderNum);
        baseOrderDto.setUserId(order.getUserId());
        return baseOrderDto;
    }
}
