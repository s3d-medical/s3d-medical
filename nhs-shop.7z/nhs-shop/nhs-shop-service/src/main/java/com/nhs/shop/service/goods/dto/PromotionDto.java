package com.nhs.shop.service.goods.dto;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 商品促销
 * @author wind.chen
 *
 */
public class PromotionDto implements Serializable {

	private static final long serialVersionUID = -3399529091598801251L;

	/**
	 * 补贴多少钻.
	 */
	private BigDecimal subsidy = new BigDecimal("0.00");
	
	/**
	 * 补贴多少钱
	 */
	private BigDecimal subsidyMoney = new BigDecimal("0.00");
	
	/**
	 * 立减
	 */
	private BigDecimal reducedCash = new BigDecimal("0.00");
	
	
	public BigDecimal getSubsidy() {
		return subsidy;
	}

	public void setSubsidy(BigDecimal subsidy) {
		this.subsidy = subsidy;
	}

	public BigDecimal getReducedCash() {
		return reducedCash;
	}

	public void setReducedCash(BigDecimal reducedCash) {
		this.reducedCash = reducedCash;
	}

	public BigDecimal getSubsidyMoney() {
		return subsidyMoney;
	}

	public void setSubsidyMoney(BigDecimal subsidyMoney) {
		this.subsidyMoney = subsidyMoney;
	}

}
