package com.nhs.shop.service.order.shop.internal;

import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nhs.core.common.NhsConstant;
import com.nhs.core.web.WebRequestException;
import com.nhs.shop.dao.legend.shop.SubDao;
import com.nhs.shop.entry.em.order.ShopOrderOperateEnum;
import com.nhs.shop.entry.em.order.ShopOrderStatusEnum;
import com.nhs.shop.entry.em.shop.EmRebateStatus;
import com.nhs.shop.entry.legend.shop.Sub;
import com.nhs.shop.entry.legend.user.UsrDetail;
import com.nhs.shop.service.BaseService;
import com.nhs.shop.service.rebate.ShopRebateService;
import com.nhs.user.service.OperateUserAccountService;

/**
 * 商城订单操作service
 * @Title: GoodsService.java
 * @Package com.nhs.shop.service.goods
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月16日 下午7:42:18
 * @version V1.0
 */
@Service
public class ShopOrderOperateService extends BaseService {
	private static Logger logger = LoggerFactory.getLogger(ShopOrderOperateService.class);
    @Autowired
    private SubDao subDao;

    @Autowired
    private ShopRebateService shopRebateService;
    
    @Autowired
    private OperateUserAccountService userAccountService;
    

    /**
     * 订单操作
     * @Title: doOrderOperate
     * @Description: TODO
     * @param @param operate   
     * @return void 
     * @author Administrator 2016年7月22日 
     * @throws
     */
    public void dealOrderOperate(String userId, Integer subId, String operate, String refundReason) {
        Sub sub = subDao.findOne(subId);
        if (sub == null) {
            throw new WebRequestException("订单不存在");
        }
        if (!sub.getUserId().equals(userId)) {
            throw new WebRequestException("没有权限操作订单");
        }

        ShopOrderOperateEnum e = ShopOrderOperateEnum.getInstance(operate);
        if (e == null) {
            throw new WebRequestException("opearte错误");
        }
        switch (e) {
            case CANCEL: // 取消订单
                cancel(sub);
                break;
            case DELETE: // 删除订单
                delete(sub);
                break;
            case REFUND: // 退款
                refund(sub, refundReason);
                break;
            case CONFIRM: // 确认订单
                confirm(sub);
                break;
        }
    }

    /**
     * 取消订单
     * @Title: cancel
     * @Description: TODO
     * @param @param sub   
     * @return void 
     * @author Administrator 2016年7月22日 
     * @throws
     */
    private void cancel(Sub sub) {
        // 只有未付款订单才能取消
        if (sub.getStatus() != ShopOrderStatusEnum.UNPAY.getStatus()) {
            throw new WebRequestException("订单无法取消");
        }
        sub.setCancelDate(new Date());
        if(sub.getCouponAmount().compareTo(new BigDecimal(0)) > 0){
        	BigDecimal coupon = sub.getCouponAmount().multiply(new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE));
        	//userAccountService.unFreezeGold(sub.getUserId(), coupon);
        	userAccountService.unfreezeGold(sub.getUserId(), sub.getSubNumber(), coupon);;
        }
        saveOrderStatus(sub, ShopOrderStatusEnum.CLOSE.getStatus());
    }

    /**
     * 删除订单
     * @Title: delete
     * @Description: TODO
     * @param @param sub   
     * @return void 
     * @author Administrator 2016年7月22日 
     * @throws
     */
    private void delete(Sub sub) {

        //冻结的抵用券直接扣除
    	if(sub.getStatus() == ShopOrderStatusEnum.UNPAY.getStatus()){
	        BigDecimal frozenGold = sub.getCouponAmount().multiply(new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE));
	        boolean success = this.userAccountService.unfreezeGold(sub.getUserId(), sub.getSubNumber(), frozenGold);
	        if(!success){
	        	throw new WebRequestException("删除订单时, 解冻用户佰德券失败.");
	        }
    	}
        sub.setDeleteStatus(1);
        subDao.saveAndFlush(sub);
    }

    /**
     * 申请退款
     * @Title: refund
     * @Description: TODO
     * @param @param sub   
     * @return void 
     * @author Administrator 2016年7月22日 
     * @throws
     */
    private void refund(Sub sub, String refundReason) {
        if (sub.getStatus() != ShopOrderStatusEnum.PADYED.getStatus()
                && sub.getStatus() != ShopOrderStatusEnum.CONSIGNMENT.getStatus()) {
            throw new WebRequestException("订单无法退款");
        }
        if (StringUtils.isBlank(refundReason)) {
            throw new WebRequestException("退款理由不能为空");
        }
        sub.setRefundReason(refundReason);
        saveOrderStatus(sub, ShopOrderStatusEnum.REFUND.getStatus());
    }

    /**
     * 确认收货
     * @Title: confirm
     * @Description: TODO
     * @param @param sub   
     * @return void 
     * @author Administrator 2016年7月22日 
     * @throws
     */
    private void confirm(Sub sub) {
        if (sub.getStatus() != ShopOrderStatusEnum.CONSIGNMENT.getStatus()) {
            throw new WebRequestException("订单无法确认收货");
        }
        Date date = new Date();
        sub.setSuccessDate(date);
        sub.setFinallyDate(date);
        sub.setUpdateDate(date);
        saveOrderStatus(sub, ShopOrderStatusEnum.SUCCESS.getStatus());

        //冻结的抵用券直接扣除
        BigDecimal frozenGold = sub.getCouponAmount().multiply(new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE));
        this.userAccountService.reductFrozenGold(sub.getUserId(), sub.getSubNumber(), frozenGold);
        
        // TODO hxj 服务订单付款后就直接结算广告费
        try {
            if (sub.getRebateStatus() == null || sub.getRebateStatus() == EmRebateStatus.not_rebate.status) {
                shopRebateService.saveRebate(sub, new Date());
            }
        } catch (Exception e) {
        	logger.error("确认收货处理失败.", e);
        }
    }

    /**
     * 更新订单状态
     * @Title: updateOrderStatus
     * @Description: TODO
     * @param @param sub
     * @param @param status   
     * @return void 
     * @author Administrator 2016年7月22日 
     * @throws
     */
    private void saveOrderStatus(Sub sub, int status) {
        sub.setStatus(status); // 取消订单
        Date date = new Date();
        if (status == ShopOrderStatusEnum.UNPAY.getStatus()) {
            sub.setSubDate(date);
            sub.setUpdateDate(date);
        } else if (status == ShopOrderStatusEnum.PADYED.getStatus()) {
            sub.setPayDate(date);
            sub.setUpdateDate(date);
        } else if (status == ShopOrderStatusEnum.CONSIGNMENT.getStatus()) {
            sub.setDvyDate(date);
            sub.setUpdateDate(date);
        } else if (status == ShopOrderStatusEnum.SUCCESS.getStatus()) {
            sub.setSuccessDate(date);
            sub.setFinallyDate(date);
            sub.setUpdateDate(date);
        } else if (status == ShopOrderStatusEnum.COMMENTED.getStatus()) {
            sub.setUpdateDate(date);
        }

        sub.setUpdateDate(new Date());
        subDao.saveAndFlush(sub);
    }

}
