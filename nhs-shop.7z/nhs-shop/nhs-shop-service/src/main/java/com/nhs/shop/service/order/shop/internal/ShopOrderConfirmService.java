package com.nhs.shop.service.order.shop.internal;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.nhs.apiproxy.member.user.dto.UsrAddrDto;
import com.nhs.apiproxy.member.user.service.UserServiceApi;
import com.nhs.core.utils.common.ArithUtils;
import com.nhs.core.web.WebRequestException;
import com.nhs.shop.dao.legend.region.AreasDao;
import com.nhs.shop.dao.legend.region.CityDao;
import com.nhs.shop.dao.legend.region.ProvincesDao;
import com.nhs.shop.dao.legend.shop.BasketDao;
import com.nhs.shop.dao.legend.shop.ProdDao;
import com.nhs.shop.dao.legend.shop.ShopDetailDao;
import com.nhs.shop.dao.legend.shop.SkuDao;
import com.nhs.shop.entry.legend.region.Areas;
import com.nhs.shop.entry.legend.region.City;
import com.nhs.shop.entry.legend.region.Provinces;
import com.nhs.shop.entry.legend.shop.Basket;
import com.nhs.shop.entry.legend.shop.Prod;
import com.nhs.shop.entry.legend.shop.ShopDetail;
import com.nhs.shop.entry.legend.shop.Sku;
import com.nhs.shop.service.BaseService;
import com.nhs.shop.service.common.dto.CarriageType;
import com.nhs.shop.service.goods.GoodCarriageService;
import com.nhs.shop.service.goods.GoodsPromoService;
import com.nhs.shop.service.goods.GoodsService;
import com.nhs.shop.service.goods.dto.CarriageDto;
import com.nhs.shop.service.goods.dto.CarriageItemDto;
import com.nhs.shop.service.goods.dto.GoodsTagDto;
import com.nhs.shop.service.goods.dto.PromotionDto;
import com.nhs.shop.service.goods.dto.SkuProdDto;
import com.nhs.shop.service.order.assist.OrderCustDataConvertor;
import com.nhs.shop.service.order.dto.OrderConfirmDto;
import com.nhs.shop.service.order.dto.OrderConfirmRequestDto;
import com.nhs.shop.service.order.dto.OrderShopDto;
import com.nhs.shop.service.order.dto.ShopProdDto;
import com.nhs.shop.service.order.dto.UserAddressDto;
import com.nhs.user.service.UserService;

/**
 * 商城订单确认service
 * @Title: GoodsService.java
 * @Package com.nhs.shop.service.goods
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月16日 下午7:42:18
 * @version V1.0
 */
@Service
public class ShopOrderConfirmService extends BaseService {

    @Autowired
    private ProvincesDao provincesDao;

    @Autowired
    private CityDao cityDao;

    @Autowired
    private AreasDao areasDao;

    @Autowired
    private BasketDao basketDao;

    @Autowired
    private ProdDao prodDao;

    @Autowired
    private SkuDao skuDao;

    @Autowired
    private ShopDetailDao shopDetailDao;

    @Autowired
    private GoodsService goodsService;

    @Autowired
    private GoodsPromoService goodPromoService;
    
    @Autowired
    private GoodCarriageService goodCarriageService;
    
    @Autowired
    private OrderCustDataConvertor orderCustDataConvertor;
    
    @Autowired
    private UserService userService;
     
    @Autowired
    private UserServiceApi userServiceApi;
    
    /**
     * 获取订单确认信息
     * @Title: getOrderConfirm
     * @Description: TODO
     * @param @param dto
     * @param @return   
     * @return OrderConfirmDto 
     * @author Administrator 2016年7月19日 
     * @throws
     */
    public OrderConfirmDto getOrderConfirm(OrderConfirmRequestDto dto) {
        if ((dto.getProdId() == null) && dto.getBasketIdList().size() == 0) {
            throw new WebRequestException("参数prodId和参数basketId都为空");
        }
        if ((dto.getProdId() != null) && dto.getBasketIdList().size() > 0) {
            throw new WebRequestException("参数prodId和参数basketId都不为空");
        }

        OrderConfirmDto orderConfirmDto = null;
        if (dto.getProdId() != null) {
            // 从商品详情点立即购买
            orderConfirmDto = this.buildConfirmedOrderFromDetail(dto);
        } else if (dto.getBasketIdList().size() > 0) {
            // 从购物车点结算
            orderConfirmDto = this.buildConfirmedOrderFromBasket(dto);
        }
        // 用户默认地址   
        orderConfirmDto.setAddress(getDefaultUserAddress(dto.getUserId()));
        return orderConfirmDto;
    }

    @SuppressWarnings({ "deprecation", "unchecked", "rawtypes" })
    private OrderConfirmDto buildConfirmedOrderFromDetail(OrderConfirmRequestDto dto) {
        if (dto.getProdId() <= 0) {
            throw new WebRequestException("参数prodId错误");
        }
        if (dto.getCount() == null || dto.getCount() <= 0) {
            throw new WebRequestException("参数count错误");
        }
        Prod prod = prodDao.findOne(dto.getProdId());
        if (prod == null || prod.getStatus() != 1) {
            throw new WebRequestException("商品已下架");
        }
        ShopDetail shop = shopDetailDao.findOne(prod.getShopId());
        if (shop == null) {
            throw new WebRequestException("店铺已下架");
        }
        Sku sku = null;
        if (dto.getSkuId() != null && dto.getSkuId() > 0) {
            sku = skuDao.findOne(dto.getSkuId());
            if (sku == null) {
                throw new WebRequestException("商品sku不存在");
            }
        }
        
        OrderConfirmDto orderConfirmDto = new OrderConfirmDto();
        // 创建订单商家DTO, 以及包含的商家商品DTO
        OrderShopDto orderShopDto = createOrderShopDto(shop);
        ShopProdDto shopProdDto = createShopProdDto(prod, sku, null, dto.getCount());
        orderShopDto.addShopProdDto(shopProdDto);
        orderConfirmDto.addOrderShopDto(orderShopDto);
        
        //总价
        Double totalAmount = ArithUtils.mul(sku != null ? 
        		sku.getPrice().doubleValue() : prod.getCash().doubleValue(), dto.getCount());
        // 计算运费.
        Integer cityId = this.userService.findCityIdOfDefaultShipAddr(dto.getUserId()); 
        CarriageDto carriageDto = this.goodCarriageService.calAllKindsOfPostage(prod, new Double(dto.getCount()), cityId);
        
        //设置默认总价, 各种运费情况下的价格.
        this.fillTotalOrderPrice(carriageDto, orderConfirmDto, totalAmount);    
 
        //计算促销费.   
        BoughtSkuProd boughtSkuProd = new BoughtSkuProd();
        boughtSkuProd.addOne(sku, prod, dto.getCount());
        this.fillPromotion(orderConfirmDto, boughtSkuProd);
        
        //设置废弃字段.
        orderConfirmDto.setCarriageList(new HashMap<String, Object>());
        orderConfirmDto.setCarriage(new HashMap());
        orderConfirmDto.setTotalAountList(new HashMap());
        return orderConfirmDto;
    }
    
    /**
     * 设置订单在各种运费情况下的订单总额，以及运费关系.
     * @param carriageDto
     * @param prodTotalPrice
     * @return
     */
    private List<Map<String, Object>> buildTotalParams(CarriageDto carriageDto, Double prodTotalPrice){
		BigDecimal totalAmount = new BigDecimal(prodTotalPrice.toString());
		List<Map<String, Object>> totalParams = Lists.newArrayList();		
		for (CarriageType carriageType : CarriageType.getAllTypes()) {
			CarriageItemDto item = carriageDto.getPostageItem(carriageType);
			if (item != null && item.getVal().doubleValue() > 0.00) {
				Map<String, Object> param = Maps.newHashMap();
				param.put("postage", item.getVal().toString());
				param.put("type", carriageType.getDesc());
				param.put("totalAount", totalAmount.add(item.getVal()));
				totalParams.add(param);
			}
		}
        return totalParams;
    }
    
    /**
     * 从购物车结算进入订单确认
     * @Title: buildOrderConfirmDtoFromBasket
     * @Description: TODO
     * @param @param dto
     * @param @return   
     * @return OrderConfirmDto 
     * @author Administrator 2016年7月19日 
     * @throws
     */
    @SuppressWarnings({ "deprecation", "rawtypes", "unchecked" })
    private OrderConfirmDto buildConfirmedOrderFromBasket(OrderConfirmRequestDto dto) {
        OrderConfirmDto orderConfirmDto = new OrderConfirmDto();
        double totalAmount = 0;
        Map<Integer, OrderShopDto> map = Maps.newHashMap();
        BoughtSkuProd boughtSkuProd = new BoughtSkuProd();
        //1 构建订单基本信息.
        for (Integer basketId : dto.getBasketIdList()) {
            Basket basket = basketDao.findOne(basketId);
            Prod prod = prodDao.findOne(basket.getProdId());
            if (prod == null || prod.getStatus() != 1) {
                throw new WebRequestException("商品已下架");
            }
            ShopDetail shop = shopDetailDao.findOne(prod.getShopId());
            if (shop == null) {
                throw new WebRequestException("店铺已下架");
            }
            Sku sku = null;
            if (basket.getSkuId() != null && basket.getSkuId() > 0) {
                sku = skuDao.findOne(basket.getSkuId());
                if (sku == null) {
                    throw new WebRequestException("商品sku不存在");
                }
            }
            // 收集购买的产品及其数量
            totalAmount = ArithUtils.add(totalAmount, ArithUtils.mul(sku != null ? sku.getPrice().doubleValue() : prod.getCash().doubleValue(),
                            basket.getBasketCount()));
            OrderShopDto orderShopDto = map.get(shop.getShopId());
            if (orderShopDto == null) {
                orderShopDto = createOrderShopDto(shop);
                map.put(shop.getShopId(), orderShopDto);
                orderConfirmDto.addOrderShopDto(orderShopDto);
            }
            ShopProdDto shopProdDto = this.createShopProdDto(prod, sku, basketId, basket.getBasketCount());
            orderShopDto.addShopProdDto(shopProdDto);
            boughtSkuProd.addOne(sku, prod, basket.getBasketCount());
        }
        
        //2 计算运费:
        Integer cityId = this.userService.findCityIdOfDefaultShipAddr(dto.getUserId());
        CarriageDto carriageDto = this.goodCarriageService.calAllKindsOfPostage(boughtSkuProd.getProdList(), 
        		boughtSkuProd.getCountList(), cityId);
        //3 计算每种运费情况下的总价, 并设置一个默认的总价,
        this.fillTotalOrderPrice(carriageDto, orderConfirmDto, totalAmount);
        //设置一些废弃的值.
        orderConfirmDto.setCarriageList(new HashMap<String, Object>());
        orderConfirmDto.setCarriage(new HashMap());
        orderConfirmDto.setTotalAountList(new HashMap<String, BigDecimal>());
        //设置付费附加项
        this.fillPromotion(orderConfirmDto, boughtSkuProd);
        return orderConfirmDto;
    }
    
    /**
     * 计算每种运费情况下的总价, 并设置一个默认的总价,
     * @param carriageDto
     * @param orderConfirmDto
     * @param prodTotalAmount
     */
	private void fillTotalOrderPrice(CarriageDto carriageDto, OrderConfirmDto orderConfirmDto, Double prodTotalAmount) {
		//计算每种运费情况下的总价, 并设置一个默认的总价,
		if (!carriageDto.isFreePostage()) {  // 有价格
			CarriageItemDto item = carriageDto.getFirstNone0PostageItem(CarriageType.getAllTypes());
			if (item != null) {
				orderConfirmDto.setIsCarrage("1");
				orderConfirmDto.setDeliveryType(item.getType().getDesc() + ":" + item.getVal());
				orderConfirmDto.setTotalProdAmount(new BigDecimal(prodTotalAmount + ""));
				// 计算订单默认价格总和= 商品总价 + 默认运费
				orderConfirmDto.setTotalAmount(item.getVal().add(new BigDecimal(prodTotalAmount + "")));
				List<Map<String, Object>> totalParams = this.buildTotalParams(carriageDto, prodTotalAmount);
				orderConfirmDto.setTotalParams(totalParams);
				return;
			}
		}
		// 按照包邮处理.
		orderConfirmDto.setDeliveryType("包邮快递");
		orderConfirmDto.setIsCarrage("0");
		orderConfirmDto.setTotalProdAmount(new BigDecimal(prodTotalAmount + ""));
		orderConfirmDto.setTotalAmount(new BigDecimal(prodTotalAmount + "")); // 商品总价
		orderConfirmDto.setTotalParams(new ArrayList<Map<String, Object>>());
	}

    /**
     * 计算订单的立减总额, 以及计算账户佰德劵.
     * @param orderConfirmDto
     * @param boughtSkuProd
     */
    private void fillPromotion(OrderConfirmDto orderConfirmDto, BoughtSkuProd boughtSkuProd) {
        //
        PromotionDto promo = this.goodPromoService.calMultiSkuProdPromo(boughtSkuProd.getCountList(),
                boughtSkuProd.getSkuList(), boughtSkuProd.getProdList(), 2);
        if (promo == null) {
            return;
        }
        double totalCount = 0;
        for(Double count : boughtSkuProd.getCountList()){
        	totalCount += count;
        }
        orderConfirmDto.setTotalProdNum(totalCount);
        this.orderCustDataConvertor.formatPromoInfo(orderConfirmDto, promo);
    }

    /**
     * 创建订单商家DTO
     * @Title: createOrderShopDto
     * @Description: TODO
     * @param @param shop
     * @param @return   
     * @return OrderShopDto 
     * @author Administrator 2016年7月19日 
     * @throws
     */
    private OrderShopDto createOrderShopDto(ShopDetail shop) {
        // 订单中的商家
        OrderShopDto orderShopDto = new OrderShopDto();
        orderShopDto.setShopId(shop.getShopId());
        orderShopDto.setShopName(shop.getSiteName());
        return orderShopDto;
    }

    private ShopProdDto createShopProdDto(Prod prod, Sku sku, Integer basketId, Integer count) {
        // 商家的商品列表
        SkuProdDto skuProdDto = this.goodsService.getSkuProd(prod, sku);
        ShopProdDto shopProdDto = new ShopProdDto();
        shopProdDto.setBasketId(basketId);
        shopProdDto.setCount(count);
        shopProdDto.setPic(skuProdDto.getPic());
        shopProdDto.setPrice(skuProdDto.getPrice());
        shopProdDto.setProdId(skuProdDto.getProdId());
        shopProdDto.setProdName(skuProdDto.getProdName());
        shopProdDto.setHasInvoice(skuProdDto.getHasInvoice());
        shopProdDto.setSkuId(skuProdDto.getSkuId());
        shopProdDto.setSkuDesc(skuProdDto.getSkuDesc());
        shopProdDto.setDetailUrl(skuProdDto.getDetailUrl());
        // 处理标签: 减, 送, 包邮
        GoodsTagDto goodsTagDto = skuProdDto.getGoodsTag();
        shopProdDto.setPostFreeFlag(goodsTagDto.getPostageTag());
        shopProdDto.setReducedCashFlag(goodsTagDto.getReducedCashTag());
        shopProdDto.setSubsidyFlag(goodsTagDto.getSubsidyTag());
        return shopProdDto;
    }

    /**
     * 获取用户默认地址
     * @Title: getDefaultUserAddress
     * @Description: TODO
     * @param @param userId
     * @param @return   
     * @return UserAddressDto 
     * @author Administrator 2016年7月19日 
     * @throws
     */
    public UserAddressDto getDefaultUserAddress(String userId) {
    	
 	
    	UsrAddrDto usrAddrDto= this.userServiceApi.findDefaultShipAddrById(userId);
    	if(usrAddrDto == null){
    		return null;
    	}
    	UserAddressDto dto = new UserAddressDto();
        dto.setAdderssId(usrAddrDto.getId());
        dto.setAddress(usrAddrDto.getAddress());
        dto.setAreaId(usrAddrDto.getDistrictId());
        dto.setCityId(usrAddrDto.getCityId());
        dto.setProvinceId(usrAddrDto.getProvinceId());
        dto.setContact(usrAddrDto.getReceiver());
        dto.setMobile(usrAddrDto.getMobileNo());
        Provinces p = provincesDao.findOne(usrAddrDto.getProvinceId());
        City c = null;
        if (usrAddrDto.getCityId() != null) {
            c = cityDao.findOne(usrAddrDto.getCityId());
        }

        Areas a = null;
        if (usrAddrDto.getDistrictId() != null) {
            a = areasDao.findOne(usrAddrDto.getDistrictId());
        }

        StringBuilder sb = new StringBuilder();
        if (p != null) {
            sb.append(p.getProvince());
        }
        if (c != null) {
            sb.append(" " + c.getCity());
        }
        if (a != null) {
            sb.append(" " + a.getArea());
        }
        dto.setDetailAddress(sb.toString() + " " + dto.getAddress());
        return dto;
    }

    class BoughtSkuProd {
        private List<Double> countList = new ArrayList<Double>();
        private List<Sku> skuList = new ArrayList<Sku>();
        private List<Prod> prodList = new ArrayList<Prod>();
        
        public List<Double> getCountList() {
            return countList;
        }

        public List<Sku> getSkuList() {
            return skuList;
        }

        public List<Prod> getProdList() {
            return prodList;
        }

        public void addOne(Sku sku, Prod prod, double count) {
            if (count <= 0.0 || prod == null) {
                return;
            }
            this.countList.add(count);
            this.prodList.add(prod);
            this.skuList.add(sku);
        }
    }
}
