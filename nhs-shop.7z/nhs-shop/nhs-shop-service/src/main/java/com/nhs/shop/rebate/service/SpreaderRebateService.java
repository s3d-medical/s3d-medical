package com.nhs.shop.rebate.service;

import java.math.BigDecimal;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import com.nhs.apiproxy.member.acc.service.AccountTransferService;
import com.nhs.core.mapper.JsonMapper;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.core.web.WebRequestException;
import com.nhs.shop.entry.legend.user.UsrDetail;
import com.nhs.shop.rebate.dao.BusinessTaskDao;
import com.nhs.shop.rebate.entity.BusinessTask;
import com.nhs.user.service.UserService;

@Service
public class SpreaderRebateService {
	
	@Autowired
	private BusinessTaskDao businessTaskDao;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private AccountTransferService accountTransferService;
	
	@SuppressWarnings("all")
	public void dealSpreaderRebate(BusinessTask businessTask) {
		Assert.notNull(businessTask);
		// 1.获取业务数据
		String businessData = businessTask.getBusiness();
		if(StringUtils.isBlank(businessData))
			throw new WebRequestException("业务数据不合法");
		
		// 2.解析业务数据
		Map<String, Object> businessMap = JsonMapper.nonDefaultMapper().fromJson(businessData, Map.class);
		if(MapUtils.isEmpty(businessMap))
			throw new WebRequestException("业务数据不合法");
		
		String shopUserId = ObjectUtils.toString(businessMap.get("toUserId"));
		String mobileNo = ObjectUtils.toString(businessMap.get("mobileNo"));
		Integer spreaderType = Integer.valueOf(ObjectUtils.toString(businessMap.get("spreaderType")));
		BigDecimal amount =  StringHelper.objectToBigDecimal(businessMap.get("amount"),"0.00");
		
		// 3.检查当前用户是否已注册
		UsrDetail usrDetail = this.userService.findUserByMobile(mobileNo);//usrDetailDao.findUserDetail(mobileNo);
		if(usrDetail != null){
			// 4.给商家加钱
			UsrDetail toUser = this.userService.findUserById(shopUserId);//usrDetailDao.findUserById(shopUserId);
			if(toUser == null){
				throw new WebRequestException("推广商家、个人未找到");
			}
			
			if(0 == spreaderType.intValue()) {
				// 4.1 商家
				accountTransferService.depositUserBizAccount(shopUserId, shopUserId+"-spreader-"+businessTask.getId(), amount);
//				toUser.setShopAvailablePred(toUser.getShopAvailablePred().add(amount));
			} else if(1 == spreaderType.intValue()){
				accountTransferService.depositUserAccount(shopUserId, shopUserId+"-spreader-"+businessTask.getId(), amount);
//				toUser.setAvailablePredeposit(toUser.getAvailablePredeposit().add(amount));
			}
			// 5.保存
			businessTask.setState(BusinessTask.BUSINESS_TASK_STATE_COMPLETED);
			businessTaskDao.saveAndFlush(businessTask);
		}
		
	}

}
