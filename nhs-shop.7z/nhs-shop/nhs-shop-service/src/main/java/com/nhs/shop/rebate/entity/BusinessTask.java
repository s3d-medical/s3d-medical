package com.nhs.shop.rebate.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="nhs_business_task")
public class BusinessTask implements Serializable {

	private static final long serialVersionUID = -4058312791207551167L;
	
	/**
	 * 任务状态 - 未执行 - 0
	 */
	public static final String BUSINESS_TASK_STATE_INIT = "0";
	
	/**
	 * 任务状态 - 执行完成 - 1
	 */
	public static final String BUSINESS_TASK_STATE_COMPLETED = "1";
	
	/**
	 * 任务状态 - 执行失败 - 2
	 */
	public static final String BUSINESS_TASK_STATE_FAILED = "2";
	
	@Id
	@GeneratedValue
	@Column(name = "n_id")
	private Long id;
	
	@Column(name = "s_type")
	private String type;
	
	@Column(name = "s_business")
	private String business;
	
	@Column(name = "n_relation_id")
	private Long relationId;
	
	@Column(name = "s_state")
	private String state;
	
	@Column(name = "d_create")
	private Date createDate;
	
	@Column(name = "n_piece_id")
	private Long pieceId;
	
	@Column(name = "d_update")
	private Date updateDate;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getBusiness() {
		return business;
	}

	public void setBusiness(String business) {
		this.business = business;
	}

	public Long getRelationId() {
		return relationId;
	}

	public void setRelationId(Long relationId) {
		this.relationId = relationId;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Long getPieceId() {
		return pieceId;
	}

	public void setPieceId(Long pieceId) {
		this.pieceId = pieceId;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	
	

}
