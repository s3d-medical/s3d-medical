package com.nhs.shop.service.order.dto;

import java.io.Serializable;
import java.util.List;

import com.google.common.collect.Lists;

/**
 * 订单创建请求数据DTO
 * @Title: OrderAddRequestDto.java
 * @Package com.nhs.shop.service.order.dto
 * @Description: TODO
 * @author Administrator
 * @date 2016年7月19日 下午8:14:16
 * @version V1.0
 */
public class OrderAddRequestDto implements Serializable {

    private static final long serialVersionUID = 6768334879940207540L;
    private String userId;
    private String userName;
    private Integer addressId;
    private String invoice; // 发票抬头
    private String remark;
    private List<OrderShopDto> shopList = Lists.newArrayList();
    private int invoiceType;
    private Integer invoiceTitle;
    private String invoiceCompany;
    private int invoiceContentId;
    private String invoiceRecPhone;
    private String invoiceRecEmail;
    private Integer needInvoice;
    private String invoiceSubId;
    private String expressType;
    private int consumeReduceType = 0;
    private int couponType = 0;
    private Double couponCount = 0d;

    public String getExpressType() {
        return expressType;
    }

    public void setExpressType(String expressType) {
        this.expressType = expressType;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Integer getAddressId() {
        return addressId;
    }

    public void setAddressId(Integer addressId) {
        this.addressId = addressId;
    }

    public String getInvoice() {
        return invoice;
    }

    public void setInvoice(String invoice) {
        this.invoice = invoice;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public List<OrderShopDto> getShopList() {
        return shopList;
    }

    public void setShopList(List<OrderShopDto> shopList) {
        this.shopList = shopList;
    }

    public int getInvoiceType() {
        return invoiceType;
    }

    public void setInvoiceType(int invoiceType) {
        this.invoiceType = invoiceType;
    }

    public Integer getInvoiceTitle() {
        return invoiceTitle;
    }

    public void setInvoiceTitle(Integer invoiceTitle) {
        this.invoiceTitle = invoiceTitle;
    }

    public String getInvoiceCompany() {
        return invoiceCompany;
    }

    public void setInvoiceCompany(String invoiceCompany) {
        this.invoiceCompany = invoiceCompany;
    }

    public int getInvoiceContentId() {
        return invoiceContentId;
    }

    public void setInvoiceContentId(int invoiceContentId) {
        this.invoiceContentId = invoiceContentId;
    }

    public String getInvoiceRecPhone() {
        return invoiceRecPhone;
    }

    public void setInvoiceRecPhone(String invoiceRecPhone) {
        this.invoiceRecPhone = invoiceRecPhone;
    }

    public String getInvoiceRecEmail() {
        return invoiceRecEmail;
    }

    public void setInvoiceRecEmail(String invoiceRecEmail) {
        this.invoiceRecEmail = invoiceRecEmail;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Integer getNeedInvoice() {
        return needInvoice;
    }

    public void setNeedInvoice(Integer needInvoice) {
        this.needInvoice = needInvoice;
    }

    public String getInvoiceSubId() {
        return invoiceSubId;
    }

    public void setInvoiceSubId(String invoiceSubId) {
        this.invoiceSubId = invoiceSubId;
    }

	public int getConsumeReduceType() {
		return consumeReduceType;
	}

	public void setConsumeReduceType(int consumeReduceType) {
		this.consumeReduceType = consumeReduceType;
	}

	public int getCouponType() {
		return couponType;
	}

	public void setCouponType(int couponType) {
		this.couponType = couponType;
	}

	public Double getCouponCount() {
		return couponCount;
	}

	public void setCouponCount(Double couponCount) {
		this.couponCount = couponCount;
	}
    
    
}
