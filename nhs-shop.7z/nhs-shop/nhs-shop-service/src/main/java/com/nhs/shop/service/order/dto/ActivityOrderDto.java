package com.nhs.shop.service.order.dto;

import java.io.Serializable;

import org.apache.commons.lang3.StringUtils;

import com.nhs.core.utils.common.DateUtils;

public class ActivityOrderDto  implements Comparable<ActivityOrderDto>,Serializable {

    private static final long serialVersionUID = 2308053677959309156L;
    private Integer orderId;
    private String orderNum;
    private String payTimeStr;
    private String payAmountStr;
    private String userId;
    private String type;
    private String baseSilver;
    private String userMobile;
	public Integer getOrderId() {
		return orderId;
	}
	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}
	public String getOrderNum() {
		return orderNum;
	}
	public void setOrderNum(String orderNum) {
		this.orderNum = orderNum;
	}
	
	public String getPayTimeStr() {
		return payTimeStr;
	}
	public void setPayTimeStr(String payTimeStr) {
		this.payTimeStr = payTimeStr;
	}
	
	public String getPayAmountStr() {
		return payAmountStr;
	}
	public void setPayAmountStr(String payAmountStr) {
		this.payAmountStr = payAmountStr;
	}

	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getBaseSilver() {
		return baseSilver;
	}
	public void setBaseSilver(String baseSilver) {
		this.baseSilver = baseSilver;
	}
	@Override
	public int compareTo(ActivityOrderDto arg0) {
		if(StringUtils.isEmpty(payTimeStr) || StringUtils.isEmpty(arg0.getPayTimeStr())){
			return 1;
		}
		return DateUtils.str2Timestamp(payTimeStr).compareTo(DateUtils.str2Timestamp(arg0.getPayTimeStr()));
			
	}
	public String getUserMobile() {
		return userMobile;
	}
	public void setUserMobile(String userMobile) {
		this.userMobile = userMobile;
	}
    
    

}
