package com.nhs.shop.rebate;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nhs.apiproxy.member.acc.service.AccountTransferService;
import com.nhs.core.common.NhsConstant;
import com.nhs.shop.bindspreader.dto.BindedSpreaderDto;
import com.nhs.shop.bindspreader.service.BindedSpreaderService;
import com.nhs.shop.dao.legend.coin.CoinRmbGoldLogDao;
import com.nhs.shop.dao.legend.coin.CoinRmbSilverLogDao;
import com.nhs.shop.dao.legend.pay.PayCashLogDao;
import com.nhs.shop.dao.legend.shop.ShopDetailDao;
import com.nhs.shop.entry.em.shop.EmCashLogType;
import com.nhs.shop.entry.em.user.EmCashType;
import com.nhs.shop.entry.legend.coin.CoinRmbGoldLog;
import com.nhs.shop.entry.legend.coin.CoinRmbSilverLog;
import com.nhs.shop.entry.legend.pay.PdCashLog;
import com.nhs.shop.entry.legend.service.O2oServiceOrder;
import com.nhs.shop.entry.legend.shop.ShopDetail;
import com.nhs.shop.entry.legend.user.UsrDetail;
import com.nhs.shop.rebate.entity.RebatePresent;
import com.nhs.shop.rebate.service.CalRebateService;
import com.nhs.user.service.UserService;

/**
 * <pre>
 * 	<h1>o2o赠送类型</h1>
 * 新规则
 * </pre>
 * @author sungs
 *
 */
@Service("rebateType_o2o")
public class RebateType_o2o implements RebateType {
	
	@Autowired
	private BindedSpreaderService bindedSpreaderService;
	
	// 广告费率
    public static final Double ad_fee_rate = 0.16;
    // 商品的最高赠送比
    public static final Double rebate_rate_max = 1.00;
    // 商品的最小赠送比
    public static final Double rebate_rate_min = 0.3125;
    // 人民币兑换银币
    private static final Integer exchange_rate = 1; //1积分=1券=1RMB
    
    @Autowired
    private CoinRmbSilverLogDao coinRmbSilverLogDao;
    
    @Autowired
    private CoinRmbGoldLogDao coinRmbGoldLogDao;
    
    @Autowired
    private PayCashLogDao payCashLogDao;
    
    @Autowired
    private ShopDetailDao shopDetailDao;
    
    @Autowired
    private AccountTransferService accountTransferService;
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private CalRebateService calRebateService;

	@Override
	public void doRebate(RebatePresent rebatePresent, Map<String, Object> inParams)  throws Exception {
		UsrDetail user = (UsrDetail)inParams.get("user");
		O2oServiceOrder o2oServiceOrder = (O2oServiceOrder)inParams.get("order");
		UsrDetail shopUser = (UsrDetail)inParams.get("shopUser");
		//给推广商家赠送返利
		saveShopRebate(user,o2oServiceOrder,rebatePresent,shopUser);
		
		//给个人赠送返利
		saveUserRebate(user,o2oServiceOrder);
		
		//给消费商家的入账金额
		saveShopCash(user, o2oServiceOrder,shopUser);
	}
	
	/**
     * 处理个人账户的银币
     * @Title: saveUserRebate
     * @Description: TODO
     * @param @param usrDetail
     * @param @param prodRebate
     * @param @param prodId
     * @param @param totalAmount
     * @param @param cash
     * @param @param price
     * @param @param orderNo
     * @param @param prodNum
     * @param @param nowTime
     * @param @throws Exception   
     * @return void 
     * @author Li Guangrong 2016年12月7日 
     * @throws
     */

	 private void saveUserRebate(UsrDetail usrDetail, O2oServiceOrder o2oServiceOrder) throws Exception {
        BigDecimal rebate = calRebateService.calRebate(o2oServiceOrder.getAdFeeRate(), o2oServiceOrder.getAdFeeBasicRate(), NhsConstant.DEFAULT_AD_FEE_RATE_NEW_MAX_O2O);//this.calRebate(o2oServiceOrder.getRebate());
        BigDecimal totalRebateCash = o2oServiceOrder.getPayAmount().multiply(rebate);
        BigDecimal coins = totalRebateCash.multiply(new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE));

        CoinRmbSilverLog silverLog = new CoinRmbSilverLog();
        silverLog.setCash(o2oServiceOrder.getPayAmount());
        silverLog.setPrice(o2oServiceOrder.getPayAmount());
        silverLog.setSubNumber(o2oServiceOrder.getOrderNum());
        silverLog.setProdId(0);
        silverLog.setCreateTime(new Date());
        silverLog.setUserId(usrDetail.getUserId());
        silverLog.setConvertScale(o2oServiceOrder.getAdFeeRate().floatValue());
        silverLog.setRebateScale(rebate.floatValue());
        silverLog.setProdNum(1);
        silverLog.setTotalCash(o2oServiceOrder.getPayAmount());
        silverLog.setTotalRebateCash(totalRebateCash);
        silverLog.setCoinSum(coins);
        silverLog.setType(1); // 普通用户
        coinRmbSilverLogDao.save(silverLog);

        this.accountTransferService.rebateSilver(usrDetail.getUserId(), o2oServiceOrder.getOrderNum(), coins);
        
//        usrDetail.setSilver(usrDetail.getSilver().add(coins).setScale(2, BigDecimal.ROUND_DOWN));
//        usrDetailDao.save(usrDetail);
    }
    
    
    /**
     * 处理个人绑定的推广商家的账户的银币
     * @Title: saveUserRebate
     * @Description: TODO
     * @param @param usrDetail
     * @param @param prodRebate
     * @param @param prodId
     * @param @param totalAmount
     * @param @param cash
     * @param @param price
     * @param @param orderNo
     * @param @param prodNum
     * @param @param nowTime
     * @param @throws Exception   
     * @return void 
     * @author Li Guangrong 2016年12月7日 
     * @throws
     */

     private void saveShopRebate(UsrDetail usrDetail, O2oServiceOrder o2oServiceOrder, RebatePresent rebatePresent,UsrDetail shopUser) throws Exception {
    	// 1.计算推广费
 		BigDecimal totalAmount = o2oServiceOrder.getTotalAmount();
 		BigDecimal actAmount = totalAmount.subtract(o2oServiceOrder.getShopDiscountMoney());
 		BigDecimal prodAdRate = o2oServiceOrder.getAdFeeRate();
 		BigDecimal totalRebateCash = actAmount.multiply(prodAdRate);
 		
 		// 2.得到当前赠送类型的返利比例
 		BigDecimal fee = rebatePresent.getFee();
 		BigDecimal rebateGold = totalRebateCash.multiply(fee);
 		BigDecimal rebateGoldAmount = rebateGold.multiply(new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE)).setScale(2, BigDecimal.ROUND_DOWN);
 		
 		// 3.查到当前购买用户属于哪个推广商家
 		BindedSpreaderDto bindedSpread = bindedSpreaderService.findUserBindShop(usrDetail.getUserId());
 		String toUserId = "";
 		if(bindedSpread == null) {
        	boolean flag = false;
        	ShopDetail shop = shopDetailDao.findOne(o2oServiceOrder.getShopId());
            if (shop != null) {
                // 添加黑白名单，开关控制，决定需要不需要给商家返银币{
                if (shop.getWhiteList() != null && shop.getWhiteList().intValue() == 1) {
                    flag = true;
                } else if ((shop.getWhiteList() == null || shop.getWhiteList().intValue() == 0) && (shop.getCoinSwitch() != null && shop.getCoinSwitch().intValue() == 1)) {
                    flag = true;
                }
                // }
                if (flag) {
                	BigDecimal coins = totalRebateCash.multiply(new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE));
                	CoinRmbSilverLog silverLog = new CoinRmbSilverLog();
                    silverLog.setCash(o2oServiceOrder.getPayAmount());
                    silverLog.setPrice(o2oServiceOrder.getPayAmount());
                    silverLog.setSubNumber(o2oServiceOrder.getOrderNum());
                    silverLog.setProdId(0);
                    silverLog.setCreateTime(new Date());
                    silverLog.setUserId(shopUser.getUserId());
                    silverLog.setConvertScale(o2oServiceOrder.getAdFeeRate().floatValue());
                    silverLog.setRebateScale(o2oServiceOrder.getRebate().floatValue());
                    silverLog.setProdNum(1);
                    silverLog.setTotalCash(o2oServiceOrder.getPayAmount());
                    silverLog.setTotalRebateCash(totalRebateCash);
                    silverLog.setCoinSum(coins);
                    silverLog.setType(2); // 商家用户
                    coinRmbSilverLogDao.save(silverLog);
                    
                    this.accountTransferService.rebateSilver(shopUser.getUserId(), o2oServiceOrder.getOrderNum(), coins);
                    
//                    shopUser.setSilver(shopUser.getSilver().add(coins).setScale(2, BigDecimal.ROUND_DOWN));
//                    usrDetailDao.save(shopUser);
                }
            }
 		}else{
 			if("0".equals(bindedSpread.getSpreaderType())){
	 			toUserId = bindedSpread.getUserId();
	 			UsrDetail toUsrDetail = userService.findUserById(toUserId);//usrDetailDao.findUserById(toUserId);
	 			this.accountTransferService.rebateGold(toUserId, o2oServiceOrder.getOrderNum(), rebateGoldAmount);
//	 			toUsrDetail.setGold(toUsrDetail.getGold().add(rebateGoldAmount));
//	 			usrDetailDao.save(toUsrDetail);
	 			
	 			CoinRmbGoldLog goldLog = new CoinRmbGoldLog();
	 	        goldLog.setSubNumber(o2oServiceOrder.getOrderNum());
	 	        goldLog.setProdId(0);
	 	        goldLog.setCreateTime(new Date());
	 	        goldLog.setUserId(toUserId);
	 	        goldLog.setGoldSum(rebateGoldAmount);
	 	        goldLog.setType(2); // 商家用户
	 	        goldLog.setActivityId(0);
	 	        goldLog.setActivityTitle("推广用户返利");
	 	        coinRmbGoldLogDao.save(goldLog);
 			}
 		}
 		

    }
     
     
     /**
      * 处理商家的入账金额
      * @Title: saveShopCash
      * @Description: TODO
      * @param @param shopDetail
      * @param @param orderDesc
      * @param @param prodRebate
      * @param @param prodAdRate
      * @param @param totalAmount
      * @param @param orderNo
      * @param @param nowTime
      * @param @throws Exception   
      * @return void 
      * @author huxianjun 2016年8月24日 
      * @throws
      */
//     public void saveShopCash(UsrDetail shopDetail, String orderDesc, BigDecimal prodRebate, BigDecimal prodAdRate,
//             BigDecimal totalAmount, String orderNo, Date nowTime) throws Exception {
     private void saveShopCash(UsrDetail usrDetail, O2oServiceOrder o2oServiceOrder,UsrDetail shopUser) throws Exception {

    	 
         BigDecimal money = o2oServiceOrder.getTotalAmount().subtract(o2oServiceOrder.getShopDiscountMoney());
         BigDecimal shopRmb = money.multiply((BigDecimal.valueOf(1).subtract(o2oServiceOrder.getAdFeeRate())));
         BigDecimal shopMoney = shopRmb.setScale(2, BigDecimal.ROUND_DOWN);
//         shopUser.setShopAvailablePred(shopUser.getShopAvailablePred().add(shopMoney));
//         usrDetailDao.save(shopUser);
         
         this.accountTransferService.depositUserBizAccount(shopUser.getUserId(), o2oServiceOrder.getOrderNum(), shopMoney);
         
         ShopDetail shopDetail = shopDetailDao.findShopDetail(shopUser.getUserId());
    
         PdCashLog pdCashLog = new PdCashLog();
         pdCashLog.setAddTime(new Date());
         pdCashLog.setAmount(shopMoney);
         pdCashLog.setCashType(EmCashType.merchant.value);
         StringBuilder logDesc = new StringBuilder();
         logDesc.append("商家账户收入：").append(shopMoney).append("-服务订单-").append(",(子)订单流水号: ").append(o2oServiceOrder.getOrderNum());
         pdCashLog.setLogType(EmCashLogType.SHOP_PD_INCOME.value);
         pdCashLog.setLogDesc(logDesc.toString());
         pdCashLog.setUserId(shopDetail.getUserId());
         pdCashLog.setUserName(shopDetail.getUserName());
         pdCashLog.setSn(o2oServiceOrder.getOrderNum());
         payCashLogDao.save(pdCashLog);
     }

     
     /**
      * 计算赠送比例
      * @Title: calRebate
      * @Description: TODO
      * @param @param prodRebate
      * @param @return   
      * @return BigDecimal 
      * @author huxianjun 2016年11月1日 
      * @throws
      */
     private BigDecimal calRebate(BigDecimal prodRebate) {
         BigDecimal rebate = BigDecimal.valueOf(0.00);
         if (prodRebate != null) {
             if (BigDecimal.valueOf(rebate_rate_min).compareTo(prodRebate) <= 0
                     && BigDecimal.valueOf(rebate_rate_max).compareTo(prodRebate) >= 0) {
                 rebate = prodRebate;
             } else if (BigDecimal.valueOf(rebate_rate_max).compareTo(prodRebate) < 0) {
                 rebate = BigDecimal.valueOf(rebate_rate_max);
             }
         }
         return rebate;
     }
}
