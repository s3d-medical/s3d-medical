package com.nhs.shop.service.order.dto;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 服务订单列表DTO
 * @Title: OrderListDto.java
 * @Package com.nhs.shop.service.order.dto
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月20日 下午3:37:26
 * @version V1.0
 */
public class ServiceOrderListDto implements Serializable {

    private static final long serialVersionUID = 2308053677959309156L;
    private Integer orderId;
    private String orderNum;
    private Integer shopId;
    private String shopName;
    private String address ="";
    private String pic;
    private Integer status;
    private String statusName;
    private BigDecimal totalAmount;
    private String createTime;
    private BigDecimal subsidy;
    private String payAmountStr;
    private String subsidyStr;
    private String userNickName;
    private String userImg;
    private String userId;
    private BigDecimal rebate;
    private String reduce;
    private String discount;
    private String coupon;
    private String discountStr;
    private String couponStr;
    private String totalAmountStr;


    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public String getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(String orderNum) {
        this.orderNum = orderNum;
    }

    public Integer getShopId() {
        return shopId;
    }

    public void setShopId(Integer shopId) {
        this.shopId = shopId;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getStatusName() {
        return statusName;
    }

    public void setStatusName(String statusName) {
        this.statusName = statusName;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    public BigDecimal getSubsidy() {
        return subsidy;
    }

    public void setSubsidy(BigDecimal subsidy) {
        this.subsidy = subsidy;
    }

	public String getPayAmountStr() {
		return payAmountStr;
	}

	public void setPayAmountStr(String payAmountStr) {
		this.payAmountStr = payAmountStr;
	}

	public String getSubsidyStr() {
		return subsidyStr;
	}

	public void setSubsidyStr(String subsidyStr) {
		this.subsidyStr = subsidyStr;
	}

	public String getUserNickName() {
		return userNickName;
	}

	public void setUserNickName(String userNickName) {
		this.userNickName = userNickName;
	}

	public String getUserImg() {
		return userImg;
	}

	public void setUserImg(String userImg) {
		this.userImg = userImg;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public BigDecimal getRebate() {
		return rebate;
	}

	public void setRebate(BigDecimal rebate) {
		this.rebate = rebate;
	}

	public String getReduce() {
		return reduce;
	}

	public void setReduce(String reduce) {
		this.reduce = reduce;
	}

	public String getDiscount() {
		return discount;
	}

	public void setDiscount(String discount) {
		this.discount = discount;
	}

	public String getCoupon() {
		return coupon;
	}

	public void setCoupon(String coupon) {
		this.coupon = coupon;
	}

	public String getDiscountStr() {
		return discountStr;
	}

	public void setDiscountStr(String discountStr) {
		this.discountStr = discountStr;
	}

	public String getCouponStr() {
		return couponStr;
	}

	public void setCouponStr(String couponStr) {
		this.couponStr = couponStr;
	}

	public String getTotalAmountStr() {
		return totalAmountStr;
	}

	public void setTotalAmountStr(String totalAmountStr) {
		this.totalAmountStr = totalAmountStr;
	}
    
    

}
