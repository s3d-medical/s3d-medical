package com.nhs.shop.rebate;

import java.util.Map;

import com.nhs.shop.rebate.entity.RebatePresent;

/**
 * 
 * @author sungs
 *
 */
public interface RebateType {
	
	public void doRebate(RebatePresent rebatePresent, Map<String, Object> inParams)   throws Exception;

}
