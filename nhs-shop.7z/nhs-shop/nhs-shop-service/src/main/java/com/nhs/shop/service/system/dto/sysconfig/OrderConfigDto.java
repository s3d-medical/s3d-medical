package com.nhs.shop.service.system.dto.sysconfig;

import java.io.Serializable;

public class OrderConfigDto implements Serializable {
	private static final long serialVersionUID = -6144772923584426167L;
	/**
	 * 订单处理回调地址.
	 */
	private OrderCallBackUrls callbackUrls;
	
	public OrderCallBackUrls getCallbackUrls() {
		return callbackUrls;
	}

	public void setCallbackUrls(OrderCallBackUrls callbackUrls) {
		this.callbackUrls = callbackUrls;
	}

	/**
	 * 订单支付完毕， 回调处理订单的地址. 
	 * @author wind.chen
	 */
	public static class OrderCallBackUrls implements Serializable {
		private static final long serialVersionUID = 8929216728664344809L;
		private String handleOrderAfterPay;
		public String getHandleOrderAfterPay() {
			return handleOrderAfterPay;
		}
		public void setHandleOrderAfterPay(String handleOrderAfterPay) {
			this.handleOrderAfterPay = handleOrderAfterPay;
		}
	}
}
