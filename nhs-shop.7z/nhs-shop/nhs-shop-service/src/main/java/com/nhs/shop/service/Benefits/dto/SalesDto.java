package com.nhs.shop.service.Benefits.dto;

import java.io.Serializable;

/**
 *  营业员资料
 * @Title: SalesDto.java
 * @Package com.nhs.shop.service.Benefits.dto
 * @Description: TODO
 * @author liangdanhua
 * @date 2016年11月4日 下午3:14:14
 * @version V1.0
 */
public class SalesDto implements Serializable {

    // 营业员申请信息

    private static final long serialVersionUID = -7302458203617719235L;
    private String name = "";
    private String phone = "";
    private String shopName = "";
    private String addTime = "";
    private String userId = "";
    private String nickName = "";
    private String detailPic = "";
    private String realName = "";
    private String sex = "";
    private String cardNo = "";
    private String email = "";
    private String QQ = "";
    private String birthday = "";
    private String Hobby = "";
    private String commissionGold = "";
    private String commissionSilver = "";
    private String totalGold = "";
    private String totalSilver = "";
    private String salesId = "";
    private String isSales = "0";
    private Integer shopId;
    private String address = "";
    private Integer status = 4;
    private String exceedterm = "";
    private String userName = "";

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getExceedterm() {
        return exceedterm;
    }

    public void setExceedterm(String exceedterm) {
        this.exceedterm = exceedterm;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getTotalGold() {
        return totalGold;
    }

    public void setTotalGold(String totalGold) {
        this.totalGold = totalGold;
    }

    public String getTotalSilver() {
        return totalSilver;
    }

    public void setTotalSilver(String totalSilver) {
        this.totalSilver = totalSilver;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Integer getShopId() {
        return shopId;
    }

    public void setShopId(Integer shopId) {
        this.shopId = shopId;
    }

    public String getIsSales() {
        return isSales;
    }

    public void setIsSales(String isSales) {
        this.isSales = isSales;
    }

    public String getSalesId() {
        return salesId;
    }

    public void setSalesId(String salesId) {
        this.salesId = salesId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public String getAddTime() {
        return addTime;
    }

    public void setAddTime(String addTime) {
        this.addTime = addTime;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getDetailPic() {
        return detailPic;
    }

    public void setDetailPic(String detailPic) {
        this.detailPic = detailPic;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getQQ() {
        return QQ;
    }

    public void setQQ(String qQ) {
        QQ = qQ;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getHobby() {
        return Hobby;
    }

    public void setHobby(String hobby) {
        Hobby = hobby;
    }

    public String getCommissionGold() {
        return commissionGold;
    }

    public void setCommissionGold(String commissionGold) {
        this.commissionGold = commissionGold;
    }

    public String getCommissionSilver() {
        return commissionSilver;
    }

    public void setCommissionSilver(String commissionSilver) {
        this.commissionSilver = commissionSilver;
    }
}
