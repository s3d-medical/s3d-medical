package com.nhs.shop.service.version;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nhs.shop.dao.legend.version.VersionDao;
import com.nhs.shop.service.BaseService;

/**
 * 版本跟新 service
 * 
 * @Title: VersionService.java
 * @Package com.nhs.shop.service.goods
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月16日 下午7:42:18
 * @version V1.0
 */
@Service
@Transactional
public class VersionService extends BaseService {

    @Autowired
    private VersionDao versionDao;

    /**
     * 更新最新的版本信息 
     * @Title: query
     * @Description: TODO
     * @param @param versionNum
     * @param @return   
     * @return Map<String,Object> 
     * @author Administrator 2016年8月25日 
     * @throws
     */

    public Map<String, Object> query(Integer versionNum, String channel) {
        if (StringUtils.isEmpty(channel)) {
            channel = "android";
        }
        String isFlag = "";
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> vn1 = versionDao.findVersion(channel.toLowerCase());
        if (vn1.get("version_number") == null) {
            isFlag = "当前版本是最新的版本";
            map.put("isnew", isFlag);
        } else {
            int version_number = (Integer) vn1.get("version_number");
            // TODO liangdanhua 修改支付的斑斑
            if (versionNum >= version_number) {
                isFlag = "当前版本是最新的版本";
                map.put("isnew", isFlag);
            } else if (versionNum < version_number) {// >
                isFlag = "当前版本不是最新的版本";
                map.put("isnew", isFlag);
                map.put("information", vn1.get("update_infomation"));
                map.put("isforce", vn1.get("isforce_update"));
                map.put("address", vn1.get("apk_address"));
            }
        }
        return map;
    }

    /**
     * 更新最新的版本信息 
     * @Title: query
     * @Description: TODO
     * @param @param versionNum
     * @param @return   
     * @return Map<String,Object> 
     * @author Administrator 2016年8月25日 
     * @throws
     */

    public Map<String, Object> querySeller(Integer versionNum, String channel) {
        String isFlag = "";
        if (StringUtils.isEmpty(channel)) {
            channel = "android";
        }
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> vn1 = versionDao.findVersionForSeller(channel.toLowerCase());
        if (vn1.get("version_number") == null) {
            isFlag = "当前版本是最新的版本";
            map.put("isnew", isFlag);
        } else {
            int version_number = (Integer) vn1.get("version_number");
            if (versionNum >= version_number) {
                isFlag = "当前版本是最新的版本";
                map.put("isnew", isFlag);
            } else if (versionNum < version_number) {// >
                isFlag = "当前版本不是最新的版本";
                map.put("isnew", isFlag);
                map.put("information", vn1.get("update_infomation"));
                map.put("isforce", vn1.get("isforce_update"));
                map.put("address", vn1.get("apk_address"));

            }
        }
        return map;
    }
}
