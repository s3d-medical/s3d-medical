package com.nhs.shop.service.pay;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.nhs.core.persistence.DynamicSpecifications;
import com.nhs.core.persistence.SearchFilter;
import com.nhs.core.persistence.SearchFilter.Operator;
import com.nhs.shop.dao.legend.pay.PayLogDao;
import com.nhs.shop.entry.legend.pay.PayLog;

@Service
public class PayLogService {

    @Autowired
    private PayLogDao payLogDao;

    /**
     * 保存支付日志
     * @Title: savePayLog
     * @Description: TODO
     * @param @param orderNum
     * @param @param tradeNo
     * @param @param payAmount
     * @param @param payTypeName
     * @param @param payStatus
     * @param @param payAccount   
     * @return void 
     * @author Administrator 2016年7月28日 
     * @throws
     */
    public void savePayLog(String orderNum, String tradeNo, Double payAmount, String payTypeName, String payStatus,
            String payAccount, String userId) {
        PayLog payLog = new PayLog();
        payLog.setOrderNum(orderNum);
        payLog.setTradeNo(tradeNo);
        payLog.setPayAmount(BigDecimal.valueOf(payAmount));
        payLog.setPayTypeName(payTypeName);
        payLog.setPayStatus(payStatus);
        payLog.setPayAccount(payAccount);
        payLog.setPayTime(new Date());
        payLog.setUserId(userId);
        payLog.setState(PayLog.StateEnum.ENABLE.toString());
        payLogDao.save(payLog);
    }

    /**
     * 保存支付日志  PC商城用
     * @Title: savePayLog
     * @Description: TODO
     * @param @param orderNum
     * @param @param tradeNo
     * @param @param payAmount
     * @param @param payTypeName
     * @param @param payStatus
     * @param @param payAccount
     * @param @param userId   
     * @return void 
     * @author Administrator 2016年12月7日 
     * @throws
     */
    public void savePayLog(String orderNum, String tradeNo, String payAmount, String payTypeName, String payStatus,
            String payAccount, String userId) {
        PayLog payLog = new PayLog();
        payLog.setOrderNum(orderNum);
        payLog.setTradeNo(tradeNo);
        payLog.setPayAmount(new BigDecimal(payAmount));
        payLog.setPayTypeName(payTypeName);
        payLog.setPayStatus(payStatus);
        payLog.setPayAccount(payAccount);
        payLog.setPayTime(new Date());
        payLog.setUserId(userId);
        payLog.setState(PayLog.StateEnum.ENABLE.toString());
        payLogDao.save(payLog);
    }

    /**
     * 删除记录  PC商城用
     * @Title: deletePayLog
     * @Description: TODO
     * @param @param pid   
     * @return void 
     * @author Administrator 2016年12月6日 
     * @throws
     */
    public void deletePayLog(Integer pid) {
        PayLog payLog = payLogDao.findOne(pid);
        payLog.setState(PayLog.StateEnum.DISABLE.toString());
        payLogDao.saveAndFlush(payLog);
    }

    /**
     * 消费记录 分页
     * @Title: getPayLogPage
     * @Description: TODO
     * @param @param params
     * @param @param userId
     * @param @param pageNo
     * @param @param pageSize
     * @param @return   
     * @return Page<PayLog> 
     * @author Administrator 2016年12月6日 
     * @throws
     */
    public Page<PayLog> getPayLogPage(Map<String, Object> params, String userId, int pageNo, int pageSize) {
        PageRequest request = new PageRequest(pageNo - 1, pageSize,
                new Sort(new Sort.Order(Sort.Direction.DESC, "payTime")));
        Map<String, SearchFilter> filters = SearchFilter.parse(params);
        if (filters.get("EQ_userId") == null) {
            SearchFilter user_Id = new SearchFilter("userId", Operator.EQ, userId);
            filters.put("EQ_userId", user_Id);
        }
        if (filters.get("EQ_state") == null) {
            SearchFilter state = new SearchFilter("state", Operator.NEQ, "0");
            filters.put("EQ_state", state);
        }
        Specification<PayLog> spec = DynamicSpecifications.bySearchFilter(filters.values(), PayLog.class);
        Page<PayLog> page = payLogDao.findAll(spec, request);
        return page;
    }

    /**
     * 判断是否已经处理过(如果存在就是处理过，这个PayLog是订单关联的，还是积蓄宝关联的呢？)
     * 我自己觉得是订单关联的。需要验证一下。
     * @Title: isHandled
     * @Description: TODO
     * @param @param orderNum
     * @param @return   
     * @return boolean 
     * @author Administrator 2016年7月28日 
     * @throws
     */
    public boolean isHandled(String orderNum) {
        PayLog payLog = payLogDao.findPayLogByOrderNum(orderNum);
        return (payLog != null);
    }
}
