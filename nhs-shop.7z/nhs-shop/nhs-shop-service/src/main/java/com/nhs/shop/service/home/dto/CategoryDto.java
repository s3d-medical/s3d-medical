package com.nhs.shop.service.home.dto;

import java.io.Serializable;
import java.util.List;

import com.google.common.collect.Lists;

/**
 * 分类dto
 * @Title: CategoryDto.java
 * @Package com.nhs.shop.service.home.dto
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月16日 下午5:31:32
 * @version V1.0
 */
public class CategoryDto implements Serializable {

	private static final long serialVersionUID = -6184909547688220652L;

	private Integer categoryId = 0;
	private String title = "";
	private String image = "";
	private String color = "";
	private List<CategoryDto> list = Lists.newArrayList();

	public Integer getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Integer categoryId) {
		this.categoryId = categoryId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public List<CategoryDto> getList() {
		return list;
	}

	public void setList(List<CategoryDto> list) {
		this.list = list;
	}

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
	
	

}
