package com.nhs.shop.service.activity.dto;



import java.io.Serializable;

/**
 * 
 */
public class SchoolCountDto implements Serializable {

    private static final long serialVersionUID = 3702485138530016071L;

    private Integer countRegs;

    private Integer countDownLoad;

    private String totalResume;
    
    private String userId;
    
    private String userName;

	public Integer getCountRegs() {
		return countRegs;
	}

	public void setCountRegs(Integer countRegs) {
		this.countRegs = countRegs;
	}

	public Integer getCountDownLoad() {
		return countDownLoad;
	}

	public void setCountDownLoad(Integer countDownLoad) {
		this.countDownLoad = countDownLoad;
	}

	public String getTotalResume() {
		return totalResume;
	}

	public void setTotalResume(String totalResume) {
		this.totalResume = totalResume;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	

   
}
