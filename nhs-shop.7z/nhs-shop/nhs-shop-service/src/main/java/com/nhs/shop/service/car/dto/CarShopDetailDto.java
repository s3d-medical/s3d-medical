package com.nhs.shop.service.car.dto;

import java.io.Serializable;
import java.util.List;

import com.google.common.collect.Lists;

/**
 * 汽车店铺详情DTO
 * @Title: CarShopDetailDto.java
 * @Package com.nhs.shop.service.car.dto
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月27日 上午11:10:57
 * @version V1.0
 */
public class CarShopDetailDto implements Serializable{

    /**
     * 
     */
    private static final long serialVersionUID = 7212682285032087061L;
    private Integer shopId;
    private String title;
    private String image;
    private String address;
    private String mobile;
    private Integer prodNum;
    private String deposit; // 保证金
    private String createTime;
    private List<CarDto> list = Lists.newArrayList(); // 促销车型

    public Integer getShopId() {
        return shopId;
    }

    public void setShopId(Integer shopId) {
        this.shopId = shopId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public Integer getProdNum() {
        return prodNum;
    }

    public void setProdNum(Integer prodNum) {
        this.prodNum = prodNum;
    }

    public String getDeposit() {
        return deposit;
    }

    public void setDeposit(String deposit) {
        this.deposit = deposit;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public List<CarDto> getList() {
        return list;
    }

    public void setList(List<CarDto> list) {
        this.list = list;
    }

}
