package com.nhs.shop.service.activity.dto;


import java.io.Serializable;

/**
 * Created by 光荣 on 2016/10/20.
 * 校园代理活动返还金币
 */
public class GoldSchoolRegsDto implements Serializable {

    private static final long serialVersionUID = -2947128927151141559L;
    /**
     * 注册者id
     */
    private String inviteeUserId;

    /**
     * 注册者赠送金额
     */
    private String inviteeGold;

    /**
     * 邀请者id
     */
    private String inviterUserId;

    /**
     * 邀请者赠送金额
     */
    private String inviterGold;

    public String getInviteeUserId() {
        return inviteeUserId;
    }

    public void setInviteeUserId(String inviteeUserId) {
        this.inviteeUserId = inviteeUserId;
    }

    public String getInviteeGold() {
        return inviteeGold;
    }

    public void setInviteeGold(String inviteeGold) {
        this.inviteeGold = inviteeGold;
    }

    public String getInviterUserId() {
        return inviterUserId;
    }

    public void setInviterUserId(String inviterUserId) {
        this.inviterUserId = inviterUserId;
    }

    public String getInviterGold() {
        return inviterGold;
    }

    public void setInviterGold(String inviterGold) {
        this.inviterGold = inviterGold;
    }
}
