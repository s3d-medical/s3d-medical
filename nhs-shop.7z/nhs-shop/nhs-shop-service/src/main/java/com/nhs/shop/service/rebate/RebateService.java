package com.nhs.shop.service.rebate;

import java.math.BigDecimal;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nhs.apiproxy.member.acc.dto.UserAllAccDto;
import com.nhs.apiproxy.member.acc.service.AccountTransferService;
import com.nhs.shop.activity.dao.ActivitySchoolDao;
import com.nhs.shop.activity.entry.ActivitySchool;
import com.nhs.shop.dao.legend.coin.CoinRmbGoldLogDao;
import com.nhs.shop.dao.legend.coin.CoinRmbSilverLogDao;
import com.nhs.shop.dao.legend.pay.PayCashLogDao;
import com.nhs.shop.entry.em.shop.EmCashLogType;
import com.nhs.shop.entry.em.user.EmCashType;
import com.nhs.shop.entry.legend.coin.CoinRmbGoldLog;
import com.nhs.shop.entry.legend.coin.CoinRmbSilverLog;
import com.nhs.shop.entry.legend.pay.PdCashLog;
import com.nhs.shop.entry.legend.user.UsrDetail;
import com.nhs.shop.rebate.service.CalRebateService;
import com.nhs.shop.service.activity.dto.GoldSchoolRegsDto;
import com.nhs.user.service.UserService;
import com.nhs.core.common.NhsConstant;

@Service
public class RebateService {

    private static Logger logger = LoggerFactory.getLogger(RebateService.class);
    // 广告费率
    public static final Double ad_fee_rate = 0.16;
    // 商品的最高赠送比
    public static final Double rebate_rate_max = 0.625;
    // 商品的最小赠送比
    public static final Double rebate_rate_min = 0.02;
    // 人民币兑换银币
    private static final Integer exchange_rate = 1;
    
    //广告费率最低比
    public static final Double ad_fee_rate_min = 0.01;

    @Autowired
    private CoinRmbSilverLogDao coinRmbSilverLogDao;

    @Autowired
    private PayCashLogDao payCashLogDao;

    @Autowired
    private CoinRmbGoldLogDao coinRmbGoldLogDao;

    @Autowired
    private ActivitySchoolDao schoolDao;

    @Autowired
    private AccountTransferService accountTransferService;

    @Autowired
    private UserService userService;
    
    @Autowired
    private CalRebateService calRebateService;

    /**
     * 处理个人账户的银币
     * @Title: saveUserRebate
     * @Description: TODO
     * @param @param usrDetail
     * @param @param prodRebate
     * @param @param prodId
     * @param @param totalAmount
     * @param @param cash
     * @param @param price
     * @param @param orderNo
     * @param @param prodNum
     * @param @param nowTime
     * @param @throws Exception   
     * @return void 
     * @author huxianjun 2016年8月12日 
     * @author Robin.chu 2016年11月18日
     * @throws
     */
    public void saveUserRebate(UsrDetail usrDetail, String orderDesc, BigDecimal prodRebate, BigDecimal prodAdRate,
            Integer prodId, BigDecimal totalAmount, BigDecimal cash, BigDecimal price, String orderNo, Integer prodNum,
            Date nowTime) throws Exception {
        logger.info("开始结算个人账户的银币，清算订单类型：" + orderDesc + ",用户ID:" + usrDetail.getUserId());
//        BigDecimal rebate = this.calRebate(prodRebate);
        BigDecimal rebate = calRebateService.calRebate(prodAdRate, new BigDecimal(NhsConstant.DEFAULT_AD_FEE_BASIC_RATE), NhsConstant.DEFAULT_AD_FEE_RATE_NEW_MAX_O2O);
        BigDecimal totalRebateCash = totalAmount.multiply(rebate);
        BigDecimal coins = totalRebateCash.multiply(new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE));

        CoinRmbSilverLog silverLog = new CoinRmbSilverLog();
        silverLog.setCash(cash);
        silverLog.setPrice(price);
        silverLog.setSubNumber(orderNo);
        silverLog.setProdId(prodId);
        silverLog.setCreateTime(nowTime);
        silverLog.setUserId(usrDetail.getUserId());
        silverLog.setConvertScale(prodAdRate.floatValue());
        silverLog.setRebateScale(rebate.floatValue());
        silverLog.setProdNum(prodNum);
        silverLog.setTotalCash(totalAmount);
        silverLog.setTotalRebateCash(totalRebateCash);
        silverLog.setCoinSum(coins);
        silverLog.setType(1); // 普通用户
        coinRmbSilverLogDao.save(silverLog);

        // 返利佰德券
        this.accountTransferService.rebateSilver(usrDetail.getUserId(), orderNo, coins);
    }

    /**
     * 处理商家的返利
     * @Title: saveShopRebate
     * @Description: TODO
     * @param @param shop
     * @param @param prodRebate
     * @param @param prodAdRate
     * @param @param prodId
     * @param @param totalAmount
     * @param @param cash
     * @param @param price
     * @param @param orderNo
     * @param @param prodNum
     * @param @param nowTime
     * @param @throws Exception   
     * @return void 
     * @author huxianjun 2016年8月12日 
     * @throws
     */
    public void saveShopRebate(UsrDetail shop, String orderDesc, BigDecimal prodRebate, BigDecimal prodAdRate,
            Integer prodId, BigDecimal totalAmount, BigDecimal cash, BigDecimal price, String orderNo, Integer prodNum,
            Date nowTime) throws Exception {
        logger.info("开始结算商家账户的银币，清算订单类型：" + orderDesc + ",用户ID:" + shop.getUserId());
        BigDecimal rebate = calRebateService.calRebate(prodAdRate, new BigDecimal(NhsConstant.DEFAULT_AD_FEE_BASIC_RATE), NhsConstant.DEFAULT_AD_FEE_RATE_NEW_MAX_O2O);//this.calRebate(prodRebate);
        // prodAdRate = this.calAdRebate(prodRebate);
        BigDecimal totalRebateCash = totalAmount.multiply(prodAdRate);
        BigDecimal coins = totalRebateCash.multiply(new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE));

        CoinRmbSilverLog silverLog = new CoinRmbSilverLog();
        silverLog.setCash(cash);
        silverLog.setPrice(price);
        silverLog.setSubNumber(orderNo);
        silverLog.setProdId(prodId);
        silverLog.setCreateTime(nowTime);
        silverLog.setUserId(shop.getUserId());
        silverLog.setConvertScale(prodAdRate.floatValue());
        silverLog.setRebateScale(rebate.floatValue());
        silverLog.setProdNum(prodNum);
        silverLog.setTotalCash(totalAmount);
        silverLog.setTotalRebateCash(totalRebateCash);
        silverLog.setCoinSum(coins);
        silverLog.setType(2); // 商家用户
        coinRmbSilverLogDao.save(silverLog);

        // TODO Robin.Chu 2016-11-18
        // shop.setSilver(shop.getSilver().add(coins).setScale(2, BigDecimal.ROUND_DOWN));
        this.accountTransferService.rebateSilver(shop.getUserId(), orderNo, coins);
    }

    /**
     * 处理商家的结算金额
     * @Title: saveShopCash
     * @Description: TODO
     * @param @param shopDetail
     * @param @param orderDesc
     * @param @param prodRebate
     * @param @param prodAdRate
     * @param @param totalAmount
     * @param @param orderNo
     * @param @param nowTime
     * @param @throws Exception   
     * @return void 
     * @author huxianjun 2016年8月24日 
     * @throws
     */
    public void saveShopCash(UsrDetail shopDetail, String orderDesc, BigDecimal prodRebate, BigDecimal prodAdRate,
            BigDecimal totalAmount, String orderNo, Date nowTime) throws Exception {

        logger.info("开始结算商家账户的订单收入，清算订单类型：" + orderDesc + ",用户ID:" + shopDetail.getUserId());
        Integer money = totalAmount.multiply(BigDecimal.valueOf(100)).intValue();
        Double shopRmb = money * (1 - prodAdRate.doubleValue()) / 100;
        BigDecimal shopMoney = new BigDecimal(shopRmb.toString()).setScale(2, BigDecimal.ROUND_DOWN);

        // TODO 是商户余额
        // TODO Robin.Chu 2016-11-18
        // shopDetail.setShopAvailablePred(shopDetail.getShopAvailablePred().add(shopMoney));
        this.accountTransferService.depositUserBizAccount(shopDetail.getUserId(), orderNo, shopMoney);

        PdCashLog pdCashLog = new PdCashLog();
        pdCashLog.setAddTime(nowTime);
        pdCashLog.setAmount(shopMoney);
        pdCashLog.setCashType(EmCashType.merchant.value);
        StringBuilder logDesc = new StringBuilder();
        logDesc.append("商家账户收入：").append(shopMoney).append(orderDesc).append(",(子)订单流水号: ").append(orderNo);
        pdCashLog.setLogType(EmCashLogType.SHOP_PD_INCOME.value);
        pdCashLog.setLogDesc(logDesc.toString());
        pdCashLog.setUserId(shopDetail.getUserId());
        pdCashLog.setUserName(shopDetail.getUserName());
        pdCashLog.setSn(orderNo);
        payCashLogDao.save(pdCashLog);
    }

    /**
     * 清算商家的运费
     * @Title: saveFreight
     * @Description: TODO
     * @param @param shopDetail
     * @param @param freightAmount
     * @param @param orderNo
     * @param @param nowTime
     * @param @throws Exception   
     * @return void 
     * @author huxianjun 2016年8月25日 
     * @throws
     */
    public void saveFreight(UsrDetail shopDetail, BigDecimal freightAmount, String orderNo, Date nowTime)
            throws Exception {
        if (BigDecimal.valueOf(0.0).compareTo(freightAmount) >= 0) {
            logger.info("商家账户的运费等于0.0，不清算，" + "用户ID:" + shopDetail.getUserId());
            return;
        }
        logger.info("开始结算商家账户的运费，" + "用户ID:" + shopDetail.getUserId());
        // shopDetail.setShopAvailablePred(shopDetail.getShopAvailablePred().add(freightAmount));
        // 增加企业账户余额
        this.accountTransferService.depositUserBizAccount(shopDetail.getUserId(), orderNo, freightAmount);

        PdCashLog pdCashLog = new PdCashLog();
        pdCashLog.setAddTime(nowTime);
        pdCashLog.setAmount(freightAmount);
        pdCashLog.setCashType(EmCashType.merchant.value);
        StringBuilder logDesc = new StringBuilder();
        logDesc.append("商家账户收入：").append(freightAmount).append(",(子)订单流水号: ").append(orderNo);
        pdCashLog.setLogType(EmCashLogType.SHOP_PD_INCOME.value);
        pdCashLog.setLogDesc(logDesc.toString());
        pdCashLog.setUserId(shopDetail.getUserId());
        pdCashLog.setUserName(shopDetail.getUserName());
        pdCashLog.setSn("freight_" + orderNo);
        payCashLogDao.save(pdCashLog);
    }

    public static void main(String[] args) {
        BigDecimal totalAmount = BigDecimal.valueOf(100.00);
        Integer money = totalAmount.multiply(BigDecimal.valueOf(100)).intValue();
        System.out.println(money);
        Double shopRmb = money * (1 - ad_fee_rate * rebate_rate_max.doubleValue()) / 100;
        System.out.println(shopRmb);
        BigDecimal shopMoney = new BigDecimal(shopRmb.toString()).setScale(2, BigDecimal.ROUND_DOWN);
        System.out.println(shopMoney);
    }

    /**
     * 处理参加活动个人账户返还的银币
     * @Title: saveUserRebate
     * @Description: TODO
     * @param @param usrDetail
     * @param @param prodRebate
     * @param @param prodId
     * @param @param totalAmount
     * @param @param cash
     * @param @param price
     * @param @param orderNo
     * @param @param prodNum
     * @param @param nowTime
     * @param @throws Exception   
     * @return void 
     * @author huxianjun 2016年8月12日 
     * @throws
     */
    public void saveActivityUserRebate(UsrDetail usrDetail, String orderDesc, String silver, String orderNo,
            Integer prodId, Date nowTime, Integer activityId) throws Exception {
        logger.info("开始计算个人账户的银币，计算订单类型：" + orderDesc + ",用户ID:" + usrDetail.getUserId());

        BigDecimal coins = new BigDecimal(silver);
        CoinRmbSilverLog silverLog = new CoinRmbSilverLog();
        silverLog.setSubNumber(orderNo);
        silverLog.setProdId(prodId);
        silverLog.setCreateTime(nowTime);
        silverLog.setUserId(usrDetail.getUserId());
        silverLog.setCoinSum(coins);
        silverLog.setType(1); // 普通用户
        silverLog.setActivityId(activityId);
        silverLog.setActivityTitle(orderDesc);
        coinRmbSilverLogDao.save(silverLog);

        // 返利佰德砖
        this.accountTransferService.rebateSilver(usrDetail.getUserId(), orderNo, coins);
    }

    /**
     * 处理个人账户消费正常的返还银币
     * @Title: saveUserRebate
     * @Description: TODO
     * @param @param usrDetail
     * @param @param prodRebate
     * @param @param prodId
     * @param @param totalAmount
     * @param @param cash
     * @param @param price
     * @param @param orderNo
     * @param @param prodNum
     * @param @param nowTime
     * @param @throws Exception   
     * @return void 
     * @author huxianjun 2016年8月12日 
     * @throws
     */
    public BigDecimal getUserBasicRebate(UsrDetail usrDetail, String orderDesc, BigDecimal prodRebate,
            BigDecimal prodAdRate, Integer prodId, BigDecimal totalAmount, BigDecimal cash, BigDecimal price,
            String orderNo, Integer prodNum, Date nowTime) throws Exception {
        logger.info("开始计算个人账户的银币，计算订单类型：" + orderDesc + ",用户ID:" + usrDetail.getUserId());
        BigDecimal rebate = calRebateService.calRebate(prodAdRate, new BigDecimal(NhsConstant.DEFAULT_AD_FEE_BASIC_RATE), NhsConstant.DEFAULT_AD_FEE_RATE_NEW_MAX_O2O);//this.calRebate(prodRebate);
        BigDecimal totalRebateCash = totalAmount.multiply(rebate);
        BigDecimal coins = totalRebateCash.multiply(new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE));
        return coins.setScale(2, BigDecimal.ROUND_DOWN);
    }

    /**
     * 处理参加活动个人账户返还的金币
     * @Title: saveUserRebate
     * @Description: TODO
     * @param @param usrDetail
     * @param @param prodRebate
     * @param @param prodId
     * @param @param totalAmount
     * @param @param cash
     * @param @param price
     * @param @param orderNo
     * @param @param prodNum
     * @param @param nowTime
     * @param @throws Exception   
     * @return void 
     * @author huxianjun 2016年8月12日 
     * @throws
     */
    public void saveActivityUserGoldRebate(GoldSchoolRegsDto dto, String activityTitle, String orderNo, Integer prodId,
            Date nowTime, Integer activityId) throws Exception {
        logger.info("开始计算个人账户的金币，活动类型：" + activityTitle);

        UsrDetail usrDetail = this.userService.findUserById(dto.getInviteeUserId());
        if (usrDetail != null) {

            UsrDetail usrDetail1 = this.userService.findUserById(dto.getInviterUserId());
            if (usrDetail1 != null) {
                ActivitySchool school = schoolDao.findByInviteeUserMobileAndInviterUserId(usrDetail.getUserMobile(),
                        dto.getInviterUserId());
                if (school == null) {
                    logger.info("邀请者用户ID：" + dto.getInviterUserId() + "和被邀请者用户ID：" + dto.getInviteeUserId()
                            + "不存在绑定关系，不返金币。");
                } else if (school != null && school.getRebateStatus() != 0) {
                    logger.info("邀请者用户ID：" + dto.getInviterUserId() + "和被邀请者用户ID：" + dto.getInviteeUserId()
                            + "已返还过返金币，不继续返");
                } else {
                	UserAllAccDto userAllAcc = this.accountTransferService.findUserAllAcc(usrDetail1.getUserId());
                    // 被邀请者返利佰德券
                    BigDecimal inviteeCoins = new BigDecimal(dto.getInviteeGold());
                    insertGoldTransferLog(dto.getInviteeUserId(), inviteeCoins, activityId, activityTitle, orderNo,
                            prodId, nowTime);

                    logger.info("被邀请者用户ID：" + dto.getInviterUserId() + "，手机号为：" + usrDetail.getUserMobile() + "开始返还金币："
                            + inviteeCoins + ",初始金币:" + userAllAcc.getPGold());
                    // userDetailDao.selectLock(dto.getInviteeUserId());
                    // userDetailDao.updateUserGold(dto.getInviteeUserId(), inviteeCoins);
                    this.accountTransferService.rebateGold(dto.getInviteeUserId(), orderNo, inviteeCoins);

                    // 邀请者返利佰德券
                    BigDecimal inviterCoins = new BigDecimal(dto.getInviterGold());
                    insertGoldTransferLog(dto.getInviterUserId(), inviterCoins, activityId, activityTitle, orderNo,
                            prodId, nowTime);

                    logger.info("邀请者用户ID：" + dto.getInviterUserId() + "开始返还金币：" 
                    		+ inviterCoins + ",初始金币:" + userAllAcc.getPGold());

                    // userDetailDao.selectLock(dto.getInviterUserId());
                    // userDetailDao.updateUserGold(dto.getInviterUserId(), inviterCoins);
                    this.accountTransferService.rebateGold(dto.getInviterUserId(), orderNo, inviterCoins);

                    logger.info("邀请者用户ID：" + dto.getInviterUserId() + "和被邀请者用户ID：" + dto.getInviteeUserId()
                            + "开始更新返还佰德券状态。");
                    school.setRebateStatus(1);
                    schoolDao.save(school);
                }
            } else {
                logger.info("邀请者用户ID：" + dto.getInviterUserId() + "不存在，不返银币，更新ActivitySchool返银币状态为已返！");
            }
        } else {
            logger.info("被邀请者用户ID：" + dto.getInviteeUserId() + "不存在，不返银币，不更新ActivitySchool返银币状态！");
        }
    }

    private void insertGoldTransferLog(String userId, BigDecimal addGoldNum, Integer activityId, String activityTitle,
            String orderNo, Integer prodId, Date nowTime) {
        CoinRmbGoldLog goldLog = new CoinRmbGoldLog();
        goldLog.setSubNumber(orderNo);
        goldLog.setProdId(prodId);
        goldLog.setCreateTime(nowTime);
        goldLog.setUserId(userId);
        goldLog.setGoldSum(addGoldNum);
        goldLog.setType(1); // 普通用户
        goldLog.setActivityId(activityId);
        goldLog.setActivityTitle(activityTitle);
        coinRmbGoldLogDao.save(goldLog);
    }

    /**
     * 计算赠送比例
     * @Title: calRebate
     * @Description: TODO
     * @param @param prodRebate
     * @param @return   
     * @return BigDecimal 
     * @author huxianjun 2016年11月1日 
     * @throws
     */
//    private BigDecimal calRebate(BigDecimal prodRebate) {
//        BigDecimal rebate = BigDecimal.valueOf(0.00);
//        if (prodRebate != null) {
//            if (BigDecimal.valueOf(rebate_rate_min).compareTo(prodRebate) <= 0
//                    && BigDecimal.valueOf(rebate_rate_max).compareTo(prodRebate) >= 0) {
//                rebate = prodRebate;
//            } else if (BigDecimal.valueOf(rebate_rate_max).compareTo(prodRebate) < 0) {
//                rebate = BigDecimal.valueOf(rebate_rate_max);
//            }
//        }
//        return rebate;
//    }
}
