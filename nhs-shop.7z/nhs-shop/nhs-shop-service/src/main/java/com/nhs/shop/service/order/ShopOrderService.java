package com.nhs.shop.service.order;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nhs.core.orm.Page;
import com.nhs.shop.dao.legend.shop.InvoiceDao;
import com.nhs.shop.entry.em.PayTypeEnum;
import com.nhs.shop.entry.legend.shop.Invoice;
import com.nhs.shop.service.BaseService;
import com.nhs.shop.service.order.dto.OrderAddRequestDto;
import com.nhs.shop.service.order.dto.OrderCommAddRequestDto;
import com.nhs.shop.service.order.dto.OrderConfirmDto;
import com.nhs.shop.service.order.dto.OrderConfirmRequestDto;
import com.nhs.shop.service.order.dto.OrderDetailDto;
import com.nhs.shop.service.order.dto.OrderListDto;
import com.nhs.shop.service.order.shop.internal.ShopOrderAddService;
import com.nhs.shop.service.order.shop.internal.ShopOrderCommService;
import com.nhs.shop.service.order.shop.internal.ShopOrderConfirmService;
import com.nhs.shop.service.order.shop.internal.ShopOrderDetailService;
import com.nhs.shop.service.order.shop.internal.ShopOrderListService;
import com.nhs.shop.service.order.shop.internal.ShopOrderOperateService;

/**
 * 商城订单service
 * @Title: GoodsService.java
 * @Package com.nhs.shop.service.goods
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月16日 下午7:42:18
 * @version V1.0
 */
@Service
@Transactional
public class ShopOrderService extends BaseService {

    @Autowired
    private ShopOrderConfirmService shopOrderConfirmService;

    @Autowired
    private ShopOrderAddService shopOrderAddService;

    @Autowired
    private ShopOrderListService shopOrderListService;

    @Autowired
    private ShopOrderDetailService shopOrderDetailService;

    @Autowired
    private ShopOrderOperateService shopOrderOperateService;

    @Autowired
    private ShopOrderCommService shopOrderCommService;

    @Autowired
    private InvoiceDao invoiceDao;

    @Autowired
    private OrderHandleAfterPayService orderHandleAfterPayService;
    
    /**
     * 获取订单确认信息
     * @Title: getOrderConfirm
     * @Description: TODO
     * @param @param dto
     * @param @return   
     * @return OrderConfirmDto 
     * @author Administrator 2016年7月19日 
     * @throws
     */
    public OrderConfirmDto getOrderConfirm(OrderConfirmRequestDto dto) {
        return shopOrderConfirmService.getOrderConfirm(dto);
    }

    /**
     * 创建商城订单
     * @Title: saveShopOrder
     * @Description: TODO
     * @param @param dto
     * @param @return   
     * @return Map<String,Object> 
     * @author Administrator 2016年7月20日 
     * @throws
     */
    public Map<String, Object> saveShopOrder(OrderAddRequestDto dto, String platformType) {
        return shopOrderAddService.saveShopOrder(dto, platformType);
    }

    /**
     * 获取订单列表
     * @Title: getOrderList
     * @Description: TODO
     * @param @param userId
     * @param @param status
     * @param @param page
     * @param @return   
     * @return List<OrderListDto> 
     * @author Administrator 2016年7月20日 
     * @throws
     */
    public List<OrderListDto> getOrderList(String userId, Integer status, Page<Map<String, Object>> page) {
        return shopOrderListService.getOrderList(userId, status, page);
    }

    /**
     * 获取订单详情
     * @Title: getOrderDetail
     * @Description: TODO
     * @param @param userId
     * @param @param orderId
     * @param @return   
     * @return OrderDetailDto 
     * @author Administrator 2016年7月20日 
     * @throws
     */
    public OrderDetailDto getOrderDetail(String userId, Integer orderId) {
        return shopOrderDetailService.getOrderDetail(userId, orderId);
    }

    /**
     * 获取订单支付总额
     * @Title: getOrderPayAmount
     * @Description: TODO
     * @param @param orderNum
     * @param @return   
     * @return double 
     * @author Administrator 2016年7月21日 
     * @throws
     */
    public double getOrderPayAmount(String orderNum) {
        return shopOrderAddService.getOrderPayAmount(orderNum);
    }

    /**
     * 订单操作
     * @Title: doOrderOperate
     * @Description: TODO
     * @param @param userId
     * @param @param subId
     * @param @param operate   
     * @return void 
     * @author Administrator 2016年7月22日 
     * @throws
     */
    public void doOrderOperate(String userId, Integer subId, String operate, String refundReason) {
        shopOrderOperateService.dealOrderOperate(userId, subId, operate, refundReason);
    }

    /**
     * 保存订单评价
     * @Title: saveShopOrderComm
     * @Description: TODO
     * @param @param dto   
     * @return void 
     * @author Administrator 2016年7月22日 
     * @throws
     */
    public void saveShopOrderComm(OrderCommAddRequestDto dto) {
        shopOrderCommService.saveShopOrderComm(dto);
    }

    /**
     * 保存订单评价
     * @Title: saveShopOrderComm
     * @Description: TODO
     * @param @param dto   
     * @return void 
     * @author Administrator 2016年7月22日 
     * @throws
     */
    public void saveShopOrderCommList(OrderCommAddRequestDto dto) {
        shopOrderCommService.saveShopOrderCommList(dto);
    }

    /**
     * 处理订单支付成功
     * @Title: handleOrderPay
     * @Description: TODO
     * @param @param orderNum
     * @param @param payAmount   
     * @return void 
     * @author Administrator 2016年7月28日 
     * @throws
     */
    @Deprecated
    public void handleOrderPay(String orderNum, String payAmount, String payTypeName,int payType,String payNo) {
        shopOrderAddService.handleOrderPay(orderNum, payAmount, payTypeName,0,"");
    }

    /**
     * 
     * @Title: findArriageShow
     * @Description: TODO
     * @param @param orderNumber
     * @param @return   
     * @return Map<String,Object> 
     * @author liangdanhua 2016年8月19日 
     * @throws
     */
    public Map<String, Object> findArriageShow(Integer orderNumber) {
        Map<String, Object> map = shopOrderAddService.findArriageShow(orderNumber);
        return map;
    }

    /**
     * 
     * @Title: clacCartDeleivery
     * @Description: TODO
     * @param @param cityId
     * @param @param prodId
     * @param @param count
     * @param @param deliveType
     * @param @return   
     * @return BigDecimal 
     * @author liangdanhua 2016年8月22日 
     * @throws
     */

    public BigDecimal clacCartDeleivery(int cityId, int prodId, int count, String deliveType) {
        double sportFree = shopOrderDetailService.clacCartDeleivery(cityId, prodId, count, deliveType);
        return new BigDecimal(sportFree);
    }

    /**
     * 
     * @Title: saveInvoice
     * @Description: TODO
     * @param @param dto
     * @param @return   
     * @return Integer 
     * @author Cary 2016年8月23日 
     * @throws
     */
    public Integer saveInvoice(OrderAddRequestDto dto) {
        Invoice invoice = new Invoice();
        invoice.setUserId(dto.getUserId());
        invoice.setUserName(dto.getUserName());
        invoice.setTypeId(dto.getInvoiceType());
        invoice.setTitleId(dto.getInvoiceTitle());
        invoice.setCompany(dto.getInvoiceCompany());
        invoice.setContentId(dto.getInvoiceContentId());
        invoice.setRecPhone(dto.getInvoiceRecPhone());
        invoice.setRecEmail(dto.getInvoiceRecEmail());
        invoice.setCreateTime(new Date());
        invoice = invoiceDao.save(invoice);
        return invoice.getId();
    }

}
