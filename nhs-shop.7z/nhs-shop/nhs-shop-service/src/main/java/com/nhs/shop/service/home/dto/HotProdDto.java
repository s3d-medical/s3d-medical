package com.nhs.shop.service.home.dto;

import java.io.Serializable;

/**
 *  热卖商品 dto
 * @Title: HotProdDto.java
 * @Package com.nhs.shop.service.home.dto
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月16日 下午5:31:53
 * @version V1.0
 */
public class HotProdDto implements Serializable {

    private static final long serialVersionUID = 2261337449759349600L;

    private Integer prodId = 0;
    private String image = "";
    private String title = "";
    private String price = "0";
    private Integer buys = 0;
    private String detailUrl = "";
    private String mailStatus = "包邮";
    private String subsidy = ""; // 补贴
    private String subsidyStr = "";

    public Integer getProdId() {
        return prodId;
    }

    public void setProdId(Integer prodId) {
        this.prodId = prodId;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public Integer getBuys() {
        return buys;
    }

    public void setBuys(Integer buys) {
        this.buys = buys;
    }

    public String getDetailUrl() {
        return detailUrl;
    }

    public void setDetailUrl(String detailUrl) {
        this.detailUrl = detailUrl;
    }

    public String getMailStatus() {
        return mailStatus;
    }

    public void setMailStatus(String mailStatus) {
        this.mailStatus = mailStatus;
    }

    public String getSubsidy() {
        return subsidy;
    }

    public void setSubsidy(String subsidy) {
        this.subsidy = subsidy;
    }

	public String getSubsidyStr() {
		return subsidyStr;
	}

	public void setSubsidyStr(String subsidyStr) {
		this.subsidyStr = subsidyStr;
	}
    
    

}
