package com.nhs.shop.service.pay;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.Maps;
import com.nhs.apiproxy.member.acc.datatype.CurrencyEnum;
import com.nhs.apiproxy.member.acc.dto.UserAllAccDto;
import com.nhs.apiproxy.member.acc.service.AccountTransferService;
import com.nhs.core.utils.common.ArithUtils;
import com.nhs.core.utils.common.RandomUtils;
import com.nhs.core.web.WebRequestException;
import com.nhs.shop.dao.legend.pay.PayRecordDao;
import com.nhs.shop.entry.em.order.OrderCodeEnum;
import com.nhs.shop.entry.em.order.PayRecordStatusEnum;
import com.nhs.shop.entry.legend.pay.PayRecord;
import com.nhs.shop.entry.legend.shop.ShopDetail;
import com.nhs.shop.entry.legend.user.UsrDetail;
import com.nhs.shop.generator.OrderNumGenerator;
import com.nhs.shop.service.BaseOrderDto;
import com.nhs.shop.service.BaseOrderService;
import com.nhs.user.dto.MemberAccountDto;
import com.nhs.user.dto.MemberDetailDto;
import com.nhs.user.service.MemberService;
import com.nhs.user.service.OperateUserAccountService;
import com.nhs.user.service.UserService;
import com.nhs.core.common.NhsConstant;

@Service
public class PayRecordService extends BaseOrderService {

    @Autowired
    private PayRecordDao payRecordDao;

    @Autowired
    private UserService userService;

    @Autowired
    private OperateUserAccountService userAccountService;

    @Autowired
    private AccountTransferService accountService;
    
    @Autowired
    private MemberService memberService;

    /**
     * 保存支付流水记录
     * @Title: savePayRecord
     * @Description: TODO
     * @param @param userId
     * @param @param shopId
     * @param @param totalAmount   
     * @return void 
     * @author Administrator 2016年11月16日 
     * @throws
     */
    public Map<String, Object> savePayRecord(String userId, ShopDetail shop, Double totalAmount, String platformType,
            BigDecimal couponMoney, int couponType, String deskNo) {
        UsrDetail user = this.userService.findUserById(userId);
        if (user == null) {
            throw new WebRequestException("userId不存在");
        }
        
        couponMoney = new BigDecimal("0.00");
//        //抵用券
//        if(couponType != 0){
//        	if(user.getGold().compareTo(couponMoney.multiply(new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE))) < 0){
//        		throw new WebRequestException("抵用券数量不足");
//        	}
//        }
        PayRecord order = new PayRecord();
        String orderNum = OrderNumGenerator.getOrderNumber(user.getUserMobile(), OrderCodeEnum.STORE_PAY_RECORD_ORDER);
        order.setOrderNo(orderNum);
        order.setPaymentOrderNo(orderNum);
        order.setShopId(shop.getShopId());
        order.setShopName(shop.getSiteName());
        order.setUserId(userId);
        order.setOrderState(PayRecordStatusEnum.UNPAY.getStatus());
        order.setPaymentState(PayRecordStatusEnum.UNPAY.getStatus());
        order.setSubName("商超订单支付");
        order.setPaymentState(0);
        order.setCreateTime(new Date());
        order.setInvalidTime(DateUtils.addMinutes(new Date(), 30));
        order.setMatchState(0);
        order.setDeskNo(deskNo);

        BigDecimal payAmount = BigDecimal.valueOf(totalAmount);
        
        MemberDetailDto memberDto = memberService.getUserDetailByUserId(userId);
        BigDecimal gold = new BigDecimal("0.00");
        if(memberDto != null){
        	gold = memberDto.getAccountByType(CurrencyEnum.CURRENCY_GOLD_COIN.getCurrency());
        }
       
        //付款金额减去白德券抵用金额
        if(couponType != 0){
	        if(gold.compareTo(payAmount) >= 0){
	        	couponMoney = payAmount;
	        	payAmount = new BigDecimal("0.00");
	        }else{
	        	couponMoney = gold;
	        	payAmount = ArithUtils.sub2(payAmount, couponMoney, 2, BigDecimal.ROUND_DOWN);
	        }
        }
//        payAmount = ArithUtils.sub2(payAmount, couponMoney, 2, BigDecimal.ROUND_DOWN);
        order.setTotalMoney(BigDecimal.valueOf(totalAmount));
        order.setPaymentMoney(payAmount);
        order.setCouponMoney(couponMoney);

        PayRecord newOrder = payRecordDao.save(order);

        // 生成订单时暂时把个人账户的佰德券转冻结起来，支付成功后扣除，如果未支付，将给他释放冻结部分
        if (couponType != 0) {
            // boolean flag = userAccountService.goldFreeze(couponMoney.multiply(new BigDecimal(100)), userId);
            boolean flag = userAccountService.freezeGold(userId, orderNum, couponMoney.multiply(new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE)));
            if (!flag) {
                // 个人账户抵用券余额不足
                throw new WebRequestException("抵用券数量不足");
            }
        }
        // 返回结果
        Map<String, Object> map = Maps.newHashMap();
        map.put("orderId", newOrder.getId());
        map.put("orderNum", orderNum);
        map.put("totalAmount", payAmount);
        return map;
    }

    @Override
    public void handleOrderPay(String orderNum, String payAmount, String payTypeName, int payType, String payOrderNo) {
        PayRecord order = payRecordDao.findByOrderNo(orderNum);
        if (order == null) {
            throw new WebRequestException("订单不存在");
        }

        // 支付成功，冻结的佰德券直接扣除
        // UsrDetail usrDetail = this.userService.findUserById(order.getUserId());
        this.userAccountService.reductFrozenGold(order.getUserId(), order.getOrderNo(),
                order.getCouponMoney().multiply(new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE)));
        // usrDetail.setGoldFreeze(usrDetail.getGoldFreeze().subtract(order.getCouponMoney().multiply(new
        // BigDecimal(100))));
        // userDetailDao.save(usrDetail);

        order.setOrderState(PayRecordStatusEnum.PADYED.getStatus());
        order.setPaymentState(PayRecordStatusEnum.PADYED.getStatus());
        order.setPaymentOrderNo(payOrderNo);
        order.setPaymentPayTime(new Date());
        order.setPaymentType(payType);
        order.setPayMentTypeName(payTypeName);
        String validateCode = RandomUtils.getRandomStr(6) + order.getDeskNo();
        order.setValidateCode(validateCode);
        payRecordDao.saveAndFlush(order);

    }

    @Override
    public double getOrderPayAmount(String orderNum) {
        PayRecord order = payRecordDao.findByOrderNo(orderNum);
        if (order != null) {
            return order.getPaymentMoney().doubleValue();
        }
        return 0;
    }

    @Override
    public void verifyOrder(String userId, String orderNum) {
        // TODO Auto-generated method stub

    }

    public List<PayRecord> getPayRecordListBy(int shopId, String userId) {
        return payRecordDao.findPayRecordList(shopId, userId);
    }

    public String getValidateCodeByOrderNo(String orderNo) {
        PayRecord payRecord = payRecordDao.findByOrderNo(orderNo);
        String validateCode = "";
        if (payRecord != null) {
            validateCode = payRecord.getValidateCode();
        }
        return validateCode;
    }

    public PayRecord getPayRecordByOrderNo(String orderNo) {
        PayRecord payRecord = payRecordDao.findByOrderNo(orderNo);
        return payRecord;
    }

    @Override
    public BaseOrderDto getBaseOrderDto(String orderNum) {
        PayRecord order = payRecordDao.findByOrderNo(orderNum);
        if (order != null) {
            BaseOrderDto baseOrderDto = new BaseOrderDto();
            baseOrderDto.setOrderNum(orderNum);
            baseOrderDto.setUserId(order.getUserId());
            return baseOrderDto;
        }
        return null;
    }

}
