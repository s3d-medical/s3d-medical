package com.nhs.shop.service.system.dto.sysconfig;

import java.io.Serializable;

/**
 * 支付相关的配置.
 * @author wind.chen
 */
public class PayConfigDto implements Serializable {
	private static final long serialVersionUID = -6144772923584426167L;
	private PayRedirectUrls redirectUrls;
	
	public PayRedirectUrls getRedirectUrls() {
		return redirectUrls;
	}

	public void setRedirectUrls(PayRedirectUrls redirectUrls) {
		this.redirectUrls = redirectUrls;
	}

	/**
	 * 支付完毕后, 客户端redirect地址.  
	 * @author wind.chen
	 */
	public static class PayRedirectUrls implements Serializable{
		private static final long serialVersionUID = 3224477994102783794L;
		private String payOrderResult;
		public String getPayOrderResult() {
			return payOrderResult;
		}
		public void setPayOrderResult(String payOrderResult) {
			this.payOrderResult = payOrderResult;
		}
	}
}
