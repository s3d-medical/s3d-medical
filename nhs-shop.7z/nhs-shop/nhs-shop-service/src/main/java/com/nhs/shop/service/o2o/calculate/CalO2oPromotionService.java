package com.nhs.shop.service.o2o.calculate;

import java.math.BigDecimal;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nhs.core.common.NhsConstant;
import com.nhs.core.context.SysPropsFactory;
import com.nhs.core.utils.common.ArithUtils;
import com.nhs.shop.entry.legend.service.O2oServiceOrder;
import com.nhs.shop.entry.legend.shop.ShopDetail;
import com.nhs.shop.rebate.service.CalRebateService;
import com.nhs.shop.service.order.dto.ServiceOrderDetailDto;
import com.nhs.shop.service.shop.dto.O2oShopDetailDto;
import com.nhs.shop.service.shop.dto.ShopDto;
import com.nhs.shop.service.system.SystemParameterService;

/**
 * 计算商家促销信息
 * @author Administrator
 *
 */
@Service
@Transactional
public class CalO2oPromotionService {
	
	@Autowired
    private SystemParameterService sysService;
	
	@Autowired
    private CalRebateService calRebateService;
	
	/**
     * 计算o2o商家列表的立减和抵用券
     * @param shopDto
     * @param shop
     */
    public void calShopCoupon(ShopDto shopDto,ShopDetail shop){
    	if(shop.getAdFeeRate() == null){
        	shop.setAdFeeRate(new BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE));
        }
        if(shop.getAdFeeBasicRate() == null){
        	shop.setAdFeeBasicRate(new BigDecimal(NhsConstant.DEFAULT_AD_FEE_BASIC_RATE));
        }
        //商家推广费率<=16%时，按照之前规则赠送给用户佰德钻；商家推广费率>16%时，超出比例部分做立减
        if(shop.getAdFeeRate().compareTo(new BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE_CRITICAL_O2O)) > 0){
        	shopDto.setReduce(ArithUtils.sub2(shop.getAdFeeRate(), new BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE_CRITICAL_O2O),3,BigDecimal.ROUND_DOWN).toString());
//        	shop.setRebate(new BigDecimal(NhsConstant.DEFAULT_REBATE_O2O));
        	shopDto.setDiscount(SysPropsFactory.getProperty(NhsConstant.SYS_CONSUME_REDUCE_LABEL));
        }else{
        	shopDto.setReduce("");
        	shopDto.setDiscount("");
//        	shop.setRebate(ArithUtils.div2(shop.getAdFeeRate(), shop.getAdFeeBasicRate(), 3,BigDecimal.ROUND_DOWN));
        }
        shop.setRebate(calRebateService.calRebate(shop.getAdFeeRate(), shop.getAdFeeBasicRate(), NhsConstant.DEFAULT_AD_FEE_RATE_NEW_MAX_O2O));
        shopDto.setSubsidy(shop.getRebate().multiply(new BigDecimal("100")).setScale(0, BigDecimal.ROUND_DOWN)+"%");
        shopDto.setSubsidyStr(sysService.getSingleValueByType(NhsConstant.PARAM_PRESENT_SIGN) + shopDto.getSubsidy());
        if(StringUtils.isEmpty(shopDto.getReduce())){
        	shopDto.setDiscountStr("");
        }else{
        	String reduceFont = SysPropsFactory.getProperty(NhsConstant.SYS_CONSUME_REDUCE_FONT);
        	if(StringUtils.isEmpty(reduceFont)){
        		shopDto.setDiscountStr("");
        	}else{
        		reduceFont = reduceFont.replace("#", new BigDecimal(shopDto.getReduce()).multiply(new BigDecimal("100")).setScale(0, BigDecimal.ROUND_DOWN) + "%");
        		shopDto.setDiscountStr(reduceFont);
        	}
        }
        String couponFont = SysPropsFactory.getProperty(NhsConstant.SYS_COUPON_FONT);
    	if(StringUtils.isEmpty(couponFont)){
    		shopDto.setCouponStr("");
    	}else{
    		couponFont = couponFont.replace("#", shopDto.getSubsidy());
    		shopDto.setCouponStr(couponFont);
    	}
        shopDto.setCoupon(SysPropsFactory.getProperty(NhsConstant.SYS_COUPON_LABEL));
        
        if(shop.getShopDiscountRate().compareTo(new BigDecimal(NhsConstant.DEFAULT_SHOP_DISCOUNT_RATE_O2O)) < 0 && shop.getShopDiscountRate().compareTo(new BigDecimal(0)) > 0){
        	shopDto.setShopDiscount(SysPropsFactory.getProperty(NhsConstant.SYS_SHOP_DISCOUNT_LABEL_O2O));
        	String shopDiscountFont = SysPropsFactory.getProperty(NhsConstant.SYS_SHOP_DISCOUNT_FONT_O2O);
        	String shopDiscountRate = shop.getShopDiscountRate().multiply(BigDecimal.valueOf(10)).setScale(2,BigDecimal.ROUND_DOWN).toString();
        	shopDiscountFont = shopDiscountFont.replace("#", shopDiscountRate+"折");
        	shopDto.setShopDiscountStr(shopDiscountFont);
        	shopDto.setShopDiscountRate(shop.getShopDiscountRate().toString());
        }else{
        	shopDto.setShopDiscount("");
        }
    }
    
    
    
    
    /**
     * 计算o2o商家详情的立减和抵用券
     * @param shopDto
     * @param shop
     */
    public void calShopDetailCoupon(O2oShopDetailDto osdd,ShopDetail shop){
    	if(shop.getAdFeeRate() == null){
        	shop.setAdFeeRate(new BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE));
        }
        if(shop.getAdFeeBasicRate() == null){
        	shop.setAdFeeBasicRate(new BigDecimal(NhsConstant.DEFAULT_AD_FEE_BASIC_RATE));
        }
        //商家推广费率<=16%时，按照之前规则赠送给用户佰德钻；商家推广费率>16%时，超出比例部分做立减
        if(shop.getAdFeeRate().compareTo(new BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE_CRITICAL_O2O)) > 0){
        	osdd.setReduce(ArithUtils.sub2(shop.getAdFeeRate(), new BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE_CRITICAL_O2O),3,BigDecimal.ROUND_DOWN).toString());
//        	shop.setRebate(new BigDecimal(NhsConstant.DEFAULT_REBATE_O2O));
        	osdd.setDiscount(SysPropsFactory.getProperty(NhsConstant.SYS_CONSUME_REDUCE_LABEL));
        }else{
        	osdd.setReduce("");
        	osdd.setDiscount("");
//        	shop.setRebate(ArithUtils.div2(shop.getAdFeeRate(), shop.getAdFeeBasicRate(), 3,BigDecimal.ROUND_DOWN));
        }
        shop.setRebate(calRebateService.calRebate(shop.getAdFeeRate(), shop.getAdFeeBasicRate(), NhsConstant.DEFAULT_AD_FEE_RATE_NEW_MAX_O2O));
        osdd.setCoupon(SysPropsFactory.getProperty(NhsConstant.SYS_COUPON_LABEL));
        osdd.setSubsidy(shop.getRebate().multiply(new BigDecimal("100")).setScale(0, BigDecimal.ROUND_DOWN) + "%");
        osdd.setSubsidyStr(sysService.getSingleValueByType(NhsConstant.PARAM_PRESENT_SIGN) + osdd.getSubsidy());
        if(shop.getShopDiscountRate().compareTo(new BigDecimal(NhsConstant.DEFAULT_SHOP_DISCOUNT_RATE_O2O)) < 0 && shop.getShopDiscountRate().compareTo(new BigDecimal(0)) > 0){
        	osdd.setShopDiscount(SysPropsFactory.getProperty(NhsConstant.SYS_SHOP_DISCOUNT_LABEL_O2O));
        	String shopDiscountFont = SysPropsFactory.getProperty(NhsConstant.SYS_SHOP_DISCOUNT_FONT_O2O);
        	String shopDiscountRate = shop.getShopDiscountRate().multiply(BigDecimal.valueOf(10)).setScale(2,BigDecimal.ROUND_DOWN).toString();
        	shopDiscountFont = shopDiscountFont.replace("#", shopDiscountRate+"折");
        	osdd.setShopDiscountStr(shopDiscountFont);
        	osdd.setShopDiscountRate(shop.getShopDiscountRate().toString());
        }else{
        	osdd.setShopDiscount("");
        	osdd.setShopDiscountRate(NhsConstant.DEFAULT_SHOP_DISCOUNT_RATE_O2O);
        }
    }
    
    
    /**
     * 计算o2o商家订单列表和详情立减标志和抵用券标志
     * @param shopDto
     * @param shop
     */
    public void calOrderDetailCoupon(ServiceOrderDetailDto orderDto,ShopDetail shop){
    	if(shop.getAdFeeRate() == null){
        	shop.setAdFeeRate(new BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE));
        }
        if(shop.getAdFeeBasicRate() == null){
        	shop.setAdFeeBasicRate(new BigDecimal(NhsConstant.DEFAULT_AD_FEE_BASIC_RATE));
        }
        //商家推广费率<=16%时，按照之前规则赠送给用户佰德钻；商家推广费率>16%时，超出比例部分做立减
        if(shop.getAdFeeRate().compareTo(new BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE_CRITICAL_O2O)) > 0){
        	orderDto.setDiscount(SysPropsFactory.getProperty(NhsConstant.SYS_CONSUME_REDUCE_LABEL));
        }else{
        	orderDto.setDiscount("");
        }
    	orderDto.setCoupon(SysPropsFactory.getProperty(NhsConstant.SYS_COUPON_LABEL));
    	String couponFont = SysPropsFactory.getProperty(NhsConstant.SYS_COUPON_ORDER_FONT);
    	if(StringUtils.isEmpty(couponFont)){
    		orderDto.setCouponStr("");
    	}else{
    		couponFont = couponFont.replace("#", new BigDecimal(orderDto.getPayAmountStr()).multiply(orderDto.getRebate()).setScale(2, BigDecimal.ROUND_DOWN).multiply(new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE)).toString());
    		orderDto.setCouponStr(couponFont);
    	}
    	if(new BigDecimal(orderDto.getShopDiscountRate()).compareTo(new BigDecimal(NhsConstant.DEFAULT_SHOP_DISCOUNT_RATE_O2O)) < 0 && new BigDecimal(orderDto.getShopDiscountRate()).compareTo(new BigDecimal(0)) > 0){
    		orderDto.setShopDiscount(SysPropsFactory.getProperty(NhsConstant.SYS_SHOP_DISCOUNT_LABEL_O2O));
        	String shopDiscountFont = SysPropsFactory.getProperty(NhsConstant.SYS_SHOP_DISCOUNT_FONT_O2O);
        	String shopDiscountRate = shop.getShopDiscountRate().multiply(BigDecimal.valueOf(10)).setScale(2,BigDecimal.ROUND_DOWN).toString();
        	shopDiscountFont = shopDiscountFont.replace("#", shopDiscountRate+"折");
        	orderDto.setShopDiscountStr(shopDiscountFont);
        }else{
        	orderDto.setShopDiscount("");
        }
    }
    
    /**
     * 计算o2o商家生成订单时立减金额和付款金额
     * @param shopDto
     * @param shop
     */
    public void calOrderAddPayAmount(O2oServiceOrder order,ShopDetail shop,BigDecimal payAmount,BigDecimal couponMoney,int consumeReduceType){
    	 if(shop.getAdFeeRate() == null){
         	shop.setAdFeeRate(new BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE));
         }
         if(shop.getAdFeeBasicRate() == null){
         	shop.setAdFeeBasicRate(new BigDecimal(NhsConstant.DEFAULT_AD_FEE_BASIC_RATE));
         }
         
         BigDecimal shopDiscountMoney = new BigDecimal("0.00");
         
         if(shop.getShopDiscountRate().compareTo(new BigDecimal(NhsConstant.DEFAULT_SHOP_DISCOUNT_RATE_O2O)) < 0 && shop.getShopDiscountRate().compareTo(new BigDecimal(0)) > 0){
        	 shopDiscountMoney = (payAmount.subtract(order.getDiscountBeyondMoney())).multiply(BigDecimal.valueOf(1).subtract(shop.getShopDiscountRate())).setScale(2, BigDecimal.ROUND_DOWN);
         }
         order.setShopDiscountRate(shop.getShopDiscountRate());
         order.setShopDiscountMoney(shopDiscountMoney);
         payAmount = payAmount.subtract(shopDiscountMoney);
         
         //商家推广费率<=16%时，按照之前规则赠送给用户佰德钻；商家推广费率>16%时，超出比例部分做立减
         if(shop.getAdFeeRate().compareTo(new BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE_CRITICAL_O2O)) > 0){
         	if(consumeReduceType != 0){ 	//已经勾选消费立减选项
         		BigDecimal reduce = ArithUtils.sub2(shop.getAdFeeRate(), new BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE_CRITICAL_O2O),3,BigDecimal.ROUND_DOWN); //立减百分比
         		BigDecimal reduceMoney = ArithUtils.mul2(payAmount, reduce, 2, BigDecimal.ROUND_DOWN);  //立减金额
         		payAmount = ArithUtils.sub2(payAmount, reduceMoney, 2, BigDecimal.ROUND_DOWN);
         		order.setReduceAmount(reduceMoney);
         	}
//         	shop.setRebate(new BigDecimal(NhsConstant.DEFAULT_REBATE_O2O));
         }else{
//         	shop.setRebate(ArithUtils.div2(shop.getAdFeeRate(), shop.getAdFeeBasicRate(), 3, BigDecimal.ROUND_DOWN));
         }
         shop.setRebate(calRebateService.calRebate(shop.getAdFeeRate(), shop.getAdFeeBasicRate(), NhsConstant.DEFAULT_AD_FEE_RATE_NEW_MAX_O2O));
         //付款金额减去白德券抵用金额
         payAmount = ArithUtils.sub2(payAmount, couponMoney, 2, BigDecimal.ROUND_DOWN);
         order.setPayAmount(payAmount);
    }
}
