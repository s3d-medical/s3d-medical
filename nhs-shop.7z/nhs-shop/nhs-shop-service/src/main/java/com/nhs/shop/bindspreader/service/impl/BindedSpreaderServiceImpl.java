package com.nhs.shop.bindspreader.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nhs.core.utils.common.StringHelper;
import com.nhs.core.web.WebRequestException;
import com.nhs.shop.account.UserAccService;
import com.nhs.shop.bindspreader.dao.BindedSpreaderDao;
import com.nhs.shop.bindspreader.dto.BindedSpreaderDto;
import com.nhs.shop.bindspreader.entity.BindedSpreader;
import com.nhs.shop.bindspreader.service.BindedSpreaderService;
import com.nhs.shop.bindspreader.util.Gift;
import com.nhs.shop.bindspreader.util.LotteryUtil;
import com.nhs.shop.entry.legend.shop.ShopDetail;
import com.nhs.shop.entry.legend.user.UsrDetail;
import com.nhs.shop.service.shop.ShopService;
import com.nhs.user.service.UserService;

@Service
@Transactional
public class BindedSpreaderServiceImpl implements BindedSpreaderService {
	private ShopService shopService;
	private BindedSpreaderDao bindedAgentDao;
	private UserAccService userAccService;
	private UserService userService;
	
	@Override
	public boolean bindSpreader(BindedSpreaderDto bindedAgentDto) {
		// 1 check precondition.
		this.checkBeforeBinding(bindedAgentDto);
		
		// 2 check whether current user has been registered.
		UsrDetail usrDetail = this.userService.findUserByMobile(bindedAgentDto.getMobileNo());//this.usrDetailDao.findUserDetail(bindedAgentDto.getMobileNo());
		if(usrDetail != null){
			throw new WebRequestException("当前用户已注册, 已不能绑定当前推广商家.");
		}
		// 3 check if existing binding, if yes update, no, create new record.
		BindedSpreader  bindedSpreader = this.saveOrUpdateBindRecord(bindedAgentDto);
		
		// 4 give red packets 1RMB to spreader who is a shop owner.
		//this.userAccService.giveBizRedPackets(bindedAgentDto.getUserId(), new BigDecimal("1.00"));
		
		// 4.将绑定的手机号，存入异步task处理表
		BigDecimal spreaderMoney = calcSpreaderMoney();
		userAccService.addBindSpreaderBusinessTask(bindedSpreader.getShopOwerId(), bindedSpreader.getId().longValue(), 
				bindedSpreader.getUserMobile(), bindedSpreader.getSpreaderType(), spreaderMoney);
		
		return true;
	}
	
	
	public BigDecimal calcSpreaderMoney(){
		List<Gift> gifts = new ArrayList<Gift>();
        // 序号==物品Id==物品名称==概率
        gifts.add(new Gift(1, "P1", "1", 0.9995d)); // 1元红包
        gifts.add(new Gift(2, "P2", "2", 0.0002d)); // 2元红包
        gifts.add(new Gift(3, "P3", "5", 0.0002d)); // 5元红包
        gifts.add(new Gift(4, "P4", "10", 0.0001d)); // 10元红包
        
        List<Double> orignalRates = new ArrayList<Double>(gifts.size());
        for (Gift gift : gifts) {
            double probability = gift.getProbability();
            if (probability < 0) {
                probability = 0;
            }
            orignalRates.add(probability);
        }
        
        int index =0;
        index = LotteryUtil.lottery(orignalRates);
        
        Gift gift = gifts.get(index);
		return new BigDecimal(gift.getGiftName());
	}
	
	private BindedSpreader saveOrUpdateBindRecord(BindedSpreaderDto bindedAgentDto) {
		BindedSpreader agent = null;
		Integer shopId = StringHelper.objectToInt(bindedAgentDto.getShopId(), 0);
		Integer spreaderType = StringHelper.objectToInt(bindedAgentDto.getSpreaderType(), 0);
		List<BindedSpreader> bindedAgents = bindedAgentDao.getBindedAgent(bindedAgentDto.getMobileNo());
		if (bindedAgents != null && bindedAgents.size() >0) {
			agent = bindedAgents.get(0);
			agent.setShopId(shopId);
			agent.setShopOwerId(bindedAgentDto.getUserId());
			agent.setUpdatedTime(new Date());
			agent.setSpreaderType(spreaderType);
			this.bindedAgentDao.saveAndFlush(agent);
		} else {
			agent = new BindedSpreader(shopId, bindedAgentDto.getUserId(), 
					bindedAgentDto.getMobileNo(), spreaderType);
			this.bindedAgentDao.saveAndFlush(agent);
		}
		return agent;
	}
	
	private void checkBeforeBinding(BindedSpreaderDto bindedAgentDto){
		if(bindedAgentDto == null){
			throw new WebRequestException("没有正确接收到参数.");
		}
		if(bindedAgentDto.getMobileNo() == null){
			throw new WebRequestException("手机号不能为空.");
		}
		// ensure user id not null.
		if(bindedAgentDto.getUserId() == null){
			throw new WebRequestException("shop所有人id为null");
		}
		// check if existing this shop and its related usrid.
		Integer spreaderType = StringHelper.objectToInt(bindedAgentDto.getSpreaderType(), 0);
		if(spreaderType == 0){ //商家推广.
			Integer shopId = StringHelper.objectToInt(bindedAgentDto.getShopId(), -1);
			ShopDetail shopDetail = this.shopService.getShopDetailByShopId(shopId);
			if(shopDetail == null){
				throw new WebRequestException("被绑定的商家不存在. shopId=" + shopId);
			}
			if(shopDetail.getUserId() == null 
					|| !bindedAgentDto.getUserId().equals(shopDetail.getUserId())){
				throw new WebRequestException("被绑定商家用户id和所传递的商家用户id值不同. usrId=" 
					+ bindedAgentDto.getUserId());
			}
		}else if(spreaderType == 1){ //个人推广.
			UsrDetail usr = this.userService.findUserById(bindedAgentDto.getUserId());//this.usrDetailDao.findUserById(bindedAgentDto.getUserId());
			if(usr == null){
				throw new WebRequestException("当前推广人不存在.");
			}
		}
	} 

	@Autowired
	public void setShopService(ShopService shopService) {
		this.shopService = shopService;
	}
	
    @Autowired
	public void setBindedAgentDao(BindedSpreaderDao bindedAgentDao) {
		this.bindedAgentDao = bindedAgentDao;
	}
    
    @Autowired
    public void setUserService(UserService userService) {
		this.userService = userService;
	}

    @Autowired
	public void setUserAccService(UserAccService userAccService) {
		this.userAccService = userAccService;
	}
    
    


	/**
     * 判断当前用户是否是商家推广的用户
     */
	@Override
	public BindedSpreaderDto findUserBindShop(String userId) {
		UsrDetail userDetail = this.userService.findUserById(userId);//usrDetailDao.findUserById(userId);
		if(userDetail == null){
			throw new WebRequestException("用户不存在");
		}
		
		String mobileNo = userDetail.getUserMobile();
		BindedSpreader bindedSprieader =  bindedAgentDao.findByUserMobileAndSpreaderType(mobileNo, BindedSpreader.SPREADERTYPE_SHOP);
		BindedSpreaderDto bindedSpreaderDto = null;
		if(bindedSprieader != null){
			bindedSpreaderDto = new BindedSpreaderDto();
			bindedSpreaderDto.setShopId(bindedSprieader.getShopId() == null ? "0" : String.valueOf(bindedSprieader.getShopId()));
			bindedSpreaderDto.setUserId(bindedSprieader.getShopOwerId());
			bindedSpreaderDto.setMobileNo(mobileNo);
			bindedSpreaderDto.setSpreaderType(String.valueOf(bindedSprieader.getSpreaderType()));
		}
		
		return bindedSpreaderDto;
	}
	
}
