package com.nhs.shop.service.goods.dto;

import java.io.Serializable;
import java.util.List;

import com.google.common.collect.Lists;

/**
 * SKU Name DTO
 * @Title: SkuNameDto.java
 * @Package com.nhs.shop.service.goods.dto
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月18日 下午2:36:44
 * @version V1.0
 */
public class SkuNameDto implements Serializable {

    private static final long serialVersionUID = -91282390267041242L;
    private Integer skuNameId;
    private String skuName;
    private List<SkuValueDto> values = Lists.newArrayList();

    public Integer getSkuNameId() {
        return skuNameId;
    }

    public void setSkuNameId(Integer skuNameId) {
        this.skuNameId = skuNameId;
    }

    public String getSkuName() {
        return skuName;
    }

    public void setSkuName(String skuName) {
        this.skuName = skuName;
    }

    public List<SkuValueDto> getValues() {
        return values;
    }

    public void setValues(List<SkuValueDto> values) {
        this.values = values;
    }

    public void addSkuValueDto(SkuValueDto dto) {
        values.add(dto);
    }

}
