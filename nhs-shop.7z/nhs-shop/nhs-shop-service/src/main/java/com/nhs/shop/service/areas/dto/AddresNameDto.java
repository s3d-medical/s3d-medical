package com.nhs.shop.service.areas.dto;

import java.io.Serializable;

public class AddresNameDto implements Serializable {

    private static final long serialVersionUID = -2859779347836625381L;

    private String provinceName = "";
    private String cityName = "";
    private String areaName = "";

    public String getProvinceName() {
        return provinceName;
    }

    public void setProvinceName(String provinceName) {
        this.provinceName = provinceName;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getAreaName() {
        return areaName;
    }

    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }

}
