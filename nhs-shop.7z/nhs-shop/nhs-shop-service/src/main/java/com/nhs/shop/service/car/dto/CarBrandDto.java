package com.nhs.shop.service.car.dto;

import java.io.Serializable;
import java.util.List;

import com.google.common.collect.Lists;

/**
 * 汽车品牌DTO
 * @Title: CarBrandDto.java
 * @Package com.nhs.shop.service.car.dto
 * @Description: TODO
 * @author Administrator
 * @date 2016年7月26日 下午2:14:23
 * @version V1.0
 */
public class CarBrandDto implements Serializable {
    private static final long serialVersionUID = 2851536218247311323L;
    private String letter;
    private List<BrandDto> list = Lists.newArrayList();

    public String getLetter() {
        return letter;
    }

    public void setLetter(String letter) {
        this.letter = letter;
    }

    public List<BrandDto> getList() {
        return list;
    }

    public void setList(List<BrandDto> list) {
        this.list = list;
    }

    public void addBrandDto(BrandDto brandDto) {
        this.list.add(brandDto);
    }

    public static class BrandDto implements Serializable {
        private Integer brandId;
        private String image;
        private String name;
        private String letter;

        public Integer getBrandId() {
            return brandId;
        }

        public void setBrandId(Integer brandId) {
            this.brandId = brandId;
        }

        public String getImage() {
            return image;
        }

        public void setImage(String image) {
            this.image = image;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getLetter() {
            return letter;
        }

        public void setLetter(String letter) {
            this.letter = letter;
        }

    }
}
