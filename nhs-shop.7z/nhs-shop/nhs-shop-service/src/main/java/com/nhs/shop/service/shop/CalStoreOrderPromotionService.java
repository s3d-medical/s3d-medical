/**
 * 
 */
package com.nhs.shop.service.shop;

import java.math.BigDecimal;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nhs.core.common.NhsConstant;
import com.nhs.core.utils.common.ArithUtils;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.shop.entry.legend.store.StoreOrderItem;
import com.nhs.shop.rebate.service.CalRebateService;
import com.nhs.shop.service.order.dto.StoreItemDto;
import com.nhs.shop.service.order.dto.StoreOrderItemDto;

/**
 * @author Administrator
 *
 */
@Service
public class CalStoreOrderPromotionService {
	
	
	@Autowired
    private CalRebateService calRebateService;
	
//	 public void calStoreOrderPromotion(StoreOrderItemDto itemDto,BigDecimal prodAdFeeRate,BigDecimal prodAdFeeBasicRate,BigDecimal totalSilverNum,BigDecimal totalCouponNum,BigDecimal orderleftEffectiveAmount){
//			 if(prodAdFeeRate == null){
//				 prodAdFeeRate = new BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE);
//	         }
//	         if(prodAdFeeBasicRate == null){
//	        	 prodAdFeeBasicRate = new BigDecimal(NhsConstant.DEFAULT_AD_FEE_BASIC_RATE);
//	         }
//	         BigDecimal rebate = ArithUtils.div2(prodAdFeeRate, prodAdFeeBasicRate, 3,BigDecimal.ROUND_DOWN);
//	         //商品可用于返利部分的金额
//	         BigDecimal prodEffectiveAmout = new BigDecimal(itemDto.getProdTotalPrice());
//	        //订单可返金额大于商品价格时
//	         if(orderleftEffectiveAmount.compareTo(new BigDecimal(itemDto.getProdTotalPrice())) > 0){
//	        	 orderleftEffectiveAmount = ArithUtils.sub2(orderleftEffectiveAmount, new BigDecimal(itemDto.getProdTotalPrice()), 2, BigDecimal.ROUND_DOWN);
//	         }else{
//	        	 prodEffectiveAmout = ArithUtils.sub2(new BigDecimal(itemDto.getProdTotalPrice()),orderleftEffectiveAmount , 2, BigDecimal.ROUND_DOWN);
//	        	 orderleftEffectiveAmount = new BigDecimal("0.00");
//	         }
//	       //商品价格大于抵用券价格，可返券
//	        if(prodEffectiveAmout.compareTo(new BigDecimal(itemDto.getCouponAmountStr())) > 0){
//	        	//商家推广费率<=10%时，按照之前规则赠送给用户佰德钻；商家推广费率>10%时，超出比例送佰德券
//	        	BigDecimal prodPayAmount = ArithUtils.sub2(prodEffectiveAmout, new BigDecimal(itemDto.getCouponAmountStr()), 2, BigDecimal.ROUND_DOWN);
//		        if(prodAdFeeBasicRate.compareTo(new BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE_CRITICAL)) > 0){
//	        		rebate = new BigDecimal(NhsConstant.DEFAULT_REBATE);
//	        		BigDecimal moreRate = ArithUtils.sub2(prodAdFeeBasicRate, new BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE_CRITICAL), 3, BigDecimal.ROUND_DOWN);
//	        		BigDecimal couponNum = ArithUtils.mul2(prodPayAmount, moreRate, 3, BigDecimal.ROUND_DOWN).multiply(new BigDecimal(100)) ;
//	        		itemDto.setGiveGold(couponNum.toString());
//	        		totalSilverNum = ArithUtils.add2(totalSilverNum, couponNum , 2, BigDecimal.ROUND_DOWN);
//		        }
//		        
//		        BigDecimal silverNum = ArithUtils.mul2(prodPayAmount, rebate, 3, BigDecimal.ROUND_DOWN).multiply(new BigDecimal(100)) ;
//		        itemDto.setGiveSilver(silverNum.toString());
//		        totalCouponNum = ArithUtils.add2(totalCouponNum, silverNum , 2, BigDecimal.ROUND_DOWN);
//		        
//	        }
//	        
//	    }
//	 
	 
	 public void calStoreOrderProdCouponAmount(StoreOrderItemDto itemDto,Map<String, Object> couponAmoutMap){
		 
		//商品可用于抵用券的金额
         BigDecimal prodEffectiveAmout = new BigDecimal(itemDto.getProdTotalPrice());
         
         BigDecimal totalCouponAmount = StringHelper.objectToBigDecimal(couponAmoutMap.get("totalCouponAmount"),"0.00");
		 
		 if(totalCouponAmount.compareTo(new BigDecimal("0")) > 0 && totalCouponAmount.compareTo(prodEffectiveAmout) >= 0){
			 totalCouponAmount = totalCouponAmount.subtract(prodEffectiveAmout);
			 itemDto.setCouponAmountStr(prodEffectiveAmout.toString());
        }else if(totalCouponAmount.compareTo(new BigDecimal("0")) > 0 && totalCouponAmount.compareTo(prodEffectiveAmout) < 0){
        	itemDto.setCouponAmountStr(totalCouponAmount.toString());
        	totalCouponAmount = new BigDecimal("0");
        }else{
        	itemDto.setCouponAmountStr("0");
        }
		 
		 couponAmoutMap.put("totalCouponAmount", totalCouponAmount);
        
    }
	 
	 
	 public void calStoreOrderPromotion(StoreOrderItem item,BigDecimal prodAdFeeRate,BigDecimal prodAdFeeBasicRate,Map<String, Object> calOrderMap){
		 
	        
         BigDecimal totalSilverNum = StringHelper.objectToBigDecimal(calOrderMap.get("totalSilverNum"),"0.00");
        
         BigDecimal totalCouponNum = StringHelper.objectToBigDecimal(calOrderMap.get("totalCouponNum"),"0.00");
        
         BigDecimal orderleftEffectiveAmount = StringHelper.objectToBigDecimal(calOrderMap.get("orderleftEffectiveAmount"),"0.00");
		 
		 if(prodAdFeeRate == null){
			 prodAdFeeRate = new BigDecimal("0.00");
         }else if(prodAdFeeRate.compareTo(new BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE)) > 0){
        	 prodAdFeeRate = new BigDecimal("0.00");
         }
         if(prodAdFeeBasicRate == null){
        	 prodAdFeeBasicRate = new BigDecimal(NhsConstant.DEFAULT_AD_FEE_BASIC_RATE);
         }
//         BigDecimal rebate = ArithUtils.div2(prodAdFeeRate, prodAdFeeBasicRate, 3,BigDecimal.ROUND_DOWN);
         BigDecimal rebate = calRebateService.calRebate(prodAdFeeRate, prodAdFeeBasicRate, NhsConstant.DEFAULT_AD_FEE_RATE_NEW_MAX_STORE);
         //商品可用于返利部分的金额
         BigDecimal prodEffectiveAmout = item.getProdAmount();
        //订单可返利部分的金额大于商品价格时
         if(orderleftEffectiveAmount.compareTo(item.getProdAmount()) >= 0){
        	 orderleftEffectiveAmount = ArithUtils.sub2(orderleftEffectiveAmount, item.getProdAmount(), 2, BigDecimal.ROUND_DOWN);
         }else{
        	 prodEffectiveAmout = orderleftEffectiveAmount;
        	 orderleftEffectiveAmount = new BigDecimal("0.00");
         }
       //商品价格大于抵用券价格，可返券
         BigDecimal prodPayAmount = prodEffectiveAmout;
        if(prodEffectiveAmout.compareTo(item.getCouponAmount()) >= 0){
        	//商家推广费率<=10%时，按照之前规则赠送给用户佰德钻；商家推广费率>10%时，超出比例送佰德券
        	prodPayAmount = ArithUtils.sub2(prodEffectiveAmout, item.getCouponAmount(), 2, BigDecimal.ROUND_DOWN);
        	BigDecimal couponNum = new BigDecimal("0.00");
	        if(prodAdFeeRate.compareTo(new BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE_CRITICAL)) > 0){
//        		rebate = new BigDecimal(NhsConstant.DEFAULT_REBATE);
        		BigDecimal moreRate = ArithUtils.sub2(prodAdFeeRate, new BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE_CRITICAL), 3, BigDecimal.ROUND_DOWN);
        		couponNum = ArithUtils.mul2(prodPayAmount, moreRate, 4, BigDecimal.ROUND_DOWN).multiply(new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE)).setScale(2,BigDecimal.ROUND_DOWN);
        		item.setGiveGold(couponNum);
        		totalCouponNum = ArithUtils.add2(totalCouponNum, couponNum , 2, BigDecimal.ROUND_DOWN);
	        }else{
	        	item.setGiveGold(new BigDecimal("0.00"));
	        }
	        
	        BigDecimal silverNum = ArithUtils.mul2(prodPayAmount.subtract(couponNum.divide(new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE))), rebate, 4, BigDecimal.ROUND_DOWN).multiply(new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE)).setScale(2,BigDecimal.ROUND_DOWN);
	        item.setGiveSilver(silverNum);
	        totalSilverNum = ArithUtils.add2(totalSilverNum, silverNum , 2, BigDecimal.ROUND_DOWN);
	        
        }
        calOrderMap.put("totalSilverNum", totalSilverNum);
        calOrderMap.put("totalCouponNum", totalCouponNum);
        calOrderMap.put("orderleftEffectiveAmount", orderleftEffectiveAmount);
        item.setProdRebateRate(rebate);
    }
	    
	 public void calStoreOrderProdPromotion(StoreItemDto dto){
		 if(dto.getAdFeeRate() == null){
			 dto.setAdFeeRate(new BigDecimal("0.00"));
         }else if(dto.getAdFeeRate().compareTo(new BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE)) > 0){
        	 dto.setAdFeeRate(new BigDecimal("0.00"));
         }
         BigDecimal prodAdFeeBasicRate = new BigDecimal(NhsConstant.DEFAULT_AD_FEE_BASIC_RATE);
         BigDecimal rebate = calRebateService.calRebate(dto.getAdFeeRate(), prodAdFeeBasicRate, NhsConstant.DEFAULT_AD_FEE_RATE_NEW_MAX_STORE);
         BigDecimal couponNum = new BigDecimal("0.00");
         if(dto.getAdFeeRate().compareTo(new BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE_CRITICAL)) > 0){
//     		rebate = new BigDecimal(NhsConstant.DEFAULT_REBATE);
     		BigDecimal moreRate = ArithUtils.sub2(prodAdFeeBasicRate, new BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE_CRITICAL), 3, BigDecimal.ROUND_DOWN);
     		couponNum = ArithUtils.mul2(new BigDecimal(dto.getSalePrice()), moreRate, 4, BigDecimal.ROUND_DOWN);
     		dto.setGiveGoldNum(couponNum.multiply(new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE)).setScale(2, BigDecimal.ROUND_DOWN).toString());
     		dto.setGiveGold(couponNum.setScale(2, BigDecimal.ROUND_DOWN).toString());
     		
         }
         BigDecimal silverNum = ArithUtils.mul2(new BigDecimal(dto.getSalePrice()).subtract(couponNum), rebate, 4, BigDecimal.ROUND_DOWN) ;
         dto.setGiveSilverNum(silverNum.multiply(new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE)).setScale(2, BigDecimal.ROUND_DOWN).toString());
         dto.setGiveSilver(silverNum.setScale(2, BigDecimal.ROUND_DOWN).toString());
         
	 }
	        
	
}
