package com.nhs.shop.service.order.dto;

import java.io.Serializable;

/**
 * 服务订单详情DTO
 * @Title: OrderListDto.java
 * @Package com.nhs.shop.service.order.dto
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月20日 下午3:37:26
 * @version V1.0
 */
public class CarOrderDetailDto implements Serializable {

    private static final long serialVersionUID = 2308053677959309156L;
    private Integer orderId;
    private String orderNum = "";
    private Integer shopId;
    private String shopName = "";
    private String pic;
    private String contact = "";
    private String mobile = "";
    private String carWay = "";
    private String carCity = "";
    private String payType = "订金支付";
    private Integer status;
    private String statusName;
    private String deposit;
    // TODO liangdanhua 添加一个字段
    private Double totalAmount;
    private String price;
    private String prodName = "";
    private String skuDesc = "";
    private String createTime;
    private String payTime = "";
    private String detailUrl = "";
    private String subsidy = "";
    private int prodId;
    private String cancelDate = "";
    private String subsidyStr = "";

    public String getCancelDate() {
        return cancelDate;
    }

    public void setCancelDate(String cancelDate) {
        this.cancelDate = cancelDate;
    }

    public Double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(Double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public String getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(String orderNum) {
        this.orderNum = orderNum;
    }

    public Integer getShopId() {
        return shopId;
    }

    public void setShopId(Integer shopId) {
        this.shopId = shopId;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getStatusName() {
        return statusName;
    }

    public void setStatusName(String statusName) {
        this.statusName = statusName;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getCarWay() {
        return carWay;
    }

    public void setCarWay(String carWay) {
        this.carWay = carWay;
    }

    public String getCarCity() {
        return carCity;
    }

    public void setCarCity(String carCity) {
        this.carCity = carCity;
    }

    public String getPayType() {
        return payType;
    }

    public void setPayType(String payType) {
        this.payType = payType;
    }

    public String getProdName() {
        return prodName;
    }

    public void setProdName(String prodName) {
        this.prodName = prodName;
    }

    public String getSkuDesc() {
        return skuDesc;
    }

    public void setSkuDesc(String skuDesc) {
        this.skuDesc = skuDesc;
    }

    public String getPayTime() {
        return payTime;
    }

    public void setPayTime(String payTime) {
        this.payTime = payTime;
    }

    public String getDeposit() {
        return deposit;
    }

    public void setDeposit(String deposit) {
        this.deposit = deposit;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getDetailUrl() {
        return detailUrl;
    }

    public void setDetailUrl(String detailUrl) {
        this.detailUrl = detailUrl;
    }

    public String getSubsidy() {
        return subsidy;
    }

    public void setSubsidy(String subsidy) {
        this.subsidy = subsidy;
    }

    public int getProdId() {
        return prodId;
    }

    public void setProdId(int prodId) {
        this.prodId = prodId;
    }

	public String getSubsidyStr() {
		return subsidyStr;
	}

	public void setSubsidyStr(String subsidyStr) {
		this.subsidyStr = subsidyStr;
	}
    
    

}
