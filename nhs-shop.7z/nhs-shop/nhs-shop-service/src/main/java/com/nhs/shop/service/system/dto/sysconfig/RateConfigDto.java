package com.nhs.shop.service.system.dto.sysconfig;

import java.io.Serializable;

/**
 * 比率相关配置
 * @author Administrator
 *
 */
public class RateConfigDto  implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2425789267833283014L;
	
	private String rmbGoldExchageRate;

	public String getRmbGoldExchageRate() {
		return rmbGoldExchageRate;
	}

	public void setRmbGoldExchageRate(String rmbGoldExchageRate) {
		this.rmbGoldExchageRate = rmbGoldExchageRate;
	}
	
	
	
	
}
