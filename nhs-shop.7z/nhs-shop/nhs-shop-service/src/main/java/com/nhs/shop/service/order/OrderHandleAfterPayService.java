package com.nhs.shop.service.order;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import com.nhs.apiproxy.UnifiedInApiReqHelper;
import com.nhs.core.utils.common.MapUtils;
import com.nhs.shop.dao.legend.service.O2oServiceOrderDao;
import com.nhs.shop.dao.legend.shop.O2oShopDetailDao;
import com.nhs.shop.dao.legend.shop.ShopDetailDao;
import com.nhs.shop.entry.em.PayTypeEnum;
import com.nhs.shop.entry.em.order.OrderCodeEnum;
import com.nhs.shop.entry.legend.service.O2oServiceOrder;
import com.nhs.shop.entry.legend.shop.O2oShopDetail;
import com.nhs.shop.entry.legend.shop.ShopDetail;
import com.nhs.shop.entry.legend.user.UsrDetail;
import com.nhs.shop.service.BaseOrderDto;
import com.nhs.shop.service.BaseOrderService;
import com.nhs.shop.service.order.dto.OrderPayResultDto;
import com.nhs.shop.service.pay.PayLogService;
import com.nhs.shop.service.sms.OrderSmsService;
import com.nhs.user.service.UserService;

/**
 * 支付成功逻辑处理
 * @Title: PayService.java
 * @Package com.nhs.o2o.pay.service
 * @Description: TODO
 * @author wind.chen
 * @date 2016年7月28日 下午2:41:41
 * @version V1.0
 */
@Service
public class OrderHandleAfterPayService {

    private static Logger logger = Logger.getLogger(OrderHandleAfterPayService.class);

    @Autowired
    private PayLogService payLogService;

    @Autowired
    private OrderSmsService orderSmsService;

    @Autowired
    private O2oServiceOrderDao o2oServiceOrderDao;

    @Autowired
    private O2oShopDetailDao o2oShopDetailDao;

    @Autowired
    private UserService userService;

    @Autowired
    private ShopDetailDao shopDetailDao;

    /**
     * 订单支付成功处理
     * 确保订单
     * @param orderPayResultDto
     */
    public boolean handleOrderPay(OrderPayResultDto param) {
        // 1. check data.
        Assert.isTrue(param != null, "支付后处理订单, 给参不能null.");
        Assert.isTrue(!StringUtils.isEmpty(param.getSign()), "支付后处理订单, 参数的sign不能为空.");
        // check sign.
        Map<String, Object> map = MapUtils.toMap(param);
        if (!UnifiedInApiReqHelper.verifyParamSign(map)) {
            throw new RuntimeException("支付后处理订单, 传入的sign和计算出来的sign必须相同.");
        }
        // 2. 订单处理.
        PayTypeEnum payType = PayTypeEnum.parseByCode(param.getPlatformid());
        return this.handleOrderPay(param.getPartnerorderno(), param.getOrderno(), param.getMoney(), null, payType,
                param.ifSuccessfulPay());
    }

    /**
     * 订单支付成功处理
     * @Title: handleOrderPay
     * @Desc: 
     * @author wind.chen 2016年11月21日 上午11:56:00
     * 
     * @param orderNum    商户订单号
     * @param tradeNo     平台交易订单号
     * @param payAmount   支付金额
     * @param payAccount  支付账户
     * @param payType     支付类型.
     * @return
     * @throws
     */
    private boolean handleOrderPay(String orderNum, String tradeNo, String payAmount, String payAccount,
            PayTypeEnum payType, boolean isSuccessPay) {
        // check
        boolean checkFlag = this.checkOrderPayParam(orderNum, tradeNo, payAmount, payAccount, payType, isSuccessPay);
        if (!checkFlag) {
            return false;
        }

        // 检查订单是否重复处理.
        if (payLogService.isHandled(orderNum)) {
            logger.info("orderNum[" + orderNum + "]重复处理. 默认为已成功处理.");
            return true;
        }
        BaseOrderService service = OrderServiceFactory.getOrderServiceByOrderNum(orderNum);
        BaseOrderDto baseDto = service.getBaseOrderDto(orderNum);
        String userId = baseDto != null ? baseDto.getUserId() : "";
        // 判断支付金额
        double expectPay = getOrderPayAmount(orderNum);
        if (Double.parseDouble(payAmount) != expectPay) {
            logger.error("orderNum[" + orderNum + "],payAmount[" + payAmount + "] is not equal order totalAmount["
                    + expectPay + "]");
            payLogService.savePayLog(orderNum, tradeNo, Double.parseDouble(payAmount), payType.getName(), "支付金额异常",
                    payAccount, userId);
            return false;
        }

        // 保存支付日志
        payLogService.savePayLog(orderNum, tradeNo, Double.parseDouble(payAmount), payType.getName(), "支付成功",
                payAccount, userId);
        // 处理订单支付成功后的逻辑
        service.handleOrderPay(orderNum, payAmount, payType.getName(), payType.ordinal(), tradeNo);
        this.sendSms(orderNum, expectPay);
        return true;
    }

    /**
     * 减产订单支付的参数.
     * @Title: checkOrderPayParam
     * @Desc: 
     * @author wind.chen 2016年11月21日 下午2:01:17
     *
     * @return
     * @throws
     */
    private boolean checkOrderPayParam(String orderNum, String tradeNo, String payAmount, String payAccount,
            PayTypeEnum payType, boolean isSuccessfulPay) {
        // 检查参数: 订单号满足规则, 交易号, 支付类型， 订单的金额.
        Assert.isTrue(!StringUtils.isEmpty(orderNum), "业务订单编号不能为空.");
        Assert.isTrue(!StringUtils.isEmpty(tradeNo), "平台交易订单号不能为空.");
        Assert.isTrue(payAmount != null, "订单支付金额不能空.");
        Assert.isTrue(Double.parseDouble(payAmount) >= 0.0, "订单支付金额必须大于等于0");
        Assert.isTrue(payType != null, "支付类型不能为空. ");
        if (!isSuccessfulPay) {
            return false;
        }
        return true;
    }

    private void sendSms(String orderNum, Double totalAmount) {
        // 发送短信通知
        if (orderNum.endsWith(OrderCodeEnum.O2O_SERVICE_ORDER.getCode().toString())) {
            O2oServiceOrder o2oServiceOrder = o2oServiceOrderDao.findO2oServiceOrderByOrderNum(orderNum);
            if (null != o2oServiceOrder && StringUtils.isNotBlank(o2oServiceOrder.getUserId())) {
                UsrDetail usrDetail = userService.findUserById(o2oServiceOrder.getUserId()); // usrDetailDao.findUserById(o2oServiceOrder.getUserId());
                ShopDetail shopDetail = shopDetailDao.findOne(o2oServiceOrder.getShopId());
                UsrDetail shopUsrDetail = null;// usrDetailDao.findShopUser(o2oServiceOrder.getShopId());
                if (shopDetail != null) {
                    shopUsrDetail = userService.findUserById(shopDetail.getUserId());
                }
                O2oShopDetail o2oShopDetail = o2oShopDetailDao.findO2oShopDetailByshopId(o2oServiceOrder.getShopId());
                // o2o店铺是否设置短信接受手机号码
                Boolean flagSms = false;
                if (null != o2oShopDetail) {
                    if (StringUtils.isNotBlank(o2oShopDetail.getSmsPhone())) {
                        flagSms = true;
                    }
                }
                if (null != usrDetail && null != shopUsrDetail) {
                    try {
                        if (flagSms) {
                            orderSmsService.smsAfterOrder(usrDetail.getUserMobile(), o2oShopDetail.getSmsPhone(), "",
                                    new String[] { o2oServiceOrder.getShopName(), String.valueOf(totalAmount) },
                                    new String[] { orderNum, String.valueOf(o2oServiceOrder.getTotalAmount()),
                                            usrDetail.getUserName() });
                        } else {
                            orderSmsService.smsAfterOrder(usrDetail.getUserMobile(), shopUsrDetail.getUserMobile(), "",
                                    new String[] { o2oServiceOrder.getShopName(), String.valueOf(totalAmount) },
                                    new String[] { orderNum, String.valueOf(o2oServiceOrder.getTotalAmount()),
                                            usrDetail.getUserName() });
                        }
                    } catch (Exception e) {
                        logger.error("短信发送失败！");
                    }
                }
            }
        }
    }

    /**
     * 获取订单支付金额
     * @Title: getOrderPayAmount
     * @Description: TODO
     * @param @param orderNum
     * @param @return   
     * @return double 
     * @author Administrator 2016年7月28日 
     * @throws
     */
    public double getOrderPayAmount(String orderNum) {
        BaseOrderService service = OrderServiceFactory.getOrderServiceByOrderNum(orderNum);
        return service.getOrderPayAmount(orderNum);
    }
}
