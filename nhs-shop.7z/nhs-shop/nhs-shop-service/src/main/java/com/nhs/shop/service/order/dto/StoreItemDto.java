package com.nhs.shop.service.order.dto;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 商超商品表
 * @Title: StoreItemDto.java
 * @Package com.nhs.shop.service.order.dto
 * @Description: TODO
 * @author liangdanhua
 * @date 2016年11月18日 下午4:20:30
 * @version V1.0
 */
public class StoreItemDto implements Serializable {

    private static final long serialVersionUID = 163166522072915801L;

    private Integer shopId;

    private String itemCode = "";

    private String itemName = "";

    private String salePrice = "0.00";	//零售价

    private String memberPrice = "0.00";	//会员价

    private BigDecimal adFeeRate;

    private String createdTime = "";

    private String lastModifiedTime = "";
    
    private String coupon = "";
    
    private String prodPrimePrice = "0.00";   //原价
    
    private String giveSilverNum = "";
    
    private String giveGoldNum = "";
    
    private String giveSilver = "";
    
    private String giveGold = "";

    public Integer getShopId() {
        return shopId;
    }

    public void setShopId(Integer shopId) {
        this.shopId = shopId;
    }

    public String getItemCode() {
        return itemCode;
    }

    public void setItemCode(String itemCode) {
        this.itemCode = itemCode;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getSalePrice() {
        return salePrice;
    }

    public void setSalePrice(String salePrice) {
        this.salePrice = salePrice;
    }

    public String getMemberPrice() {
        return memberPrice;
    }

    public void setMemberPrice(String memberPrice) {
        this.memberPrice = memberPrice;
    }

    public BigDecimal getAdFeeRate() {
		return adFeeRate;
	}

	public void setAdFeeRate(BigDecimal adFeeRate) {
		this.adFeeRate = adFeeRate;
	}

	public String getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(String createdTime) {
        this.createdTime = createdTime;
    }

    public String getLastModifiedTime() {
        return lastModifiedTime;
    }

    public void setLastModifiedTime(String lastModifiedTime) {
        this.lastModifiedTime = lastModifiedTime;
    }

	public String getCoupon() {
		return coupon;
	}

	public void setCoupon(String coupon) {
		this.coupon = coupon;
	}


	public String getGiveSilverNum() {
		return giveSilverNum;
	}

	public void setGiveSilverNum(String giveSilverNum) {
		this.giveSilverNum = giveSilverNum;
	}

	public String getGiveGoldNum() {
		return giveGoldNum;
	}

	public void setGiveGoldNum(String giveGoldNum) {
		this.giveGoldNum = giveGoldNum;
	}

	public String getProdPrimePrice() {
		return prodPrimePrice;
	}

	public void setProdPrimePrice(String prodPrimePrice) {
		this.prodPrimePrice = prodPrimePrice;
	}

	public String getGiveSilver() {
		return giveSilver;
	}

	public void setGiveSilver(String giveSilver) {
		this.giveSilver = giveSilver;
	}

	public String getGiveGold() {
		return giveGold;
	}

	public void setGiveGold(String giveGold) {
		this.giveGold = giveGold;
	}

	
    

}
