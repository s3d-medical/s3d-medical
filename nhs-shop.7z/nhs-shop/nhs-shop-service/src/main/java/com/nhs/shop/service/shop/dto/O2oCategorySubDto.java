package com.nhs.shop.service.shop.dto;

public class O2oCategorySubDto {
	
	private int subCategoryId;
	
	private String subCategoryName;
	
	private int subSort;
	

	public int getSubCategoryId() {
		return subCategoryId;
	}

	public void setSubCategoryId(int subCategoryId) {
		this.subCategoryId = subCategoryId;
	}

	public String getSubCategoryName() {
		return subCategoryName;
	}

	public void setSubCategoryName(String subCategoryName) {
		this.subCategoryName = subCategoryName;
	}

	public int getSubSort() {
		return subSort;
	}

	public void setSubSort(int subSort) {
		this.subSort = subSort;
	}
	
	

}
