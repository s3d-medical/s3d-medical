package com.nhs.shop.service.order.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.google.common.collect.Lists;
import com.nhs.shop.service.common.dto.CustFieldDto;

/**
 * 订单确认DTO
 * @Title: OrderConfirmDto.java
 * @Package com.nhs.shop.service.order.dto
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月19日 下午2:55:54
 * @version V1.0
 */
public class OrderConfirmDto implements Serializable {

    private static final long serialVersionUID = -2030752000081236203L;
    private UserAddressDto address;
    private List<OrderShopDto> shopList = Lists.newArrayList();
    private String deliveryType = "";
    @Deprecated
    private Map<String, Object> carriageList;
    /**
     * 订单默认总价格: 商品价格 + 运费
     */
    private BigDecimal totalAmount;
    /**
     * 订单中商品总价格.
     */
    private BigDecimal totalProdAmount;
    
    @Deprecated
    private Map<String, BigDecimal> totalAountList;
    private String isCarrage = "";
    List<Map<String, Object>> totalParams;
    private double totalProdNum;
    
    /**
     * 补贴.
     */
    private CustFieldDto reducedCash;
    
   
    
    public List<Map<String, Object>> getTotalParams() {
        return totalParams;
    }

    public void setTotalParams(List<Map<String, Object>> totalParams) {
        this.totalParams = totalParams;
    }

    public String getIsCarrage() {
        return isCarrage;
    }

    public void setIsCarrage(String isCarrage) {
        this.isCarrage = isCarrage;
    }

    Map<Object, Map<String, Object>> carriage;

    @Deprecated
    public Map<String, BigDecimal> getTotalAountList() {
        return totalAountList;
    }
    
    @Deprecated
    public void setTotalAountList(Map<String, BigDecimal> totalAountList) {
        this.totalAountList = totalAountList;
    }
    
    @Deprecated
    public Map<String, Object> getCarriageList() {
        return carriageList;
    }

    @Deprecated
    public void setCarriageList(Map<String, Object> carriageList) {
        this.carriageList = carriageList;
    }
    @Deprecated
    public Map<Object, Map<String, Object>> getCarriage() {
        return carriage;
    }
    @Deprecated
    public void setCarriage(Map<Object, Map<String, Object>> carriage) {
        this.carriage = carriage;
    }

    public UserAddressDto getAddress() {
        return address;
    }

    public void setAddress(UserAddressDto address) {
        this.address = address;
    }

    public List<OrderShopDto> getShopList() {
        return shopList;
    }

    public void setShopList(List<OrderShopDto> shopList) {
        this.shopList = shopList;
    }

    public void addOrderShopDto(OrderShopDto orderShopDto) {
        this.shopList.add(orderShopDto);
    }

    public String getDeliveryType() {
        return deliveryType;
    }

    public void setDeliveryType(String deliveryType) {
        this.deliveryType = deliveryType;
    }
    
    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

	public CustFieldDto getReducedCash() {
		return reducedCash;
	}

	public void setReducedCash(CustFieldDto reducedCash) {
		this.reducedCash = reducedCash;
	}

	public double getTotalProdNum() {
		return totalProdNum;
	}

	public void setTotalProdNum(double totalProdNum) {
		this.totalProdNum = totalProdNum;
	}

	public BigDecimal getTotalProdAmount() {
		return totalProdAmount;
	}

	public void setTotalProdAmount(BigDecimal totalProdAmount) {
		this.totalProdAmount = totalProdAmount;
	}

}
