package com.nhs.shop.service.system.dto.sysconfig;

import java.io.Serializable;

/**
 * 更新配置
 * @author wind.chen
 */
public class GlUpdateInfoDto implements Serializable {
	private static final long serialVersionUID = 8987026218568889341L;

	private String updateWay; // "hotFix", //hotFix, forceUpdate, None
	private String newAppVer; // "1.9.3",
	private String updateUrl; // "http://www.badiu.com/cdn/xxxx"

	public String getUpdateWay() {
		return updateWay;
	}
	public void setUpdateWay(String updateWay) {
		this.updateWay = updateWay;
	}
	public String getNewAppVer() {
		return newAppVer;
	}
	public void setNewAppVer(String newAppVer) {
		this.newAppVer = newAppVer;
	}
	public String getUpdateUrl() {
		return updateUrl;
	}
	public void setUpdateUrl(String updateUrl) {
		this.updateUrl = updateUrl;
	}

}
