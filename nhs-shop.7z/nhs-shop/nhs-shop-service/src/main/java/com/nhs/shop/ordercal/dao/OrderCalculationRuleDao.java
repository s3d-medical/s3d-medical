package com.nhs.shop.ordercal.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.nhs.shop.ordercal.entity.OrderCalculationRule;

public interface OrderCalculationRuleDao  extends JpaRepository<OrderCalculationRule, Integer>,
PagingAndSortingRepository<OrderCalculationRule, Integer>, JpaSpecificationExecutor<OrderCalculationRule>{
	
	public OrderCalculationRule findByOrderNumAndRuleType(String orderNum,String ruleType);

}
