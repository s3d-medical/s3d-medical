package com.nhs.shop.service.basket.dto;

import java.io.Serializable;
import java.util.List;

import com.google.common.collect.Lists;

/**
 * 购物车Dto
 * @Title: BasketDto.java
 * @Package com.nhs.o2o.web
 * @Description: TODO
 * @author Administrator
 * @date 2016年7月18日 下午7:53:37
 * @version V1.0
 */
public class BasketDto implements Serializable {

    private static final long serialVersionUID = 5963026884653016734L;

    private Integer shopId;
    private String shopName;
    private List<BasketProdDto> list = Lists.newArrayList();

    public Integer getShopId() {
        return shopId;
    }

    public void setShopId(Integer shopId) {
        this.shopId = shopId;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public List<BasketProdDto> getList() {
        return list;
    }

    public void setList(List<BasketProdDto> list) {
        this.list = list;
    }

    public void addBasketProd(BasketProdDto basketProd) {
        list.add(basketProd);
    }

    // 购物车中的商品
    public static class BasketProdDto implements Serializable {
        private static final long serialVersionUID = -9128603797220114360L;
        private Integer basketId;
        private Integer prodId;
        private Integer skuId = 0;
        private String prodName;
        private String skuDesc;
        private String pic;
        private String price;
        private Integer count;
        private String detailUrl = "";
        private Integer prodStocks = 0;
        private Integer skuStocks = -1;
        private String subsidy = "";
        private String mailStatus = "包邮";
        private String subsidyStr = "";
        private String reducedCashTag = "";
        public String getMailStatus() {
            return mailStatus;
        }

        public void setMailStatus(String mailStatus) {
            this.mailStatus = mailStatus;
        }

        public String getSubsidy() {
            return subsidy;
        }

        public void setSubsidy(String subsidy) {
            this.subsidy = subsidy;
        }

        public Integer getBasketId() {
            return basketId;
        }

        public void setBasketId(Integer basketId) {
            this.basketId = basketId;
        }

        public Integer getProdId() {
            return prodId;
        }

        public void setProdId(Integer prodId) {
            this.prodId = prodId;
        }

        public Integer getSkuId() {
            return skuId;
        }

        public void setSkuId(Integer skuId) {
            this.skuId = skuId;
        }

        public String getProdName() {
            return prodName;
        }

        public void setProdName(String prodName) {
            this.prodName = prodName;
        }

        public String getSkuDesc() {
            return skuDesc;
        }

        public void setSkuDesc(String skuDesc) {
            this.skuDesc = skuDesc;
        }

        public String getPic() {
            return pic;
        }

        public void setPic(String pic) {
            this.pic = pic;
        }

        public String getPrice() {
            return price;
        }

        public void setPrice(String price) {
            this.price = price;
        }

        public Integer getCount() {
            return count;
        }

        public void setCount(Integer count) {
            this.count = count;
        }

        public String getDetailUrl() {
            return detailUrl;
        }

        public void setDetailUrl(String detailUrl) {
            this.detailUrl = detailUrl;
        }

        public Integer getProdStocks() {
            return prodStocks;
        }

        public void setProdStocks(Integer prodStocks) {
            this.prodStocks = prodStocks;
        }

        public Integer getSkuStocks() {
            return skuStocks;
        }

        public void setSkuStocks(Integer skuStocks) {
            this.skuStocks = skuStocks;
        }

		public String getSubsidyStr() {
			return subsidyStr;
		}

		public void setSubsidyStr(String subsidyStr) {
			this.subsidyStr = subsidyStr;
		}

		public String getReducedCashTag() {
			return reducedCashTag;
		}

		public void setReducedCashTag(String reducedCashTag) {
			this.reducedCashTag = reducedCashTag;
		}

        
    }

}
