package com.nhs.shop.bindspreader.service;

import com.nhs.shop.bindspreader.dto.BindedSpreaderDto;

public interface BindedSpreaderService {
	
	/**
	 * 绑定代理商. 
	 * @param bindedAgentDto
	 * @return
	 */
	public boolean bindSpreader(BindedSpreaderDto bindedAgentDto);
	
	/**
	 * 查找用户绑定的店铺
	 * @param userId
	 * @return
	 */
	public BindedSpreaderDto findUserBindShop(String userId);
	
}
