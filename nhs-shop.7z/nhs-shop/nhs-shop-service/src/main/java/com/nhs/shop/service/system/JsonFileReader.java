package com.nhs.shop.service.system;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import com.nhs.core.json.JsonParseFastJson;
import com.nhs.core.utils.common.FileUtils;

public class JsonFileReader {
	private Logger logger = LoggerFactory.getLogger(JsonFileReader.class);
	private Map<String, Object> fileContentInMap;
	private String filePath;

	public String getFilePath() {
		return filePath;
	}
	/**
	 * 读取json文件内容, 以map的方式返回. 
	 * @Title: getJsonInMap
	 * @Desc: 
	 * @author wind.chen 2016年12月16日 下午12:00:46
	 *
	 * @return
	 * @throws
	 */
	public Map<String, Object> getJsonInMap(){
		// check
		logger.info("配置文件= " + filePath);
		if(StringUtils.isEmpty(filePath)){			
			return new HashMap<String, Object>();
		}
		if(fileContentInMap != null && fileContentInMap.size()>0){
			return this.fileContentInMap;
		}
		// to json
		String json = FileUtils.readFile(filePath);
		logger.info("json file = " + filePath + ", fileContent="  + json);
		// to map
		this.fileContentInMap = JsonParseFastJson.toObj(json, Map.class);
		return fileContentInMap;
	}
	
}
