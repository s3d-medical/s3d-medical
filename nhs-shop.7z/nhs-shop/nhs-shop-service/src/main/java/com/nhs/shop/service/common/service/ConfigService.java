package com.nhs.shop.service.common.service;

import org.springframework.stereotype.Service;

import com.nhs.core.context.SysPropsFactory;

/**
/**
 * 读取配置文件
 * @Title: StoreOrderService.java
 * @Package com.nhs.shop.service.order
 * @Description: TODO
 * @author shushu
 * @date 2016年11月28日 下午07:36:16
 * @version V1.0
 */
@Service
public class ConfigService {

    public String getExcelExportPath() {
        return SysPropsFactory.getProperty("order.store.export.dataPath");
    }

    public String getExcelTemplateFilePath() {
        return SysPropsFactory.getProperty("order.store.export.excelTemplateFilePath");
    }

    public String getExcelExportPathUrl() {
        return SysPropsFactory.getProperty("order.store.export.download.url");
    }

    /**
     * 商超订单记录 配置参数
     * @author shiy 
     * @date 2016年12月9日 下午07:36:16
     */
    public String getMailHost() {
        return SysPropsFactory.getProperty("order.store.export.mail.host");
    }

    public String getMailSendUserName() {
        return SysPropsFactory.getProperty("order.store.export.mail.username");
    }

    public String getMailSendPassword() {
        return SysPropsFactory.getProperty("order.store.export.mail.password");
    }

    public String getMailFrom() {
        return SysPropsFactory.getProperty("order.store.export.mail.from");
    }

    public String getDownloadPayRecordPath() {
        return SysPropsFactory.getProperty("order.store.export.mail.pay.filepath");
    }

    public String getPayRecordZipPath() {
        return SysPropsFactory.getProperty("order.store.export.mail.pay.zippath");
    }

    public String getPayTemplatePath() {
        return SysPropsFactory.getProperty("order.store.export.mail.pay.templatepath");
    }

    public String getOrderTemplatePath() {
        return SysPropsFactory.getProperty("order.store.export.mail.order.templatepath");
    }

    public String getDownloadOrderRecordPath() {
        return SysPropsFactory.getProperty("order.store.export.mail.order.filepath");
    }
}
