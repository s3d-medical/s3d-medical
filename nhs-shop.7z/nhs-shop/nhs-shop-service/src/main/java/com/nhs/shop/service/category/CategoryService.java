package com.nhs.shop.service.category;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Lists;
import com.nhs.core.web.WebRequestException;
import com.nhs.shop.dao.legend.service.O2oCategoryDao;
import com.nhs.shop.dao.legend.shop.CategoryDao;
import com.nhs.shop.dao.legend.shop.O2oHotCategoryConfigDao;
import com.nhs.shop.dao.legend.shop.O2oHotCategoryDao;
import com.nhs.shop.entry.legend.service.O2oCategory;
import com.nhs.shop.entry.legend.shop.Category;
import com.nhs.shop.entry.legend.shop.O2oHotCategory;
import com.nhs.shop.entry.legend.shop.O2oHotCategoryConfig;
import com.nhs.shop.service.BaseService;
import com.nhs.shop.service.category.dto.CategoryDto;
import com.nhs.shop.service.category.dto.O2oCategoryDto;
import com.nhs.shop.service.category.dto.O2oHotCategoryDto;
import com.nhs.shop.service.category.dto.SubCategoryDto;

/**
 * 商品分类service
 * @Title: CategoryService.java
 * @Package com.nhs.shop.service.category
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月16日 下午5:28:52
 * @version V1.0
 */
@Service
@Transactional
public class CategoryService extends BaseService {

    @Autowired
    private CategoryDao categoryDao; // 分类dao

    @Autowired
    private O2oCategoryDao o2oCategoryDao;

    @Autowired
    private O2oHotCategoryDao o2oHotCategoryDao;

    @Autowired
    private O2oHotCategoryConfigDao o2oHotCategoryConfigDao;

    private static String sortType_down = "down";
    
    private static String sortType_up = "up";

    public List<CategoryDto> getCategoryList() {
        List<CategoryDto> list = Lists.newArrayList();
        // 获取全部分类
        List<Category> categorys = categoryDao.findCategory();
        // 获取二级分类
        List<Category> firstCategorys = categoryDao.findFirstCategory();
        CategoryDto dto = null;
        for (Category firstCategory : firstCategorys) {
            dto = new CategoryDto();
            dto.setCategoryId(firstCategory.getId());
            dto.setTitle(firstCategory.getName());
            dto.setChildren(getChildren(firstCategory.getId(), categorys));
            list.add(dto);
        }
        return list;
    }

    /**
     * 获取分类子节点
     * 
     * @param id
     * @param categorys
     * @return
     */
    private List<SubCategoryDto> getChildren(int id, List<Category> categorys) {
        List<SubCategoryDto> children = Lists.newArrayList();
        SubCategoryDto subDto = null;
        for (Category category : categorys) {
            if (category.getParentId() != null && category.getParentId() > 0 && category.getParentId() == id) {
                subDto = new SubCategoryDto();
                subDto.setCategoryId(category.getId());
                subDto.setTitle(category.getName());
                subDto.setIcon(this.buildImg(category.getIcon()));
                children.add(subDto);
            }
        }
        return children;
    }

    /**
     * 获取分类配置信息
     * @Title: getO2oHotCategoryList
     * @Description: TODO
     * @param @return   
     * @return List<O2oHotCategoryDto> 
     * @author liangdanhua 2016年9月18日 
     * @throws
     */
    public List<O2oHotCategoryDto> getO2oHotCategoryList(int pageNo, int pageSize) {
        Page<O2oHotCategory> page = null;
        try {
            PageRequest request = new PageRequest(pageNo - 1, pageSize,
                    new Sort(new Sort.Order(Sort.Direction.DESC, "updateTime")));
            page = o2oHotCategoryDao.findAllO2oHotCategory(request);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        List<O2oHotCategory> hotCategoryParams = page.getContent();
        List<O2oHotCategoryDto> returnParams = Lists.newArrayList();
        if (hotCategoryParams != null && hotCategoryParams.size() != 0) {
            for (O2oHotCategory hotCategory : hotCategoryParams) {
                O2oHotCategoryDto returnParam = new O2oHotCategoryDto();
                returnParam.setApplyCout(hotCategory.getApplynumber());
                returnParam.setGroupId(hotCategory.getId());
                returnParam.setName(hotCategory.getName());
                returnParam.setReleaseCout(hotCategory.getReleaseNumber());
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
                returnParam.setReleaseTime(sdf.format(hotCategory.getReleaseTime()));
                returnParam.setUpdateTime(sdf.format(hotCategory.getUpdateTime()));
                returnParam.setStatus(hotCategory.getStatus());
                List<O2oHotCategoryConfig> o2oHotCategoryConfigList = o2oHotCategoryConfigDao
                        .findO2oHotCategoryConfigByGroupId(hotCategory.getId());
                for (O2oHotCategoryConfig o2oHotCategoryConfig : o2oHotCategoryConfigList) {
                    O2oCategory o2oCategory = o2oCategoryDao.findOne(o2oHotCategoryConfig.getParentId());
                    if (o2oCategory != null) {
                        o2oHotCategoryConfig.setRealName(o2oCategory.getName());
                    }
                }
                if (o2oHotCategoryConfigList != null && o2oHotCategoryConfigList.size() != 0) {
                    returnParam.setO2oHotCategoryConfig(o2oHotCategoryConfigList);
                    returnParam.setCount(o2oHotCategoryConfigList.size());
                } else {
                    returnParam.setCount(0);
                }
                returnParams.add(returnParam);
            }
        }
        return returnParams;
    }

    /**
     * O2O热门分类配置组新增接口
     * @Title: addO2oHotCategory
     * @Description: TODO
     * @param @param name
     * @param @return   
     * @return String 
     * @author liangdanhua 2016年9月18日 
     * @throws
     */
    public String addO2oHotCategory(String name) {
        Date date = new Date();
        String isSave = "0";
        O2oHotCategory oldO2oHotCategory = o2oHotCategoryDao.findO2oHotCategoryByName(name);
        if (oldO2oHotCategory != null) {
            throw new WebRequestException("该分组名字已经使用");
        }
        O2oHotCategory newO2oHotCategory = new O2oHotCategory();
        newO2oHotCategory.setApplynumber(0);
        newO2oHotCategory.setName(name);
        newO2oHotCategory.setReleaseNumber(0);
        newO2oHotCategory.setSort(o2oHotCategoryDao.findAll().size());
        newO2oHotCategory.setStatus(0);
        newO2oHotCategory.setUpdateTime(date);
        newO2oHotCategory.setReleaseTime(date);
        O2oHotCategory totalCategory = o2oHotCategoryDao.save(newO2oHotCategory);
        if (name.equals(newO2oHotCategory.getName())) {
            isSave = "1";
        }
        return isSave;
    }

    /**
     * O2O热门分类配置发布
     * @Title: addO2oHotCategory
     * @Description: TODO
     * @param @param name
     * @param @return   
     * @return String 
     * @author liangdanhua 2016年9月18日 
     * @throws
     */
    public String publishO2oHotCategory() {
        Date date = new Date();
        String isSave = "0";
        List<O2oHotCategory> findhotCategorys = o2oHotCategoryDao.findAll();
        for (O2oHotCategory param : findhotCategorys) {
            param.setStatus(2);
            param.setUpdateTime(date);
            o2oHotCategoryDao.saveAndFlush(param);

        }
        isSave = "1";
        return isSave;
    }

    /**
     * O2O热门分类配保存
     * @Title: hotCategorySave
     * @Description: TODO
     * @param @param o2oHotCategorylist   
     * @return void 
     * @author liangdanhua 2016年9月18日 
     * @throws
     */
    public String saveHotCategory(List<O2oHotCategoryConfig> o2oHotCategorylist) {
        String isSave = "1";
        if (o2oHotCategorylist != null && o2oHotCategorylist.size() != 0) {
            for (O2oHotCategoryConfig oldHCCf : o2oHotCategorylist) {
                O2oHotCategoryConfig newHCCf = o2oHotCategoryConfigDao.findO2oHotCategoryConfigParentIdAndGroupId(
                        oldHCCf.getSort(), oldHCCf.getCategoryId(), oldHCCf.getGroupId());
                if (newHCCf == null) {
                    oldHCCf.setRecDate(new Date());
                    O2oHotCategoryConfig findHCCf = o2oHotCategoryConfigDao.save(oldHCCf);
                    if (oldHCCf.getCategoryId() != findHCCf.getCategoryId()) {
                        isSave = "0";
                    }
                } else {
                    if (oldHCCf.getCategoryId() != null) {
                        newHCCf.setCategoryId(oldHCCf.getCategoryId());
                    }
                    if (oldHCCf.getGroupId() != null) {
                        newHCCf.setGroupId(oldHCCf.getGroupId());
                    }
                    if (oldHCCf.getIcon() != null) {
                        newHCCf.setIcon(oldHCCf.getIcon());
                    }
                    if (oldHCCf.getId() != null) {
                        newHCCf.setId(oldHCCf.getId());
                    }
                    if (StringUtils.isNotBlank(oldHCCf.getName())) {
                        newHCCf.setName(oldHCCf.getName());
                    }
                    if (oldHCCf.getParentId() != null) {
                        newHCCf.setParentId(oldHCCf.getParentId());
                    }
                    if (oldHCCf.getRecDate() != null) {
                        newHCCf.setRecDate(new Date());
                    }
                    if (oldHCCf.getSort() != null) {
                        newHCCf.setSort(oldHCCf.getSort());
                    }
                    if (oldHCCf.getStatus() != null) {
                        newHCCf.setStatus(oldHCCf.getStatus());
                    }
                    O2oHotCategoryConfig findHCCf = o2oHotCategoryConfigDao.saveAndFlush(newHCCf);

                    if (newHCCf.getId() != findHCCf.getId()) {
                        isSave = "0";
                    }
                }
            }
        }
        return isSave;
    }

    /**
     * O2O热门分类配二级分类获取
     * @Title: getO2oCategoryList
     * @Description: TODO
     * @param @return   
     * @return List<O2oCategoryDto> 
     * @author liangdanhua 2016年9月18日 
     * @throws
     */
    public List<O2oCategoryDto> getO2oCategoryList() {
        List<O2oCategoryDto> list = Lists.newArrayList();
        List<O2oCategory> categorys = o2oCategoryDao.findO2oCategory();
        O2oCategoryDto dto = null;
        for (O2oCategory o2oCategory : categorys) {
            if (o2oCategory.getParentId() != 0) {
                continue;
            }
            dto = new O2oCategoryDto();
            dto.setCategoryId(o2oCategory.getId());
            dto.setTitle(o2oCategory.getName());
            dto.setChildren(o2oCategoryDao.findO2oCategory(o2oCategory.getId()));
            list.add(dto);
        }
        return list;
    }

    public String deleteCategoryByGroupId(Integer groupId) {
        String isdelete = "1";
        O2oHotCategory o2oHotCategory = o2oHotCategoryDao.findOne(groupId);
        if (o2oHotCategory != null) {
            o2oHotCategoryDao.delete(o2oHotCategory);
        }
        O2oHotCategory o2oHotCategory2 = o2oHotCategoryDao.findOne(groupId);
        if (o2oHotCategory2 == null) {
            isdelete = "0";
        }
        List<O2oHotCategoryConfig> o2oHotCategorys = o2oHotCategoryConfigDao.findO2oHotCategoryConfigByGroupId(groupId);
        o2oHotCategoryConfigDao.delete(o2oHotCategorys);
        List<O2oHotCategoryConfig> o2oHotCategorys2 = o2oHotCategoryConfigDao
                .findO2oHotCategoryConfigByGroupId(groupId);
        if (o2oHotCategorys2 == null) {
            isdelete = "0";
        }
        return isdelete;
    }

    public List<O2oHotCategoryConfig> queryO2oHotCategoryDtoByGroupId(Integer groupId) {
        List<O2oHotCategoryConfig> o2oHotCategorys = o2oHotCategoryConfigDao.findO2oHotCategoryConfigByGroupId(groupId);
        return o2oHotCategorys;
    }

    public String saveChange(Integer groupId, Integer id1, String index) {
        String isSave = "0";
        O2oHotCategoryConfig category1 = o2oHotCategoryConfigDao.findOne(id1);
        int sort1 = category1.getSort();
        int sort2 = 0;
        if (sortType_down.equals(index)) {
            sort2 = sort1 + 1;
        } else if (sortType_up.equals(index)) {
            sort2 = sort1 - 1;
        }
        O2oHotCategoryConfig category2 = o2oHotCategoryConfigDao.findO2oHotCategoryConfigbySortandGroupId(sort2,
                groupId);

        category1.setSort(sort2);
        category2.setSort(sort1);

        o2oHotCategoryConfigDao.saveAndFlush(category1);
        o2oHotCategoryConfigDao.saveAndFlush(category2);

        if (category1.getSort() == sort2 && category2.getSort() == sort1) {
            isSave = "1";
        }
        return isSave;
    }
}
