package com.nhs.shop.service.order.assist;

import java.math.BigDecimal;

import org.springframework.stereotype.Service;

import com.nhs.shop.service.common.dto.CustFieldDto;
import com.nhs.shop.service.goods.dto.PromotionDto;
import com.nhs.shop.service.order.dto.OrderConfirmDto;

@Service
public class OrderCustDataConvertor {
	
	/**
	 * 将确认订单上的优惠选项进行格式化
	 * @param orderConfirmDto
	 * @param promo
	 */
	public void formatPromoInfo(OrderConfirmDto orderConfirmDto, PromotionDto promo){
		if(promo == null){
    		return ;
    	}
    	//立减
    	BigDecimal totalReduced = promo.getReducedCash();
    	if(totalReduced != null && totalReduced.doubleValue() >0){
    		orderConfirmDto.setReducedCash(new CustFieldDto("减", 
    				"立减" + totalReduced.toString()+ "元", totalReduced.toString()));
    	}
	}
}
