package com.nhs.shop.service.Benefits.dto;

import java.io.Serializable;

public class CoinCommissionGoldLogDto implements Serializable {

    private static final long serialVersionUID = 7379506324156196472L;

    private String createTime = "";
    private String income = "";
    private String payment = "";
    private String orderNum = "";
    private String remarks = "";
    private Integer type;

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getIncome() {
        return income;
    }

    public void setIncome(String income) {
        this.income = income;
    }

    public String getPayment() {
        return payment;
    }

    public void setPayment(String payment) {
        this.payment = payment;
    }

    public String getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(String orderNum) {
        this.orderNum = orderNum;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

}
