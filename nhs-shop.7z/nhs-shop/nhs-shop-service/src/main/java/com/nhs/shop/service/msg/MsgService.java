package com.nhs.shop.service.msg;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nhs.core.orm.Page;
import com.nhs.shop.dao.legend.msg.MsgDao;
import com.nhs.shop.dao.legend.msg.MsgTextDao;
import com.nhs.shop.entry.legend.shop.MsgText;

/**
 * 消息处理 service
 * @Title: MsgService.java
 * @Package com.nhs.shop.service.goods
 * @Description: TODO
 * @author Cary
 * @date 2016年8月24日 下午7:42:18
 * @version V1.0
 */
@Service
@Transactional
public class MsgService {
    @Autowired
    private MsgDao msgDao;
    @Autowired
    private MsgTextDao msgTextDao;

    public Integer getUnReadMsgCount(String userName) {
        Map<String, Object> count = msgDao.getUnReadCount(userName);
        return ((Long) count.get("count")).intValue();
    }

    public List<Map<String, Object>> getMsgList(String userName, Page<Map<String, Object>> page) {
        Page<Map<String, Object>> pageData = msgDao.getMsgList(userName, page);
        return pageData.getResult();
    }

    public MsgText readMsg(String userName, Integer msgId) {
        MsgText msgText = msgTextDao.findMsgTextById(msgId);
        msgDao.updateReadStatus(userName, String.valueOf(msgId));
        return msgText;
    }

}
