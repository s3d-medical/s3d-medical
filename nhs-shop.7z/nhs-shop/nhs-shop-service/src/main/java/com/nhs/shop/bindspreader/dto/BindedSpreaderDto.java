package com.nhs.shop.bindspreader.dto;

import java.io.Serializable;

/**
 * 
 * @author wind.chen
 *
 */
public class BindedSpreaderDto implements Serializable{
	private static final long serialVersionUID = -2027934340675989065L;
	private String userId;
	private String shopId;
	private String mobileNo;
	private String spreaderType;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getShopId() {
		return shopId;
	}
	public void setShopId(String shopId) {
		this.shopId = shopId;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getSpreaderType() {
		return spreaderType;
	}
	public void setSpreaderType(String spreaderType) {
		this.spreaderType = spreaderType;
	}
}
