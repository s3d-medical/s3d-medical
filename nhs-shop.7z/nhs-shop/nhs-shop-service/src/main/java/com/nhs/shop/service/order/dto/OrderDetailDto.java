package com.nhs.shop.service.order.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import com.google.common.collect.Lists;

public class OrderDetailDto implements Serializable {
    private static final long serialVersionUID = 2308053677959309156L;
    private Integer orderId;
    private String orderNum = "";
    private Integer shopId;
    private String shopName = "";
    private Integer status;
    private String statusName = "";
    private Integer totalNum;
    private Double totalAmount;
    private BigDecimal freightAmount;
    private Double payAmount;
    private List<OrderItemDto> itemList = Lists.newArrayList();
    private UserAddressDto address;
    private String createTime = "";
    private String payTime = "";
    private String sendTime = "";
    private String arriageShowUrl = "";
    private String cancelTime = "";
    private String successTime = "";
    private String reduceAmount = "";
    private String couponAmount = "";
    private String couponStr;
    private String actualPayAmountStr = "";
    private String coupon;
    private String discount;

    public String getCancelTime() {
        return cancelTime;
    }

    public void setCancelTime(String cancelTime) {
        this.cancelTime = cancelTime;
    }

    public String getSuccessTime() {
        return successTime;
    }

    public void setSuccessTime(String successTime) {
        this.successTime = successTime;
    }

    public String getArriageShowUrl() {
        return arriageShowUrl;
    }

    public void setArriageShowUrl(String arriageShowUrl) {
        this.arriageShowUrl = arriageShowUrl;
    }

    public Integer getShopId() {
        return shopId;
    }

    public void setShopId(Integer shopId) {
        this.shopId = shopId;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getStatusName() {
        return statusName;
    }

    public void setStatusName(String statusName) {
        this.statusName = statusName;
    }

    public Integer getTotalNum() {
        return totalNum;
    }

    public void setTotalNum(Integer totalNum) {
        this.totalNum = totalNum;
    }

    public Double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(Double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public List<OrderItemDto> getItemList() {
        return itemList;
    }

    public void setItemList(List<OrderItemDto> itemList) {
        this.itemList = itemList;
    }

    public void addOrderItemDto(OrderItemDto orderItemDto) {
        this.itemList.add(orderItemDto);
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public BigDecimal getFreightAmount() {
        return freightAmount;
    }

    public void setFreightAmount(BigDecimal bigDecimal) {
        this.freightAmount = bigDecimal;
    }

    public Double getPayAmount() {
        return payAmount;
    }

    public void setPayAmount(Double payAmount) {
        this.payAmount = payAmount;
    }

    public String getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(String orderNum) {
        this.orderNum = orderNum;
    }

    public UserAddressDto getAddress() {
        return address;
    }

    public void setAddress(UserAddressDto address) {
        this.address = address;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getPayTime() {
        return payTime;
    }

    public void setPayTime(String payTime) {
        this.payTime = payTime;
    }

    public String getSendTime() {
        return sendTime;
    }

    public void setSendTime(String sendTime) {
        this.sendTime = sendTime;
    }
    

    public String getReduceAmount() {
		return reduceAmount;
	}

	public void setReduceAmount(String reduceAmount) {
		this.reduceAmount = reduceAmount;
	}

	public String getCouponAmount() {
		return couponAmount;
	}

	public void setCouponAmount(String couponAmount) {
		this.couponAmount = couponAmount;
	}

	public String getCouponStr() {
		return couponStr;
	}

	public void setCouponStr(String couponStr) {
		this.couponStr = couponStr;
	}

	public String getActualPayAmountStr() {
		return actualPayAmountStr;
	}

	public void setActualPayAmountStr(String actualPayAmountStr) {
		this.actualPayAmountStr = actualPayAmountStr;
	}

	public String getCoupon() {
		return coupon;
	}

	public void setCoupon(String coupon) {
		this.coupon = coupon;
	}

	public String getDiscount() {
		return discount;
	}

	public void setDiscount(String discount) {
		this.discount = discount;
	}




	public static class OrderItemDto implements Serializable {
        private static final long serialVersionUID = -3558757278649774970L;
        private Integer prodId;
        private String prodName = "";
        private String skuDesc = "";
        private Double price;
        private Integer count;
        private String pic = "";
        private String detailUrl = "";
        private String subsidy = "";
        private String mailStatus = "";
        private String subsidyStr = "";
        private String coupon;
        private String discount;

        public String getMailStatus() {
            return mailStatus;
        }

        public void setMailStatus(String mailStatus) {
            this.mailStatus = mailStatus;
        }

        public Integer getProdId() {
            return prodId;
        }

        public void setProdId(Integer prodId) {
            this.prodId = prodId;
        }

        public String getProdName() {
            return prodName;
        }

        public void setProdName(String prodName) {
            this.prodName = prodName;
        }

        public String getSkuDesc() {
            return skuDesc;
        }

        public void setSkuDesc(String skuDesc) {
            this.skuDesc = skuDesc;
        }

        public Double getPrice() {
            return price;
        }

        public void setPrice(Double price) {
            this.price = price;
        }

        public Integer getCount() {
            return count;
        }

        public void setCount(Integer count) {
            this.count = count;
        }

        public String getPic() {
            return pic;
        }

        public void setPic(String pic) {
            this.pic = pic;
        }

        public String getDetailUrl() {
            return detailUrl;
        }

        public void setDetailUrl(String detailUrl) {
            this.detailUrl = detailUrl;
        }

        public String getSubsidy() {
            return subsidy;
        }

        public void setSubsidy(String subsidy) {
            this.subsidy = subsidy;
        }

		public String getSubsidyStr() {
			return subsidyStr;
		}

		public void setSubsidyStr(String subsidyStr) {
			this.subsidyStr = subsidyStr;
		}

		public String getCoupon() {
			return coupon;
		}

		public void setCoupon(String coupon) {
			this.coupon = coupon;
		}

		public String getDiscount() {
			return discount;
		}

		public void setDiscount(String discount) {
			this.discount = discount;
		}

    }
}
