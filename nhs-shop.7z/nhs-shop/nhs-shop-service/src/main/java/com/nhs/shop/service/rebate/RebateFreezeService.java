package com.nhs.shop.service.rebate;

import java.math.BigDecimal;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nhs.apiproxy.member.acc.service.AccountTransferService;
import com.nhs.core.common.NhsConstant;
import com.nhs.shop.dao.legend.coin.CoinFreezeGoldDao;
import com.nhs.shop.dao.legend.coin.CoinFreezeSilverDao;
import com.nhs.shop.dao.legend.pay.PayCashLogDao;
import com.nhs.shop.entry.em.EmStatus;
import com.nhs.shop.entry.em.shop.EmCashLogType;
import com.nhs.shop.entry.em.user.EmCashType;
import com.nhs.shop.entry.em.user.EmUserType;
import com.nhs.shop.entry.legend.coin.CoinFreezeGold;
import com.nhs.shop.entry.legend.coin.CoinFreezeSilver;
import com.nhs.shop.entry.legend.pay.PdCashLog;
import com.nhs.shop.entry.legend.store.StoreOrderItem;
import com.nhs.shop.entry.legend.user.UsrDetail;
import com.nhs.shop.rebate.service.CalRebateService;

/**
 * 清算冻结的银币计算
 * @Title: RebateFreezeService.java
 * @Package com.nhs.shop.service.rebate
 * @Description: TODO
 * @author huxianjun
 * @date 2016年11月8日 上午11:51:11
 * @version V1.0
 */
@Service
public class RebateFreezeService {

    private static Logger logger = LoggerFactory.getLogger(RebateFreezeService.class);
    // 商品的最高赠送比
    public static final Double rebate_rate_max = 0.625;
    // 商品的最小赠送比
    public static final Double rebate_rate_min = 0.02;
    // 人民币兑换银币
    private static final Integer exchange_rate = 1;

    @Autowired
    private CoinFreezeSilverDao coinFreezeSilverDao;

    @Autowired
    private PayCashLogDao payCashLogDao;
    
    @Autowired
    private CoinFreezeGoldDao coinFreezeGoldDao;
    
    @Autowired
    private AccountTransferService accountTransferService;
    
    @Autowired
    private CalRebateService calRebateService;

    /**
     * 处理个人账户的银币
     * @Title: saveUserRebate
     * @Description: TODO
     * @param @param usrDetail
     * @param @param prodRebate
     * @param @param prodId
     * @param @param totalAmount
     * @param @param cash
     * @param @param price
     * @param @param orderNo
     * @param @param prodNum
     * @param @param nowTime
     * @param @throws Exception   
     * @return void 
     * @author huxianjun 2016年8月12日 
     * @throws
     */
    public void saveUserRebate(UsrDetail usrDetail, String orderDesc, BigDecimal prodRebate, BigDecimal prodAdRate,
            Integer prodId, BigDecimal totalAmount, BigDecimal cash, BigDecimal price, String orderNo, Integer prodNum,
            Date unfreezeTime, Date nowTime, Integer flag) throws Exception {
        logger.info("------个人账户的冻结银币，清算订单类型：" + orderDesc + ",用户ID:" + usrDetail.getUserId());
//        BigDecimal rebate = this.calRebate(prodRebate);
        BigDecimal rebate = calRebateService.calRebate(prodAdRate, new BigDecimal(NhsConstant.DEFAULT_AD_FEE_BASIC_RATE), NhsConstant.DEFAULT_AD_FEE_RATE_NEW_MAX_O2O);
        BigDecimal totalRebateCash = totalAmount.multiply(rebate);
        BigDecimal coins = totalRebateCash.multiply(new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE));

        CoinFreezeSilver freezeSilver = new CoinFreezeSilver();
        freezeSilver.setCash(cash);
        freezeSilver.setPrice(price);
        freezeSilver.setSubNumber(orderNo);
        freezeSilver.setProdId(prodId);
        freezeSilver.setProdNo(prodId == null ? null : String.valueOf(prodId));
        freezeSilver.setCreateTime(nowTime);
        freezeSilver.setUserId(usrDetail.getUserId());
        freezeSilver.setConvertScale(prodAdRate.floatValue());
        freezeSilver.setRebateScale(rebate.floatValue());
        freezeSilver.setProdNum(prodNum);
        freezeSilver.setTotalCash(totalAmount);
        freezeSilver.setTotalRebateCash(totalRebateCash);
        freezeSilver.setCoinSum(coins);
        freezeSilver.setType(EmUserType.general.value); // 普通用户
        freezeSilver.setUnfreezeTime(unfreezeTime);
        freezeSilver.setUnfreezeStatus(EmStatus.undeal.value);
        freezeSilver.setFlag(flag);
        coinFreezeSilverDao.save(freezeSilver);
        
        // TODO
        //usrDetail.setSilverFreeze(usrDetail.getSilverFreeze().add(coins).setScale(2, BigDecimal.ROUND_DOWN));
        this.accountTransferService.rebateFrozenSilver(usrDetail.getUserId(), orderNo, coins);
    }

    /**
     * 处理商家的返利
     * @Title: saveShopRebate
     * @Description: TODO
     * @param @param shop
     * @param @param prodRebate
     * @param @param prodAdRate
     * @param @param prodId
     * @param @param totalAmount
     * @param @param cash
     * @param @param price
     * @param @param orderNo
     * @param @param prodNum
     * @param @param nowTime
     * @param @throws Exception   
     * @return void 
     * @author huxianjun 2016年8月12日 
     * @throws
     */
    public void saveShopRebate(UsrDetail shop, String orderDesc, BigDecimal prodRebate, BigDecimal prodAdRate,
            Integer prodId, BigDecimal totalAmount, BigDecimal cash, BigDecimal price, String orderNo, Integer prodNum,
            Date unfreezeTime, Date nowTime, Integer flag) throws Exception {
        logger.info("------商家账户的冻结银币，清算订单类型：" + orderDesc + ",用户ID:" + shop.getUserId());
//        BigDecimal rebate = this.calRebate(prodRebate);
        BigDecimal rebate = calRebateService.calRebate(prodAdRate, new BigDecimal(NhsConstant.DEFAULT_AD_FEE_BASIC_RATE), NhsConstant.DEFAULT_AD_FEE_RATE_NEW_MAX_O2O);
        BigDecimal totalRebateCash = totalAmount.multiply(prodAdRate);
        BigDecimal coins = totalRebateCash.multiply(new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE));

        CoinFreezeSilver freezeSilver = new CoinFreezeSilver();
        freezeSilver.setCash(cash);
        freezeSilver.setPrice(price);
        freezeSilver.setSubNumber(orderNo);
        freezeSilver.setProdId(prodId);
        freezeSilver.setProdNo(prodId == null ? null : String.valueOf(prodId));
        freezeSilver.setCreateTime(nowTime);
        freezeSilver.setUserId(shop.getUserId());
        freezeSilver.setConvertScale(prodAdRate.floatValue());
        freezeSilver.setRebateScale(rebate.floatValue());
        freezeSilver.setProdNum(prodNum);
        freezeSilver.setTotalCash(totalAmount);
        freezeSilver.setTotalRebateCash(totalRebateCash);
        freezeSilver.setCoinSum(coins);
        freezeSilver.setType(EmUserType.shop.value); // 商家用户
        freezeSilver.setUnfreezeTime(unfreezeTime);
        freezeSilver.setUnfreezeStatus(EmStatus.undeal.value);
        freezeSilver.setFlag(flag);
        coinFreezeSilverDao.save(freezeSilver);

        // shop.setSilverFreeze(shop.getSilverFreeze().add(coins).setScale(2, BigDecimal.ROUND_DOWN));
        this.accountTransferService.rebateFrozenSilver(shop.getUserId(), orderNo, coins);
    }

    /**
     * 清算商家的运费
     * @Title: saveFreight
     * @Description: TODO
     * @param @param shopDetail
     * @param @param freightAmount
     * @param @param orderNo
     * @param @param nowTime
     * @param @throws Exception   
     * @return void 
     * @author huxianjun 2016年8月25日 
     * @throws
     */
    public void saveFreight(UsrDetail shopDetail, BigDecimal freightAmount, String orderNo, Date nowTime)
            throws Exception {
        if (BigDecimal.valueOf(0.0).compareTo(freightAmount) >= 0) {
            logger.info("商家账户的运费等于0.0，不清算，" + "用户ID:" + shopDetail.getUserId());
            return;
        }
        logger.info("开始结算商家账户的运费，" + "用户ID:" + shopDetail.getUserId());
        // TODO 商户余额 Robin.Chu 2016-11-18
        //shopDetail.setShopAvailablePred(shopDetail.getShopAvailablePred().add(freightAmount));
        this.accountTransferService.depositUserBizAccount(shopDetail.getUserId(), orderNo, freightAmount);
        
        PdCashLog pdCashLog = new PdCashLog();
        pdCashLog.setAddTime(nowTime);
        pdCashLog.setAmount(freightAmount);
        pdCashLog.setCashType(EmCashType.merchant.value);
        StringBuilder logDesc = new StringBuilder();
        logDesc.append("商家账户收入：").append(freightAmount).append(",(子)订单流水号: ").append(orderNo);
        pdCashLog.setLogType(EmCashLogType.SHOP_PD_INCOME.value);
        pdCashLog.setLogDesc(logDesc.toString());
        pdCashLog.setUserId(shopDetail.getUserId());
        pdCashLog.setUserName(shopDetail.getUserName());
        pdCashLog.setSn("freight_" + orderNo);
        payCashLogDao.save(pdCashLog);
    }
    
    
    /**
     * 处理个人账户的银币(商超订单)
     * @Title: saveUserRebate
     * @Description: TODO
     * @param @param usrDetail
     * @param @param prodRebate
     * @param @param prodId
     * @param @param totalAmount
     * @param @param cash
     * @param @param price
     * @param @param orderNo
     * @param @param prodNum
     * @param @param nowTime
     * @param @throws Exception   
     * @return void 
     * @author huxianjun 2016年8月12日 
     * @throws
     */
    public void saveUserRebateOfStoreOrder(UsrDetail usrDetail, StoreOrderItem item, 
            Date unfreezeTime, Date nowTime, Integer flag) throws Exception {
        logger.info("------个人账户的冻结银币，清算订单类型：商超订单,用户ID:" + usrDetail.getUserId());
//        BigDecimal rebate = this.calRebate(item.getProdRebateRate());
        BigDecimal rebate = calRebateService.calRebate(item.getProdAdFeeRate(), item.getProdAdFeeBasicRate(), NhsConstant.DEFAULT_AD_FEE_RATE_NEW_MAX_O2O);
        BigDecimal coins = item.getGiveSilver();
        BigDecimal totalRebateCash = coins.divide(new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE)).setScale(2, BigDecimal.ROUND_DOWN);

        CoinFreezeSilver freezeSilver = new CoinFreezeSilver();
        freezeSilver.setCash(item.getProdSalePrice());
        freezeSilver.setPrice(item.getProdPrimePrice());
        freezeSilver.setSubNumber(item.getOrderNum());
        freezeSilver.setProdId(null);
        freezeSilver.setProdNo(item.getProdNo());
        freezeSilver.setCreateTime(nowTime);
        freezeSilver.setUserId(usrDetail.getUserId());
        freezeSilver.setConvertScale(item.getProdAdFeeRate().floatValue());
        freezeSilver.setRebateScale(rebate.floatValue());
        freezeSilver.setProdNum(item.getProdNum().intValue());
        freezeSilver.setTotalCash(item.getProdAmount());
        freezeSilver.setTotalRebateCash(totalRebateCash);
        freezeSilver.setCoinSum(coins);
        freezeSilver.setType(EmUserType.general.value); // 普通用户
        freezeSilver.setUnfreezeTime(unfreezeTime);
        freezeSilver.setUnfreezeStatus(EmStatus.undeal.value);
        freezeSilver.setFlag(flag);
        coinFreezeSilverDao.save(freezeSilver);
        
        
        BigDecimal goldCoins = item.getGiveGold();
        BigDecimal totalRebateCashGold = goldCoins.divide(new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE)).setScale(2, BigDecimal.ROUND_DOWN);
        CoinFreezeGold freezeGold = new CoinFreezeGold();
        freezeGold.setCash(item.getProdSalePrice());
        freezeGold.setPrice(item.getProdPrimePrice());
        freezeGold.setSubNumber(item.getOrderNum());
        freezeGold.setProdNo(item.getProdNo());
        freezeGold.setCreateTime(nowTime);
        freezeGold.setUserId(usrDetail.getUserId());
        freezeGold.setConvertScale(item.getProdAdFeeRate().floatValue());
        freezeGold.setRebateScale(rebate.floatValue());
        freezeGold.setProdNum(item.getProdNum().intValue());
        freezeGold.setTotalCash(item.getProdAmount());
        freezeGold.setTotalRebateCash(totalRebateCashGold);
        freezeGold.setGoldSum(goldCoins);
        freezeGold.setType(EmUserType.general.value); // 普通用户
        freezeGold.setUnfreezeTime(unfreezeTime);
        freezeGold.setUnfreezeStatus(EmStatus.undeal.value);
        freezeGold.setFlag(flag);
        coinFreezeGoldDao.save(freezeGold);

//        usrDetail.setSilverFreeze(usrDetail.getSilverFreeze().add(coins).setScale(2, BigDecimal.ROUND_DOWN));
//        usrDetail.setGoldFreeze(usrDetail.getGoldFreeze().add(goldCoins).setScale(2, BigDecimal.ROUND_DOWN));
        this.accountTransferService.rebateFrozenSilver(usrDetail.getUserId(), item.getOrderNum()+"-"+item.getId(), coins);
        this.accountTransferService.rebateFrozenGold(usrDetail.getUserId(), item.getOrderNum()+"-"+item.getId(), goldCoins);
    }
    
    /**
     * 处理商家的返利(商超订单)
     * @Title: saveShopRebate
     * @Description: TODO
     * @param @param shop
     * @param @param prodRebate
     * @param @param prodAdRate
     * @param @param prodId
     * @param @param totalAmount
     * @param @param cash
     * @param @param price
     * @param @param orderNo
     * @param @param prodNum
     * @param @param nowTime
     * @param @throws Exception   
     * @return void 
     * @author huxianjun 2016年8月12日 
     * @throws
     */
    public void saveShopRebateOfStoreOrder(UsrDetail usrShopDetail, StoreOrderItem item, 
            Date unfreezeTime, Date nowTime, Integer flag) throws Exception {
        logger.info("------商家账户的冻结银币，清算订单类型：商超订单,用户ID:" + usrShopDetail.getUserId());
//        BigDecimal rebate = this.calRebate(item.getProdAdFeeRate());
        BigDecimal rebate = calRebateService.calRebate(item.getProdAdFeeRate(), item.getProdAdFeeBasicRate(), NhsConstant.DEFAULT_AD_FEE_RATE_NEW_MAX_O2O);
        BigDecimal totalRebateCash = item.getProdAmount().multiply(item.getProdAdFeeRate());
        BigDecimal coins = totalRebateCash.multiply(new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE));

        CoinFreezeSilver freezeSilver = new CoinFreezeSilver();
        freezeSilver.setCash(item.getProdSalePrice());
        freezeSilver.setPrice(item.getProdPrimePrice());
        freezeSilver.setSubNumber(item.getOrderNum());
        freezeSilver.setProdId(null);
        freezeSilver.setProdNo(item.getProdNo());
        freezeSilver.setCreateTime(nowTime);
        freezeSilver.setUserId(usrShopDetail.getUserId());
        freezeSilver.setConvertScale(item.getProdAdFeeRate().floatValue());
        freezeSilver.setRebateScale(rebate.floatValue());
        freezeSilver.setProdNum(item.getProdNum().intValue());
        freezeSilver.setTotalCash(item.getProdAmount());
        freezeSilver.setTotalRebateCash(totalRebateCash);
        freezeSilver.setCoinSum(coins);
        freezeSilver.setType(EmUserType.storeShop.value); // 普通用户
        freezeSilver.setUnfreezeTime(unfreezeTime);
        freezeSilver.setUnfreezeStatus(EmStatus.undeal.value);
        freezeSilver.setFlag(flag);
        coinFreezeSilverDao.save(freezeSilver);

        // shop.setSilverFreeze(shop.getSilverFreeze().add(coins).setScale(2, BigDecimal.ROUND_DOWN));
        this.accountTransferService.rebateFrozenSilver(usrShopDetail.getUserId(), item.getOrderNum()+"-"+item.getId(), coins);
    }

    /**
     * 计算赠送比例
     * @Title: calRebate
     * @Description: TODO
     * @param @param prodRebate
     * @param @return   
     * @return BigDecimal 
     * @author huxianjun 2016年11月1日 
     * @throws
     */
//    private BigDecimal calRebate(BigDecimal prodRebate) {
//        BigDecimal rebate = BigDecimal.valueOf(rebate_rate_min);
//        if (prodRebate != null) {
//            if (BigDecimal.valueOf(rebate_rate_min).compareTo(prodRebate) <= 0
//                    && BigDecimal.valueOf(rebate_rate_max).compareTo(prodRebate) >= 0) {
//                rebate = prodRebate;
//            } else if (BigDecimal.valueOf(rebate_rate_max).compareTo(prodRebate) < 0) {
//                rebate = BigDecimal.valueOf(rebate_rate_max);
//            }
//        }
//        return rebate;
//    }
}
