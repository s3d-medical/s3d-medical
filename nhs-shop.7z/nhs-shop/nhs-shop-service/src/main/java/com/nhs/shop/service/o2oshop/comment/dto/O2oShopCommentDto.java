package com.nhs.shop.service.o2oshop.comment.dto;

import java.util.List;

import com.nhs.shop.entry.legend.o2oshop.comment.O2oShopComment;

/**
 * 浏览器
 * @Title: VitLogDto.java
 * @Package com.nhs.shop.service.recommend.dto
 * @Description: TODO
 * @author Administrator
 * @date 2016年8月24日 下午7:58:01
 * @version V1.0
 */
public class O2oShopCommentDto extends O2oShopComment {

    private static final long serialVersionUID = 2453508524743748223L;

    private String userName;

    private String shopName;

    private String commentTimeStr;

    private int hasLike;

    private List<String> imagesList;

    private int likeCount;

    private String average;

    private String userImage;

    public String getShopUrl() {
        return shopUrl;
    }

    public void setShopUrl(String shopUrl) {
        this.shopUrl = shopUrl;
    }

    private String shopUrl;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public String getCommentTimeStr() {
        return commentTimeStr;
    }

    public void setCommentTimeStr(String commentTimeStr) {
        this.commentTimeStr = commentTimeStr;
    }

    public int getHasLike() {
        return hasLike;
    }

    public void setHasLike(int hasLike) {
        this.hasLike = hasLike;
    }

    public List<String> getImagesList() {
        return imagesList;
    }

    public void setImagesList(List<String> imagesList) {
        this.imagesList = imagesList;
    }

    public int getLikeCount() {
        return likeCount;
    }

    public void setLikeCount(int likeCount) {
        this.likeCount = likeCount;
    }

    public String getAverage() {
        return average;
    }

    public void setAverage(String average) {
        this.average = average;
    }

    public String getUserImage() {
        return userImage;
    }

    public void setUserImage(String userImage) {
        this.userImage = userImage;
    }

}
