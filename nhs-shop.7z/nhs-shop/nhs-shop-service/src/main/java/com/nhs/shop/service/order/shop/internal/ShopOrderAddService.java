package com.nhs.shop.service.order.shop.internal;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.nhs.apiproxy.member.acc.dto.UserAllAccDto;
import com.nhs.apiproxy.member.acc.service.AccountTransferService;
import com.nhs.core.common.NhsConstant;
import com.nhs.core.context.SysPropsFactory;
import com.nhs.core.mapper.JsonMapper;
import com.nhs.core.utils.common.ArithUtils;
import com.nhs.core.utils.common.DateUtils;
import com.nhs.core.web.WebRequestException;
import com.nhs.shop.dao.legend.region.AreasDao;
import com.nhs.shop.dao.legend.region.CityDao;
import com.nhs.shop.dao.legend.region.ProvincesDao;
import com.nhs.shop.dao.legend.shop.BasketDao;
import com.nhs.shop.dao.legend.shop.DeliveryDao;
import com.nhs.shop.dao.legend.shop.DvyTypeDao;
import com.nhs.shop.dao.legend.shop.InvoiceDao;
import com.nhs.shop.dao.legend.shop.InvoiceSubDao;
import com.nhs.shop.dao.legend.shop.ProdDao;
import com.nhs.shop.dao.legend.shop.SkuDao;
import com.nhs.shop.dao.legend.shop.SubDao;
import com.nhs.shop.dao.legend.shop.SubItemDao;
import com.nhs.shop.dao.legend.shop.UsrAddrSubDao;
import com.nhs.shop.entry.em.order.OrderCodeEnum;
import com.nhs.shop.entry.em.order.ServiceOrderStatusEnum;
import com.nhs.shop.entry.em.order.ShopOrderStatusEnum;
import com.nhs.shop.entry.legend.region.Areas;
import com.nhs.shop.entry.legend.region.City;
import com.nhs.shop.entry.legend.region.Provinces;
import com.nhs.shop.entry.legend.shop.Delivery;
import com.nhs.shop.entry.legend.shop.DvyType;
import com.nhs.shop.entry.legend.shop.Invoice;
import com.nhs.shop.entry.legend.shop.InvoiceSub;
import com.nhs.shop.entry.legend.shop.Prod;
import com.nhs.shop.entry.legend.shop.Sku;
import com.nhs.shop.entry.legend.shop.Sub;
import com.nhs.shop.entry.legend.shop.SubItem;
import com.nhs.shop.entry.legend.user.UsrAddr;
import com.nhs.shop.entry.legend.user.UsrAddrSub;
import com.nhs.shop.entry.legend.user.UsrDetail;
import com.nhs.shop.generator.OrderNumGenerator;
import com.nhs.shop.rebate.service.CalRebateService;
import com.nhs.shop.service.BaseOrderDto;
import com.nhs.shop.service.BaseOrderService;
import com.nhs.shop.service.common.dto.CarriageType;
import com.nhs.shop.service.goods.GoodCarriageService;
import com.nhs.shop.service.order.dto.OrderAddRequestDto;
import com.nhs.shop.service.order.dto.OrderShopDto;
import com.nhs.shop.service.order.dto.ShopProdDto;
import com.nhs.shop.service.sku.SkuService;
import com.nhs.shop.util.BasicConstant;
import com.nhs.user.service.OperateUserAccountService;
import com.nhs.user.service.UserService;

/**
 * 商城订单创建service
 * @Title: GoodsService.java
 * @Package com.nhs.shop.service.goods
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月16日 下午7:42:18
 * @version V1.0
 */
@Service
public class ShopOrderAddService extends BaseOrderService {

    @Autowired
    private ProvincesDao provincesDao;

    @Autowired
    private CityDao cityDao;

    @Autowired
    private AreasDao areasDao;

    // @Autowired
    // private UsrAddrDao usrAddressDao;

    @Autowired
    private UsrAddrSubDao usrAddrSubDao;

    @Autowired
    private UserService userService;

    @Autowired
    private BasketDao basketDao;

    @Autowired
    private ProdDao prodDao;

    @Autowired
    private SubDao subDao;

    @Autowired
    private SkuDao skuDao;

    @Autowired
    private SubItemDao subItemDao;

    @Autowired
    private SkuService skuService;

    @Autowired
    private DvyTypeDao dvyTypeDao;

    @Autowired
    private DeliveryDao deliveryDao;

    @Autowired
    private InvoiceDao invoiceDao;

    @Autowired
    private InvoiceSubDao invoiceSubDao;

    @Autowired
    private OperateUserAccountService userAccountService;

    @Autowired
    private AccountTransferService accountTransferService;

    @Autowired
    private GoodCarriageService goodCarriageService;
    
    @Autowired
    private CalRebateService calRebateService;

    /**
     * 创建商城订单
     * @Title: saveShopOrder
     * @Description: TODO
     * @param @param dto
     * @param @return   
     * @return Map<String,Object> 
     * @author Administrator 2016年7月20日 
     * @throws
     */

    public Map<String, Object> saveShopOrder(OrderAddRequestDto dto, String platformType) {
        UsrDetail user = userService.findUserById(dto.getUserId());
        if (user == null) {
            throw new WebRequestException("user不存在");
        }
        List<OrderShopDto> shopList = dto.getShopList();
        if (shopList.size() == 0) {
            throw new WebRequestException("订单数据为空");
        }

        // 抵用券
        BigDecimal couponMoney = new BigDecimal(0);
        if (dto.getCouponType() != 0) {
            UserAllAccDto userAllAcc = this.accountTransferService.findUserAllAcc(dto.getUserId());
            if (userAllAcc.getPGold().compareTo(BigDecimal.valueOf(dto.getCouponCount())) < 0) {
                throw new WebRequestException("抵用券数量不足");
            }
            couponMoney = ArithUtils.div2(BigDecimal.valueOf(dto.getCouponCount()), new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE), 2,
                    BigDecimal.ROUND_DOWN);
        }

        // 检查库存
        checkInventory(shopList);

        // 保存用户地址
        UsrAddr usrAddr = this.userService.findShipAddrById(dto.getUserId(), dto.getAddressId());
        if (usrAddr == null || StringUtils.isEmpty(usrAddr.getUserId())) {
            throw new WebRequestException("用户地址不存在");
        }
        UsrAddrSub usrAddrSub = saveUserAddressSub(usrAddr);
        List<String> orderNumList = Lists.newArrayList();
        List<String> orderIdList = Lists.newArrayList();
        BigDecimal totalAmount = new BigDecimal("0.00");
        // 一个商家一个订单
        for (OrderShopDto orderShopDto : shopList) {
            // 生成订单号
            String orderNum = OrderNumGenerator.getOrderNumber(user.getUserMobile(), OrderCodeEnum.SHOP_ORDER);
            StringBuilder prodName = new StringBuilder();
            // 订单主信息
            Sub sub = new Sub();
            sub.setPlatformType(platformType);
            sub.setUserName(user.getUserName());
            sub.setAddrOrderId(usrAddrSub.getAddrOrderId()); // 订单地址
            sub.setSubNumber(orderNum);

            // 发票信息
            saveInvoiceInfo(dto, sub);

            // double emsTransfee = 0.0;
            BigDecimal totalReduceMoney = new BigDecimal("0.00");
            List<ShopProdDto> shoplist = orderShopDto.getProdList();
            List<Prod> prodList = new ArrayList<>();
            List<Double> countList = new ArrayList<>();
            for (ShopProdDto spd : shoplist) {
                Prod prod = prodDao.findOne(spd.getProdId());
                // 计算运费
                // calEmsTransfee(dto,platformType,prod,emsTransfee,spd);
                // 运费计算的参数封装
                prodList.add(prod);
                countList.add(new Double(spd.getCount()));
                // 立减，抵用券
                if (prod.getAdFeeRate() == null) {
                    prod.setAdFeeRate(new BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE));
                }
                if (prod.getAdFeeBasicRate() == null) {
                    prod.setAdFeeBasicRate(new BigDecimal(NhsConstant.DEFAULT_AD_FEE_BASIC_RATE));
                }
                // 商家推广费率<=10%时，按照之前规则赠送给用户佰德钻；商家推广费率>10%时，超出比例部分做立减
                Sku sku = null;
                if (spd.getSkuId() != null && spd.getSkuId() > 0) {
                    sku = skuDao.findOne(spd.getSkuId());
                }

                double prodCash = ArithUtils
                        .mul(sku != null ? sku.getPrice().doubleValue() : prod.getCash().doubleValue(), spd.getCount());
                if (prod.getAdFeeRate().compareTo(new BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE_CRITICAL)) > 0) {
                    if (dto.getConsumeReduceType() != 0) { // 已经勾选消费立减选项
                        BigDecimal reduce = ArithUtils.sub2(prod.getAdFeeRate(),
                                new BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE_CRITICAL), 3, BigDecimal.ROUND_DOWN); // 立减百分比
                        BigDecimal reduceMoney = ArithUtils.mul2(BigDecimal.valueOf(prodCash), reduce, 4,
                                BigDecimal.ROUND_DOWN); // 立减金额
                        spd.setReduceAmount(reduceMoney);
                        totalReduceMoney = ArithUtils.add2(totalReduceMoney, reduceMoney, 2, BigDecimal.ROUND_DOWN);
                    }
//                    spd.setRebate(new BigDecimal(NhsConstant.DEFAULT_REBATE));
                } else {
//                    spd.setRebate(
//                            ArithUtils.div2(prod.getAdFeeRate(), prod.getAdFeeBasicRate(), 3, BigDecimal.ROUND_DOWN));
                }
                spd.setRebate(calRebateService.calRebate(prod.getAdFeeRate(), prod.getAdFeeBasicRate(), NhsConstant.DEFAULT_AD_FEE_RATE_NEW_MAX_SHOP));
            }

            int cityId = NhsConstant.DEFAULT_CITY_ID;
            if (null != usrAddr.getCityId()) {
                cityId = usrAddr.getCityId();
            }

            BigDecimal emsTransfee = goodCarriageService.calOneKindsOfPostageVal(prodList, countList, cityId,
                    CarriageType.parse(dto.getExpressType()));

            sub.setCouponAmount(couponMoney);

            sub.setFreightAmount(emsTransfee);

            // 保存订单明细信息
            saveSubItem(orderShopDto, orderNum, dto.getUserId(), prodName, sub, couponMoney);
            // 计算订单真实的总价格.
            BigDecimal oneSubTotalAmount = new BigDecimal("0.00");
            oneSubTotalAmount = this.calOrderTotalAmount(sub.getTotal(), emsTransfee, totalReduceMoney, couponMoney);
            sub.setActualTotal(oneSubTotalAmount);
            // 所有订单总额累加.
            totalAmount = totalAmount.add(oneSubTotalAmount);

            // 保存订单主信息
            Sub newSub = saveSub(sub, dto, orderShopDto, prodName.toString());
            // 订单id
            orderNumList.add(orderNum);
            orderIdList.add(String.valueOf(newSub.getSubId()));

            // 生成订单时暂时把个人账户的佰德券转冻结起来，支付成功后扣除，如果未支付，将给他释放冻结部分
            if (dto.getCouponType() != 0) {
                // boolean flag = userAccountService.goldFreeze(BigDecimal.valueOf(dto.getCouponCount()),
                // dto.getUserId());
                boolean flag = userAccountService.freezeGold(dto.getUserId(), orderNum,
                        BigDecimal.valueOf(dto.getCouponCount()));
                if (!flag) {
                    // 个人账户抵用券余额不足
                    throw new WebRequestException("抵用券数量不足");
                }
            }
        }

        return buildResult(orderIdList, orderNumList, totalAmount);
    }

    /**
     * 
     * @param initOrderTotal
     * @param emsTransfee
     * @param totalReduceMoney
     * @param couponMoney
     * @return
     */
    private BigDecimal calOrderTotalAmount(BigDecimal initOrderTotal, BigDecimal emsTransfee,
            BigDecimal totalReduceMoney, BigDecimal couponMoney) {
        BigDecimal totalAmount = new BigDecimal(0);
        totalAmount = ArithUtils.add2(totalAmount, emsTransfee, 2, BigDecimal.ROUND_DOWN);
        // 总付款金额
        // TODO liangdanhua 修改总付款金额
        totalAmount = ArithUtils.add2(totalAmount, initOrderTotal, 2, BigDecimal.ROUND_DOWN);
        // 总额减去立减的钱
        totalAmount = ArithUtils.sub2(totalAmount, totalReduceMoney, 2, BigDecimal.ROUND_DOWN);
        // 总额减去抵用券
        totalAmount = ArithUtils.sub2(totalAmount, couponMoney, 2, BigDecimal.ROUND_DOWN);
        return totalAmount;
    }

    private void saveInvoiceInfo(OrderAddRequestDto dto, Sub sub) {
        if (StringUtils.isNotBlank(dto.getInvoiceSubId())) {
            Invoice invoice = invoiceDao.findOne(Integer.parseInt(dto.getInvoiceSubId()));
            /** 保存订单发票信息 **/
            if (invoice != null) {
                InvoiceSub invoiceSub = new InvoiceSub();
                invoiceSub.setCompany(invoice.getCompany());
                invoiceSub.setContentId(invoice.getContentId());
                invoiceSub.setInvoiceId(invoice.getId());
                invoiceSub.setTitleId(invoice.getTitleId());
                invoiceSub.setTypeId(invoice.getTypeId());
                invoiceSub.setVersion(invoice.getVersion());
                invoiceSubDao.save(invoiceSub);
                sub.setInvoiceSubId(invoiceSub.getId()); // 发票ID
                sub.setIsNeedInvoice(1); // 是否需要发票 0:不需要;1:需要
            } else {
                sub.setIsNeedInvoice(0);
            }

        } else {
            sub.setIsNeedInvoice(0);
        }
    }

    /**
     * 构建返回结果
     * @Title: buildResult
     * @Description: TODO
     * @param @param subIdList
     * @param @param totalAmount
     * @param @return   
     * @return Map<String,Object> 
     * @author Administrator 2016年7月20日 
     * @throws
     */
    private Map<String, Object> buildResult(List<String> orderIdList, List<String> orderNumList,
            BigDecimal totalAmount) {
        // 返回结果
        Map<String, Object> map = Maps.newHashMap();
        StringBuilder sb = new StringBuilder();
        StringBuilder sbSubId = new StringBuilder();
        int i = 0;
        for (String orderNum : orderNumList) {
            if (i > 0) {
                sb.append(",");
            }
            sb.append(orderNum);
            i++;
        }
        int j = 0;
        for (String orderNum : orderIdList) {
            if (j > 0) {
                sbSubId.append(",");
            }
            sbSubId.append(orderNum);
            j++;
        }
        map.put("orderId", sbSubId.toString());
        map.put("orderNum", sb.toString());
        map.put("totalAmount", totalAmount);
        return map;
    }

    /**
    * 保存订单明细
    * @Title: saveSubItem
    * @Description: TODO
    * @param @param orderShopDto
    * @param @param orderNumber
    * @param @param userId
    * @param @param sb
    * @param @param sub   
    * @return void 
    * @author Administrator 2016年7月19日 
    * @throws
    */
    private void saveSubItem(OrderShopDto orderShopDto, String orderNumber, String userId, StringBuilder sb, Sub sub,
            BigDecimal couponMoney) {
        // 订单商家中的商品列表
        List<ShopProdDto> prodList = orderShopDto.getProdList();
        List<Integer> basketIdList = Lists.newArrayList();
        double total = 0;
        int productNums = 0;
        int i = 0;
        BigDecimal totalReduceMoney = new BigDecimal(0);
        for (ShopProdDto shopProdDto : prodList) {
            Prod prod = prodDao.findOne(shopProdDto.getProdId());
            if (prod == null || prod.getStatus() != 1) {
                throw new WebRequestException("商品已下架");
            }

            Sku sku = null;
            if (shopProdDto.getSkuId() != null && shopProdDto.getSkuId() > 0) {
                sku = skuDao.findOne(shopProdDto.getSkuId());
            }

            i++;
            if (i > 1) {
                sb.append(",");
            }
            sb.append(prod.getName());
            double subtotal = ArithUtils.mul(sku != null ? sku.getPrice().doubleValue() : prod.getCash().doubleValue(),
                    shopProdDto.getCount());
            total = ArithUtils.add(total, subtotal);
            productNums += shopProdDto.getCount();
            if (shopProdDto.getBasketId() != null) {
                basketIdList.add(shopProdDto.getBasketId());
            }

            SubItem subItem = new SubItem();
            // 抵用券先抵用第一个商品，有剩余抵用第二个，以此类推
            BigDecimal reduceMony = shopProdDto.getReduceAmount();
            if (reduceMony == null) {
                reduceMony = new BigDecimal("0.00");
            }
            BigDecimal prodTotalMoney = BigDecimal.valueOf(subtotal).subtract(reduceMony);
            if (couponMoney.compareTo(new BigDecimal("0")) > 0 && couponMoney.compareTo(prodTotalMoney) >= 0) {
                couponMoney = couponMoney.subtract(prodTotalMoney);
                subItem.setCouponAmount(prodTotalMoney);
            } else if (couponMoney.compareTo(new BigDecimal("0")) > 0 && couponMoney.compareTo(prodTotalMoney) < 0) {
                subItem.setCouponAmount(couponMoney);
                couponMoney = new BigDecimal("0");
            } else {
                subItem.setCouponAmount(new BigDecimal("0"));
            }
            subItem.setSubNumber(orderNumber);
            subItem.setSubItemNumber(orderNumber + "-" + i);
            subItem.setProdId(shopProdDto.getProdId());
            subItem.setSkuId(shopProdDto.getSkuId());
            subItem.setSnapshotId(null); // 交易快照Id
            subItem.setBasketCount(shopProdDto.getCount());
            subItem.setProdName(prod.getName());
            subItem.setAttribute(shopProdDto.getSkuDesc());
            subItem.setPic(prod.getPic());
            subItem.setPrice(prod.getPrice());
            subItem.setCash(sku != null ? sku.getPrice() : prod.getCash());
            subItem.setUserId(userId);
            subItem.setTotalAmount(BigDecimal.valueOf(subtotal));
            if (shopProdDto.getReduceAmount() == null) {
                shopProdDto.setReduceAmount(new BigDecimal(0));
            }
            totalReduceMoney = totalReduceMoney.add(reduceMony);
            // 实付金额 = 商品总价 - 立减 - 抵用券
            subItem.setProductTotalAmout(
                    BigDecimal.valueOf(subtotal).subtract(reduceMony).subtract(subItem.getCouponAmount()));
            subItem.setSubItemDate(new Date());
            subItem.setWeight(prod.getWeight());
            subItem.setVolume(prod.getVolume());
            subItem.setCommSts(0);
            subItem.setRebateClrSts(0);
            subItem.setRebate(shopProdDto.getRebate());
            subItem.setAdFeeRate(prod.getAdFeeRate());
            subItem.setAdFeeBasicRate(prod.getAdFeeBasicRate());
            subItem.setReduceAmount(reduceMony);
            subItemDao.save(subItem);

            // 扣减库存(库存计数方式，0：拍下减库存，1：付款减库存)
            if (prod.getStockCounting() == 0) {
                decreaseStock(prod, sku, shopProdDto.getCount());
            }
        }
        sub.setTotal(BigDecimal.valueOf(total));
        // sub.setActualTotal(sub.getTotal().add(sub.getFreightAmount()));
        sub.setReduceAmount(totalReduceMoney);
        sub.setProductNums(productNums);

        // 清空购物车
        removeBasket(basketIdList);
    }

    /**
     * 扣减库存
     * @Title: decreaseStock
     * @Description: TODO
     * @param @param prod
     * @param @param sku
     * @param @param count   
     * @return void 
     * @author Administrator 2016年8月3日 
     * @throws
     */
    private void decreaseStock(Prod prod, Sku sku, int count) {
        if (sku != null) {
            sku.setStocks(sku.getStocks() - count);
            skuDao.saveAndFlush(sku);
        }
        if (prod != null) {
            prod.setStocks(prod.getStocks() - count);
            prodDao.saveAndFlush(prod);
        }
    }

    /**
     * 保存订单主信息
     * @Title: saveSub
     * @Description: TODO
     * @param @param sub
     * @param @param dto
     * @param @param orderShopDto
     * @param @param prodName   
     * @return void 
     * @author Administrator 2016年7月20日 
     * @throws
     */
    private Sub saveSub(Sub sub, OrderAddRequestDto dto, OrderShopDto orderShopDto, String prodName) {
        // 保存订单主信息
        sub.setProdName(parseProdName(prodName));
        sub.setUserId(dto.getUserId());
        Date date = new Date();
        sub.setSubDate(date);
        sub.setUpdateDate(date);
        sub.setSubCheck("N");
        sub.setPayManner(2);
        sub.setShopId(orderShopDto.getShopId());
        sub.setShopName(orderShopDto.getShopName());
        sub.setStatus(ShopOrderStatusEnum.UNPAY.getStatus());
        sub.setDeleteStatus(0);
        sub.setIsNeedInvoice(0);
        sub.setOrderRemark(dto.getRemark());
        return subDao.save(sub);
    }

    /**
     * 解析商品名称长度是否大于1000
     * @Title: parseProdName
     * @Description: TODO
     * @param @param prodName
     * @param @return   
     * @return String 
     * @author Administrator 2016年7月20日 
     * @throws
     */
    private String parseProdName(String prodName) {
        String result = null;
        if (StringUtils.isNotBlank(prodName)) {
            if (prodName.length() < 1000) {
                result = prodName;
            } else {
                result = prodName.substring(0, 996) + "...";
            }

        }
        return result;
    }

    /**
     * 检查库存
     * @Title: checkInventory
     * @Description: TODO
     * @param @param shopList   
     * @return void 
     * @author Administrator 2016年7月19日 
     * @throws
     */
    private void checkInventory(List<OrderShopDto> shopList) {
        // Map<Integer, Sku> skuMap = skuService.initSkuMap();
        for (OrderShopDto orderShopDto : shopList) {
            // 订单商家中的商品列表
            List<ShopProdDto> prodList = orderShopDto.getProdList();
            for (ShopProdDto shopProdDto : prodList) {
                // Sku sku = skuMap.get(shopProdDto.getSkuId());
                Sku sku = skuService.getSkuBySkuId(shopProdDto.getSkuId());
                if (sku != null) {
                    if (sku.getStocks() < shopProdDto.getCount()) {
                        throw new WebRequestException("库存不足");
                    }
                } else {
                    // 如果sku不存在，找商品的库存
                    Prod prod = prodDao.findOne(shopProdDto.getProdId());
                    if (prod != null) {
                        if (prod.getStocks() < shopProdDto.getCount()) {
                            throw new WebRequestException("库存不足");
                        }
                    }
                }
            }
        }
    }

    /**
     * 保存用户地址
     * @Title: saveUserAddressSub
     * @Description: TODO
     * @param @param addressId
     * @param @return   
     * @return UsrAddrSub 
     * @author Administrator 2016年7月20日 
     * @throws
     */
    private UsrAddrSub saveUserAddressSub(UsrAddr usrAddr) {

        UsrAddrSub usrAddrSub = usrAddrSubDao.findUsrAddrSubByAddrIdAndVersion(usrAddr.getAddrId(),
                usrAddr.getVersion());
        // 根据addrId和version 获取配送地址信息，如果没找到就 保存一份
        if (usrAddrSub == null) {
            usrAddrSub = new UsrAddrSub();
            usrAddrSub.setAddrId(usrAddr.getAddrId());
            usrAddrSub.setVersion(usrAddr.getVersion());
            Provinces p = provincesDao.findOne(usrAddr.getProvinceId());
            City c = cityDao.findOne(usrAddr.getCityId());
            Areas a = areasDao.findOne(usrAddr.getAreaId());
            if (a != null) {
                usrAddrSub.setArea(a.getArea());
            }
            if (c != null) {
                usrAddrSub.setCity(c.getCity());
            }
            if (p != null) {
                usrAddrSub.setProvince(p.getProvince());
            }

            usrAddrSub.setCreateTime(new Date());
            usrAddrSub.setEmail(usrAddr.getEmail());
            usrAddrSub.setMobile(usrAddr.getMobile());
            usrAddrSub.setReceiver(usrAddr.getReceiver());
            usrAddrSub.setSubAdds(usrAddr.getSubAdds());
            usrAddrSub.setSubPost(usrAddr.getSubPost());
            usrAddrSub.setTelphone(usrAddr.getTelphone());
            usrAddrSub.setUserId(usrAddr.getUserId());
            usrAddrSub.setCreateTime(new Date());
            usrAddrSubDao.save(usrAddrSub);
        }
        return usrAddrSub;
    }

    /**
     * 清空购物车
     * @Title: removeBasket
     * @Description: TODO
     * @param @param basketIdList   
     * @return void 
     * @author Administrator 2016年7月20日 
     * @throws
     */
    private void removeBasket(List<Integer> basketIdList) {
        for (Integer basketId : basketIdList) {
            basketDao.delete(basketId);
        }
    }

    /**
     * 获取订单支付总额
     * @Title: getOrderTotalAmount
     * @Description: TODO
     * @param @param subIds
     * @param @return   
     * @return double 
     * @author Administrator 2016年7月21日 
     * @throws
     */
    public double getOrderPayAmount(String orderNum) {
        BigDecimal totalAmount = new BigDecimal(0);
        String[] group = orderNum.split(",");
        if (group != null && group.length > 0) {
            for (String subNum : group) {
                Sub sub = subDao.findSubBySubNum(subNum);
                if (sub != null) {
                    totalAmount = ArithUtils.add2(totalAmount, sub.getTotal(), 2, BigDecimal.ROUND_DOWN);
                    // 2016-08-19 Cary 修改商城订单尾号“10”的获取
                    if (subNum != null && (subNum.endsWith(OrderCodeEnum.SHOP_ORDER.getCode().toString())
                            || subNum.startsWith(BasicConstant.SHOP_ORDER_SN))) {
                        if (sub.getReduceAmount() != null) {
                            totalAmount = ArithUtils.sub2(totalAmount, sub.getReduceAmount(), 2, BigDecimal.ROUND_DOWN);
                        }
                        if (sub.getCouponAmount() != null) {
                            totalAmount = ArithUtils.sub2(totalAmount, sub.getCouponAmount(), 2, BigDecimal.ROUND_DOWN);
                        }
                        totalAmount = ArithUtils.add2(totalAmount, sub.getFreightAmount(), 2, BigDecimal.ROUND_DOWN);
                    }
                }
            }
        }
        return totalAmount.doubleValue();
    }

    @Override
    public void handleOrderPay(String orderNum, String payAmount, String payTypeName, int payType, String payNo) {
        String[] group = orderNum.split(",");

        if (group != null && group.length > 0) {
            for (String subNum : group) {
                Sub sub = subDao.findSubBySubNum(subNum);
                if (sub != null) {
                    Date date = new Date();
                    sub.setPayDate(date);
                    sub.setUpdateDate(date);
                    sub.setPayTypeName(payTypeName);
                    sub.setStatus(ShopOrderStatusEnum.PADYED.getStatus());
                    subDao.saveAndFlush(sub);

                    // 扣减库存
                    decreaseStock(sub);
                    // BigDecimal silverNum = new BigDecimal("0.00");
                    // 更新商品购买量
                    List<SubItem> subItems = subItemDao.findSubItem(sub.getSubNumber());
                    if (null != subItems && subItems.size() > 0) {
                        for (SubItem subItem : subItems) {
                            Prod prod = prodDao.findOne(subItem.getProdId());
                            prod.setBuys((null == prod.getBuys() ? 0 : prod.getBuys()) + subItem.getBasketCount());
                            prodDao.saveAndFlush(prod);
                            // silverNum = silverNum.add(shopOrderSilverService.getShopOrderSilverNum(subItem));
                        }
                    }
                    // 冻结需要赠送得银币，7天收货后给用户
                    // userAccountService.silverFreeze(silverNum, sub.getUserId());
                    // ShopDetail shop = shopDetailDao.findOne(sub.getShopId());
                    // boolean flag = false;
                    // //判断是否需要返银币给商家。如果需要，把需要返得银币冻结起来，收货后给商家
                    // if (shop != null) {
                    // if (shop.getWhiteList() != null && shop.getWhiteList().intValue() == 1) {
                    // flag = true;
                    // } else if ((shop.getWhiteList() == null || shop.getWhiteList().intValue() == 0) &&
                    // (shop.getCoinSwitch() != null && shop.getCoinSwitch().intValue() == 1)) {
                    // flag = true;
                    // }
                    // if (flag) {
                    // userAccountService.silverFreeze(sub.getActualTotal().multiply(shop.getAdFeeRate() == null ? new
                    // BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE) : shop.getAdFeeRate()), shop.getUserId());
                    // }
                    // }
                }
            }
        }

    }

    /**
     * 扣减库存
     * @Title: decreaseStock
     * @Description: TODO
     * @param @param sub   
     * @return void 
     * @author Administrator 2016年8月3日 
     * @throws
     */
    private void decreaseStock(Sub sub) {
        List<SubItem> items = subItemDao.findSubItem(sub.getSubNumber());
        for (SubItem item : items) {
            Prod prod = prodDao.findOne(item.getProdId());
            // 付款扣减库存
            if (prod != null && prod.getStockCounting() == 1) {
                Sku sku = null;
                if (item.getSkuId() != null) {
                    sku = skuDao.findOne(item.getSkuId());
                }
                decreaseStock(prod, sku, item.getBasketCount());
            }
        }
    }

    @Override
    public void verifyOrder(String userId, String orderNum) {
        Sub order = subDao.findSubBySubNum(orderNum);
        if (order == null) {
            throw new WebRequestException("订单不存在");
        }
        if (!order.getUserId().equals(userId)) {
            throw new WebRequestException("无权限支付该订单");
        }
        if (order.getStatus() != ServiceOrderStatusEnum.UNPAY.getStatus()) {
            throw new WebRequestException("订单不是待付款状态");
        }
    }

    /**
     * 
     * @Title: findArriageShow
     * @Description: TODO
     * @param @param orderNumber
     * @param @return   
     * @return Map<String,Object> 
     * @author liangdanhua 2016年8月19日 
     * @throws
     */
    @SuppressWarnings("unchecked")
    public Map<String, Object> findArriageShow(Integer orderNumber) {
        // 根基订单号获取订单信息
        Sub sub = subDao.findOne(orderNumber);
        // 根据ls_sub(订购表)获取物流单号、配送方式ID
        String dvyFlowId = sub.getDvyFlowId();
        int dvyTypeId = sub.getDvyTypeId();
        // 获取配送方式
        DvyType dvytype = dvyTypeDao.findOne(dvyTypeId);
        Integer dvyId = dvytype.getDvyId();
        // 获取物流公司
        Delivery delivery = deliveryDao.findOne(dvyId);
        String queryURL = delivery.getQueryUrl();
        // 发送物流信息到第三方系统查询数据
        CloseableHttpClient httpClient = HttpClients.createDefault();
        Map<String, Object> map = null;
        String result = "";
        try {
            map = new HashMap<String, Object>();
            HttpPost method = new HttpPost(queryURL.replace("{dvyFlowId}", dvyFlowId));
            StringEntity entity = new StringEntity("", "utf-8");// 解决中文乱码问题
            entity.setContentEncoding("UTF-8");
            entity.setContentType("application/json");
            method.setEntity(entity);
            HttpResponse response = httpClient.execute(method);
            if (response.getStatusLine().getStatusCode() == 200) {
                result = EntityUtils.toString(response.getEntity());
            }
            if (response.getStatusLine().getStatusCode() == 404) {
                throw new RuntimeException("404");
            }
            map = JsonMapper.nonEmptyMapper().fromJson(result, Map.class);
            map.put("dvyFlowId", dvyFlowId);// 物流单号
            map.put("dvyCom", delivery.getName());// 物流单号
            map.put("orderNum", sub.getSubNumber());// 订单号
            map.put("dvyDate", DateUtils.date2Str(sub.getDvyDate(), "yyyy-MM-dd HH:mm:ss"));// 发货时间
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                httpClient.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return map;
    }

    /**
     * 获取运单的Url地址
     * @Title: findArriageShowUrl
     * @Description: TODO
     * @param @param orderNumber
     * @param @return   
     * @return String 
     * @author liangdanhua 2016年8月24日 
     * @throws
     */
    public String findArriageShowUrl(String orderNumber) {
        return SysPropsFactory.getProperty("arriageShowUrl") + orderNumber;
    }

    /**
     *
     * @Title: saveInvoice
     * @Description: TODO
     * @param @param dto
     * @param @return
     * @return Map<String,Object>
     * @author Cary 2016年8月19日
     * @throws
     */
    private void saveInvoice(OrderAddRequestDto dto) {
        Invoice invoice = new Invoice();
        invoice.setUserId(dto.getUserId());
        invoice.setUserName(dto.getUserName());
        invoice.setTypeId(dto.getInvoiceType());
        invoice.setTitleId(dto.getInvoiceTitle());
        invoice.setCompany(dto.getInvoiceCompany());
        invoice.setContentId(dto.getInvoiceContentId());
        invoice.setRecPhone(dto.getInvoiceRecPhone());
        invoice.setRecEmail(dto.getInvoiceRecEmail());
        invoice.setCreateTime(new Date());
        invoiceDao.save(invoice);
    }

    @Override
    public BaseOrderDto getBaseOrderDto(String orderNum) {
        Sub order = subDao.findSubBySubNum(orderNum);
        if (order == null) {
            throw new WebRequestException("订单不存在");
        }
        BaseOrderDto baseOrderDto = new BaseOrderDto();
        baseOrderDto.setOrderNum(orderNum);
        baseOrderDto.setUserId(order.getUserId());
        return baseOrderDto;
    }

}
