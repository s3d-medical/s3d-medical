package com.nhs.shop.service.goods.dto;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.common.collect.Lists;
import com.nhs.shop.service.common.dto.CustFieldDto;

/**
 * 商品详情DTO
 * @Title: GoodsDetailDto.java
 * @Package com.nhs.shop.service.goods.dto
 * @Description: TODO
 * @author Administrator
 * @date 2016年7月17日 下午4:44:17
 * @version V1.0
 */
public class GoodsDetailDto implements Serializable {

    private static final long serialVersionUID = -6961788699638117407L;
    private GoodsDto goods;
    private CommentDto comment;
    private ShopDto shop;
    private String userId;

    public GoodsDto getGoods() {
        return goods;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public void setGoods(GoodsDto goods) {
        this.goods = goods;
    }

    public CommentDto getComment() {
        return comment;
    }

    public void setComment(CommentDto comment) {
        this.comment = comment;
    }

    public ShopDto getShop() {
        return shop;
    }

    public void setShop(ShopDto shop) {
        this.shop = shop;
    }

	// 商品信息
    public static class GoodsDto implements Serializable {
        private static final long serialVersionUID = -2191933300540998366L;
        private Integer prodId;
        private Integer shopId;
        private String title;
        private List<String> images = Lists.newArrayList();
        private String price;
        private String expressFee;
        private Integer saleNum;
        private String address;
        private String brief;
        private String content;
        @Deprecated
        private String subsidy = "";
        private Integer stocks = 0;
        private List<SpecificationDto> specifications = Lists.newArrayList();
        private List<SkuNameDto> skuNames = Lists.newArrayList();
        private List<SkuDto> skus = Lists.newArrayList();
        private String isCollected;
        private String isdown = "";
        @Deprecated
		private String subsidyStr = "";

        /**
         * 产品促销信息, 主要是用于ui布局和显示, 现融合在dto中. 
         */
        private Map<String, CustFieldDto> promotion = new HashMap<String, CustFieldDto>();
        
        /**
         * @return the stocks
         */

        public Integer getStocks() {
            return stocks;
        }

        /**
         * @param stocks the stocks to set
         */
        public void setStocks(Integer stocks) {
            this.stocks = stocks;
        }

        public String getIsdown() {
            return isdown;
        }

        public void setIsdown(String isdown) {
            this.isdown = isdown;
        }

        public Integer getProdId() {
            return prodId;
        }

        public void setProdId(Integer prodId) {
            this.prodId = prodId;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public List<String> getImages() {
            return images;
        }

        public void setImages(List<String> images) {
            this.images = images;
        }

        public String getPrice() {
            return price;
        }

        public void setPrice(String price) {
            this.price = price;
        }

        public String getExpressFee() {
            return expressFee;
        }

        public void setExpressFee(String expressFee) {
            this.expressFee = expressFee;
        }

        public Integer getSaleNum() {
            return saleNum;
        }

        public void setSaleNum(Integer saleNum) {
            this.saleNum = saleNum;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String getBrief() {
            return brief;
        }

        public void setBrief(String brief) {
            this.brief = brief;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }

        public Integer getShopId() {
            return shopId;
        }

        public void setShopId(Integer shopId) {
            this.shopId = shopId;
        }

        public List<SpecificationDto> getSpecifications() {
            return specifications;
        }

        public void setSpecifications(List<SpecificationDto> specifications) {
            this.specifications = specifications;
        }

        public List<SkuNameDto> getSkuNames() {
            return skuNames;
        }

        public void setSkuNames(List<SkuNameDto> skuNames) {
            this.skuNames = skuNames;
        }

        public List<SkuDto> getSkus() {
            return skus;
        }

        public void setSkus(List<SkuDto> skus) {
            this.skus = skus;
        }

        public String getSubsidy() {
            return subsidy;
        }

        public void setSubsidy(String subsidy) {
            this.subsidy = subsidy;
        }

        public String getIsCollected() {
            return isCollected;
        }

        public void setIsCollected(String isCollected) {
            this.isCollected = isCollected;
        }

		public String getSubsidyStr() {
			return subsidyStr;
		}

		public void setSubsidyStr(String subsidyStr) {
			this.subsidyStr = subsidyStr;
		}

		public Map<String, CustFieldDto> getPromotion() {
			return promotion;
		}

		public void setPromotion(Map<String, CustFieldDto> promotion) {
			this.promotion = promotion;
		}
    }

    // 评价信息
    public static class CommentDto implements Serializable {
        private static final long serialVersionUID = 8219127108729542206L;
        private int num = 0; // 评价数量
        private String degree; // 好评度
        private List<CommentDetailDto> list = Lists.newArrayList();

        public int getNum() {
            return num;
        }

        public void setNum(int num) {
            this.num = num;
        }

        public String getDegree() {
            return degree;
        }

        public void setDegree(String degree) {
            this.degree = degree;
        }

        public List<CommentDetailDto> getList() {
            return list;
        }

        public void setList(List<CommentDetailDto> list) {
            this.list = list;
        }

    }

    // 评论详情
    public static class CommentDetailDto implements Serializable {
        /**
        * 
        */
        private static final long serialVersionUID = -6696559499370464701L;
        private String userId;
        private String username;
        private String content;
        private int score;
        private List<String> images = Lists.newArrayList();
        private String addtime;
        private String userImage;

        public String getUserImage() {
            return userImage;
        }

        public void setUserImage(String userImage) {
            this.userImage = userImage;
        }

        public String getAddtime() {
            return addtime;
        }

        public void setAddtime(String addtime) {
            this.addtime = addtime;
        }

        public String getUserId() {
            return userId;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }

        public int getScore() {
            return score;
        }

        public void setScore(int score) {
            this.score = score;
        }

        public List<String> getImages() {
            return images;
        }

        public void setImages(List<String> images) {
            this.images = images;
        }

    }

    // 店铺信息
    public static class ShopDto implements Serializable {
        private int shopId;
        private String title;
        private String image;
        private int totalNum;
        private int attentionNum;
        private double speed;
        private double attitude;
        private double describe;

        public int getShopId() {
            return shopId;
        }

        public void setShopId(int shopId) {
            this.shopId = shopId;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getImage() {
            return image;
        }

        public void setImage(String image) {
            this.image = image;
        }

        public int getTotalNum() {
            return totalNum;
        }

        public void setTotalNum(int totalNum) {
            this.totalNum = totalNum;
        }

        public int getAttentionNum() {
            return attentionNum;
        }

        public void setAttentionNum(int attentionNum) {
            this.attentionNum = attentionNum;
        }

        public double getSpeed() {
            return speed;
        }

        public void setSpeed(double speed) {
            this.speed = speed;
        }

        public double getAttitude() {
            return attitude;
        }

        public void setAttitude(double attitude) {
            this.attitude = attitude;
        }

        public double getDescribe() {
            return describe;
        }

        public void setDescribe(double describe) {
            this.describe = describe;
        }

    }

    // 规格参数
    public static class SpecificationDto implements Serializable {

        private static final long serialVersionUID = 6794802488406773432L;
        private String name;
        private String value;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }

    }

}
