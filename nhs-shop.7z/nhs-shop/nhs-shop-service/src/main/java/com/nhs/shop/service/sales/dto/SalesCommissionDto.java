package com.nhs.shop.service.sales.dto;

import java.io.Serializable;
import java.math.BigDecimal;

public class SalesCommissionDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String userId;
	
	private BigDecimal adFeeRate;
	
	private BigDecimal orderPayAmount;
	
	private int shopId;
	
	private String orderNum;

    private BigDecimal commissionSilver;

    public String getUserId() {
        return userId;
    }

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public BigDecimal getAdFeeRate() {
		return adFeeRate;
	}

	public void setAdFeeRate(BigDecimal adFeeRate) {
		this.adFeeRate = adFeeRate;
	}

	public BigDecimal getOrderPayAmount() {
		return orderPayAmount;
	}

	public void setOrderPayAmount(BigDecimal orderPayAmount) {
		this.orderPayAmount = orderPayAmount;
	}

	public int getShopId() {
		return shopId;
	}

	public void setShopId(int shopId) {
		this.shopId = shopId;
	}

	public String getOrderNum() {
		return orderNum;
	}

	public void setOrderNum(String orderNum) {
		this.orderNum = orderNum;
	}

    public BigDecimal getCommissionSilver() {
        return commissionSilver;
    }

    public void setCommissionSilver(BigDecimal commissionSilver) {
        this.commissionSilver = commissionSilver;
    }

}
