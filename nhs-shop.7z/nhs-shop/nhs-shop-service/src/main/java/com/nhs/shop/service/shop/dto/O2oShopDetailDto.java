package com.nhs.shop.service.shop.dto;

import java.math.BigDecimal;
import java.util.List;

import com.nhs.shop.entry.legend.shop.O2oShopPhotos;
import com.nhs.shop.service.o2oshop.comment.dto.O2oShopCommentDto;

/**
 * O2o商家详情
 * @Title: O2oShopDetailDto.java
 * @Package com.nhs.shop.service.shop.dto
 * @Description: TODO
 * @author liangdanhua
 * @date 2016年8月27日 下午12:28:26
 * @version V1.0
 */
public class O2oShopDetailDto {
    private Integer shopId;

    private String shopTitle = "";
    private Integer starNum = 0;
    private String address = "";
    private Double distance = 0.00;
    private String pic = "";
    private Integer consumePer = 0; // 人均消费，需确认用哪个？
    private String category = "";
    private Integer categoryId;
    private String area = "";
    private String mobile = "";
    private Double tasteScore = 0.0;
    private Double envScore = 0.0;
    private Double serviceScore = 0.0;
    private String subsidy = "";
    private Double lat = 0.0;
    private Double lng = 0.0;
    private String linearMeasure = "";

    private BigDecimal perCost; // 人均消费，需确认用哪个？

    private String smsPhone;

    private String serviceBeginOrd;

    private String serviceBiginWkd;

    private String serviceEndOrd;

    private String serviceEndWkd;

    private String serviceTime;

    private String installation;

    private String story;

    private int photos;

    private String brief;

    // 环境图片
    private List<O2oShopPhotos> envPics;
    // 特色图片
    private List<O2oShopPhotos> spePics;
    // 活动图片
    private List<O2oShopPhotos> actPics;

    private String totalOrderNum;

    // 评价列表
    private List<O2oShopCommentDto> commentList;

    private int commentNum;

    private String average;
    
    private String subsidyStr;

    private String collection; // 0表示没有收藏,其他为收藏了该店铺
    
    private String reduce;
    
    private String discount;
    
    private String coupon;
    
    private String shopDiscount;
    private String shopDiscountStr;
    private String shopDiscountRate;
    

    public String getCollection() {
        return collection;
    }

    public void setCollection(String collection) {
        this.collection = collection;
    }

    public Integer getShopId() {
        return shopId;
    }

    public void setShopId(Integer shopId) {
        this.shopId = shopId;
    }

    public BigDecimal getPerCost() {
        return perCost;
    }

    public void setPerCost(BigDecimal perCost) {
        this.perCost = perCost;
    }

    public String getSmsPhone() {
        return smsPhone;
    }

    public void setSmsPhone(String smsPhone) {
        this.smsPhone = smsPhone;
    }

    public String getServiceBeginOrd() {
        return serviceBeginOrd;
    }

    public void setServiceBeginOrd(String serviceBeginOrd) {
        this.serviceBeginOrd = serviceBeginOrd;
    }

    public String getServiceBiginWkd() {
        return serviceBiginWkd;
    }

    public void setServiceBiginWkd(String serviceBiginWkd) {
        this.serviceBiginWkd = serviceBiginWkd;
    }

    public String getServiceEndOrd() {
        return serviceEndOrd;
    }

    public void setServiceEndOrd(String serviceEndOrd) {
        this.serviceEndOrd = serviceEndOrd;
    }

    public String getServiceEndWkd() {
        return serviceEndWkd;
    }

    public void setServiceEndWkd(String serviceEndWkd) {
        this.serviceEndWkd = serviceEndWkd;
    }

    public String getInstallation() {
        return installation;
    }

    public void setInstallation(String installation) {
        this.installation = installation;
    }

    public String getStory() {
        return story;
    }

    public void setStory(String story) {
        this.story = story;
    }

    public List<O2oShopPhotos> getEnvPics() {
        return envPics;
    }

    public void setEnvPics(List<O2oShopPhotos> envPics) {
        this.envPics = envPics;
    }

    public List<O2oShopPhotos> getSpePics() {
        return spePics;
    }

    public void setSpePics(List<O2oShopPhotos> spePics) {
        this.spePics = spePics;
    }

    public List<O2oShopPhotos> getActPics() {
        return actPics;
    }

    public void setActPics(List<O2oShopPhotos> actPics) {
        this.actPics = actPics;
    }

    public int getPhotos() {
        return photos;
    }

    public void setPhotos(int photos) {
        this.photos = photos;
    }

    public String getBrief() {
        return brief;
    }

    public void setBrief(String brief) {
        this.brief = brief;
    }

    public String getShopTitle() {
        return shopTitle;
    }

    public void setShopTitle(String shopTitle) {
        this.shopTitle = shopTitle;
    }

    public Integer getStarNum() {
        return starNum;
    }

    public void setStarNum(Integer starNum) {
        this.starNum = starNum;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Double getDistance() {
        return distance;
    }

    public void setDistance(Double distance) {
        this.distance = distance;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public Integer getConsumePer() {
        return consumePer;
    }

    public void setConsumePer(Integer consumePer) {
        this.consumePer = consumePer;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public Double getTasteScore() {
        return tasteScore;
    }

    public void setTasteScore(Double tasteScore) {
        this.tasteScore = tasteScore;
    }

    public Double getEnvScore() {
        return envScore;
    }

    public void setEnvScore(Double envScore) {
        this.envScore = envScore;
    }

    public Double getServiceScore() {
        return serviceScore;
    }

    public void setServiceScore(Double serviceScore) {
        this.serviceScore = serviceScore;
    }

    public String getSubsidy() {
        return subsidy;
    }

    public void setSubsidy(String subsidy) {
        this.subsidy = subsidy;
    }

    public Double getLat() {
        return lat;
    }

    public void setLat(Double lat) {
        this.lat = lat;
    }

    public Double getLng() {
        return lng;
    }

    public void setLng(Double lng) {
        this.lng = lng;
    }

    public String getLinearMeasure() {
        return linearMeasure;
    }

    public void setLinearMeasure(String linearMeasure) {
        this.linearMeasure = linearMeasure;
    }

    public Integer getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Integer categoryId) {
        this.categoryId = categoryId;
    }

    public String getServiceTime() {
        return serviceTime;
    }

    public void setServiceTime(String serviceTime) {
        this.serviceTime = serviceTime;
    }

    public String getTotalOrderNum() {
        return totalOrderNum;
    }

    public void setTotalOrderNum(String totalOrderNum) {
        this.totalOrderNum = totalOrderNum;
    }

    public List<O2oShopCommentDto> getCommentList() {
        return commentList;
    }

    public void setCommentList(List<O2oShopCommentDto> commentList) {
        this.commentList = commentList;
    }

    public String getAverage() {
        return average;
    }

    public void setAverage(String average) {
        this.average = average;
    }

    public int getCommentNum() {
        return commentNum;
    }

    public void setCommentNum(int commentNum) {
        this.commentNum = commentNum;
    }

	public String getSubsidyStr() {
		return subsidyStr;
	}

	public void setSubsidyStr(String subsidyStr) {
		this.subsidyStr = subsidyStr;
	}


	public String getReduce() {
		return reduce;
	}

	public void setReduce(String reduce) {
		this.reduce = reduce;
	}

	public String getDiscount() {
		return discount;
	}

	public void setDiscount(String discount) {
		this.discount = discount;
	}

	public String getCoupon() {
		return coupon;
	}

	public void setCoupon(String coupon) {
		this.coupon = coupon;
	}

	public String getShopDiscount() {
		return shopDiscount;
	}

	public void setShopDiscount(String shopDiscount) {
		this.shopDiscount = shopDiscount;
	}

	public String getShopDiscountStr() {
		return shopDiscountStr;
	}

	public void setShopDiscountStr(String shopDiscountStr) {
		this.shopDiscountStr = shopDiscountStr;
	}

	public String getShopDiscountRate() {
		return shopDiscountRate;
	}

	public void setShopDiscountRate(String shopDiscountRate) {
		this.shopDiscountRate = shopDiscountRate;
	}
	
	
    
}
