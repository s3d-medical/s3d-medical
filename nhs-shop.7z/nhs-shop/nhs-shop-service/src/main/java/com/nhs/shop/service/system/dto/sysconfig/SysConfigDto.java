package com.nhs.shop.service.system.dto.sysconfig;

import java.io.Serializable;

/**
 * 系统配置参数
 * @author wind.chen
 */
public class SysConfigDto implements Serializable {

	private static final long serialVersionUID = 9105296161767944489L;
	/**
	 * 更新配置
	 */
	private GlUpdateInfoDto  glUpdateInfo;
	
	/**
	 * 全局label布局配置
	 */
	private GlLabelConfigDto glLabelConfig;
	
	/**
	 * 订单配置
	 */
	private OrderConfigDto orderConfig;
	
	/**
	 * 支付配置
	 */
	private PayConfigDto  payConfig;
	
	private RateConfigDto rateConfig;
	
	private AppServersConfigDto appServersConfig;
	
	public GlUpdateInfoDto getGlUpdateInfo() {
		return glUpdateInfo;
	}

	public void setGlUpdateInfo(GlUpdateInfoDto glUpdateInfo) {
		this.glUpdateInfo = glUpdateInfo;
	}

	public GlLabelConfigDto getGlLabelConfig() {
		return glLabelConfig;
	}

	public void setGlLabelConfig(GlLabelConfigDto glLabelConfig) {
		this.glLabelConfig = glLabelConfig;
	}

	public OrderConfigDto getOrderConfig() {
		return orderConfig;
	}

	public void setOrderConfig(OrderConfigDto orderConfig) {
		this.orderConfig = orderConfig;
	}

	public PayConfigDto getPayConfig() {
		return payConfig;
	}

	public void setPayConfig(PayConfigDto payConfig) {
		this.payConfig = payConfig;
	}

	public AppServersConfigDto getAppServersConfig() {
		return appServersConfig;
	}

	public void setAppServersConfig(AppServersConfigDto appServersConfig) {
		this.appServersConfig = appServersConfig;
	}

	public RateConfigDto getRateConfig() {
		return rateConfig;
	}

	public void setRateConfig(RateConfigDto rateConfig) {
		this.rateConfig = rateConfig;
	}

}
