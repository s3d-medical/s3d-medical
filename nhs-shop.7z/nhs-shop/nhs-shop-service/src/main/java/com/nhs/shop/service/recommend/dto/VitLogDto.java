package com.nhs.shop.service.recommend.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * 浏览器
 * @Title: VitLogDto.java
 * @Package com.nhs.shop.service.recommend.dto
 * @Description: TODO
 * @author Administrator
 * @date 2016年8月24日 下午7:58:01
 * @version V1.0
 */
public class VitLogDto implements Serializable {

    private static final long serialVersionUID = 2453508524743748223L;

    private Integer visitId;
    private Integer prodId;
    private String userName = "";
    private String shopName = "";
    private Date recDate;
    private String prodName = "";
    private Integer visitNum;
    private String cash;
    /**
     * 商品赠送比
     */
    private String rebate;
    private Integer buys;
    private String pic = "";
    private String shopaddr = "";
    /**
     * 是否包邮
     */
    private String mailStatus;
    private String prodIdurl;
    private String lg = "元";
    
    /**
     * 补贴描述
     */
    private String subsidyStr = "";
    /**
     * 立减额度描述
     */
    private String reducedCashTag="";

    public String getLg() {
        return lg;
    }

    public void setLg(String lg) {
        this.lg = lg;
    }

    public String getProdIdurl() {
        return prodIdurl;
    }

    public void setProdIdurl(String prodIdurl) {
        this.prodIdurl = prodIdurl;
    }

    public Integer getVisitNum() {
        return visitNum;
    }

    public void setVisitNum(Integer visitNum) {
        this.visitNum = visitNum;
    }

    public Integer getVisitId() {
        return visitId;
    }

    public void setVisitId(Integer visitId) {
        this.visitId = visitId;
    }

    public Integer getProdId() {
        return prodId;
    }

    public void setProdId(Integer prodId) {
        this.prodId = prodId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public Date getRecDate() {
        return recDate;
    }

    public void setRecDate(java.util.Date date) {
        this.recDate = date;
    }

    public String getProdName() {
        return prodName;
    }

    public void setProdName(String prodName) {
        this.prodName = prodName;
    }

    public String getRebate() {
        return rebate;
    }

    public void setRebate(String rebate) {
        this.rebate = rebate;
    }

    public Integer getBuys() {
        return buys;
    }

    public void setBuys(Integer buys) {
        this.buys = buys;
    }

    public String getCash() {
        return cash;
    }

    public void setCash(String cash) {
        this.cash = cash;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public String getShopaddr() {
        return shopaddr;
    }

    public void setShopaddr(String shopaddr) {
        this.shopaddr = shopaddr;
    }

    public String getMailStatus() {
        return mailStatus;
    }

    public void setMailStatus(String mailStatus) {
        this.mailStatus = mailStatus;
    }

    public String getSubsidyStr() {
        return subsidyStr;
    }

    public void setSubsidyStr(String subsidyStr) {
        this.subsidyStr = subsidyStr;
    }

	public String getReducedCashTag() {
		return reducedCashTag;
	}

	public void setReducedCashTag(String reducedCashTag) {
		this.reducedCashTag = reducedCashTag;
	}
	
}
