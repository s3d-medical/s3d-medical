package com.nhs.shop.service.goods.dto;

import java.io.Serializable;

/**
 * 商品列表DTO
 * @Title: GoodsDto.java
 * @Package com.nhs.o2o.web
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月17日 上午9:17:59
 * @version V1.0
 */
public class GoodsDto implements Serializable {

    private static final long serialVersionUID = 1146220076170510571L;
    private Integer prodId = 0;
    private String title = "";
    private String image = "";
    private String city = "";
    private String mailStatus = "包邮";
    private String price = "";
    private Integer payNum = 0;
    private String detailUrl = "";
    @Deprecated
    private String subsidy = "";
    @Deprecated
    private String subsidyStr = "";
  
    /**
     * 立减额度描述
     */
    private String reducedCashTag="";

    private String subsidyTag="";

    public Integer getProdId() {
        return prodId;
    }

    public void setProdId(Integer prodId) {
        this.prodId = prodId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getMailStatus() {
        return mailStatus;
    }

    public void setMailStatus(String mailStatus) {
        this.mailStatus = mailStatus;
    }

    public Integer getPayNum() {
        return payNum;
    }

    public void setPayNum(Integer payNum) {
        this.payNum = payNum;
    }

    public String getDetailUrl() {
        return detailUrl;
    }

    public void setDetailUrl(String detailUrl) {
        this.detailUrl = detailUrl;
    }

    @Deprecated
    public String getSubsidy() {
        return subsidy;
    }
    
    @Deprecated
    public void setSubsidy(String subsidy) {
        this.subsidy = subsidy;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }
    
    @Deprecated
	public String getSubsidyStr() {
		return subsidyStr;
	}
    
    @Deprecated
	public void setSubsidyStr(String subsidyStr) {
		this.subsidyStr = subsidyStr;
	}

	public String getReducedCashTag() {
		return reducedCashTag;
	}

	public void setReducedCashTag(String reducedCashTag) {
		this.reducedCashTag = reducedCashTag;
	}

	public String getSubsidyTag() {
		return subsidyTag;
	}

	public void setSubsidyTag(String subsidyTag) {
		this.subsidyTag = subsidyTag;
	}
    
}
