package com.nhs.shop.service.shop.dto;

import java.util.List;


public class O2oCategoryDto{
	
	private int categoryId;
	
	private String categoryName;
	
	private int sort;
	
	private List<O2oCategorySubDto> subList;
	
	private String icon;
	
	
	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public List<O2oCategorySubDto> getSubList() {
		return subList;
	}
	public void setSubList(List<O2oCategorySubDto> subList) {
		this.subList = subList;
	}
	public int getSort() {
		return sort;
	}
	public void setSort(int sort) {
		this.sort = sort;
	}
	public String getIcon() {
		return icon;
	}
	public void setIcon(String icon) {
		this.icon = icon;
	}


}
