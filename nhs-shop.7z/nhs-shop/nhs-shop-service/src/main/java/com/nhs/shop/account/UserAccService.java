package com.nhs.shop.account;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nhs.apiproxy.member.acc.service.AccountTransferService;
import com.nhs.core.mapper.JsonMapper;
import com.nhs.shop.bindspreader.util.Gift;
import com.nhs.shop.bindspreader.util.LotteryUtil;
import com.nhs.shop.rebate.dao.BusinessTaskDao;
import com.nhs.shop.rebate.entity.BusinessTask;
import com.nhs.user.service.UserService;

/**
 * 用户账户处理.
 * @author wind.chen
 */
@Service
@Transactional
public class UserAccService {
    @Autowired
    private UserService userService;
    
    @Autowired
    private BusinessTaskDao businessTaskDao;
    
    @Autowired
    private AccountTransferService accountTransferService;
    
    public final static String task_type_spreader_rabate = "100"; // 商家推广返利类型
    
	
	/**
	 * 保存task记录
	 * @param userId 商家推广userid
	 * @param relationId 相关记录id
	 * @param mobileNo 被推广绑定手机号
	 * @param shopMoney 商家获赠的商家余额
	 */
	public void addBindSpreaderBusinessTask(String userId, Long relationId, String mobileNo, int spreaderType, BigDecimal shopMoney) {
		// 1.检查当前记录是否存在
		BusinessTask businessTask = businessTaskDao.findBusinessTaskByTypeAndRelationId(task_type_spreader_rabate, relationId);
		if(businessTask != null){
			// 如果存在，更新为现在的推广
			Map<String, Object> businessMap = new HashMap<String, Object>();
			businessMap.put("toUserId", userId);
			businessMap.put("mobileNo", mobileNo);
			businessMap.put("amount", shopMoney);
			businessMap.put("spreaderType", spreaderType);
			String business = JsonMapper.nonDefaultMapper().toJson(businessMap);
			businessTask.setBusiness(business);
			// 更改时间
			businessTask.setUpdateDate(new Date());
			
			businessTaskDao.saveAndFlush(businessTask);
		} else {
			businessTask = new BusinessTask();
			businessTask.setType(task_type_spreader_rabate);
			Map<String, Object> businessMap = new HashMap<String, Object>();
			businessMap.put("toUserId", userId);
			businessMap.put("mobileNo", mobileNo);
			businessMap.put("amount", shopMoney);
			businessMap.put("spreaderType", spreaderType);
			String business = JsonMapper.nonDefaultMapper().toJson(businessMap);
			businessTask.setBusiness(business);
			businessTask.setRelationId(relationId);
			businessTask.setState(BusinessTask.BUSINESS_TASK_STATE_INIT);
			businessTask.setCreateDate(new Date());
			businessTask.setUpdateDate(new Date());
			
			businessTaskDao.save(businessTask);
		}
		
	}
	
	public static void main(String[] args) {
		Map<String, Object> businessMap = new HashMap<String, Object>();
		businessMap.put("toUserId", "402881d756318ca30156318d6158016c");
		businessMap.put("mobileNo", "18913744333");
		businessMap.put("amount", UserAccService.calcSpreaderMoney());
		businessMap.put("spreaderType", 0);
		String business = JsonMapper.nonDefaultMapper().toJson(businessMap);
		System.out.println(business);
	}
	
	public static BigDecimal calcSpreaderMoney(){
		List<Gift> gifts = new ArrayList<Gift>();
        // 序号==物品Id==物品名称==概率
        gifts.add(new Gift(1, "P1", "1", 0.995d)); // 1元红包
        gifts.add(new Gift(2, "P2", "2", 0.002d)); // 2元红包
        gifts.add(new Gift(3, "P3", "5", 0.002d)); // 5元红包
        gifts.add(new Gift(4, "P4", "100", 0.001d)); // 100元红包
        
        List<Double> orignalRates = new ArrayList<Double>(gifts.size());
        for (Gift gift : gifts) {
            double probability = gift.getProbability();
            if (probability < 0) {
                probability = 0;
            }
            orignalRates.add(probability);
        }
        
        int index =0;
        index = LotteryUtil.lottery(orignalRates);
        
        Gift gift = gifts.get(index);
		return new BigDecimal(gift.getGiftName());
	}
	
}
