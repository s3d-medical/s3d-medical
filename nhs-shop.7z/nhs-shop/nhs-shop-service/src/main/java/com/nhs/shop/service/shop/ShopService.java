package com.nhs.shop.service.shop;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.nhs.core.common.NhsConstant;
import com.nhs.core.context.SysPropsFactory;
import com.nhs.core.orm.Page;
import com.nhs.core.utils.common.ArithUtils;
import com.nhs.core.utils.common.DistanceUtils;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.core.web.WebRequestException;
import com.nhs.shop.dao.legend.region.AreasDao;
import com.nhs.shop.dao.legend.region.CityDao;
import com.nhs.shop.dao.legend.service.O2oCategoryDao;
import com.nhs.shop.dao.legend.service.O2oServiceOrderDao;
import com.nhs.shop.dao.legend.shop.O2oShopDetailDao;
import com.nhs.shop.dao.legend.shop.ShopDao;
import com.nhs.shop.dao.legend.shop.ShopDetailDao;
import com.nhs.shop.entry.legend.banner.Banner;
import com.nhs.shop.entry.legend.region.Areas;
import com.nhs.shop.entry.legend.service.O2oCategory;
import com.nhs.shop.entry.legend.shop.O2oHotCategoryConfig;
import com.nhs.shop.entry.legend.shop.O2oShopDetail;
import com.nhs.shop.entry.legend.shop.ShopDetail;
import com.nhs.shop.service.BaseService;
import com.nhs.shop.service.banner.BannerService;
import com.nhs.shop.service.category.dto.O2oHotCategoryDto;
import com.nhs.shop.service.home.HomePageService;
import com.nhs.shop.service.o2o.calculate.CalO2oPromotionService;
import com.nhs.shop.service.shop.dto.NearbyShopDto;
import com.nhs.shop.service.shop.dto.NearbyShopDto.O2oCategoryDto;
import com.nhs.shop.service.shop.dto.ShopDto;
import com.nhs.shop.service.system.SystemParameterService;

/**
 * 商品service
 * @Title: GoodsService.java
 * @Package com.nhs.shop.service.goods
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月16日 下午7:42:18
 * @version V1.0
 */
@Service
public class ShopService extends BaseService {

    @Autowired
    private O2oCategoryDao o2oCategoryDao;

    @Autowired
    private ShopDetailDao shopDetailDao;

    @Autowired
    private AreasDao areasDao;

    @Autowired
    private ShopDao shopDao;

    @Autowired
    private O2oShopDetailDao o2oShopDetailDao;

    @Autowired
    private O2oServiceOrderDao o2oServiceOrderDao;

    @Autowired
    private BannerService bannerService;

    @Autowired
    private HomePageService homePageService;

    @Autowired
    private SystemParameterService sysService;
    
    @Autowired
    private CalO2oShopPromotionService o2oPromotionService;

    private static String status = "status";
    
    @Autowired
    private CalO2oPromotionService calO2oPromotionService;

    @Autowired
    private CityDao cityDao;

    private List<ShopDto> getNearByShopList(List<Map<String, Object>> shopList,int type) {
        List<ShopDto> list = Lists.newArrayList();
        ShopDto shopDto = null;
        Map<Integer, Areas> areaMap = initAreaMap();
        Map<Integer, O2oCategory> categoryMap = initO2oCategoryMap();
        for (Map<String, Object> shopMap : shopList) {
            shopDto = new ShopDto();
            shopDto.setShopId(StringHelper.objectToInt(shopMap.get("shop_id"), 0));
            shopDto.setShopTitle(StringHelper.objectToString(shopMap.get("site_name"), ""));
            shopDto.setAddress(StringHelper.objectToString(shopMap.get("shop_addr"), ""));
            long totalOrderNum = o2oServiceOrderDao
                    .countByShopIdAndStatus(StringHelper.objectToInt(shopMap.get("shop_id"), 0));
            shopDto.setTotalOrderNum(String.valueOf(totalOrderNum));
//            shopDto.setConsumePer(Integer.parseInt(String.valueOf(totalOrderNum)));
            shopDto.setAverage(StringHelper.objectToString(shopMap.get("ave"), ""));
            shopDto.setCategoryId(StringHelper.objectToInt((shopMap.get("category_id")), 0));
            Double distance = StringHelper.objectToDouble(shopMap.get("distance"), 0);

            shopDto.setDistance(distance);

            if (distance >= 1000) {
                BigDecimal dis = new BigDecimal(distance).divide(new BigDecimal(1000), 2, BigDecimal.ROUND_HALF_UP);
                shopDto.setDistanceWithUnit(String.valueOf(dis) + "km");
            } else {
                shopDto.setDistanceWithUnit(String.valueOf(distance.intValue()) + "m");
            }

            shopDto.setStarNum(5);
            shopDto.setPic(this.buildImg(StringHelper.objectToString(shopMap.get("shop_pic2"), "")));
            O2oShopDetail o2oShopDetail = o2oShopDetailDao
                    .findO2oShopDetailByshopId(StringHelper.objectToInt(shopMap.get("shop_id"), 0));
            if (o2oShopDetail != null) {
                if (o2oShopDetail.getPerCost() != null) {
                    shopDto.setConsumePer(o2oShopDetail.getPerCost().intValue());
                }else{
                	shopDto.setConsumePer(0);
                }
            }else{
            	shopDto.setConsumePer(0);
            }
            ShopDetail shop = shopDetailDao.findOne(shopDto.getShopId());
           
            Areas area = areaMap.get(StringHelper.objectToString(shopMap.get("areaid"), ""));
            if (area != null) {
                shopDto.setArea(area.getArea());
            }
            O2oCategory category = categoryMap.get(StringHelper.objectToInt((shopMap.get("category_id")), 0));
            if (category != null) {
                shopDto.setCategory(category.getName());
            }
            
            //计算商家立减和抵用券
            if(type == 0){
            	//兼容老版本
            	o2oPromotionService.calShopCoupon(shopDto,shop);
            }else{
            	//1.9.3新规则计算
            	calO2oPromotionService.calShopCoupon(shopDto, shop);
            }
            
            shopDto.setLat(StringHelper.objectToDouble(shopMap.get("lat"), 0.0));
            shopDto.setLng(StringHelper.objectToDouble(shopMap.get("lng"), 0.0));
            list.add(shopDto);
        }
        return list;
    }
    
    

    private Page<Map<String, Object>> createPage(int pageNo, int pageSize) {
        Page<Map<String, Object>> page = new Page<Map<String, Object>>();
        page.setPageNo(pageNo);
        page.setPageSize(pageSize);
        return page;
    }

    /**
     * 获取附近商家
     * @Title: getNearbyShop
     * @Description: TODO
     * @param @param cityId
     * @param @param lng
     * @param @param lat
     * @param @return   
     * @return NearbyShopDto 
     * @author Administrator 2016年7月23日 
     * @throws
     */
    @Deprecated
    public NearbyShopDto getNearbyShop2(Integer cityId, Double lng, Double lat, int categoryId, int shopId) {
        NearbyShopDto dto = new NearbyShopDto();

        List<Map<String, Object>> shopList = new ArrayList<>();
        Page<Map<String, Object>> page = createPage(0, 24);

        if (0 == categoryId) {
            if (lng == 0 || lat == 0) {
                // 如果客户端没有定位到经纬度，默认显示苏州市的商家
                lat = NhsConstant.DEFAULT_LAT;
                lng = NhsConstant.DEFAULT_LNG;
                cityId = NhsConstant.DEFAULT_CITY_ID;

                Page<Map<String, Object>> pageData = shopDao.getShopNearByList(cityId, lng, lat, null, page);
                shopList = pageData.getResult();

            } else {
                Page<Map<String, Object>> pageData = shopDao.getShopNearByList(cityId, lng, lat, null, page);
                shopList = pageData.getResult();
            }
        } else {
            List<Integer> categoryIds = new ArrayList<>();
            categoryIds.add(categoryId);

            if (lng == 0 || lat == 0) {
                // 如果客户端没有定位到经纬度，默认显示苏州市的商家
                lat = NhsConstant.DEFAULT_LAT;
                lng = NhsConstant.DEFAULT_LNG;
                cityId = NhsConstant.DEFAULT_CITY_ID;

                Page<Map<String, Object>> pageData = shopDao.getShopNearByList(cityId, lng, lat, categoryId, page);
                shopList = pageData.getResult();

            } else {
                Page<Map<String, Object>> pageData = shopDao.getShopNearByList(cityId, lng, lat, categoryId, page);
                shopList = pageData.getResult();
            }
        }

        List<ShopDto> shopDtoList = getNearByShopList(shopList,0);

        List<ShopDto> nearByshop2 = new ArrayList<ShopDto>();
        for (ShopDto shopDto : shopDtoList) {
            if (shopDto.getShopId() != shopId) {
                nearByshop2.add(shopDto);
            }
        }
        dto.setShopList(nearByshop2);
        // 获取首页banner横幅图片
        List<Banner> bannerList = bannerService.BannerList(status);
        // 设置图标的地址
        for (Banner banner : bannerList) {
            banner.setImg(buildImg(banner.getImg()));
        }
        dto.setBannerList(bannerList);
        // 获取附近商家热门分类
        List<O2oHotCategoryDto> o2oHotCategoryConfigList = homePageService.getCategoryhotData();
        dto.setO2oHotCategoryConfigList(o2oHotCategoryConfigList);

        if (o2oHotCategoryConfigList.size() > 0) {
            O2oHotCategoryDto o2ohotcateOne = o2oHotCategoryConfigList.get(0);
            List<O2oHotCategoryConfig> o2oHotCategorySix = o2ohotcateOne.getO2oHotCategoryConfig();
            for (O2oHotCategoryConfig param : o2oHotCategorySix) {
                O2oCategoryDto categoryDto = new O2oCategoryDto();
                categoryDto.setCategoryId(param.getCategoryId());
                categoryDto.setIcon(buildImg(param.getIcon()));
                categoryDto.setName(param.getName());
                dto.addO2oCategoryDto(categoryDto);
                if (dto.getCategoryList().size() > 5) {
                    break;
                }
            }
        }


        return dto;
    }

    /**
     * 获取附近商家
     * @Title: getNearbyShop
     * @Description: TODO
     * @param @param cityId
     * @param @param lng
     * @param @param lat
     * @param @return   
     * @return NearbyShopDto 
     * @author Administrator 2016年7月23日 
     * @throws
     */
    @Deprecated
    public NearbyShopDto getNearbyShop(Integer cityId, Double lng, Double lat, int categoryId, int shopId) {
        NearbyShopDto dto = new NearbyShopDto();

        // 附近商家
        List<Map<String, Object>> shopList = new ArrayList<>();
        Page<Map<String, Object>> page = createPage(0, 24);

        if (0 == categoryId) {
            if (lng == 0 || lat == 0) {
                // 如果客户端没有定位到经纬度，默认显示苏州市的商家
                lat = NhsConstant.DEFAULT_LAT;
                lng = NhsConstant.DEFAULT_LNG;
                cityId = NhsConstant.DEFAULT_CITY_ID;
                Page<Map<String, Object>> pageData = shopDao.getShopNearByList(cityId, lng, lat, null, page);
                shopList = pageData.getResult();
            } else {
                Page<Map<String, Object>> pageData = shopDao.getShopNearByList(cityId, lng, lat, null, page);
                shopList = pageData.getResult();
            }
        } else {
            List<Integer> categoryIds = new ArrayList<>();
            categoryIds.add(categoryId);

            if (lng == 0 || lat == 0) {
                // 如果客户端没有定位到经纬度，默认显示苏州市的商家
                lat = NhsConstant.DEFAULT_LAT;
                lng = NhsConstant.DEFAULT_LNG;
                cityId = NhsConstant.DEFAULT_CITY_ID;
                Page<Map<String, Object>> pageData = shopDao.getShopNearByList(cityId, lng, lat, categoryId, page);
                shopList = pageData.getResult();
            } else {
                Page<Map<String, Object>> pageData = shopDao.getShopNearByList(cityId, lng, lat, categoryId, page);
                shopList = pageData.getResult();
            }
        }

        List<ShopDto> shopDtoList = getNearByShopList(shopList,0);
        List<ShopDto> nearByshop2 = new ArrayList<ShopDto>();
        for (ShopDto shopDto : shopDtoList) {
            if (shopDto.getShopId() != shopId) {
                nearByshop2.add(shopDto);
            }
        }
        dto.setShopList(nearByshop2);
        // 获取首页banner横幅图片
        List<Banner> bannerList = bannerService.BannerList(status);
        // 设置图标的地址
        for (Banner banner : bannerList) {
            banner.setImg(buildImg(banner.getImg()));
        }
        dto.setBannerList(bannerList);
        // 获取附近商家热门分类
        List<O2oHotCategoryDto> o2oHotCategoryConfigList = homePageService.getCategoryhotData(0);
        dto.setO2oHotCategoryConfigList(o2oHotCategoryConfigList);

        if (o2oHotCategoryConfigList.size() > 0) {
            O2oHotCategoryDto o2ohotcateOne = o2oHotCategoryConfigList.get(0);
            List<O2oHotCategoryConfig> o2oHotCategorySix = o2ohotcateOne.getO2oHotCategoryConfig();
            for (O2oHotCategoryConfig param : o2oHotCategorySix) {
                O2oCategoryDto categoryDto = new O2oCategoryDto();
                categoryDto.setCategoryId(param.getCategoryId());
                categoryDto.setIcon(buildImg(param.getIcon()));
                categoryDto.setName(param.getName());
                dto.addO2oCategoryDto(categoryDto);
                if (dto.getCategoryList().size() > 5) {
                    break;
                }
            }
        }


        return dto;
    }

    /**
     * 获取商家列表
     * @Title: getShopList
     * @Description: TODO
     * @param @param cityId
     * @param @param categoryId
     * @param @param lng
     * @param @param lat
     * @param @param pageNo
     * @param @param pageSize
     * @param @return   
     * @return List<ShopDto> 
     * @author Administrator 2016年7月23日 
     * @throws
     */
    @Deprecated
    public List<ShopDto> getShopList(Integer cityId, Integer categoryId, String keyword, Double lng, Double lat,
            Page<Map<String, Object>> page, int distance, int sort) {
        List<Integer> categoryIds = null;
        if (categoryId != null && categoryId > 0) {
            categoryIds = findSubCategoryIds(categoryId);
        }
        Page<Map<String, Object>> pageData = shopDao.getShopList(categoryIds, cityId, keyword, lng, lat, page, distance,
                sort);
        List<Map<String, Object>> shopList = pageData.getResult();
        return getNearByShopList(shopList,0);
    }

    /**
     * 获取商家列表
     * @Title: getShopList
     * @Description: TODO
     * @param @param cityId
     * @param @param categoryId
     * @param @param lng
     * @param @param lat
     * @param @param pageNo
     * @param @param pageSize
     * @param @return   
     * @return List<ShopDto> 
     * @author Administrator 2016年7月23日 
     * @throws
     */
    @Deprecated
    public List<ShopDto> getAllShopList(Integer cityId, Integer categoryId, String keyword, Double lng, Double lat,
            int distance, int sort) {
        List<Integer> categoryIds = null;
        if (categoryId != null && categoryId > 0) {
            categoryIds = findSubCategoryIds(categoryId);
        }
        List<Map<String, Object>> shopList = shopDao.getAllShopList(categoryIds, cityId, keyword, lng, lat, distance,
                sort);

        return getNearByShopList(shopList,0);

    }

    /**
     * 
     * @Title: getShopDetail
     * @Description: TODO
     * @param @param shopId
     * @param @return   
     * @return Map<String,Object> 
     * @author Administrator 2016年7月23日 
     * @throws
     */
    public ShopDto getShopDetail(Integer shopId) {
        ShopDetail shop = shopDetailDao.findOne(shopId);
        if (shop == null) {
            throw new WebRequestException("商家不存在");
        }
        Map<Integer, Areas> areaMap = initAreaMap();
        Map<Integer, O2oCategory> categoryMap = initO2oCategoryMap();
        ShopDto shopDto = new ShopDto();
        shopDto.setShopId(shop.getShopId());
        shopDto.setShopTitle(shop.getSiteName());
        shopDto.setAddress(shop.getShopAddr());
        shopDto.setStarNum(5); // 先写死5个星，后面在改
        shopDto.setPic(this.buildImg(shop.getShopPic2()));
        O2oShopDetail o2oShopDetail2 = o2oShopDetailDao.findO2oShopDetailByshopId(shopId);
        if (o2oShopDetail2 != null && o2oShopDetail2.getPerCost() != null) {
            shopDto.setConsumePer(o2oShopDetail2.getPerCost().intValue());
            if(o2oShopDetail2.getRebate() == null){
            	o2oShopDetail2.setRebate(new BigDecimal(NhsConstant.DEFAULT_REBATE));
            }
            shopDto.setSubsidy(o2oShopDetail2.getRebate().multiply(new BigDecimal("100")).setScale(0, BigDecimal.ROUND_DOWN)+"%");
        } else {
            shopDto.setConsumePer(0);
        }
        Areas area = areaMap.get(shop.getAreaid());
        if (area != null) {
            shopDto.setArea(area.getArea());
        }
        O2oCategory category = categoryMap.get(shop.getCategoryId());
        if (category != null) {
            shopDto.setCategory(category.getName());
        }
        shopDto.setMobile(shop.getContactMobile());
        shopDto.setContactTel(shop.getContactTel());
        shopDto.setTasteScore(9.0);
        shopDto.setEnvScore(9.1);
        shopDto.setServiceScore(9.0);
        // shopDto.setSubsidy("100%");
        shopDto.setSubsidyStr(sysService.getSingleValueByType(NhsConstant.PARAM_PRESENT_SIGN) + shopDto.getSubsidy());
        shopDto.setLat(shop.getLat());
        shopDto.setLng(shop.getLng());
        return shopDto;

    }

    /**
     *  构建附近商家列表
     * @Title: buildShopList
     * @Description: TODO
     * @param @param shops
     * @param @param lng
     * @param @param lat
     * @param @param size
     * @param @return   
     * @return List<ShopDto> 
     * @author Administrator 2016年7月23日 
     * @throws
     */
    @Deprecated
    public List<ShopDto> buildShopList(List<ShopDetail> shops, double lng, double lat, int size) {
        List<ShopDto> list = buildShopList(shops, lng, lat);
        // 如果大于4个，则取前4个
        if (list.size() > size) {
            list = list.subList(0, size);
        }
        return list;
    }

    /**
     * 构建附近商家列表
     * @Title: buildShopList
     * @Description: TODO
     * @param @param shops
     * @param @param lng
     * @param @param lat
     * @param @return   
     * @return List<ShopDto> 
     * @author Administrator 2016年7月23日 
     * @throws
     */
    @Deprecated
    public List<ShopDto> buildShopList(List<ShopDetail> shops, double lng, double lat) {
        Map<Integer, Areas> areaMap = initAreaMap();
        Map<Integer, O2oCategory> categoryMap = initO2oCategoryMap();
        List<ShopDto> list = Lists.newArrayList();
        ShopDto shopDto = null;
        try {
            for (ShopDetail shop : shops) {
                if (shop.getLng() == null || shop.getLat() == null) {
                    continue;
                }
                shopDto = new ShopDto();
                shopDto.setShopId(shop.getShopId());
                shopDto.setShopTitle(shop.getSiteName());
                shopDto.setAddress(shop.getShopAddr());
                long totalOrderNum = o2oServiceOrderDao.countByShopIdAndStatus(shop.getShopId());
                shopDto.setTotalOrderNum(String.valueOf(totalOrderNum));
                double distance = 0.0;
                if (lng > 0 && lat > 0) {
                    // TODO liangdanhua 修改死数据
                    distance = DistanceUtils.getDistance(lng, lat, shop.getLng(), shop.getLat());
                }
                shopDto.setDistance(distance);
                if (distance < 1) {
                    shopDto.setDistanceWithUnit(String.valueOf(String.format("%.0f", distance * 1000)) + "m");
                } else {
                    shopDto.setDistanceWithUnit(String.valueOf(distance) + "km");
                }
                // TODO liangdanhua 先写死5个星，后面在改
                shopDto.setStarNum(5);
                shopDto.setPic(this.buildImg(shop.getShopPic2()));
                O2oShopDetail o2oShopDetail = o2oShopDetailDao.findO2oShopDetailByshopId(shop.getShopId());
                if (o2oShopDetail != null) {
                    shopDto.setConsumePer(o2oShopDetail.getPerCost().intValue());
                    if(o2oShopDetail.getRebate() == null){
                    	o2oShopDetail.setRebate(new BigDecimal(NhsConstant.DEFAULT_REBATE));
                    }
                    shopDto.setSubsidy(o2oShopDetail.getRebate().multiply(new BigDecimal("100")).setScale(0,BigDecimal.ROUND_DOWN)+"%");
                }
                Areas area = areaMap.get(shop.getAreaid());
                if (area != null) {
                    shopDto.setArea(area.getArea());
                }
                O2oCategory category = categoryMap.get(shop.getCategoryId());
                if (category != null) {
                    shopDto.setCategory(category.getName());
                }
                // 商家补贴暂时默认为100%
                // shopDto.setSubsidy("100%");
                shopDto.setSubsidyStr(
                        sysService.getSingleValueByType(NhsConstant.PARAM_PRESENT_SIGN) + shopDto.getSubsidy());
                shopDto.setLat(shop.getLat());
                shopDto.setLng(shop.getLng());
                list.add(shopDto);
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        if (lng > 0 && lat > 0) {
            // 按距离排序
            Collections.sort(list, new Comparator<ShopDto>() {
                @Override
                public int compare(ShopDto o1, ShopDto o2) {
                    if (o1.getDistance() > o2.getDistance()) {
                        return 1;
                    }
                    if (o1.getDistance() < o2.getDistance()) {
                        return -1;
                    }
                    return 0;
                }
            });
        }

        return list;
    }

    /**
     * 初始化区域map
     * @Title: initAreaMap
     * @Description: TODO
     * @param @return   
     * @return Map<Integer,Areas> 
     * @author Administrator 2016年7月23日 
     * @throws
     */
    private Map<Integer, Areas> initAreaMap() {
        List<Areas> areaList = areasDao.findAreas();
        Map<Integer, Areas> map = Maps.newHashMap();
        for (Areas area : areaList) {
            map.put(area.getId(), area);
        }
        return map;
    }

    /**
     * 初始化分类map
     * @Title: initO2oCategoryMap
     * @Description: TODO
     * @param @return   
     * @return Map<Integer,O2oCategory> 
     * @author Administrator 2016年7月23日 
     * @throws
     */
    private Map<Integer, O2oCategory> initO2oCategoryMap() {
        List<O2oCategory> list = o2oCategoryDao.findO2oCategory();
        Map<Integer, O2oCategory> map = Maps.newHashMap();
        for (O2oCategory c : list) {
            map.put(c.getId(), c);
        }
        return map;
    }

    /**
     * 找子分类ID
     * @Title: findSubCategoryIds
     * @Description: TODO
     * @param @param parentId
     * @param @return   
     * @return List<Integer> 
     * @author Administrator 2016年7月23日 
     * @throws
     */
    private List<Integer> findSubCategoryIds(Integer parentId) {
        List<Integer> ids = Lists.newArrayList();
        ids.add(parentId);
        List<O2oCategory> list = o2oCategoryDao.findO2oCategory(parentId); // 只找下一级，如果有多级需要用递归来找
        if (list != null && list.size() > 0) {
            for (O2oCategory c : list) {
                List<O2oCategory> listSecond = o2oCategoryDao.findO2oCategory(c.getId());
                if (listSecond != null && listSecond.size() > 0) {
                    for (O2oCategory cs : listSecond) {
                        ids.add(cs.getId());
                    }
                } else {
                    ids.add(c.getId());
                }
            }
        }
        return ids;
    }

    public ShopDetail getShopDetailByShopId(int shopId) {
        return shopDetailDao.findOne(shopId);
    }
    
    
    /**
     * 获取附近商家
     * @Title: getNearbyShop
     * @Description: TODO
     * @param @param cityId
     * @param @param lng
     * @param @param lat
     * @param @return   
     * @return NearbyShopDto 
     * @author Administrator 2016年7月23日 
     * @throws
     */
    public NearbyShopDto getNearbyShop2Like(Integer cityId, Double lng, Double lat, int categoryId, int shopId) {
        NearbyShopDto dto = new NearbyShopDto();

        List<Map<String, Object>> shopList = new ArrayList<>();
        Page<Map<String, Object>> page = createPage(0, 24);

        if (0 == categoryId) {
            if (lng == 0 || lat == 0) {
                // 如果客户端没有定位到经纬度，默认显示苏州市的商家
                lat = NhsConstant.DEFAULT_LAT;
                lng = NhsConstant.DEFAULT_LNG;
                cityId = NhsConstant.DEFAULT_CITY_ID;

                Page<Map<String, Object>> pageData = shopDao.getShopNearByList(cityId, lng, lat, null, page);
                shopList = pageData.getResult();

            } else {
                Page<Map<String, Object>> pageData = shopDao.getShopNearByList(cityId, lng, lat, null, page);
                shopList = pageData.getResult();
            }
        } else {
            List<Integer> categoryIds = new ArrayList<>();
            categoryIds.add(categoryId);

            if (lng == 0 || lat == 0) {
                // 如果客户端没有定位到经纬度，默认显示苏州市的商家
                lat = NhsConstant.DEFAULT_LAT;
                lng = NhsConstant.DEFAULT_LNG;
                cityId = NhsConstant.DEFAULT_CITY_ID;

                Page<Map<String, Object>> pageData = shopDao.getShopNearByList(cityId, lng, lat, categoryId, page);
                shopList = pageData.getResult();

            } else {
                Page<Map<String, Object>> pageData = shopDao.getShopNearByList(cityId, lng, lat, categoryId, page);
                shopList = pageData.getResult();
            }
        }

        List<ShopDto> shopDtoList = getNearByShopList(shopList,1);

        List<ShopDto> nearByshop2 = new ArrayList<ShopDto>();
        for (ShopDto shopDto : shopDtoList) {
            if (shopDto.getShopId() != shopId) {
                nearByshop2.add(shopDto);
            }
        }
        dto.setShopList(nearByshop2);
        // 获取首页banner横幅图片
        List<Banner> bannerList = bannerService.BannerList(status);
        // 设置图标的地址
        for (Banner banner : bannerList) {
            banner.setImg(buildImg(banner.getImg()));
        }
        dto.setBannerList(bannerList);
        // 获取附近商家热门分类
        List<O2oHotCategoryDto> o2oHotCategoryConfigList = homePageService.getCategoryhotData();
        dto.setO2oHotCategoryConfigList(o2oHotCategoryConfigList);

        if (o2oHotCategoryConfigList.size() > 0) {
            O2oHotCategoryDto o2ohotcateOne = o2oHotCategoryConfigList.get(0);
            List<O2oHotCategoryConfig> o2oHotCategorySix = o2ohotcateOne.getO2oHotCategoryConfig();
            for (O2oHotCategoryConfig param : o2oHotCategorySix) {
                O2oCategoryDto categoryDto = new O2oCategoryDto();
                categoryDto.setCategoryId(param.getCategoryId());
                categoryDto.setIcon(buildImg(param.getIcon()));
                categoryDto.setName(param.getName());
                dto.addO2oCategoryDto(categoryDto);
                if (dto.getCategoryList().size() > 5) {
                    break;
                }
            }
        }


        return dto;
    }

    /**
     * 获取附近商家
     * @Title: getNearbyShop
     * @Description: TODO
     * @param @param cityId
     * @param @param lng
     * @param @param lat
     * @param @return   
     * @return NearbyShopDto 
     * @author Administrator 2016年7月23日 
     * @throws
     */
    public NearbyShopDto getNearbyShopLike(Integer cityId, Double lng, Double lat, int categoryId, int shopId) {
        NearbyShopDto dto = new NearbyShopDto();

        // 附近商家
        List<Map<String, Object>> shopList = new ArrayList<>();
        Page<Map<String, Object>> page = createPage(0, 24);

        if (0 == categoryId) {
            if (lng == 0 || lat == 0) {
                // 如果客户端没有定位到经纬度，默认显示苏州市的商家
                lat = NhsConstant.DEFAULT_LAT;
                lng = NhsConstant.DEFAULT_LNG;
                cityId = NhsConstant.DEFAULT_CITY_ID;
                Page<Map<String, Object>> pageData = shopDao.getShopNearByList(cityId, lng, lat, null, page);
                shopList = pageData.getResult();
            } else {
                Page<Map<String, Object>> pageData = shopDao.getShopNearByList(cityId, lng, lat, null, page);
                shopList = pageData.getResult();
            }
        } else {
            List<Integer> categoryIds = new ArrayList<>();
            categoryIds.add(categoryId);

            if (lng == 0 || lat == 0) {
                // 如果客户端没有定位到经纬度，默认显示苏州市的商家
                lat = NhsConstant.DEFAULT_LAT;
                lng = NhsConstant.DEFAULT_LNG;
                cityId = NhsConstant.DEFAULT_CITY_ID;
                Page<Map<String, Object>> pageData = shopDao.getShopNearByList(cityId, lng, lat, categoryId, page);
                shopList = pageData.getResult();
            } else {
                Page<Map<String, Object>> pageData = shopDao.getShopNearByList(cityId, lng, lat, categoryId, page);
                shopList = pageData.getResult();
            }
        }

        List<ShopDto> shopDtoList = getNearByShopList(shopList,1);
        List<ShopDto> nearByshop2 = new ArrayList<ShopDto>();
        for (ShopDto shopDto : shopDtoList) {
            if (shopDto.getShopId() != shopId) {
                nearByshop2.add(shopDto);
            }
        }
        dto.setShopList(nearByshop2);
        // 获取首页banner横幅图片
        List<Banner> bannerList = bannerService.BannerList(status);
        // 设置图标的地址
        for (Banner banner : bannerList) {
            banner.setImg(buildImg(banner.getImg()));
        }
        dto.setBannerList(bannerList);
        // 获取附近商家热门分类
        List<O2oHotCategoryDto> o2oHotCategoryConfigList = homePageService.getCategoryhotData(0);
        dto.setO2oHotCategoryConfigList(o2oHotCategoryConfigList);

        if (o2oHotCategoryConfigList.size() > 0) {
            O2oHotCategoryDto o2ohotcateOne = o2oHotCategoryConfigList.get(0);
            List<O2oHotCategoryConfig> o2oHotCategorySix = o2ohotcateOne.getO2oHotCategoryConfig();
            for (O2oHotCategoryConfig param : o2oHotCategorySix) {
                O2oCategoryDto categoryDto = new O2oCategoryDto();
                categoryDto.setCategoryId(param.getCategoryId());
                categoryDto.setIcon(buildImg(param.getIcon()));
                categoryDto.setName(param.getName());
                dto.addO2oCategoryDto(categoryDto);
                if (dto.getCategoryList().size() > 5) {
                    break;
                }
            }
        }


        return dto;
    }
}
