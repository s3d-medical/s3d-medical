package com.nhs.shop.service.investment;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nhs.shop.dao.legend.investment.InvestmentInfoDao;
import com.nhs.shop.entry.legend.investment.InvestmentInfo;
import com.nhs.shop.service.BaseService;

/**
 * 招商信息
 * @author Administrator
 *
 */
@Service
public class InvestmentInfoService extends BaseService{
	 @Autowired
	 private InvestmentInfoDao investmentInfoDao;
	 
	 public void saveInvestmentInfo(InvestmentInfo info){
		 info.setCreateDate(new Date());
		 investmentInfoDao.save(info);
	 }
}
