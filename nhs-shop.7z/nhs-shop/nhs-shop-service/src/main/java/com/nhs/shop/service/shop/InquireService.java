package com.nhs.shop.service.shop;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nhs.core.web.WebRequestException;
import com.nhs.shop.dao.legend.shop.AdvertisingDao;
import com.nhs.shop.dao.legend.shop.InquireDao;
import com.nhs.shop.entry.legend.shop.Advertising;
import com.nhs.shop.entry.legend.shop.Inquire;
import com.nhs.shop.service.BaseService;

/**
 * 回访内容service
 * @Title: InquireService.java
 * @Package com.nhs.shop.service.shop
 * @Description: TODO
 * @author zhujun
 * @date 2016年9月21日
 * @version V1.0
 */
@Service
@Transactional
public class InquireService extends BaseService {

    @Autowired
    private InquireDao inquireDao;
    
    @Autowired
    private AdvertisingDao advertisingDao;

    /**
     * 
     * @Title: 保存回访内容
     * @Description: TODO
     * @param @param Inquire
     * @param @return   
     * @return String 
     * @author zhujun 2016年9月21日 
     * @throws
     */

    public String saveInquireInfo(Inquire inquire) {
        String flag = "";
        if (inquire.getUserTel() == null || "".equals(inquire.getUserTel().trim())) {
            throw new WebRequestException("电话号码为空");
        }
        List<Inquire> list = inquireDao.findByUserTel(inquire.getUserTel());
        if (list.size() > 0) {
            throw new WebRequestException("相同的电话号码不能重复填写");
        }
        inquire.setCreatTime(new Date());
        Inquire newInquire = inquireDao.save(inquire);
        if (newInquire != null) {
            flag = "1";
        } else {
            flag = "0";
        }
        return flag;
    }

    /**
     * 
     * @Title: 获取所有回访内容
     * @Description: TODO
     * @param @param 
     * @return Inquire 
     * @author zhujun 2016年9月21日 
     * @throws
     */

    public List<Inquire> getAllInquireInfo() {
        List<Inquire> list = inquireDao.findAll();
        return list;
    }
    
    /**
     * 
     * @Title: 添加广告图片
     * @Description: TODO
     * @param @param Advertising
     * @param @return   
     * @return String 
     * @author zhujun 2016年9月21日 
     * @throws
     */

    public String saveAdvertisingInfo(Advertising advertising) {
        String flag = "";
        Advertising newAdvertising = advertisingDao.save(advertising);
        if (newAdvertising != null) {
            flag = "1";
        } else {
            flag = "0";
        }
        return flag;
    }
    
    /**
     * 
     * @Title: 获取所有广告图片
     * @Description: TODO
     * @param @param 
     * @return Advertising 
     * @author zhujun 2016年12月7日 
     * @throws
     */

    public List<Advertising> getAlladvertising() {
        List<Advertising> list = advertisingDao.findAdvertising();
        return list;
    }

}
