package com.nhs.shop.service.category.dto;

import java.util.List;

import com.google.common.collect.Lists;
import com.nhs.shop.entry.legend.service.O2oCategory;

public class O2oCategoryDto {

    private Integer categoryId = 0;

    private String title = "";

    private List<O2oCategory> children = Lists.newArrayList();

    public Integer getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Integer categoryId) {
        this.categoryId = categoryId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<O2oCategory> getChildren() {
        return children;
    }

    public void setChildren(List<O2oCategory> children) {
        this.children = children;
    }

}
