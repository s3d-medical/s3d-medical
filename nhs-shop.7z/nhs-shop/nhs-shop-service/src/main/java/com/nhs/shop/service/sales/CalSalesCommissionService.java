package com.nhs.shop.service.sales;


import java.math.BigDecimal;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nhs.apiproxy.member.acc.service.AccountTransferService;
import com.nhs.core.common.NhsConstant;
import com.nhs.core.utils.common.ArithUtils;
import com.nhs.shop.dao.legend.coin.CoinRmbSilverLogDao;
import com.nhs.shop.dao.legend.shop.ProfitRecordDao;
import com.nhs.shop.dao.legend.shop.ShopDetailDao;
import com.nhs.shop.entry.legend.coin.CoinRmbSilverLog;
import com.nhs.shop.entry.legend.shop.ShopDetail;
import com.nhs.shop.service.sales.dto.SalesCommissionDto;

@Service
@Transactional
public class CalSalesCommissionService {

		@Autowired
		private AccountTransferService accTransferService;
		
		@Autowired
		private ShopDetailDao shopDetailDao;
		
		@Autowired
	    private CoinRmbSilverLogDao coinRmbSilverLogDao;
		
		 @Autowired
    private ProfitRecordDao profitRecordDao;
		
		/**
		 * 计算营业员佣金
		 * @param dto
		 */
		public void addSalesComission(SalesCommissionDto dto){
			ShopDetail shop = shopDetailDao.findOne(dto.getShopId());
	        if (shop != null) {
            	BigDecimal adRate = calAdRebate(dto.getAdFeeRate());
                BigDecimal totalRebateCash = ArithUtils.mul2(dto.getOrderPayAmount(), adRate, 4, BigDecimal.ROUND_DOWN);
                BigDecimal commissionSilver = totalRebateCash.multiply(new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE)).setScale(2,
                    BigDecimal.ROUND_DOWN);
            	boolean success = this.accTransferService.addCommissionSilver(dto.getUserId(), 	dto.getOrderNum(), commissionSilver);								
				dto.setCommissionSilver(commissionSilver);
               	if(!success){
               		throw new RuntimeException("给营业员增加佣金操作失败. ");
               	}
            	CoinRmbSilverLog silverLog = new CoinRmbSilverLog();
                silverLog.setCash(dto.getOrderPayAmount());
                silverLog.setPrice(dto.getOrderPayAmount());
                silverLog.setSubNumber(dto.getOrderNum());
                silverLog.setProdId(0);
                silverLog.setCreateTime(new Date());
                silverLog.setUserId(dto.getUserId());
                silverLog.setConvertScale(dto.getAdFeeRate().floatValue());
                silverLog.setRebateScale(calRebate(dto.getAdFeeRate()).floatValue());
                silverLog.setProdNum(0);
                silverLog.setTotalCash(dto.getOrderPayAmount());
                silverLog.setTotalRebateCash(totalRebateCash);
                silverLog.setCoinSum(commissionSilver);
                silverLog.setType(3); // 营业员
                coinRmbSilverLogDao.saveAndFlush(silverLog);
	        }
		}
		
		/**
	     * 计算商家返还比例
	     * @Title: calAdRebate
	     * @Description: TODO
	     * @param @param prodRebate
	     * @param @return   
	     * @return BigDecimal 
	     * @author guangrong 2016年11月1日 
	     * @throws
	     */
	    private BigDecimal calAdRebate(BigDecimal adRate) {
	        BigDecimal adRebate = BigDecimal.valueOf(0.00);
	        if (adRate != null) {
	            if (new BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE_CRITICAL).compareTo(adRate) >= 0) {
	            	adRebate = adRate;
	            } else if (new BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE_CRITICAL).compareTo(adRate) < 0) {
	            	adRebate = new BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE_CRITICAL);
	            }
	        }else{
	        	adRebate = new BigDecimal(NhsConstant.DEFAULT_AD_FEE_RATE_CRITICAL);
	        }
	        return adRebate;
	    }
	    
	    /**
	     * 计算赠送比例
	     * @Title: calRebate
	     * @Description: TODO
	     * @param @param prodRebate
	     * @param @return   
	     * @return BigDecimal 
	     * @author guangrong 2016年11月1日 
	     * @throws
	     */
	    private BigDecimal calRebate(BigDecimal adFeeRate) {
	        BigDecimal rebate = BigDecimal.valueOf(0.00);
	        rebate = ArithUtils.div2(adFeeRate, new BigDecimal(NhsConstant.DEFAULT_AD_FEE_BASIC_RATE), 2, BigDecimal.ROUND_DOWN);
	        
            if (rebate.compareTo(new BigDecimal(NhsConstant.DEFAULT_REBATE)) > 0) {
                rebate = new BigDecimal(NhsConstant.DEFAULT_REBATE);
            } 
	        
	        return rebate;
	    }
}
