package com.nhs.shop.service.order.dto;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 服务订单详情DTO
 * @Title: OrderListDto.java
 * @Package com.nhs.shop.service.order.dto
 * @Description: TODO
 * @author penghuaiyi   
 * @date 2016年7月20日 下午3:37:26
 * @version V1.0
 */
public class ServiceOrderDetailDto implements Serializable {

    private static final long serialVersionUID = 2308053677959309156L;
    private Integer orderId;
    private String orderNum;
    private Integer shopId;
    private String shopName;
    private String address;
    private String pic;
    private Integer status;
    private String statusName;
    private Double totalAmount;
    private String createTime;
    private String consumeTime;
    private Double subsidy;
    private String cancelTime;
    private String subsidyStr;
    private String reduceAmount = "";
    private String couponAmount = "";
    private String payAmountStr;
    private String totalAmountStr;
    private String coupon;
    private String discount;
    private String couponStr;
    private BigDecimal rebate;
    private String validateCode;
    private String shopDiscount;
    private String shopDiscountStr;
    private String shopDiscountRate;
    private String shopDiscountMoney;
    

    public String getCancelTime() {
        return cancelTime;
    }

    public void setCancelTime(String cancelTime) {
        this.cancelTime = cancelTime;
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public String getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(String orderNum) {
        this.orderNum = orderNum;
    }

    public Integer getShopId() {
        return shopId;
    }

    public void setShopId(Integer shopId) {
        this.shopId = shopId;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getStatusName() {
        return statusName;
    }

    public void setStatusName(String statusName) {
        this.statusName = statusName;
    }

    public Double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(Double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public String getConsumeTime() {
        return consumeTime;
    }

    public void setConsumeTime(String consumeTime) {
        this.consumeTime = consumeTime;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Double getSubsidy() {
        return subsidy;
    }

    public void setSubsidy(Double subsidy) {
        this.subsidy = subsidy;
    }

	public String getSubsidyStr() {
		return subsidyStr;
	}

	public void setSubsidyStr(String subsidyStr) {
		this.subsidyStr = subsidyStr;
	}

	public String getReduceAmount() {
		return reduceAmount;
	}

	public void setReduceAmount(String reduceAmount) {
		this.reduceAmount = reduceAmount;
	}

	public String getCouponAmount() {
		return couponAmount;
	}

	public void setCouponAmount(String couponAmount) {
		this.couponAmount = couponAmount;
	}

	public String getPayAmountStr() {
		return payAmountStr;
	}

	public void setPayAmountStr(String payAmountStr) {
		this.payAmountStr = payAmountStr;
	}

	public String getTotalAmountStr() {
		return totalAmountStr;
	}

	public void setTotalAmountStr(String totalAmountStr) {
		this.totalAmountStr = totalAmountStr;
	}

	public String getCoupon() {
		return coupon;
	}

	public void setCoupon(String coupon) {
		this.coupon = coupon;
	}

	public String getDiscount() {
		return discount;
	}

	public void setDiscount(String discount) {
		this.discount = discount;
	}

	public String getCouponStr() {
		return couponStr;
	}

	public void setCouponStr(String couponStr) {
		this.couponStr = couponStr;
	}

	public BigDecimal getRebate() {
		return rebate;
	}

	public void setRebate(BigDecimal rebate) {
		this.rebate = rebate;
	}

	public String getValidateCode() {
		return validateCode;
	}

	public void setValidateCode(String validateCode) {
		this.validateCode = validateCode;
	}

	public String getShopDiscount() {
		return shopDiscount;
	}

	public void setShopDiscount(String shopDiscount) {
		this.shopDiscount = shopDiscount;
	}

	public String getShopDiscountStr() {
		return shopDiscountStr;
	}

	public void setShopDiscountStr(String shopDiscountStr) {
		this.shopDiscountStr = shopDiscountStr;
	}

	public String getShopDiscountRate() {
		return shopDiscountRate;
	}

	public void setShopDiscountRate(String shopDiscountRate) {
		this.shopDiscountRate = shopDiscountRate;
	}

	public String getShopDiscountMoney() {
		return shopDiscountMoney;
	}

	public void setShopDiscountMoney(String shopDiscountMoney) {
		this.shopDiscountMoney = shopDiscountMoney;
	}
    
	
    
}
