package com.nhs.shop.service.order.dto;

import java.io.Serializable;

/**
 * 用户地址信息DTO
 * @Title: UserAddressDto.java
 * @Package com.nhs.shop.service.order.dto
 * @Description: TODO
 * @author Administrator
 * @date 2016年7月19日 下午4:38:11
 * @version V1.0
 */
public class UserAddressDto implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 8345545763134079441L;
    private Integer adderssId;
    private String contact;
    private String mobile;
    private String address;
    private String detailAddress;
    private Integer provinceId;
    private Integer cityId;
    private Integer areaId;

    public Integer getAdderssId() {
        return adderssId;
    }

    public void setAdderssId(Integer adderssId) {
        this.adderssId = adderssId;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Integer getProvinceId() {
        return provinceId;
    }

    public void setProvinceId(Integer provinceId) {
        this.provinceId = provinceId;
    }

    public Integer getCityId() {
        return cityId;
    }

    public void setCityId(Integer cityId) {
        this.cityId = cityId;
    }

    public Integer getAreaId() {
        return areaId;
    }

    public void setAreaId(Integer areaId) {
        this.areaId = areaId;
    }

    public String getDetailAddress() {
        return detailAddress;
    }

    public void setDetailAddress(String detailAddress) {
        this.detailAddress = detailAddress;
    }

}
