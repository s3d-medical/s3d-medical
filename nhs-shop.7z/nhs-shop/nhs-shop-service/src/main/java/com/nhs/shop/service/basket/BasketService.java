package com.nhs.shop.service.basket;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.Maps;
import com.nhs.core.common.NhsConstant;
import com.nhs.core.context.SysPropsFactory;
import com.nhs.core.utils.common.ArithUtils;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.core.web.WebRequestException;
import com.nhs.shop.dao.legend.shop.BasketDao;
import com.nhs.shop.dao.legend.shop.GoodsDao;
import com.nhs.shop.dao.legend.shop.ProdDao;
import com.nhs.shop.dao.legend.shop.ShopDetailDao;
import com.nhs.shop.dao.legend.shop.SkuDao;
import com.nhs.shop.entry.legend.shop.Basket;
import com.nhs.shop.entry.legend.shop.Prod;
import com.nhs.shop.entry.legend.shop.ProdProp;
import com.nhs.shop.entry.legend.shop.ProdPropValue;
import com.nhs.shop.entry.legend.shop.ShopDetail;
import com.nhs.shop.entry.legend.shop.Sku;
import com.nhs.shop.entry.legend.user.UsrDetail;
import com.nhs.shop.service.BaseService;
import com.nhs.shop.service.basket.dto.BasketDto;
import com.nhs.shop.service.basket.dto.BasketDto.BasketProdDto;
import com.nhs.shop.service.goods.GoodsService;
import com.nhs.shop.service.goods.GoodsTagsService;
import com.nhs.shop.service.goods.dto.GoodsTagDto;
import com.nhs.shop.service.sku.SkuService;
import com.nhs.shop.service.system.SystemParameterService;
import com.nhs.user.service.UserService;

/**
 * 购物车service
 * @Title: BasketService.java
 * @Package com.nhs.shop.service.basket
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月18日 下午4:18:07
 * @version V1.0
 */
@Service
public class BasketService extends BaseService {

    @Autowired
    private BasketDao basketDao;

    @Autowired
    private ProdDao prodDao;

    @Autowired
    private UserService userService;

    @Autowired
    private SkuDao skuDao;

    @Autowired
    private ShopDetailDao shopDetailDao;

    @Autowired
    private SkuService skuService;

    @Autowired
    private GoodsDao goodsDao;

    @Autowired
    private GoodsService goodsService;
    
    @Autowired
    private SystemParameterService sysService; 
    
    @Autowired
    private GoodsTagsService goodsTagsService;
    
    
    /**
     * 获取购物车列表
     * @Title: getBasketList
     * @Description: TODO
     * @param @param userId
     * @param @return   
     * @return Map<String,Object> 
     * @author Administrator 2016年7月18日 
     * @throws
     */
    public Map<String, Object> getBasketList(String userId) {
        Map<Integer, BasketDto> map = Maps.newHashMap();
        double total = 0;
        List<Basket> basketList = basketDao.findBasketListByUserId(userId);
        for (Basket basket : basketList) {
        	Prod prod = prodDao.findOne(basket.getProdId());
            if (prod != null) {
	            int shopId = basket.getShopId();
	            ShopDetail shopDetail = shopDetailDao.findOne(shopId);
	            total = ArithUtils.add(total, ArithUtils.mul(basket.getCash().doubleValue(), basket.getBasketCount()));
	            BasketDto dto = map.get(shopId);
	            if (dto == null) {
	                dto = new BasketDto();
	                dto.setShopId(shopId);
	                if (shopDetail == null) {
	                    dto.setShopName(basket.getShopName());
	                } else {
	                    dto.setShopName(shopDetail.getSiteName() == null ? basket.getShopName() : shopDetail.getSiteName());
	                }
	                map.put(shopId, dto);
	            }
	            // 创建购物车商品数据
	            BasketProdDto prodDto = buildBasketProdDto(basket, userId);
	            dto.addBasketProd(prodDto);
            }
        }

        Map<String, Object> data = Maps.newHashMap();
        data.put("list", map.values());
        data.put("total", total);
        return data;
    }
    
    private BasketProdDto buildBasketProdDto(Basket basket, String userId) {
        // 购物车
        BasketProdDto prodDto = new BasketProdDto();
        prodDto.setBasketId(basket.getBasketId());
        prodDto.setCount(basket.getBasketCount());
        prodDto.setPic(this.buildImg(basket.getPic()));
        prodDto.setProdId(basket.getProdId());
        prodDto.setDetailUrl(SysPropsFactory.getProperty("goodsDetailUrl") + basket.getProdId());
        if (basket.getCash() != null) {
            prodDto.setPrice(basket.getCash().setScale(2,  BigDecimal.ROUND_DOWN).toString());
        }
        Prod prod = prodDao.findOne(basket.getProdId());
        if (prod != null) {
            prodDto.setProdStocks(prod.getStocks());
            prodDto.setProdName(prod.getName());
        }
        // sku
        Sku sku = null;
        if (basket.getSkuId() != null && basket.getSkuId() > 0) {
            prodDto.setSkuId(basket.getSkuId());
            sku = skuDao.findOne(basket.getSkuId());
            if (sku != null) {
                prodDto.setSkuStocks(sku.getStocks());
                prodDto.setPrice(StringHelper.objectToBigDecimal(sku.getPrice(), "").setScale(2, BigDecimal.ROUND_DOWN)
                        .toString());
            }
            prodDto.setSkuDesc(skuService.getSkuDesc(sku));
        }
        
        // 获取产品的标签. 
        GoodsTagDto tagDto = goodsTagsService.getSkuProdDimTag(sku, prod, userId);
        prodDto.setMailStatus(tagDto.getPostageDesc());
        prodDto.setSubsidy(tagDto.getSubsidy().toString());
        prodDto.setSubsidyStr(tagDto.getSubsidyTag());
        prodDto.setReducedCashTag(tagDto.getReducedCashTag());
        return prodDto;
    }
    
    /**
     * 创建购物车商品数据
     * @Title: createBasketProdDto
     * @Description: TODO
     * @param @param basket
     * @param @param skuMap
     * @param @param propMap
     * @param @param propValueMap
     * @param @return   
     * @return BasketProdDto 
     * @author Administrator 2016年7月18日 
     * @throws
     */
    @Deprecated
    private BasketProdDto createBasketProdDto(Basket basket, Map<Integer, Sku> skuMap, Map<Integer, ProdProp> propMap,
            Map<Integer, ProdPropValue> propValueMap) {
        // 购物车
        BasketProdDto prodDto = new BasketProdDto();
        prodDto.setBasketId(basket.getBasketId());
        prodDto.setCount(basket.getBasketCount());
        prodDto.setPic(this.buildImg(basket.getPic()));
        if (basket.getCash() != null) {
            prodDto.setPrice(StringHelper.objectToBigDecimal(basket.getCash(), "").setScale(2, BigDecimal.ROUND_DOWN)
                    .toString());

        }
        prodDto.setProdId(basket.getProdId());
        Prod prod = prodDao.findOne(basket.getProdId());
        if (prod != null) {
            prodDto.setProdStocks(prod.getStocks());
            prodDto.setProdName(prod.getName());
        }
        prodDto.setDetailUrl(SysPropsFactory.getProperty("goodsDetailUrl") + basket.getProdId());
        Double price = 0.0;
        double rebate = 1;
        if(prod !=null){
        	rebate = prod.getRebate().doubleValue();
        }
        // 计算补贴
        Map<String, Object> map = goodsDao.getGoodsDetail(basket.getProdId());
        if (map != null) {

            prodDto.setSubsidy(
                    StringHelper
                            .objectToBigDecimal(
                                    ArithUtils.mul(price == 0.0 ? basket.getCash().doubleValue() : price, rebate), "")
                            .setScale(2, BigDecimal.ROUND_DOWN).toString());
            if(StringUtils.isNotEmpty(prodDto.getSubsidy())){
            	prodDto.setSubsidyStr(sysService.getSingleValueByType(NhsConstant.PARAM_PRESENT_SIGN)+sysService.getSingleValueByType(NhsConstant.PARAM_RMB_ICON)+prodDto.getSubsidy());
            }
        }
        // TODO liangdanhua 获取运费
        if (prod != null) {
            String mailStatus = goodsService.calculatePostage(basket.getProdId().toString(), basket.getUserId());
            prodDto.setMailStatus(mailStatus);
        }
        if (basket.getSkuId() != null && basket.getSkuId() > 0) {
            prodDto.setSkuId(basket.getSkuId());
            prodDto.setSkuDesc(skuService.getSkuDesc(basket.getSkuId(), skuMap, propMap, propValueMap));
            Sku sku = skuDao.findOne(basket.getSkuId());
            if (sku != null) {
                prodDto.setSkuStocks(sku.getStocks());
                prodDto.setPrice(StringHelper.objectToBigDecimal(sku.getPrice(), "").setScale(2, BigDecimal.ROUND_DOWN)
                        .toString());
                prodDto.setSubsidy(
                        StringHelper
                                .objectToBigDecimal(
                                        ArithUtils.mul(price == 0.0 ? sku.getPrice().doubleValue() : price, rebate), "")
                                .setScale(2, BigDecimal.ROUND_DOWN).toString());
                if(StringUtils.isNotEmpty(prodDto.getSubsidy())){
                	prodDto.setSubsidyStr(sysService.getSingleValueByType(NhsConstant.PARAM_PRESENT_SIGN)+sysService.getSingleValueByType(NhsConstant.PARAM_RMB_ICON)+prodDto.getSubsidy());
                }
            }
        }
        return prodDto;

    }

    /**
     * 添加购物车
     * @Title: addBasket
     * @Description: TODO
     * @param @param userId
     * @param @param prodId
     * @param @param skuId
     * @param @param count   
     * @return void 
     * @author Administrator 2016年7月18日 
     * @throws
     */
    public String saveBasket(String userId, Integer prodId, Integer skuId, Integer count) {
        Prod prod = prodDao.findOne(prodId);
        if (prod == null) {
            throw new WebRequestException("商品不存在");
        }

        if (prod.getStatus() != 1) {
            throw new WebRequestException("商品已经下架");
        }

        //UsrDetail user = usrDetailDao.findUserById(userId);
        UsrDetail user = this.userService.findUserById(userId);
        
        if (user == null) {
            throw new WebRequestException("用户不存在");
        }

        if (skuId != null && skuId > 0) {
            Sku sku = skuDao.findOne(skuId);
            if (sku == null) {
                throw new WebRequestException("sku不存在");
            }
        }

        ShopDetail shop = shopDetailDao.findOne(prod.getShopId());
        if (shop == null) {
            throw new WebRequestException("shop不存在");
        }
        Basket basket = basketDao.findBasket(userId, prodId, skuId);
        if (basket == null) {
            // 保存购物车数据
            basket = new Basket();
            // basket.setBasketId(jdbcTemplate.getNextVal("BASKET_SEQ"));
            basket.setProdId(prodId);
            basket.setSkuId(skuId);
            basket.setPic(prod.getPic());
            basket.setUserId(userId);
            basket.setUserName(user.getUserName());
            basket.setBasketCount(count);
            basket.setProdName(prod.getName());
            basket.setPrice(prod.getPrice());
            basket.setCash(prod.getCash());
            basket.setBasketDate(new Date());
            basket.setLastUpdateDate(new Date());
            basket.setShopId(shop.getShopId());
            basket.setShopName(shop.getSiteName());
            basket.setCarriage(new BigDecimal(0));
            basket.setSubNumber("");
            basket.setAttribute("");
            basketDao.save(basket);
        } else {
            if (basket.getBasketCount() == null) {
                basket.setBasketCount(0);
            }
            basket.setBasketCount(basket.getBasketCount() + count);
            basketDao.saveAndFlush(basket);
        }
        return "1";

    }

    /**
     * 修改购物车
     * @Title: updateBasket
     * @Description: TODO
     * @param @param basketId
     * @param @param count   
     * @return void 
     * @author Administrator 2016年7月18日 
     * @throws
     */
    public void updateBasket(Integer basketId, Integer skuId, Integer count) {
        Basket basket = basketDao.findOne(basketId);
        if (basket == null) {
            throw new WebRequestException("购物车商品不存在");
        }
        // 修改购物车数据
        basket.setBasketCount(count);
        if (skuId != null && skuId > 0) {
            basket.setSkuId(skuId);
        }
        basket.setLastUpdateDate(new Date());
        basketDao.save(basket);
    }

    /**
     * 删除购物车
     * @Title: deleteBasket
     * @Description: TODO
     * @param @param userId
     * @param @param basketId   
     * @return void 
     * @author Administrator 2016年7月18日 
     * @throws
     */
    public void deleteBasket(String userId, Integer basketId) {
        Basket basket = basketDao.findOne(basketId);
        if (basket == null) {
            throw new WebRequestException("购物车商品不存在");
        }
        if (!basket.getUserId().equals(userId)) {
            throw new WebRequestException("没有权限删除");
        }
        // 删除
        basketDao.delete(basketId);
    }

}
