package com.nhs.shop.service.order.shop.internal;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nhs.core.web.WebRequestException;
import com.nhs.shop.dao.legend.shop.ProdCommDao;
import com.nhs.shop.dao.legend.shop.SubDao;
import com.nhs.shop.dao.legend.shop.SubItemDao;
import com.nhs.shop.entry.em.order.ShopOrderStatusEnum;
import com.nhs.shop.entry.legend.shop.ProdComm;
import com.nhs.shop.entry.legend.shop.Sub;
import com.nhs.shop.entry.legend.shop.SubItem;
import com.nhs.shop.entry.legend.user.UsrDetail;
import com.nhs.shop.service.BaseService;
import com.nhs.shop.service.order.dto.OrderCommAddItemDto;
import com.nhs.shop.service.order.dto.OrderCommAddRequestDto;
import com.nhs.user.service.UserService;

/**
 * 商城订单评价service
 * @Title: GoodsService.java
 * @Package com.nhs.shop.service.goods
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月16日 下午7:42:18
 * @version V1.0
 */
@Service
public class ShopOrderCommService extends BaseService {

    @Autowired
    private SubDao subDao;

    @Autowired
    private SubItemDao subItemDao;

    @Autowired
    private ProdCommDao prodCommDao;

    @Autowired
    private UserService userService;

    /**
     * 创建商城订单评价
     * @Title: saveShopOrder
     * @Description: TODO
     * @param @param dto
     * @param @return   
     * @return Map<String,Object> 
     * @author Administrator 2016年7月20日 
     * @throws
     */
    public void saveShopOrderComm(OrderCommAddRequestDto dto) {
        Sub sub = subDao.findOne(dto.getOrderId());
        if (sub == null) {
            throw new WebRequestException("订单不存在");
        }

        UsrDetail userDetail = userService.findUserById(dto.getUserId());
        if (userDetail == null) {
            throw new WebRequestException("用户不存在");
        }

        if (sub.getStatus() == ShopOrderStatusEnum.PADYED.getStatus()) {
            throw new WebRequestException("订单已评价");
        }

        List<SubItem> subItems = subItemDao.findSubItem(sub.getSubNumber());
        for (SubItem subItem : subItems) {
            ProdComm prodComm = new ProdComm();
            prodComm.setProdId(subItem.getProdId());
            prodComm.setBasketId(0);
            prodComm.setUserId(userDetail.getUserId());
            prodComm.setUserName(userDetail.getUserName());
            prodComm.setContent(dto.getCotent());
            prodComm.setAddtime(new Date());
            prodComm.setScore(dto.getScore().shortValue());
            prodComm.setSubItemId(subItem.getSubItemId());
            prodComm.setPostip("");
            prodComm.setOwnerName("");
            prodComm.setReplayCounts(0);
            prodComm.setUsefulCounts(0);
            int i = 0;
            for (String pic : dto.getPicList()) {
                i++;
                switch (i) {
                    case 1:
                        prodComm.setPhotoFile1(pic);
                        break;
                    case 2:
                        prodComm.setPhotoFile2(pic);
                        break;
                    case 3:
                        prodComm.setPhotoFile3(pic);
                        break;
                    case 4:
                        prodComm.setPhotoFile4(pic);
                        break;
                    case 5:
                        prodComm.setPhotoFile5(pic);
                        break;
                    case 6:
                        prodComm.setPhotoFile6(pic);
                        break;
                    case 7:
                        prodComm.setPhotoFile7(pic);
                        break;
                    case 8:
                        prodComm.setPhotoFile8(pic);
                        break;
                    case 9:
                        prodComm.setPhotoFile9(pic);
                        break;
                }
            }

            prodCommDao.save(prodComm);

            subItem.setCommSts(1);
            subItemDao.saveAndFlush(subItem);
        }
        sub.setUpdateDate(new Date());
        // 修改订单状态为已评价
        sub.setStatus(ShopOrderStatusEnum.COMMENTED.getStatus());
        subDao.saveAndFlush(sub);
    }

    /**
     * 创建商城订单评价
     * @Title: saveShopOrder
     * @Description: TODO
     * @param @param dto
     * @param @return   
     * @return Map<String,Object> 
     * @author Administrator 2016年7月20日 
     * @throws
     */
    public void saveShopOrderCommList(OrderCommAddRequestDto dto) {

        Sub sub = subDao.findOne(dto.getOrderId());
        if (sub == null) {
            throw new WebRequestException("订单不存在");
        }
        UsrDetail userDetail = userService.findUserById(dto.getUserId());
        if (userDetail == null) {
            throw new WebRequestException("用户不存在");
        }
        if (sub.getStatus() == ShopOrderStatusEnum.PADYED.getStatus()) {
            throw new WebRequestException("订单已评价");
        }
        List<OrderCommAddItemDto> orderCommItems = dto.getOrderCommAddItemDto();
        for (OrderCommAddItemDto ordercommItem : orderCommItems) {
            SubItem subItem = subItemDao.findSubItem(sub.getSubNumber(), ordercommItem.getProdId());
            ProdComm prodComm = new ProdComm();
            prodComm.setProdId(subItem.getProdId());
            prodComm.setBasketId(0);
            prodComm.setUserId(userDetail.getUserId());
            prodComm.setUserName(userDetail.getUserName());
            prodComm.setContent(ordercommItem.getCotent());
            prodComm.setAddtime(new Date());
            prodComm.setScore(ordercommItem.getScore().shortValue());
            prodComm.setSubItemId(subItem.getSubItemId());
            prodComm.setPostip("");
            prodComm.setOwnerName("");
            prodComm.setReplayCounts(0);
            prodComm.setUsefulCounts(0);
            prodComm.setCommentBy(userDetail.getNickName());
            int i = 0;
            for (String pic : ordercommItem.getPicList()) {
                i++;
                switch (i) {
                    case 1:
                        prodComm.setPhotoFile1(pic);
                        break;
                    case 2:
                        prodComm.setPhotoFile2(pic);
                        break;
                    case 3:
                        prodComm.setPhotoFile3(pic);
                        break;
                    case 4:
                        prodComm.setPhotoFile4(pic);
                        break;
                    case 5:
                        prodComm.setPhotoFile5(pic);
                        break;
                    case 6:
                        prodComm.setPhotoFile6(pic);
                        break;
                    case 7:
                        prodComm.setPhotoFile7(pic);
                        break;
                    case 8:
                        prodComm.setPhotoFile8(pic);
                        break;
                    case 9:
                        prodComm.setPhotoFile9(pic);
                        break;
                }
            }
            prodCommDao.save(prodComm);
            subItem.setCommSts(1);
            subItemDao.saveAndFlush(subItem);
        }
        // 修改订单状态为已评价
        sub.setUpdateDate(new Date());
        sub.setStatus(ShopOrderStatusEnum.COMMENTED.getStatus());
        subDao.saveAndFlush(sub);
    }

}
