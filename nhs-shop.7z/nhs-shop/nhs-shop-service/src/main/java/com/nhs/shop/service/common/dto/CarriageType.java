package com.nhs.shop.service.common.dto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 运费类型
 * @author wind.chen
 *
 */
public enum CarriageType {

	express("express", "快递"), ems("ems", "ems"), mail("mail", "平邮");
	
	private String code;
	private String desc;
	
	private static List<String> codes;
	private static List<String> descs;
	private static CarriageType[] allTypes;
	
	/**
	 * key code, value = CarriageType
	 */
	private static Map<String, CarriageType> typesMap = new HashMap<String, CarriageType>();
	
	static{
		CarriageType[] types = values();
		allTypes = new CarriageType[types.length];
		codes = new ArrayList<String>();
		descs = new ArrayList<String>();
		for(int i=0 ; i<types.length; i++ ){
			codes.add(types[i].code);
			descs.add(types[i].desc);
			allTypes[i] = types[i];
			typesMap.put(types[i].code, types[i]);
		}
	}
	
	CarriageType() {
	}

	CarriageType(String code, String desc) {
		this.code = code;
		this.desc = desc;
	}

	public String getCode() {
		return code;
	}

	public String getDesc() {
		return desc;
	}
	
	public static CarriageType parse(String code){
		return typesMap.get(code);
	}

	public static List<String> getCodes() {
		return codes;
	}

	public static List<String> getDescs() {
		return descs;
	}

	public static CarriageType[] getAllTypes() {
		return allTypes;
	}
	
}
