package com.nhs.shop.service.order;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.nhs.core.common.NhsConstant;
import com.nhs.core.context.SysPropsFactory;
import com.nhs.core.mapper.JsonMapper;
import com.nhs.core.orm.Page;
import com.nhs.core.utils.common.DateUtils;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.core.utils.security.SignMD5;
import com.nhs.core.web.WebRequestException;
import com.nhs.shop.dao.CommonSqlDao;
import com.nhs.shop.dao.legend.pay.PayRecordDao;
import com.nhs.shop.dao.legend.shop.AdminUserDao;
import com.nhs.shop.dao.legend.shop.ShopDetailDao;
import com.nhs.shop.dao.legend.store.StoreOrderDao;
import com.nhs.shop.dao.legend.store.StoreOrderItemDao;
import com.nhs.shop.dao.legend.store.StoreOrderJdbcDao;
import com.nhs.shop.entry.em.EmSmsType;
import com.nhs.shop.entry.em.order.EmStoreOrderStatus;
import com.nhs.shop.entry.em.order.OrderCodeEnum;
import com.nhs.shop.entry.em.shop.EmRebateStatus;
import com.nhs.shop.entry.em.shop.EmStoreClearStatus;
import com.nhs.shop.entry.legend.pay.PayRecord;
import com.nhs.shop.entry.legend.shop.AdminUser;
import com.nhs.shop.entry.legend.shop.ShopDetail;
import com.nhs.shop.entry.legend.store.StoreOrder;
import com.nhs.shop.entry.legend.store.StoreOrderItem;
import com.nhs.shop.entry.legend.user.UsrDetail;
import com.nhs.shop.generator.OrderNumGenerator;
import com.nhs.shop.service.BaseOrderDto;
import com.nhs.shop.service.BaseOrderService;
import com.nhs.shop.service.order.dto.StoreOrderDto;
import com.nhs.shop.service.order.dto.StoreOrderItemDto;
import com.nhs.shop.service.pay.PayRecordService;
import com.nhs.shop.service.rebate.StoreRebateService;
import com.nhs.shop.service.shop.CalStoreOrderPromotionService;
import com.nhs.shop.service.shop.ShopCommonService;
import com.nhs.shop.service.system.SystemParameterService;
import com.nhs.sms.service.SmsService;
import com.nhs.user.service.MemberService;
import com.nhs.user.service.UserService;

/**
 * 商超订单服务层
 * @Title: StoreOrderService.java
 * @Package com.nhs.shop.service.order
 * @Description: TODO
 * @author huxianjun
 * @date 2016年8月20日 上午10:36:16
 * @version V1.0
 */
@Service
public class StoreOrderService extends BaseOrderService {

    private final Logger logger = LoggerFactory.getLogger(StoreOrderService.class);

    @Autowired
    private CommonSqlDao commonSqlDao;

    @Autowired
    private StoreOrderDao storeOrderDao;

    @Autowired
    private StoreOrderItemDao storeOrderItemDao;

    @Autowired
    private ShopDetailDao shopDetailDao;

    @Autowired
    private MemberService memberService;

    @Autowired
    private StoreRebateService storeRebateService;

    @Autowired
    private SmsService smsService;

    @Autowired
    private PayRecordService payRecordService;

    @Autowired
    private StoreOrderJdbcDao storeOrderJdbcDao;

    @Autowired
    private CalStoreOrderPromotionService calStoreOrderPromotionService;

    @Autowired
    private SystemParameterService sysService;

    @Autowired
    private PayRecordDao payRecordDao;

    @Autowired
    private AdminUserDao adminUserDao;

    // 商品的最高赠送比
    public static final Double rebate_rate_max = 1.0;
    // 商品的最小赠送比
    public static final Double rebate_rate_min = 0.02;

    @Autowired
    private ShopCommonService commonService;

    @Autowired
    private UserService userService;

    private List<StoreOrderItem> dealStoreOrderItem(String itemStr) {
        List list = JsonMapper.nonEmptyMapper().fromJson(itemStr, List.class);
        List<StoreOrderItem> listItem = Lists.newArrayList();
        if (list != null && list.size() > 0) {
            for (int i = 0; i < list.size(); i++) {
                String listStr = JsonMapper.nonEmptyMapper().toJson(list.get(i));
                StoreOrderItem item = JsonMapper.nonEmptyMapper().fromJson(listStr, StoreOrderItem.class);
                listItem.add(item);
            }
        }
        return listItem;
    }

    public Map<String, Object> saveStoreOrder(String ip, Map<String, Object> map, String systemtime, String sign) {
        logger.info("##Start to synchronize store order##");
        BigDecimal ad_basic_fee = BigDecimal.valueOf(0.16);
        Integer shopId = StringHelper.objectToInt(map.get("shopId"), 0);
        String shopName = StringHelper.objectToString(map.get("shopName"), "");
        String userMobile = StringHelper.objectToString(map.get("userMobile"), "");
        String tradeNo = StringHelper.objectToString(map.get("tradeNo"), "");
        String payTypeName = StringHelper.objectToString(map.get("payTypeName"), "超市结算");
        // hxj TODO 增加结算方式（哪划算和商超结算的方式）
        BigDecimal appPayAmount = StringHelper.objectToBigDecimal(map.get("appPayAmount"), "0.0");
        BigDecimal otherPayAmount = StringHelper.objectToBigDecimal(map.get("otherPayAmount"), "0.0");
        String payTime = StringHelper.objectToString(map.get("payTime"), "2016-06-06 12:00:00");
        String createTime = StringHelper.objectToString(map.get("createTime"), "2016-06-06 12:00:00");
        BigDecimal totalAmount = StringHelper.objectToBigDecimal(map.get("totalAmount"), "0.0");
        BigDecimal payAmount = StringHelper.objectToBigDecimal(map.get("payAmount"), "0.0");

        logger.info("##get store order params ==> shopId: " + shopId + " shopName: " + shopName + " userMobile: "
                + userMobile + " tradeNo: " + tradeNo + " payTypeName: " + payTypeName + " appPayAmount: "
                + appPayAmount + " otherPayAmount: " + otherPayAmount + " createTime: " + createTime + " totalAmount: "
                + totalAmount + " payAmount: " + payAmount + " sign: " + sign + "##");

        if (StringUtils.isBlank(userMobile.trim())) {
            // throw new WebRequestException("会员手机号不能为空");
            userMobile = NhsConstant.DEFAULT_STORE_ORDER_USER_MOBILE;
        }
        if (StringUtils.isBlank(tradeNo.trim())) {
            throw new WebRequestException("商超订单编号不能为空");
        }
        if (shopId.intValue() < 0) {
            throw new WebRequestException("商家编号不能为空");
        }
        if (payAmount.compareTo(appPayAmount.add(otherPayAmount)) != 0) {
            throw new WebRequestException("金额参数有误，tradeNo：" + tradeNo);
        }
        ShopDetail shop = shopDetailDao.findOne(shopId);
        if (shop == null) {
            throw new WebRequestException(shopName + "商家不存在");
        } else if (shop.getShopSystem() == null || shop.getShopSystem() != 4) {
            throw new WebRequestException(shopName + "商家不是商超类型");
        }
        UsrDetail shopUser = userService.findUserById(shop.getUserId());// userDetailDao.findUserById(shop.getUserId());
        if (shopUser == null) {
            throw new WebRequestException(shopName + "商家不存在");
        }
        // 验证签名
        StringBuilder stringKey = new StringBuilder("systemtime=");

        stringKey.append(systemtime).append("&key=");
        // 设置key值
        if (StringUtils.isNotBlank(shopUser.getSignKey())) {
            stringKey.append(shopUser.getSignKey());
        } else {
            stringKey.append(shopUser.getUserId().replace("-", ""));
        }

        String mySign = SignMD5.MD5Encode(stringKey.toString(), "UTF-8").toUpperCase();
        if (!mySign.equalsIgnoreCase(sign)) {
            throw new WebRequestException("签名错误");
        }
        logger.info("##验证签名成功##");
        // 返回结果
        Map<String, Object> data = Maps.newHashMap();

        StoreOrder order = storeOrderDao.findStoreOrder(shopId, tradeNo);
        if (order != null) {
            logger.info("##商超订单已经存在##");
            data.put("tradeNo", tradeNo);
            data.put("orderNum", order.getOrderNum());
            data.put("payAmount", order.getPayAmount());
            // 暂时返回0
            data.put("payAdFee", 0.00);
            return data;
            // throw new WebRequestException("商超订单不能重复提交");
        }

        UsrDetail user = userService.findUserByMobile(userMobile);// userDetailDao.findUserDetail(userMobile);
        if (user == null) {
            logger.info("##超市会员不是哪划算会员，默认注册##");
            String password = StringHelper.radomCode(6);
            user = memberService.saveMemberRegister(userMobile, password, "1");
            if (user == null) {
                throw new WebRequestException("注册用户失败！无法同步订单！超市订单号: " + tradeNo);
            }
            user.setUserMobile(userMobile);
            try {
                smsService.saveSendSms(10004, userMobile, password, EmSmsType.VAL.value,
                        new String[] { userMobile, password });
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // 订单号
        String orderNum = OrderNumGenerator.getOrderNumber(user.getUserMobile(), OrderCodeEnum.STORE_ORDER);
        // 保存订单表
        order = new StoreOrder();

        if (appPayAmount.compareTo(new BigDecimal(0.0)) > 0) {
            boolean flag = false;
            // 查询匹配支付记录
            List<PayRecord> payRecordList = payRecordService.getPayRecordListBy(shopId, user.getUserId());
            if (payRecordList != null && payRecordList.size() > 0) {
                for (PayRecord payRecord : payRecordList) {
                    if (appPayAmount.compareTo(payRecord.getTotalMoney()) == 0) {
                        order.setExceptionStatus(0); // 正常订单
                        order.setPayNo(payRecord.getOrderNo()); // 订单记录与支付记录关联
                        payRecord.setMatchState(1); // 更新匹配状态，已匹配
                        order.setCouponAmount(payRecord.getCouponMoney());
                        flag = true;
                        payRecordDao.saveAndFlush(payRecord);
                        break;
                    }
                }
            }
            // 其他情况都是通过app支付但是未找到支付记录，全部设置为异常订单
            if (!flag) {
                order.setExceptionStatus(1); // 异常订单
            }
        } else {
            order.setExceptionStatus(2);
        }

        logger.info("##订单异常状态:##" + order.getExceptionStatus());

        order.setOrderNum(orderNum);
        order.setCreateTime(DateUtils.str2Date(createTime, DateUtils.DEFAULT_FORMAT));
        order.setInputTime(commonSqlDao.dbDate());
        order.setShopId(shopId);
        order.setShopName(shop.getSiteName());
        order.setPayTime(DateUtils.str2Date(payTime, DateUtils.DEFAULT_FORMAT));
        order.setPayTypeName(payTypeName);
        order.setOtherPayAmount(otherPayAmount);
        order.setAppPayAmount(appPayAmount);
        order.setRebateStatus(EmRebateStatus.not_rebate.status);
        order.setStoreClearStatus(EmStoreClearStatus.not_clear.status);
        order.setTradeNo(tradeNo);
        order.setUpdateTime(commonSqlDao.dbDate());
        order.setUserMobile(userMobile);
        order.setUserId(user.getUserId());
        order.setPayAmount(payAmount);
        order.setTotalAmount(totalAmount);
        order.setStatus(EmStoreOrderStatus.PADYED.status);
        order.setDeleteStatus(0);

        BigDecimal orderEffectiveAmount = new BigDecimal("0.00");
        if (order.getExceptionStatus() == 1) {
            // 异常订单 返利时按照其他方式付款金额返利(商品价格超过这部分价格的不返)
            orderEffectiveAmount = order.getOtherPayAmount();
        } else {
            orderEffectiveAmount = order.getPayAmount();
        }

        // 保存订单Item表
        List<StoreOrderItem> items = this.dealStoreOrderItem(JsonMapper.nonEmptyMapper().toJson(map.get("prodList")));
        Collections.sort(items);
        BigDecimal totalSilverNum = new BigDecimal("0.00");
        BigDecimal totalCouponNum = new BigDecimal("0.00");
        BigDecimal totalCouponAmount = order.getCouponAmount();
        Map<String, Object> couponAmoutMap = new HashMap<>();
        couponAmoutMap.put("totalCouponAmount", totalCouponAmount);

        Map<String, Object> calOrderMap = new HashMap<>();
        calOrderMap.put("totalSilverNum", totalSilverNum);
        calOrderMap.put("totalCouponNum", totalCouponNum);
        calOrderMap.put("orderleftEffectiveAmount", orderEffectiveAmount);

        if (items != null && items.size() > 0) {
            for (StoreOrderItem item : items) {
                item.setOrderNum(orderNum);
                item.setUserId(user.getUserId());
                item.setShopId(shopId);
                item.setCreateTime(commonSqlDao.dbDate());

                item.setProdAdFeeBasicRate(ad_basic_fee);

                // 通过app付款的正常订单，有抵用券
                if (order.getExceptionStatus() == 0) {
                    StoreOrderItemDto itemDto = new StoreOrderItemDto();
                    itemDto.setProdTotalPrice(item.getProdAmount().toString());
                    calStoreOrderPromotionService.calStoreOrderProdCouponAmount(itemDto, couponAmoutMap);
                    item.setCouponAmount(new BigDecimal(itemDto.getCouponAmountStr()));
                }

                calStoreOrderPromotionService.calStoreOrderPromotion(item, item.getProdAdFeeRate(),
                        item.getProdAdFeeBasicRate(), calOrderMap);
            }
        }

        order.setGiveSilver(StringHelper.objectToBigDecimal(calOrderMap.get("totalSilverNum"), "0.00"));
        order.setGiveGold(StringHelper.objectToBigDecimal(calOrderMap.get("totalCouponNum"), "0.00"));

        order = storeOrderDao.save(order);

        storeOrderItemDao.save(items);

        data.put("tradeNo", tradeNo);
        data.put("orderNum", orderNum);
        data.put("payAmount", order.getPayAmount());
        // 暂时返回0
        data.put("payAdFee", 0.00);

        logger.info("##同步订单结束，开始清算##");

        // TODO hxj 商超订单先直接结算
        try {
            if (order.getRebateStatus() == null || order.getRebateStatus() == EmRebateStatus.not_rebate.status) {
                storeRebateService.saveRebate(order, new Date());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        logger.info("##清算结束，订单同步成功！##");
        return data;
    }

    /**
     * 获取服务订单列表
     * @Title: getOrderList
     * @Description: TODO
     * @param @param userId
     * @param @param status
     * @param @param page
     * @param @return   
     * @return List<ServiceOrderListDto> 
     * @author Administrator 2016年7月25日 
     * @throws
     */
    public List<StoreOrderDto> getOrderList(String userId, Integer status, Page<Map<String, Object>> page) {
        List<StoreOrderDto> list = Lists.newArrayList();
        if (StringUtils.isBlank(userId)) {
            return list;
        }
        Page<Map<String, Object>> pageData = storeOrderJdbcDao.getOrderList(userId, status, page);
        List<Map<String, Object>> result = pageData.getResult();
        for (Map<String, Object> map : result) {
            StoreOrderDto dto = new StoreOrderDto();
            dto.setOrderId(StringHelper.objectToInt(map.get("id"), 0));
            dto.setOrderNum(StringHelper.objectToString(map.get("order_num"), ""));
            dto.setShopId(StringHelper.objectToInt(map.get("shop_id"), 0));
            ShopDetail shop = shopDetailDao.findOne(dto.getShopId());
            if (shop != null) {
                dto.setPic(buildImg(shop.getShopPic2()));
                dto.setShopName(shop.getSiteName());
                dto.setAddress(shop.getShopAddr());
            } else {
                shop = new ShopDetail();
            }
            BigDecimal totalmount = StringHelper.objectToBigDecimal(map.get("total_amount"), "0.00").setScale(2,
                    BigDecimal.ROUND_DOWN);
            dto.setTotalAmountStr(totalmount.toString());
            dto.setStatus(StringHelper.objectToInt(map.get("status"), 0));
            dto.setStatusName(EmStoreOrderStatus.desc(dto.getStatus()));
            dto.setCreateTime(DateUtils.date2Str((Date) map.get("create_time")));
            dto.setCoupon(SysPropsFactory.getProperty(NhsConstant.SYS_COUPON_LABEL));
            BigDecimal totalAdFee = storeOrderItemDao.getTotalProdAdFee(dto.getOrderNum());
            dto.setTotalProdAdFee(totalAdFee == null ? "0.00" : totalAdFee.toString());
            dto.setGiveSilver(StringHelper.objectToBigDecimal(map.get("give_silver"), "0.00")
                    .setScale(2, BigDecimal.ROUND_DOWN).toString());
            dto.setTradeNo(StringHelper.objectToString(map.get("trade_no"), ""));
            long orderProdNum = storeOrderItemDao.countByOrderNum(dto.getOrderNum());
            dto.setContainsProdNum(orderProdNum);
            list.add(dto);
        }
        return list;
    }

    /**
     * 获取服务订单列表
     * @Title: getOrderList
     * @Description: TODO
     * @param @param userId
     * @param @param status
     * @param @param page
     * @param @return   
     * @return List<ServiceOrderListDto> 
     * @author Administrator 2016年7月25日 
     * @throws
     */
    public List<StoreOrderDto> getOrderPcList(String userId, Integer status, String startTime, String endTime,
            String orderNum, String tradeNo, int type, Page<Map<String, Object>> page) {
        List<StoreOrderDto> list = Lists.newArrayList();
        if (StringUtils.isBlank(userId)) {
            return list;
        }
        AdminUser adminUser = adminUserDao.findOne(userId);
        Page<Map<String, Object>> pageData = null;
        if (adminUser != null) {
            // 管理员查出所有
            userId = "";
            type = 0;
        }
        Integer shopId = 0;
        if (type != 0) {
            ShopDetail shop = shopDetailDao.findShopDetail(userId);
            if (shop != null) {
                shopId = shop.getShopId();
            }
        }

        pageData = storeOrderJdbcDao.getOrderListPC(userId, status, startTime, endTime, orderNum, tradeNo, shopId,
                page);

        List<Map<String, Object>> result = pageData.getResult();
        for (Map<String, Object> map : result) {
            StoreOrderDto dto = new StoreOrderDto();
            dto.setOrderId(StringHelper.objectToInt(map.get("id"), 0));
            dto.setOrderNum(StringHelper.objectToString(map.get("order_num"), ""));
            dto.setShopId(StringHelper.objectToInt(map.get("shop_id"), 0));
            ShopDetail shop = shopDetailDao.findOne(dto.getShopId());
            if (shop != null) {
                dto.setPic(buildImg(shop.getShopPic2()));
                dto.setShopName(shop.getSiteName());
                dto.setAddress(shop.getShopAddr());
            } else {
                shop = new ShopDetail();
            }
            BigDecimal totalmount = StringHelper.objectToBigDecimal(map.get("total_amount"), "0.00").setScale(2,
                    BigDecimal.ROUND_DOWN);
            dto.setTotalAmountStr(totalmount.toString());
            dto.setStatus(StringHelper.objectToInt(map.get("status"), 0));
            dto.setStatusName(EmStoreOrderStatus.desc(dto.getStatus()));
            dto.setCreateTime(DateUtils.date2Str((Date) map.get("create_time")));
            dto.setPayTime(DateUtils.date2Str((Date) map.get("pay_time")));
            dto.setCoupon(SysPropsFactory.getProperty(NhsConstant.SYS_COUPON_LABEL));
            BigDecimal totalAdFee = storeOrderItemDao.getTotalProdAdFee(dto.getOrderNum());
            dto.setTotalProdAdFee(totalAdFee == null ? "0.00" : totalAdFee.toString());
            dto.setGiveSilver(StringHelper.objectToBigDecimal(map.get("give_silver"), "0.00")
                    .setScale(2, BigDecimal.ROUND_DOWN).toString());
            if (commonService.isShopReturn(dto.getShopId())) {
                dto.setShopGiveSilver(new BigDecimal(dto.getTotalProdAdFee()).multiply(new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE))
                        .setScale(2, BigDecimal.ROUND_DOWN).toString());
            }
            dto.setTradeNo(StringHelper.objectToString(map.get("trade_no"), ""));
            long orderProdNum = storeOrderItemDao.countByOrderNum(dto.getOrderNum());
            dto.setContainsProdNum(orderProdNum);
            list.add(dto);
        }
        return list;
    }

    /**
     * 获取订单详情
     * @Title: getOrderList
     * @Description: TODO
     * @param @param userId
     * @param @param status
     * @param @param page
     * @param @return   
     * @return List<OrderListDto> 
     * @author Administrator 2016年7月20日 
     * @throws
     */
    public StoreOrderDto getOrderDetail(String userId, Integer orderId) {
        StoreOrder storeOrder = storeOrderDao.findOne(orderId);
        if (storeOrder == null) {
            throw new WebRequestException("订单不存在");
        }
        StoreOrderDto dto = new StoreOrderDto();
        dto.setOrderId(storeOrder.getId());
        dto.setShopId(storeOrder.getShopId());
        dto.setShopName(storeOrder.getShopName());
        dto.setStatus(storeOrder.getStatus());
        dto.setStatusName(EmStoreOrderStatus.desc(dto.getStatus()));
        long orderProdNum = storeOrderItemDao.countByOrderNum(storeOrder.getOrderNum());
        dto.setContainsProdNum(orderProdNum);
        dto.setTotalAmountStr(storeOrder.getTotalAmount().toString());
        dto.setPayAmountStr(storeOrder.getPayAmount().toString());
        dto.setAppPayAmountStr(storeOrder.getAppPayAmount().toString());
        dto.setOtherPayAmountStr(storeOrder.getOtherPayAmount().toString());
        dto.setCreateTime(DateUtils.date2Str(storeOrder.getCreateTime()));
        dto.setOrderNum(storeOrder.getOrderNum());
        dto.setPayTime(DateUtils.date2Str(storeOrder.getPayTime()));
        dto.setExcetpionStatus(storeOrder.getExceptionStatus());
        dto.setCouponAmount(storeOrder.getCouponAmount().toString());
        dto.setGiveGold(storeOrder.getGiveSilver().toString());
        dto.setGiveSilver(storeOrder.getGiveSilver().toString());
        dto.setTradeNo(storeOrder.getTradeNo());
        if (storeOrder.getExceptionStatus() == 1) {
            // 异常订单 返利时按照其他方式付款金额返利(商品价格超过这部分价格的不返)
            dto.setOrderEffectiveAmount(storeOrder.getOtherPayAmount());
        } else {
            dto.setOrderEffectiveAmount(storeOrder.getPayAmount());
        }
        ShopDetail shop = shopDetailDao.findOne(dto.getShopId());
        if (shop != null) {
            dto.setPic(buildImg(shop.getShopPic2()));
            dto.setShopName(shop.getSiteName());
            dto.setAddress(shop.getShopAddr());
        } else {
            shop = new ShopDetail();
        }
        dto.setCoupon(SysPropsFactory.getProperty(NhsConstant.SYS_COUPON_LABEL));

        // 订单明细
        List<StoreOrderItem> storeOrderItemList = storeOrderItemDao.findStoreOrderItem(storeOrder.getOrderNum());

        for (StoreOrderItem item : storeOrderItemList) {
            StoreOrderItemDto itemDto = new StoreOrderItemDto();
            itemDto.setProdNo(item.getProdNo());
            itemDto.setProdName(item.getProdName());
            itemDto.setProdPrimePrice(item.getProdPrimePrice().toString());
            itemDto.setProdSalePrice(item.getProdSalePrice().toString());
            itemDto.setProdTotalPrice(item.getProdAmount().toString());
            itemDto.setProdNum(item.getProdNum());
            itemDto.setGiveGold(item.getGiveGold().toString());
            itemDto.setGiveSilver(item.getGiveSilver().toString());
            itemDto.setProdAdFeeRate(item.getProdAdFeeRate());
            itemDto.setProdAdFeeRateStr(item.getProdAdFeeRate().toString());
            itemDto.setProdAdFee(item.getProdAmount().multiply(item.getProdAdFeeRate())
                    .setScale(2, BigDecimal.ROUND_DOWN).toString());
            if (commonService.isShopReturn(dto.getShopId())) {
                itemDto.setShopGiveSilver(new BigDecimal(itemDto.getProdAdFee()).multiply(new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE))
                        .setScale(2, BigDecimal.ROUND_DOWN).toString());
            }
            // calStoreOrderPromotionService.calStoreOrderPromotion(itemDto, item.getProdAdFeeRate(),
            // item.getProdAdFeeBasicRate(), totalSilverNum, totalCouponNum, dto.getOrderEffectiveAmount());
            dto.addStoreOrderItemDto(itemDto);
        }

        String couponFont = dto.getCoupon() + storeOrder.getGiveSilver().toString()
                + sysService.getSingleValueByType(NhsConstant.PARAM_SILVER_NAME) + "    "
                + storeOrder.getGiveGold().toString() + sysService.getSingleValueByType(NhsConstant.PARAM_GOLD_NAME);

        dto.setCouponStr(couponFont);

        return dto;
    }

    /**
     * 订单导出excel
     * @param userId
     * @param status
     * @param startTime
     * @param endTime
     * @param orderNum
     * @param tradeNo
     * @param type
     * @author shushu 2016年11月28日
     * @return
     */
    public List<Map<String, Object>> getOrderPcList(String userId, Integer status, String startTime, String endTime,
            String orderNum, String tradeNo, int type) {
        if (StringUtils.isBlank(userId)) {
            return null;
        }
        AdminUser adminUser = adminUserDao.findOne(userId);
        Page<Map<String, Object>> pageData = null;
        if (adminUser != null) {
            // 管理员查出所有
            userId = "";
            type = 0;
        }
        Integer shopId = 0;
        if (type != 0) {
            ShopDetail shop = shopDetailDao.findShopDetail(userId);
            if (shop != null) {
                shopId = shop.getShopId();
            }
        }

        List<Map<String, Object>> result = storeOrderJdbcDao.getOrderListForExcel(userId, status, startTime, endTime,
                orderNum, tradeNo, shopId);
        return result;
    }

    /**
    * 获取订单的总推广费
    * @param orderNum
    * @return
    */
    public BigDecimal getOrderAdFee(String orderNum) {
        BigDecimal totalAdFee = storeOrderItemDao.getTotalProdAdFee(orderNum);
        return totalAdFee;
    }

    /**
     * 删除订单
     * @Title: delete
     * @Description: TODO
     * @param @param sub   
     * @return void 
     * @author Administrator 2016年7月22日 
     * @throws
     */
    public void delete(int orderId) {
        StoreOrder storeOrder = storeOrderDao.findOne(orderId);
        if (storeOrder != null) {
            storeOrder.setDeleteStatus(1);
            storeOrderDao.saveAndFlush(storeOrder);
        }
    }

    @Override
    public void handleOrderPay(String orderNum, String payAmount, String payTypeName, int payType, String payNo) {
        // TODO Auto-generated method stub

    }

    @Override
    public double getOrderPayAmount(String orderNum) {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public void verifyOrder(String userId, String orderNum) {
        // TODO Auto-generated method stub

    }

    @Override
    public BaseOrderDto getBaseOrderDto(String orderNum) {
        List<StoreOrderItem> ls = storeOrderItemDao.findStoreOrderItem(orderNum);
        if (ls != null && ls.size() > 0) {
            StoreOrderItem sot = ls.get(0);
            BaseOrderDto baseOrderDto = new BaseOrderDto();
            baseOrderDto.setOrderNum(orderNum);
            baseOrderDto.setUserId(sot.getUserId());
            return baseOrderDto;
        }
        return null;
    }

}
