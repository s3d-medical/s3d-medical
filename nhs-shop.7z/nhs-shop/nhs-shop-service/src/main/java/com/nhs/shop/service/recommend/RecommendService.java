package com.nhs.shop.service.recommend;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.nhs.core.common.NhsConstant;
import com.nhs.core.context.SysPropsFactory;
import com.nhs.core.utils.common.ArithUtils;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.shop.dao.legend.recommend.VitLogDao;
import com.nhs.shop.dao.legend.region.CityDao;
import com.nhs.shop.dao.legend.shop.ProdDao;
import com.nhs.shop.dao.legend.shop.ShopDetailDao;
import com.nhs.shop.entry.legend.region.City;
import com.nhs.shop.entry.legend.shop.Prod;
import com.nhs.shop.entry.legend.shop.ShopDetail;
import com.nhs.shop.entry.legend.shop.VitLog;
import com.nhs.shop.service.BaseService;
import com.nhs.shop.service.goods.GoodsPromoService;
import com.nhs.shop.service.goods.GoodsService;
import com.nhs.shop.service.goods.GoodsTagsService;
import com.nhs.shop.service.goods.dto.GoodsTagDto;
import com.nhs.shop.service.recommend.dto.VitLogDto;
import com.nhs.shop.service.system.SystemParameterService;

/**
 * 
 * @Title: RecommendService.java
 * @Package com.nhs.shop.service.recommend
 * @Description: TODO
 * @author Administrator
 * @date 2016年8月23日 下午5:39:16
 * @version V1.0
 */
@Service
public class RecommendService extends BaseService {

    @Autowired
    private VitLogDao vitLogDao;

    @Autowired
    private ProdDao prodDao;

    @Autowired
    private ShopDetailDao shopDetailDao;

    @Autowired
    private GoodsService goodsService;

    @Autowired
    private CityDao cityDao;

    @Autowired
    private SystemParameterService sysService;

    @Autowired
    private GoodsTagsService goodsTagsService;
    
    @Autowired
    private GoodsPromoService goodPromotionService;
    
    @Deprecated
    public List<VitLogDto> getHistoryPage(String userid, int pageNo, int pageSize) {
        PageRequest request = new PageRequest(pageNo - 1, pageSize,
                new Sort(new Sort.Order(Sort.Direction.DESC, "recDate")));
        List<VitLogDto> list = Lists.newArrayList();
        VitLogDto vitLogDto = null;
        Page<VitLog> page = vitLogDao.findVitLogByuserId(userid, request);
        for (VitLog vdt : page.getContent()) {
            vitLogDto = new VitLogDto();
            vitLogDto.setVisitId(vdt.getVisitId());
            vitLogDto.setUserName(vdt.getUserName());
            vitLogDto.setShopName(vdt.getShopName());
            vitLogDto.setRecDate((Date) vdt.getRecDate());
            vitLogDto.setVisitNum(vdt.getVisitNum());
            vitLogDto.setProdId(StringHelper.objectToInt(vdt.getProductId(), 0));
            if (vdt.getProductId() == null) {
                continue;
            }
            Prod prop = prodDao.findOne(StringHelper.objectToInt(vdt.getProductId(), 0));
            if (prop == null) {
                continue;
            }

            ShopDetail shopDetail = shopDetailDao.findOne(prop.getShopId());
            if (shopDetail != null && shopDetail.getCityid() != null) {
                City city = cityDao.findOne(shopDetail.getCityid());
                vitLogDto.setShopaddr(city.getCity());
            }
            if (StringUtils.isBlank(vdt.getIsCar())) {

                vitLogDto.setProdIdurl(SysPropsFactory.getProperty("goodsDetailUrl") + vdt.getProductId());
            } else {
                vitLogDto.setProdIdurl(SysPropsFactory.getProperty("carDetailUrl") + vdt.getProductId());
            }
            vitLogDto.setProdName(vdt.getProductName());
            if (prop != null) {
                // TODO liangdanhua 获取真实运费
                vitLogDto.setMailStatus(goodsService.calculatePostage(vdt.getProductId(), vdt.getUserId()));
                double rebate = StringHelper.objectToDouble(prop.getRebate(), 1.0);
                double cashdouble;
                if (prop.getCash() == null) {
                    cashdouble = 0;
                } else {
                    cashdouble = prop.getCash().doubleValue();
                }
                if (cashdouble >= 10000) {
                    BigDecimal cash = (prop.getCash().divide(new BigDecimal(10000)).setScale(2, BigDecimal.ROUND_DOWN));
                    vitLogDto.setCash(cash.toString());
                    vitLogDto.setLg("万");
                    vitLogDto.setRebate(
                            new BigDecimal(ArithUtils.mul(StringHelper.objectToDouble(cash.doubleValue(), 0.0), rebate))
                                    .setScale(2, BigDecimal.ROUND_DOWN).toString());
                    if (StringUtils.isBlank(vdt.getIsCar())) {
                        vitLogDto.setSubsidyStr(sysService.getSingleValueByType(NhsConstant.PARAM_PRESENT_SIGN)
                                + sysService.getSingleValueByType(NhsConstant.PARAM_RMB_ICON) + vitLogDto.getRebate());
                    }

                } else {
                    vitLogDto.setCash((prop.getCash().setScale(2, BigDecimal.ROUND_DOWN)).toString());
                    vitLogDto.setLg("");
                    vitLogDto.setRebate(new BigDecimal(
                            ArithUtils.mul(StringHelper.objectToDouble(prop.getCash().doubleValue(), 0.0), rebate))
                                    .setScale(2, BigDecimal.ROUND_DOWN).toString());

                    vitLogDto.setSubsidyStr(sysService.getSingleValueByType(NhsConstant.PARAM_PRESENT_SIGN)
                            + sysService.getSingleValueByType(NhsConstant.PARAM_RMB_ICON) + vitLogDto.getRebate());
                }
                if (StringUtils.isNotBlank(vdt.getIsCar())) {
                    vitLogDto.setLg("万起");
                }
                vitLogDto.setBuys(prop.getBuys());
                vitLogDto.setPic(buildImg(prop.getPic()));
                vitLogDto.setProdName(prop.getName());
                list.add(vitLogDto);
            }
        }
        return list;
    }
    
    public List<VitLogDto> getBrowsedProds(String userid, int pageNo, int pageSize) {
        PageRequest request = new PageRequest(pageNo - 1, pageSize,
                new Sort(new Sort.Order(Sort.Direction.DESC, "recDate")));
        List<VitLogDto> list = Lists.newArrayList();
        VitLogDto vitLogDto = null;
        Page<VitLog> page = vitLogDao.findVitLogByuserId(userid, request);
        for (VitLog vdt : page.getContent()) {
            vitLogDto = new VitLogDto();
            vitLogDto.setVisitId(vdt.getVisitId());
            vitLogDto.setUserName(vdt.getUserName());
            vitLogDto.setShopName(vdt.getShopName());
            vitLogDto.setRecDate((Date) vdt.getRecDate());
            vitLogDto.setVisitNum(vdt.getVisitNum());
            vitLogDto.setProdId(StringHelper.objectToInt(vdt.getProductId(), 0));
            if (vdt.getProductId() == null) {
                continue;
            }
            Prod prop = prodDao.findOne(StringHelper.objectToInt(vdt.getProductId(), 0));
            if (prop == null) {
                continue;
            }
            ShopDetail shopDetail = shopDetailDao.findOne(prop.getShopId());
            if (shopDetail != null && shopDetail.getCityid() != null) {
                City city = cityDao.findOne(shopDetail.getCityid());
                if(city == null){
                	vitLogDto.setShopaddr("");
                }else{
                	vitLogDto.setShopaddr(city.getCity());
                }
            }  
            if (StringUtils.isBlank(vdt.getIsCar())) {
                vitLogDto.setProdIdurl(SysPropsFactory.getProperty("goodsDetailUrl") + vdt.getProductId());
            } else {
                vitLogDto.setProdIdurl(SysPropsFactory.getProperty("carDetailUrl") + vdt.getProductId());
            }
            vitLogDto.setProdName(vdt.getProductName());
            
            if (prop != null) {
            	// rebate
                BigDecimal rebate = this.goodPromotionService.getBRebate(prop, 2);
                vitLogDto.setRebate(rebate.toString());
                // cash
                BigDecimal cash = (prop.getCash() == null? new BigDecimal("0.00"): prop.getCash());
                if (StringUtils.isNotBlank(vdt.getIsCar()) && cash.intValue()>= 10000) {
                		BigDecimal adjustCash = (cash.divide(new BigDecimal(10000)).setScale(2, BigDecimal.ROUND_DOWN));
                        vitLogDto.setCash(adjustCash.toString());
                        vitLogDto.setLg("万起");
                } else {
                    vitLogDto.setCash((cash.setScale(2, BigDecimal.ROUND_DOWN)).toString());
                    vitLogDto.setLg("");
                }
                // tag
                GoodsTagDto tag = this.goodsTagsService.getProdDimTag(prop, userid);
                vitLogDto.setSubsidyStr(tag.getSubsidyTag());
                vitLogDto.setMailStatus(tag.getPostageDesc());
                vitLogDto.setReducedCashTag(tag.getReducedCashTag());
                
                vitLogDto.setBuys(prop.getBuys());
                vitLogDto.setPic(buildImg(prop.getPic()));
                vitLogDto.setProdName(prop.getName());
                list.add(vitLogDto);
            }
        }
        return list;
    }
    
    public void delete(Integer visitId) {
        VitLog vitLog = vitLogDao.findOne(visitId);
        if (vitLog != null) {
            vitLogDao.delete(visitId);
        }
    }
}
