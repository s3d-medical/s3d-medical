package com.nhs.shop.service.comment.dto;

import java.io.Serializable;
import java.util.List;

import com.google.common.collect.Lists;

/**
 * 评论DTO
 * @Title: CommentDto.java
 * @Package com.nhs.shop.service.comment
 * @Description: TODO
 * @author Administrator
 * @date 2016年7月17日 下午4:43:50
 * @version V1.0
 */
public class CommentDto implements Serializable {

    private static final long serialVersionUID = 7530532876062076152L;

    private int totalNum;
    private int goodNum;
    private int mediunNum;
    private int badNum;
    private int photoNum;
    private List<CommentDetailDto> commentList = Lists.newArrayList();

    public int getTotalNum() {
        return totalNum;
    }

    public void setTotalNum(int totalNum) {
        this.totalNum = totalNum;
    }

    public int getGoodNum() {
        return goodNum;
    }

    public void setGoodNum(int goodNum) {
        this.goodNum = goodNum;
    }

    public int getMediunNum() {
        return mediunNum;
    }

    public void setMediunNum(int mediunNum) {
        this.mediunNum = mediunNum;
    }

    public int getBadNum() {
        return badNum;
    }

    public void setBadNum(int badNum) {
        this.badNum = badNum;
    }

    public int getPhotoNum() {
        return photoNum;
    }

    public void setPhotoNum(int photoNum) {
        this.photoNum = photoNum;
    }

    public List<CommentDetailDto> getCommentList() {
        return commentList;
    }

    public void setCommentList(List<CommentDetailDto> commentList) {
        this.commentList = commentList;
    }

    // 评论详情
    public static class CommentDetailDto implements Serializable {
        private static final long serialVersionUID = -3850570130084786048L;
        private String commentId = "";
        private String userId = "";
        private String nickname = "";
        private String avatar = "";
        private String content = "";
        private String commentDate = "";
        private int score;
        private List<String> images = Lists.newArrayList();
        private String color = "";
        private String type = "";
        private String buyTime = "";
        private String islike = "0";
        private String totallike = "";
        private String prodName = "";
        private String skuName = "";
        private String skuPerproties = "";
        private String prodTitle = "";
        private String prodUrl = "";

        public String getProdTitle() {
            return prodTitle;
        }

        public void setProdTitle(String prodTitle) {
            this.prodTitle = prodTitle;
        }

        public String getProdUrl() {
            return prodUrl;
        }

        public void setProdUrl(String prodUrl) {
            this.prodUrl = prodUrl;
        }

        public String getSkuPerproties() {
            return skuPerproties;
        }

        public void setSkuPerproties(String skuPerproties) {
            this.skuPerproties = skuPerproties;
        }

        public String getSkuName() {
            return skuName;
        }

        public void setSkuName(String skuName) {
            this.skuName = skuName;
        }

        public String getProdName() {
            return prodName;
        }

        public void setProdName(String prodName) {
            this.prodName = prodName;
        }

        public String getCommentId() {
            return commentId;
        }

        public void setCommentId(String commentId) {
            this.commentId = commentId;
        }

        public String getIslike() {
            return islike;
        }

        public void setIslike(String islike) {
            this.islike = islike;
        }

        public String getTotallike() {
            return totallike;
        }

        public void setTotallike(String totallike) {
            this.totallike = totallike;
        }

        public String getUserId() {
            return userId;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public String getNickname() {
            return nickname;
        }

        public void setNickname(String nickname) {
            this.nickname = nickname;
        }

        public String getAvatar() {
            return avatar;
        }

        public void setAvatar(String avatar) {
            this.avatar = avatar;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }

        public String getCommentDate() {
            return commentDate;
        }

        public void setCommentDate(String commentDate) {
            this.commentDate = commentDate;
        }

        public int getScore() {
            return score;
        }

        public void setScore(int score) {
            this.score = score;
        }

        public List<String> getImages() {
            return images;
        }

        public void setImages(List<String> images) {
            this.images = images;
        }

        public String getColor() {
            return color;
        }

        public void setColor(String color) {
            this.color = color;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getBuyTime() {
            return buyTime;
        }

        public void setBuyTime(String buyTime) {
            this.buyTime = buyTime;
        }

    }
}
