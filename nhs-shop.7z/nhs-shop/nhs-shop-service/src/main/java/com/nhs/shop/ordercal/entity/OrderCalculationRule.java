package com.nhs.shop.ordercal.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="nhs_order_calculation_rule")
public class OrderCalculationRule  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	@Id
    @GeneratedValue
    @Column(name = "id")
	private Integer id;
	
	
	@Column(name="order_num")
	private String orderNum;
	
	/**
	 * 记录新规则类型，适用于支付回调走哪套规则，暂时记录版本号
	 */
	@Column(name="rule_type")
	private String ruleType;
	
	
	@Column(name="order_type")
	private String orderType;


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public String getOrderNum() {
		return orderNum;
	}


	public void setOrderNum(String orderNum) {
		this.orderNum = orderNum;
	}


	public String getRuleType() {
		return ruleType;
	}


	public void setRuleType(String ruleType) {
		this.ruleType = ruleType;
	}


	public String getOrderType() {
		return orderType;
	}


	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	
	
	

}
