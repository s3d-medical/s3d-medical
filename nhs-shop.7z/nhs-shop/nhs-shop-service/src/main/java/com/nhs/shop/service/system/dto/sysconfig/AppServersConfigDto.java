package com.nhs.shop.service.system.dto.sysconfig;

import java.io.Serializable;

/**
 * app连接的服务器列表. 
 * @author wind.chen
 */
public class AppServersConfigDto implements Serializable {

	private static final long serialVersionUID = -6698437767342850136L;
	private String hostApi;
	private String hostPay;
	private String hostMember;
	private String hostSearch;
	private String hostH5;
	private String hostImg;
	
	public String getHostApi() {
		return hostApi;
	}
	public void setHostApi(String hostApi) {
		this.hostApi = hostApi;
	}
	public String getHostPay() {
		return hostPay;
	}
	public void setHostPay(String hostPay) {
		this.hostPay = hostPay;
	}
	public String getHostMember() {
		return hostMember;
	}
	public void setHostMember(String hostMember) {
		this.hostMember = hostMember;
	}
	public String getHostSearch() {
		return hostSearch;
	}
	public void setHostSearch(String hostSearch) {
		this.hostSearch = hostSearch;
	}
	public String getHostH5() {
		return hostH5;
	}
	public void setHostH5(String hostH5) {
		this.hostH5 = hostH5;
	}
	public String getHostImg() {
		return hostImg;
	}
	public void setHostImg(String hostImg) {
		this.hostImg = hostImg;
	}
	
}
