package com.nhs.shop.service.shop.dto;

import java.io.Serializable;

/**
 * 附近商家 dto
 * @Title: ShopDto.java
 * @Package com.nhs.shop.service.home.dto
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月16日 下午5:32:07
 * @version V1.0
 */
public class ShopDto implements Serializable {

    private static final long serialVersionUID = 3291824330308840760L;

    private Integer shopId = 0;
    private String shopTitle = "";
    private Integer starNum = 0;
    private String address = "";
    private Double distance = 0.00;
    private String distanceWithUnit = "";
    private String pic = "";
    private Integer consumePer = 0;
    private String category = "";
    private String area = "";
    private String mobile = "";
    private Double tasteScore = 0.0;
    private Double envScore = 0.0;
    private Double serviceScore = 0.0;
    private String subsidy = "";
    private Double lat = 0.0;
    private Double lng = 0.0;
    private String linearMeasure = "";
    private String contactTel = "";
    private String totalOrderNum = "";
    private int categoryId;
    private String average;
    private String subsidyStr;
    private String reduce;
    private String discount;
    private String coupon;
    private String discountStr;
    private String couponStr;
    private String shopDiscount;
    private String shopDiscountStr;
    private String shopDiscountRate;

    public String getLinearMeasure() {
        return linearMeasure;
    }

    public void setLinearMeasure(String linearMeasure) {
        this.linearMeasure = linearMeasure;
    }

    public Integer getShopId() {
        return shopId;
    }

    public void setShopId(Integer shopId) {
        this.shopId = shopId;
    }

    public String getShopTitle() {
        return shopTitle;
    }

    public void setShopTitle(String shopTitle) {
        this.shopTitle = shopTitle;
    }

    public Integer getStarNum() {
        return starNum;
    }

    public void setStarNum(Integer starNum) {
        this.starNum = starNum;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Double getDistance() {
        return distance;
    }

    public void setDistance(Double distance) {
        this.distance = distance;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public Integer getConsumePer() {
        return consumePer;
    }

    public void setConsumePer(Integer consumePer) {
        this.consumePer = consumePer;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public Double getTasteScore() {
        return tasteScore;
    }

    public void setTasteScore(Double tasteScore) {
        this.tasteScore = tasteScore;
    }

    public Double getEnvScore() {
        return envScore;
    }

    public void setEnvScore(Double envScore) {
        this.envScore = envScore;
    }

    public Double getServiceScore() {
        return serviceScore;
    }

    public void setServiceScore(Double serviceScore) {
        this.serviceScore = serviceScore;
    }

    public String getSubsidy() {
        return subsidy;
    }

    public void setSubsidy(String subsidy) {
        this.subsidy = subsidy;
    }

    public Double getLat() {
        return lat;
    }

    public void setLat(Double lat) {
        this.lat = lat;
    }

    public Double getLng() {
        return lng;
    }

    public void setLng(Double lng) {
        this.lng = lng;
    }

    public String getDistanceWithUnit() {
        return distanceWithUnit;
    }

    public void setDistanceWithUnit(String distanceWithUnit) {
        this.distanceWithUnit = distanceWithUnit;
    }

    public String getContactTel() {
        return contactTel;
    }
    public void setContactTel(String contactTel) {
        this.contactTel = contactTel;
    }

    public String getTotalOrderNum() {
        return totalOrderNum;
    }

    public void setTotalOrderNum(String totalOrderNum) {
        this.totalOrderNum = totalOrderNum;
    }

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public String getAverage() {
		return average;
	}

	public void setAverage(String average) {
		this.average = average;
	}

	public String getSubsidyStr() {
		return subsidyStr;
	}

	public void setSubsidyStr(String subsidyStr) {
		this.subsidyStr = subsidyStr;
	}

	public String getReduce() {
		return reduce;
	}

	public void setReduce(String reduce) {
		this.reduce = reduce;
	}

	public String getDiscount() {
		return discount;
	}

	public void setDiscount(String discount) {
		this.discount = discount;
	}

	public String getCoupon() {
		return coupon;
	}

	public void setCoupon(String coupon) {
		this.coupon = coupon;
	}

	public String getDiscountStr() {
		return discountStr;
	}

	public void setDiscountStr(String discountStr) {
		this.discountStr = discountStr;
	}

	public String getCouponStr() {
		return couponStr;
	}

	public void setCouponStr(String couponStr) {
		this.couponStr = couponStr;
	}

	public String getShopDiscount() {
		return shopDiscount;
	}

	public void setShopDiscount(String shopDiscount) {
		this.shopDiscount = shopDiscount;
	}

	public String getShopDiscountStr() {
		return shopDiscountStr;
	}

	public void setShopDiscountStr(String shopDiscountStr) {
		this.shopDiscountStr = shopDiscountStr;
	}

	public String getShopDiscountRate() {
		return shopDiscountRate;
	}

	public void setShopDiscountRate(String shopDiscountRate) {
		this.shopDiscountRate = shopDiscountRate;
	}

    
}
