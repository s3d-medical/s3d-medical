package com.nhs.shop.service.shop.dto;

import java.io.Serializable;
import java.util.List;

import com.google.common.collect.Lists;
import com.nhs.shop.entry.legend.banner.Banner;
import com.nhs.shop.service.category.dto.O2oHotCategoryDto;

public class NearbyShopDto implements Serializable {

    private static final long serialVersionUID = -8028431855629375699L;
    private List<O2oCategoryDto> categoryList = Lists.newArrayList();
    private List<ShopDto> shopList = Lists.newArrayList();
    List<Banner> bannerList = Lists.newArrayList();
    List<O2oHotCategoryDto> o2oHotCategoryConfigList = Lists.newArrayList();

    public List<Banner> getBannerList() {
        return bannerList;
    }

    public void setBannerList(List<Banner> bannerList) {
        this.bannerList = bannerList;
    }

    public List<O2oHotCategoryDto> getO2oHotCategoryConfigList() {
        return o2oHotCategoryConfigList;
    }

    public void setO2oHotCategoryConfigList(List<O2oHotCategoryDto> o2oHotCategoryConfigList) {
        this.o2oHotCategoryConfigList = o2oHotCategoryConfigList;
    }

    public List<O2oCategoryDto> getCategoryList() {
        return categoryList;
    }

    public void setCategoryList(List<O2oCategoryDto> categoryList) {
        this.categoryList = categoryList;
    }

    public void addO2oCategoryDto(O2oCategoryDto dto) {
        this.categoryList.add(dto);
    }

    public List<ShopDto> getShopList() {
        return shopList;
    }

    public void setShopList(List<ShopDto> shopList) {
        this.shopList = shopList;
    }

    public void addShopDto(ShopDto dto) {
        this.shopList.add(dto);
    }

    public static class O2oCategoryDto implements Serializable {
        private static final long serialVersionUID = -2383364036378483437L;
        private Integer categoryId;
        private String name;
        private String icon;

        public Integer getCategoryId() {
            return categoryId;
        }

        public void setCategoryId(Integer categoryId) {
            this.categoryId = categoryId;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getIcon() {
            return icon;
        }

        public void setIcon(String icon) {
            this.icon = icon;
        }

    }
}
