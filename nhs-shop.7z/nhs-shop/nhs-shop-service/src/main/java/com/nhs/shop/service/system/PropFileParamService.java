package com.nhs.shop.service.system;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * 读取配置文件参数服务. 
 * @author wind.chen
 */
@Service
public class PropFileParamService {

    /**
     * 支付成功后, 回调处理订单 
     */
    private String ckUrlOfHandlePayedOrder;

    /**
     * 支付后， 第3方系统redirect到nahuasuan的地址
     */
    private String rdUrlAfterPay;
    /**
     * 访问api
     */
	private String hostApi;
	/**
	 * 访问支付
	 */
	private String hostPay;
	/**
	 * 访问member
	 */
	private String hostMember;
	/**
	 * 访问search
	 */
	private String hostSearch;
	/**
	 * 访问h5.
	 */
	private String hostH5;
	
	private String hostImg;
	
	private String rmbExchageRate;
	
	public String getCkUrlOfHandlePayedOrder() {
		return ckUrlOfHandlePayedOrder;
	}
	
	@Value("${rest.order.callbackUrls.handleOrderAfterPay}")
	public void setCkUrlOfHandlePayedOrder(String ckUrlOfHandlePayedOrder) {
		this.ckUrlOfHandlePayedOrder = ckUrlOfHandlePayedOrder;
	}
	
	public String getRdUrlAfterPay() {
		return rdUrlAfterPay;
	}
	
	@Value("${rest.pay.redirectUrls.handlePayResult}")
	public void setRdUrlAfterPay(String rdUrlAfterPay) {
		this.rdUrlAfterPay = rdUrlAfterPay;
	}

	public String getHostApi() {
		return hostApi;
	}

	@Value("${app.server.hostApi}")
	public void setHostApi(String hostApi) {
		this.hostApi = hostApi;
	}

	public String getHostPay() {
		return hostPay;
	}
	
	@Value("${app.server.hostPay}")
	public void setHostPay(String hostPay) {
		this.hostPay = hostPay;
	}

	public String getHostMember() {
		return hostMember;
	}
	@Value("${app.server.hostMember}")
	public void setHostMember(String hostMember) {
		this.hostMember = hostMember;
	}

	public String getHostSearch() {
		return hostSearch;
	}
	@Value("${app.server.hostSearch}")
	public void setHostSearch(String hostSearch) {
		this.hostSearch = hostSearch;
	}

	public String getHostH5() {
		return hostH5;
	}
	
	@Value("${app.server.hostH5}")
	public void setHostH5(String hostH5) {
		this.hostH5 = hostH5;
	}

	public String getHostImg() {
		return hostImg;
	}
	
	@Value("${app.server.hostImg}")
	public void setHostImg(String hostImg) {
		this.hostImg = hostImg;
	}

	public String getRmbExchageRate() {
		return rmbExchageRate;
	}

	@Value("${app.server.rmb.exchage.rate}")
	public void setRmbExchageRate(String rmbExchageRate) {
		this.rmbExchageRate = rmbExchageRate;
	}
	
	
	
}
