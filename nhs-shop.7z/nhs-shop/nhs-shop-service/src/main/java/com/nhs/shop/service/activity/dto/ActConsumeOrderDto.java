package com.nhs.shop.service.activity.dto;



import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;



public class ActConsumeOrderDto implements Serializable {
    private static final long serialVersionUID = -6576080911024205665L;

   
    private Integer id;

  
    private Integer actId;

  
    private String userId;

   
    private Integer orderId;


    private BigDecimal payAmount;

    private String payTimeStr;


    private int sliverDonated;

   
    private BigDecimal basedSilver;
    
  
    private String orderType;
    
    
    private String orderNum;
    
    private BigDecimal needPresentSilver;
    
    private Date payTime;
    
    private String msgText;


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public Integer getActId() {
		return actId;
	}


	public void setActId(Integer actId) {
		this.actId = actId;
	}


	public String getUserId() {
		return userId;
	}


	public void setUserId(String userId) {
		this.userId = userId;
	}


	public Integer getOrderId() {
		return orderId;
	}


	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}


	public BigDecimal getPayAmount() {
		return payAmount;
	}


	public void setPayAmount(BigDecimal payAmount) {
		this.payAmount = payAmount;
	}


	public String getPayTimeStr() {
		return payTimeStr;
	}


	public void setPayTimeStr(String payTimeStr) {
		this.payTimeStr = payTimeStr;
	}


	public int getSliverDonated() {
		return sliverDonated;
	}


	public void setSliverDonated(int sliverDonated) {
		this.sliverDonated = sliverDonated;
	}


	public BigDecimal getBasedSilver() {
		return basedSilver;
	}


	public void setBasedSilver(BigDecimal basedSilver) {
		this.basedSilver = basedSilver;
	}


	public String getOrderType() {
		return orderType;
	}


	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}


	public String getOrderNum() {
		return orderNum;
	}


	public void setOrderNum(String orderNum) {
		this.orderNum = orderNum;
	}


	public BigDecimal getNeedPresentSilver() {
		return needPresentSilver;
	}


	public void setNeedPresentSilver(BigDecimal needPresentSilver) {
		this.needPresentSilver = needPresentSilver;
	}


	public Date getPayTime() {
		return payTime;
	}


	public void setPayTime(Date payTime) {
		this.payTime = payTime;
	}


	public String getMsgText() {
		return msgText;
	}


	public void setMsgText(String msgText) {
		this.msgText = msgText;
	}

	
    
    
    
}
