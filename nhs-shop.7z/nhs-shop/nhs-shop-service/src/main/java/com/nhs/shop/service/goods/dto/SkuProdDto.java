package com.nhs.shop.service.goods.dto;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 具体的某种型号的产品..
 * @Title: ShopProdDto.java
 * @Package com.nhs.shop.service.order.dto
 * @Description: TODO
 * @author Administrator
 * @date 2016年7月19日 下午8:23:55
 * @version V1.0
 */
public class SkuProdDto implements Serializable {
    private static final long serialVersionUID = -5202260675613415541L;
    private Integer prodId;
    private Integer skuId = 0;
    private String prodName = "";
    private String pic = "";
    private String skuDesc = "";
    private Double price;
    private String detailUrl = "";
    private BigDecimal rebate;
    private Integer hasInvoice;
    private GoodsTagDto goodsTag;

    public String getDetailUrl() {
        return detailUrl;
    }

    public void setDetailUrl(String detailUrl) {
        this.detailUrl = detailUrl;
    }

    public Integer getProdId() {
        return prodId;
    }

    public void setProdId(Integer prodId) {
        this.prodId = prodId;
    }

    public Integer getSkuId() {
        return skuId;
    }

    public void setSkuId(Integer skuId) {
        this.skuId = skuId;
    }

    public String getProdName() {
        return prodName;
    }

    public void setProdName(String prodName) {
        this.prodName = prodName;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public String getSkuDesc() {
        return skuDesc;
    }

    public void setSkuDesc(String skuDesc) {
        this.skuDesc = skuDesc;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

	public BigDecimal getRebate() {
		return rebate;
	}

	public void setRebate(BigDecimal rebate) {
		this.rebate = rebate;
	}

	public Integer getHasInvoice() {
		return hasInvoice;
	}

	public void setHasInvoice(Integer hasInvoice) {
		this.hasInvoice = hasInvoice;
	}

	public GoodsTagDto getGoodsTag() {
		return goodsTag;
	}

	public void setGoodsTag(GoodsTagDto goodsTag) {
		this.goodsTag = goodsTag;
	}
	
}
