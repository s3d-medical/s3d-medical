package com.nhs.shop.service.qiniu;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nhs.shop.service.qiniu.ext.Auth;

/**
 * 七牛云存储 service
 * @Title: GoodsService.java
 * @Package com.nhs.shop.service.goods
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月16日 下午7:42:18
 * @version V1.0
 */
@Service
@Transactional
public class QiniuService {

    private static final String AccessKey = "Y7Xt08uuEAsRlQ5qJZPkFkvxQdL2IIXLtKMmpx-t";

    private static final String SecretKey = "isJfnaZ0N3EaoU0rheJrQvTX46qD1Eyfo3ihD8JM";

    private static final String BUCKET = "nhs-o2o-app-dev";

    /**
     * 获取上传凭证
     * @Title: getUploadToken
     * @Description: TODO
     * @param @param key
     * @param @return   
     * @return String 
     * @author Administrator 2016年7月22日 
     * @throws
     */
    public String getUploadToken(String key) {
        Auth auth = Auth.create(AccessKey, SecretKey);
        return auth.uploadToken(BUCKET, key);
    }
    
    public static void main(String[] args){
        QiniuService s = new QiniuService();
        String token = s.getUploadToken("123456.jpg");
        System.out.println(token);
    }

}
