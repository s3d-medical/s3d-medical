/**
 * 
 */
package com.nhs.shop.service.shop;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nhs.shop.dao.legend.shop.ShopDetailDao;
import com.nhs.shop.entry.legend.shop.ShopDetail;

/**
 * @author Administrator
 *
 */
@Service
@Transactional
public class ShopCommonService {
	
	@Autowired
    private ShopDetailDao shopDetailDao;
	
	public boolean isShopReturn(int shopId){
		 ShopDetail shop = shopDetailDao.findOne(shopId);
	     boolean flag = false;
	     if (shop != null) {
	         if (shop.getWhiteList() != null && shop.getWhiteList().intValue() == 1) {
	             flag = true;
	         } else if ((shop.getWhiteList() == null || shop.getWhiteList().intValue() == 0)
	                 && (shop.getCoinSwitch() != null && shop.getCoinSwitch().intValue() == 1)) {
	             flag = true;
	         }
	     }
	     return flag;
	}
}
