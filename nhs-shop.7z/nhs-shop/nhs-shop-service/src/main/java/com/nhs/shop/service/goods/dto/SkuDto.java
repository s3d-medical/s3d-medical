package com.nhs.shop.service.goods.dto;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.common.collect.Lists;
import com.nhs.shop.service.common.dto.CustFieldDto;

/**
 * SKU DTO
 * @Title: SkuDto.java
 * @Package com.nhs.shop.service.goods.dto
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月18日 下午2:39:15
 * @version V1.0
 */
public class SkuDto implements Serializable {

    private static final long serialVersionUID = -7090747466773535485L;

    private Integer skuId;
    private Integer prodId;
    private String skuValue;
    private String price;
    private Integer stocks;
    @Deprecated
    private String subsidy;
    @Deprecated
    private String subsidyStr;
 
    /**
     * 产品促销信息, 主要是用于ui布局和显示, 现融合在dto中. 
     */
    private Map<String, CustFieldDto> promotion = new HashMap<String, CustFieldDto>();
    
    private List<String> skuUrl = Lists.newArrayList();;

    public List<String> getSkuUrl() {
        return skuUrl;
    }

    public void setSkuUrl(List<String> skuUrl) {
        this.skuUrl = skuUrl;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public Integer getSkuId() {
        return skuId;
    }

    public void setSkuId(Integer skuId) {
        this.skuId = skuId;
    }

    public Integer getProdId() {
        return prodId;
    }

    public void setProdId(Integer prodId) {
        this.prodId = prodId;
    }

    public String getSkuValue() {
        return skuValue;
    }

    public void setSkuValue(String skuValue) {
        this.skuValue = skuValue;
    }

    public Integer getStocks() {
        return stocks;
    }

    public void setStocks(Integer stocks) {
        this.stocks = stocks;
    }

    public String getSubsidy() {
        return subsidy;
    }

    public void setSubsidy(String subsidy) {
        this.subsidy = subsidy;
    }

    public String getSubsidyStr() {
        return subsidyStr;
    }

    public void setSubsidyStr(String subsidyStr) {
        this.subsidyStr = subsidyStr;
    }

	public Map<String, CustFieldDto> getPromotion() {
		return promotion;
	}

	public void setPromotion(Map<String, CustFieldDto> promotion) {
		this.promotion = promotion;
	}
    
}
