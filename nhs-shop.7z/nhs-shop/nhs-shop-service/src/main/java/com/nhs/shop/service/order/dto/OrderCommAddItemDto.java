package com.nhs.shop.service.order.dto;

import java.io.Serializable;
import java.util.List;

import com.google.common.collect.Lists;

public class OrderCommAddItemDto implements Serializable {

    private static final long serialVersionUID = -1996411650422992562L;
    private Integer prodId;
    private Integer score;
    private String cotent;
    private List<String> picList = Lists.newArrayList();

    public Integer getProdId() {
        return prodId;
    }

    public void setProdId(Integer prodId) {
        this.prodId = prodId;
    }

    public Integer getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }

    public String getCotent() {
        return cotent;
    }

    public void setCotent(String cotent) {
        this.cotent = cotent;
    }

    public List<String> getPicList() {
        return picList;
    }

    public void setPicList(List<String> picList) {
        this.picList = picList;
    }

}
