package com.nhs.shop.service.order.dto;

import java.io.Serializable;
import java.util.List;

import com.google.common.collect.Lists;

public class OrderCommAddRequestDto implements Serializable {
    private static final long serialVersionUID = 5288203888562026827L;
    private String userId;
    private Integer orderId;
    private String cotent;
    private List<String> picList = Lists.newArrayList();
    private Integer score;
    private List<OrderCommAddItemDto> orderCommAddItemDto;

    public List<OrderCommAddItemDto> getOrderCommAddItemDto() {
        return orderCommAddItemDto;
    }

    public void setOrderCommAddItemDto(List<OrderCommAddItemDto> orderCommAddItemDto) {
        this.orderCommAddItemDto = orderCommAddItemDto;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public String getCotent() {
        return cotent;
    }

    public void setCotent(String cotent) {
        this.cotent = cotent;
    }

    public List<String> getPicList() {
        return picList;
    }

    public void setPicList(List<String> picList) {
        this.picList = picList;
    }

    public Integer getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }

}
