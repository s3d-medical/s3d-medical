package com.nhs.shop.entry.em;

/**
 * 支付方式枚举
 * @Title: PayTypeEnum.java
 * @Package com.nhs.shop.entry.em
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月28日 下午2:39:27
 * @version V1.0
 */
public enum PayTypeEnum {
	//100-易宝PC,101-微信支付,102-支付宝支付，103-易宝一键支付
	
    AliPay("支付宝"), //102-支付宝支付

    WxPay("微信支付"), //101-微信支付

    JixubaoPay("积蓄宝支付"), 

    BankCardPay("银行卡支付");  //103-易宝一键支付


    private String name;

    PayTypeEnum(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public static PayTypeEnum parseByCode(String code){
    	if("101".equals(code)){
    		return WxPay;
    	}else if("102".equals(code)){
    		return AliPay;
    	}else if("103".equals(code)){
    		return BankCardPay;
    	}else if("104".equals(code)){
    		return JixubaoPay;
    	}
    	return null;
    }   
}
