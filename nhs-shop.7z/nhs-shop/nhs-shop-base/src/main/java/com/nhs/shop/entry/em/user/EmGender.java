package com.nhs.shop.entry.em.user;

/**
 * @author hxj
 * 性别
 */
public enum EmGender {
    secret(0, "保密"),
    man(1, "男"),
    woman(2, "女");

    public Integer value;
    public final String name;

    EmGender(Integer value, String name) {
        this.value = value;
        this.name = name;
    }

    public static String getStatusLabel(Integer value) {
        String cm = "";
        for (EmGender map : EmGender.values()) {
            if (value == map.value) {
                cm = map.name;
                break;
            }
        }
        return cm;
    }
}
