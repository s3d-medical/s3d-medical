package com.nhs.shop.entry.em.user;

public enum EmRechargeStatus {
    wait_pay(0, "待充值"),
    ok(1, "充值成功"),
    error(2, "充值失败"),
    exception(3, "充值异常");

    public Integer value;
    public final String name;

    EmRechargeStatus(Integer value, String name) {
        this.value = value;
        this.name = name;
    }

    public static String getStatusLabel(Integer value) {
        String cm = "";
        for (EmRechargeStatus map : EmRechargeStatus.values()) {
            if (value == map.value) {
                cm = map.name;
                break;
            }
        }
        return cm;
    }
}
