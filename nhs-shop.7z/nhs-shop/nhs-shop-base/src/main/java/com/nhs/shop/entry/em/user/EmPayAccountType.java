package com.nhs.shop.entry.em.user;

/**
 * 支付账号类型
 * @Title: EmPayAccountType.java
 * @Package com.nhs.shop.entry.em.user
 * @Description: TODO
 * @author huxianjun
 * @date 2016年7月18日 下午9:37:56
 * @version V1.0
 */
public enum EmPayAccountType {
    bank(1, "银行卡"),
    third_pay(2, "第三方支付");

    public Integer value;
    public final String name;

    EmPayAccountType(Integer value, String name) {
        this.value = value;
        this.name = name;
    }

    public static String getStatusLabel(Integer value) {
        String cm = "";
        for (EmPayAccountType map : EmPayAccountType.values()) {
            if (value == map.value) {
                cm = map.name;
                break;
            }
        }
        return cm;
    }
}
