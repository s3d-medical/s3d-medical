package com.nhs.shop.entry.em.user;

/**
 * 是否常用地址
 * @Title: EmCommonAddress.java
 * @Package com.nhs.shop.entry.em.user
 * @Description: TODO
 * @author huxianjun
 * @date 2016年7月15日 下午1:57:32
 * @version V1.0
 */
public enum EmCommonAddress {
    kind_addr("0", "一般地址"),
    default_addr("1", "常用地址");

    public String value;
    public final String name;

    EmCommonAddress(String value, String name) {
        this.value = value;
        this.name = name;
    }

    public static String getStatusLabel(String value) {
        String cm = "";
        for (EmCommonAddress map : EmCommonAddress.values()) {
            if (value.equals(map.value)) {
                cm = map.name;
                break;
            }
        }
        return cm;
    }
}
