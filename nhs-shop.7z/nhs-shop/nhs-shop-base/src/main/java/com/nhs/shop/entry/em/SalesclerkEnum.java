package com.nhs.shop.entry.em;

public enum SalesclerkEnum {

    SALESCLERK_STATUS_ZERO("已解绑"),

    SALESCLERK_STATUS_ONE("已生效"),

    SALESCLERK_STATUS_TWO("已禁用");

    /** The value. */
    private final String value;

    /**
     * Instantiates a new visit type enum.
     * 
     * @param value
     *            the value
     */
    private SalesclerkEnum(String value) {
        this.value = value;
    }

    /*
     * (non-Javadoc)
     * @see com.legendshop.core.constant.StringEnum#value()
     */
    public String value() {
        return this.value;
    }
}
