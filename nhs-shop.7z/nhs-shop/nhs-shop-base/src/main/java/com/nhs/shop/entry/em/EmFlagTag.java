package com.nhs.shop.entry.em;

/**
 * @author hxj
 * 通用状态标签
 */
public enum EmFlagTag {
    invalid(0, "无效"),
    valid(1, "有效");

    public Integer value;
    public final String name;

    EmFlagTag(Integer value, String name) {
        this.value = value;
        this.name = name;
    }

    public static String getStatusLabel(Integer value) {
        String cm = "";
        for (EmFlagTag map : EmFlagTag.values()) {
            if (value == map.value) {
                cm = map.name;
                break;
            }
        }
        return cm;
    }
}
