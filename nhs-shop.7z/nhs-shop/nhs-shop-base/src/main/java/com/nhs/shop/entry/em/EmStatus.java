package com.nhs.shop.entry.em;

/**
 * 通用状态
 * 改变前／改变后
 * @Title: EmStatus.java
 * @Package com.nhs.shop.entry.em
 * @Description: TODO
 * @author huxianjun
 * @date 2016年11月8日 上午11:28:46
 * @version V1.0
 */
public enum EmStatus {
    undeal(0, "未处理"),
    dealt(1, "已处理");

    public Integer value;
    public final String name;

    EmStatus(Integer value, String name) {
        this.value = value;
        this.name = name;
    }

    public static String getStatusLabel(Integer value) {
        String cm = "";
        for (EmStatus map : EmStatus.values()) {
            if (value == map.value) {
                cm = map.name;
                break;
            }
        }
        return cm;
    }
}
