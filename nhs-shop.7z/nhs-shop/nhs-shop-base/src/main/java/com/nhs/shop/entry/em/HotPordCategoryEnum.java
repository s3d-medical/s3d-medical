package com.nhs.shop.entry.em;

/**
 * 热销产品分类
 * @Title: HotPordCategoryEnum.java
 * @Package com.nhs.shop.entry.em
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月26日 下午1:26:29
 * @version V1.0
 */
public enum HotPordCategoryEnum {

    /**热销商品*/
    HOT_GOODS(1),

    /**热销车型*/
    HOT_CAR(2);

    private int category;

    HotPordCategoryEnum(int category) {
        this.category = category;
    }

    public int getCategory() {
        return category;
    }

    public void setCategory(int category) {
        this.category = category;
    }

}
