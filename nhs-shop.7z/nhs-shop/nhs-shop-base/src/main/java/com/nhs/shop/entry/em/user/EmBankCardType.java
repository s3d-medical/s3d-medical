package com.nhs.shop.entry.em.user;

/**
 * 
 * @Title: EmBankCardType.java
 * @Package com.nhs.shop.entry.em.user
 * @Description: TODO
 * @author huxianjun
 * @date 2016年7月18日 下午9:40:16
 * @version V1.0
 */
public enum EmBankCardType {
    not_card(0, "未知"),
    deposit_card(1, "储蓄卡"),
    credit_card(2, "信用卡"),
	public_card(3,"对公账号");
	

    public Integer value;
    public final String name;

    EmBankCardType(Integer value, String name) {
        this.value = value;
        this.name = name;
    }

    public static String getStatusLabel(Integer value) {
        String cm = "";
        for (EmBankCardType map : EmBankCardType.values()) {
            if (value == map.value) {
                cm = map.name;
                break;
            }
        }
        return cm;
    }
}
