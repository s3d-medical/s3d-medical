package com.nhs.shop.entry.em;

public enum EmSmsType {
    /** 语音验证 */
    VOICE_VAL(1),

    /** 短信验证 */
    VAL(2),

    /** 广告 */
    ADV(3),

    /** 订单 */
    ORDER(4),

    /** 物流 */
    LOGISTICS(5),

    TIX(6), // 提现,

    COUPON(7)// 礼券

    ;
    // 成员变量
    public Integer value;

    // 构造方法
    EmSmsType(Integer value) {
        this.value = value;
    }
}