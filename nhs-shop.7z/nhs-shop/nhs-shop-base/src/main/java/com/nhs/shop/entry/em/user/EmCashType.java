package com.nhs.shop.entry.em.user;

public enum EmCashType {
    user(0, "个人账户"),
    merchant(1, "商家账户"),
    gold(2, "金币数量"),
    silver(3, "银币数量"),
    sub(4, "交易支出"),
    add(5, "交易收入"),
    commission(6, "营业员佣金账户");

    public Integer value;
    public final String name;

    EmCashType(Integer value, String name) {
        this.value = value;
        this.name = name;
    }

    public static String getStatusLabel(Integer value) {
        String cm = "";
        for (EmCashType map : EmCashType.values()) {
            if (value == map.value) {
                cm = map.name;
                break;
            }
        }
        return cm;
    }
}
