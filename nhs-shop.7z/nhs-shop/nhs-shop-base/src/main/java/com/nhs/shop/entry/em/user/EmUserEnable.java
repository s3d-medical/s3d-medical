package com.nhs.shop.entry.em.user;

/**
 * 用户状态是否有效
 * @Title: EmUserEnable.java
 * @Package com.nhs.shop.entry.em.user
 * @Description: TODO
 * @author huxianjun
 * @date 2016年7月15日 下午10:53:12
 * @version V1.0
 */
public enum EmUserEnable {
    disable("0", "无效"),
    eable("1", "有效");

    public String value;
    public final String name;

    EmUserEnable(String value, String name) {
        this.value = value;
        this.name = name;
    }

    public static String getStatusLabel(String value) {
        String cm = "";
        for (EmUserEnable map : EmUserEnable.values()) {
            if (value.equals(map.value)) {
                cm = map.name;
                break;
            }
        }
        return cm;
    }
}
