package com.nhs.shop.entry.em;

import com.nhs.shop.entry.em.shop.IntegerEnum;

/**
 * 登录方式
 * 密码登录还是第三方登录
 */
public enum CashTypeEnum implements IntegerEnum {

    // 余额账户
    BALANCE_ACCOUNT(0),

    // 商家账户
    SHOP_ACCOUNT(1),

    // 金币
    GOLD(2),

    // 银币
    SILVER(3);

    private final Integer value;

    private CashTypeEnum(Integer value) {
        this.value = value;
    }

    public Integer value() {
        return this.value;
    }

    public static CashTypeEnum formCode(Integer value) {
        if (!CashTypeEnum.BALANCE_ACCOUNT.value.equals(value) && !CashTypeEnum.SHOP_ACCOUNT.value.equals(value)) {
            return null;
        }
        CashTypeEnum[] enums = values();
        for (int i = 0; i < enums.length; i++) {
            CashTypeEnum cashTypeEnum = enums[i];
            if (cashTypeEnum.value.equals(value)) {
                return cashTypeEnum;
            }
        }
        return null;
    }

}
