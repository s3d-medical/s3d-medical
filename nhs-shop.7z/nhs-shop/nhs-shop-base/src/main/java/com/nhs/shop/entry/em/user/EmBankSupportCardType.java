package com.nhs.shop.entry.em.user;

/**
 * 银行支持的卡类型
 * @Title: EmBankSupportCardType.java
 * @Package com.nhs.shop.entry.em.user
 * @Description: TODO
 * @author huxianjun
 * @date 2016年8月26日 下午2:18:10
 * @version V1.0
 */
public enum EmBankSupportCardType {
    not_card(0, "未知"),
    deposit_card(1, "储蓄卡"),
    credit_card(2, "信用卡"),
    deposit_credit_card(3, "储蓄卡/信用卡"),
    precharge_card(4, "预充值卡");

    public Integer value;
    public final String name;

    EmBankSupportCardType(Integer value, String name) {
        this.value = value;
        this.name = name;
    }

    public static String getStatusLabel(Integer value) {
        String cm = "";
        for (EmBankSupportCardType map : EmBankSupportCardType.values()) {
            if (value == map.value) {
                cm = map.name;
                break;
            }
        }
        return cm;
    }
}
