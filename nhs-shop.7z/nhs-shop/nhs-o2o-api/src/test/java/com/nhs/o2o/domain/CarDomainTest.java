package com.nhs.o2o.domain;

import java.util.Map;

import org.junit.Test;

import jersey.repackaged.com.google.common.collect.Maps;

public class CarDomainTest extends BaseClientTest {
    private final static String API_URL = "http://localhost:8090/o2o/car";
    private final static String API_HEADER = "?appVersion=testBase&phoneModel=eclipse&platformType=Java";

    private final String accessToken = "02A48277D31E344D2AEE9FA16685776C";

    @Test
    public void hot_brand() {
        Map<String, Object> param = Maps.newHashMap();

        String result = post(API_URL + "/hot_brand" + API_HEADER, param, String.class);

        System.out.println(result);
    }

    @Test
    public void top_brand() {
        Map<String, Object> param = Maps.newHashMap();

        String result = post(API_URL + "/top_brand" + API_HEADER, param, String.class);

        System.out.println(result);
    }

    @Test
    public void char_brand() {
        Map<String, Object> param = Maps.newHashMap();
        param.put("firstChar", "A");

        String result = post(API_URL + "/char_brand" + API_HEADER, param, String.class);

        System.out.println(result);
    }

}
