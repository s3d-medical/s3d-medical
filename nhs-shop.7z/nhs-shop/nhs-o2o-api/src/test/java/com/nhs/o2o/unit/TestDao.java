package com.nhs.o2o.unit;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.nhs.shop.dao.legend.pay.PayAccountDao;
import com.nhs.shop.entry.legend.user.UsrAddr;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
public class TestDao {

    @Resource
    PayAccountDao payAccountDao;

    @Test
    public void testPayAccountDao() throws Exception {
        // Long le = payAccountDao.countPayCard("500001");
        System.err.println("==========");
    }

    @Test
    public void addUsrAddr() throws Exception {
        UsrAddr addr = new UsrAddr();
        addr.setMobile("12");
        System.err.println("==========");
    }
}
