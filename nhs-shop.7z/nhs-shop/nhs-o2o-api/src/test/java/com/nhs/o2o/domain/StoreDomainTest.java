package com.nhs.o2o.domain;

import java.util.List;
import java.util.Map;

import org.junit.Test;

import com.google.common.collect.Lists;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.core.utils.security.SignMD5;

import jersey.repackaged.com.google.common.collect.Maps;

public class StoreDomainTest extends BaseClientTest {
    private final static String API_URL = "http://localhost:8090/o2o/storeOrder";
    private final static String API_HEADER = "?appVersion=testBase&phoneModel=eclipse&platformType=Java";

    private final String accessToken = "02A48277D31E344D2AEE9FA16685776C";

    @Test
    public void addOrder() {
        Map<String, Object> param = Maps.newHashMap();
        param.put("shopId", 60001);
        param.put("shopName", "哪划算超市");
        param.put("userMobile", "18112345678");
        param.put("tradeNo", StringHelper.radomCode(11));
        param.put("createTime", "2016-08-20 08:00:00");
        param.put("payTime", "2016-08-20 08:00:00");
        param.put("payTypeName", "现金");
        param.put("totalAmount", 200.00);
        param.put("payAmount", 200.00);

        List<Map<String, Object>> items = Lists.newArrayList();
        Map<String, Object> item = Maps.newHashMap();
        item.put("prodNo", "121");
        item.put("prodName", "青菜");
        item.put("prodNum", 10);
        item.put("prodPrimePrice", 10.50);
        item.put("prodSalePrice", 10.00);
        item.put("prodAmount", 100.00);
        item.put("prodRebateRate", 1.000);
        item.put("prodAdFeeRate", 1.000);
        item.put("prodAdFeeBasicRate", 0.160);
        item.put("prodCategoryName", "蔬菜类");
        items.add(item);

        Map<String, Object> item2 = Maps.newHashMap();
        item2.put("prodNo", "122");
        item2.put("prodName", "萝卜");
        item2.put("prodNum", 10);
        item2.put("prodPrimePrice", 10.50);
        item2.put("prodSalePrice", 10.00);
        item2.put("prodAmount", 100.00);
        item2.put("prodRebateRate", 1.000);
        item2.put("prodAdFeeRate", 1.000);
        item2.put("prodAdFeeBasicRate", 0.160);
        item2.put("prodCategoryName", "蔬菜类");
        items.add(item2);

        param.put("prodList", items);

        long st = System.currentTimeMillis();
        StringBuilder stringKey = new StringBuilder("systemtime=");
        stringKey.append(st).append("&key=12121212121212121");
        String mySign = SignMD5.MD5Encode(stringKey.toString(), "UTF-8").toUpperCase();
        System.err.println(mySign);
        String result = post(API_URL + "/add" + API_HEADER + "&systemtime=" + st + "&sign=" + mySign, param,
                String.class);

        System.out.println(result);
    }

}
