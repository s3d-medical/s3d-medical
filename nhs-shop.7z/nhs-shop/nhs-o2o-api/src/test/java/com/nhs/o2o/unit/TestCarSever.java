package com.nhs.o2o.unit;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.nhs.shop.service.car.CarService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
public class TestCarSever {

    @Resource
    CarService carService;

    @Test
    public void getTopBrand() throws Exception {
        System.err.println(carService.getTopBrand());
        System.err.println("ok");
    }

}
