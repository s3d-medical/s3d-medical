package com.nhs.o2o.domain;

import java.util.Map;

import org.junit.Test;

import com.nhs.core.mapper.JsonMapper;

import jersey.repackaged.com.google.common.collect.Maps;

public class MemberDomainTest extends BaseClientTest {
    private final static String API_URL = "http://localhost:8090/o2o/member";
    private final static String API_HEADER = "?appVersion=testBase&phoneModel=eclipse&platformType=Java";

    private final String accessToken = "02A48277D31E344D2AEE9FA16685776C";

    @Test
    public void memberLogin_1() {
        Map<String, Object> map = Maps.newHashMap();

        map.put("appVersion", "testBase");
        map.put("phoneModel", "eclipse");
        map.put("platformType", "Java");
        map.put("accessToken", null);

        Map<String, Object> param = Maps.newHashMap();
        param.put("account", "20160802997");
        param.put("password", "123456");

        map.put("param", param);
        System.err.println(map);

        String result = post(API_URL + "/login" + API_HEADER, param, String.class);

        System.out.println(result);
    }

    @Test
    public void memberRegister_1() {
        Map<String, Object> map = Maps.newHashMap();

        Map<String, Object> param = Maps.newHashMap();
        param.put("account", "25533310");
        param.put("password", "123456");
        param.put("verification", "123456");

        map.put("param", param);
        System.err.println(map);

        String result = post(API_URL + "/register" + API_HEADER, param, String.class);

        System.out.println(result);
    }

    @Test
    public void memberEditAddr_1() {
        Map<String, Object> map = Maps.newHashMap();

        Map<String, Object> param = Maps.newHashMap();
        param.put("userId", "123456");

        map.put("param", param);
        System.err.println(map);

        String result = post(API_URL + "/edit_address" + API_HEADER, param, String.class);

        System.out.println(result);
    }

    @Test
    public void memberAddAddr_1() {
        Map<String, Object> param = Maps.newHashMap();
        param.put("userId", "2549ecd6-b0cd-4724-a149-ecef69739927");
        param.put("userName", "123456");
        param.put("receiver", "123456卡xi");
        param.put("subAdds", "123456");
        param.put("provinceId", "1");
        param.put("cityId", "1");
        param.put("areaId", "1");
        param.put("mobile", "123456");
        param.put("commonAddr", "0");

        System.err.println(JsonMapper.nonEmptyMapper().toJson(param));

        String result = post(API_URL + "/add_address" + API_HEADER, param, String.class);

        System.out.println(result);
    }

    @Test
    public void validate() {
        Map<String, Object> map = Maps.newHashMap();

        Map<String, Object> param = Maps.newHashMap();
        param.put("phone", "18168185182");

        map.put("param", param);
        System.err.println(map);

        String result = post(API_URL + "/validate" + API_HEADER, param, String.class);

        System.out.println(result);
    }

}
