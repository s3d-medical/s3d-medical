package com.nhs.o2o.unit;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.nhs.shop.service.goods.GoodsService;
import com.nhs.shop.service.order.shop.internal.ShopOrderOperateService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
public class TestShopSever {

    @Resource
    ShopOrderOperateService shopOrderOperateService;

    @Resource
    GoodsService goodsService;

    @Test
    public void updateMemberDefaultAddress() throws Exception {
        shopOrderOperateService.dealOrderOperate("01826e53-7bdf-4a0f-9ab5-cb55991854b8", 560, "refund", "太贵了");
        System.err.println("ok");
    }

    @Test
    public void goodsList() throws Exception {
        // goodsService.getGoodsList(766, "", 0, 1, 1, 1, "", "", 0, null);
        System.err.println("ok");
    }

}
