package com.nhs.o2o.unit;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.nhs.sms.service.SmsService;
import com.nhs.user.service.MemberService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
public class TestSever {

    @Resource
    SmsService smsService;

    @Resource
    MemberService memberService;

    @Test
    public void testSmsService() throws Exception {
        String[] args = new String[] { "126896", "2" };
        smsService.saveSendSms(10001, "18860915051", "126896", 1, args);
        System.err.println("ok");
    }

    @Test
    public void updateMemberDefaultAddress() throws Exception {
        //memberService.updateMemberDefaultAddress("cb7cebb9-f498-4354-817e-ce22788ebdb5", 208);
        System.err.println("ok");
    }

}
