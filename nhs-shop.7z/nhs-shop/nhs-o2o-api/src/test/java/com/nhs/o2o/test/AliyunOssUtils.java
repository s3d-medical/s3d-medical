/*******************************************************************************
 * @Title: AliOss.java
 * @Description: TODO
 * @author hxj 2016-4-23 
 * @version V1.0   
 * 注意：本内容仅限于内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
package com.nhs.o2o.test;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

import com.aliyun.oss.OSSClient;
import com.aliyun.oss.model.GetObjectRequest;
import com.aliyun.oss.model.OSSObject;

/**   
 * @Title: AliOss.java
 * @Description: TODO
 * @author hxj
 * @date 2016-4-23 下午11:28:59
 * @version V1.0   
 */
public class AliyunOssUtils {
    private static String endpoint = "oss-cn-hangzhou.aliyuncs.com";
    private static String accessKeyId = "";
    private static String accessKeySecret = "";

    public static String bucketName = "jkc-office";

    public static InputStream downFile(String bucketName, String key) throws IOException {
        OSSClient client = new OSSClient(endpoint, accessKeyId, accessKeySecret);
        OSSObject object = client.getObject(new GetObjectRequest(bucketName, key));
        client.shutdown();
        return object.getObjectContent();
    }

    public static void uploadFile(String bucketName, String key, byte[] contents) throws IOException {
        OSSClient client = new OSSClient(endpoint, accessKeyId, accessKeySecret);
        client.putObject(bucketName, key, new ByteArrayInputStream(contents));
        client.shutdown();
    }

}
