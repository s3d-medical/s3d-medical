package com.nhs.o2o.domain;

import java.util.Map;

import org.junit.Test;

import jersey.repackaged.com.google.common.collect.Maps;

public class ShopDomainTest extends BaseClientTest {
    private final static String API_URL = "http://localhost:8090/o2o/shopOrder";
    private final static String API_HEADER = "?appVersion=testBase&phoneModel=eclipse&platformType=Java";

    private final String accessToken = "02A48277D31E344D2AEE9FA16685776C";

    @Test
    public void shopList() {
        Map<String, Object> param = Maps.newHashMap();
        param.put("userId", "402881d756318ca30156318cadfc0000");
        param.put("status", 2);
        param.put("pageNo", 1);
        param.put("pageSize", 10);

        System.err.println(param);

        String result = post(API_URL + "/list" + API_HEADER, param, String.class);

        System.out.println(result);
    }

}
