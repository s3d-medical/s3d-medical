package com.nhs.o2o.unit;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.nhs.shop.entry.legend.user.UsrDetail;
import com.nhs.user.dto.MemberDetailDto;
import com.nhs.user.service.MemberService;
import com.nhs.user.service.UserService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
public class TestUnit {
	
	@Resource
    MemberService memberService;
	
	@Resource
	UserService userService;
	
	@Test
    public void testUserListByUserId() throws Exception {
        // Long le = payAccountDao.countPayCard("500001");
		//memberService.getUserDetailByUserId("000000005635d997015636d846e3000a");
        System.out.println("==========");
    }
	
	@Test
    public void testUserListByUserMobile() throws Exception {
        // Long le = payAccountDao.countPayCard("500001");
		//memberService.getUserDetailByMobile("13914095213");
        System.out.println("==========");
    }
	
	
	@Test
    public void testLoginUser() throws Exception {
        // Long le = payAccountDao.countPayCard("500001");
		memberService.storeMemberLogin("192.168.10.10","13382149080","1D06A7E520010DE8CF31520E3105F859",0,"");
        System.out.println("==========");
    }
	
	@Test
    public void testRegTime() throws Exception {
        // Long le = payAccountDao.countPayCard("500001");
		//memberService.storeMemberLogin("192.168.10.10","15106203591","20917c851c4a54f2a054390dac9085b7",0,"");
        
		List<UsrDetail> list = userService.findUsersByRegtime("2016-11-30 15:00:00", "2016-11-30 23:59:59",null);
		for(UsrDetail usr : list){
			System.out.println(usr.getUserId() + "	" + usr.getUserMobile());
		}
		System.out.println("==========");
    }

}
