package com.nhs.o2o.test;

import java.math.BigDecimal;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println(new BigDecimal("0.01").subtract(new BigDecimal("0.006")).setScale(2, BigDecimal.ROUND_DOWN));

	}

}
