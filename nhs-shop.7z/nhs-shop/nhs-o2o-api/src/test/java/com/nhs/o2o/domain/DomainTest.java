package com.nhs.o2o.domain;

import java.util.Map;

import org.junit.Test;

import jersey.repackaged.com.google.common.collect.Maps;

public class DomainTest extends BaseClientTest {
    private final static String API_URL = "http://localhost:8090/o2o";

    private final String accessToken = "02A48277D31E344D2AEE9FA16685776C";

    @Test
    public void workerLogin_1() {
        Map<String, Object> map = Maps.newHashMap();

        map.put("appVersion", "testBase");
        map.put("phoneModel", "eclipse");
        map.put("platformType", "Java");
        map.put("accessToken", null);

        Map<String, Object> param = Maps.newHashMap();
        param.put("account", "admin");
        param.put("password", "123456");

        map.put("param", param);
        System.err.println(map);

        String result = post(API_URL + "/goods/test", map, String.class);

        System.out.println(result);
    }

}
