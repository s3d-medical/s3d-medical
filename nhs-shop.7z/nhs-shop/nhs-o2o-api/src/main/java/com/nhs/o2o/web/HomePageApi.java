package com.nhs.o2o.web;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Maps;
import com.nhs.core.orm.Page;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.core.web.WebController;
import com.nhs.core.web.WebExceptionCode;
import com.nhs.core.web.WebRequestException;
import com.nhs.core.web.dto.RequestHeader;
import com.nhs.core.web.dto.ResponseDto;
import com.nhs.shop.service.car.CarService;
import com.nhs.shop.service.car.dto.CarDto;
import com.nhs.shop.service.category.dto.O2oHotCategoryDto;
import com.nhs.shop.service.goods.GoodsService;
import com.nhs.shop.service.goods.dto.GoodsDto;
import com.nhs.shop.service.home.HomePageService;

/**
 * 首页数据controller
 * @Title: HomePageApi.java
 * @Package com.nhs.o2o.web
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月16日 下午5:34:22
 * @version V1.0
 */
@Controller
@RequestMapping(value = "/homePage")
public class HomePageApi extends WebController {

    private final Logger logger = LoggerFactory.getLogger(HomePageApi.class);

    @Autowired
    private HomePageService homePageService;

    @Autowired
    private GoodsService goodsService;

    @Autowired
    private CarService carService;

    /**
     * 获取首页数据  for android 2.0之前版本
     * @Title: getHomePageData
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return
     * @return ResponseDto
     * @author Administrator 2016年7月17日
     * @throws
     */
    @RequestMapping(value = "/data", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto data(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            double lng = StringHelper.objectToDouble(map.get("lng"), 0.0); // 經度
            double lat = StringHelper.objectToDouble(map.get("lat"), 0.0); // 緯度
            result = homePageService.getHomePageData(lng, lat);

        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.info(e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 获取首页数据 for android 2.0版本
     * @Title: getHomePageData
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return
     * @return ResponseDto
     * @author Administrator 2016年7月17日
     * @throws
     */
    @RequestMapping(value = "/dataA20", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto data20(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            double lng = StringHelper.objectToDouble(map.get("lng"), 0.0); // 經度
            double lat = StringHelper.objectToDouble(map.get("lat"), 0.0); // 緯度
            String userName = StringHelper.objectToString(map.get("userName"), ""); // 緯度
            int cityId = StringHelper.objectToInt(map.get("cityId"), 247); // 緯度
            long startTime = System.currentTimeMillis();
            result = homePageService.getHomePageDataA20(lng, lat, userName,cityId);
            long endTime = System.currentTimeMillis();
            logger.info("homePageApi data20 spend time: "+(endTime - startTime));

        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.info(e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }
    
    /**
     * 获取首页数据1.9.1版本
     * @Title: getHomePageData
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return
     * @return ResponseDto
     * @author Administrator 2016年7月17日
     * @throws
     */
    @RequestMapping(value = "/1.9.1/dataA20", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto newData20(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            double lng = StringHelper.objectToDouble(map.get("lng"), 0.0); // 經度
            double lat = StringHelper.objectToDouble(map.get("lat"), 0.0); // 緯度
            String userName = StringHelper.objectToString(map.get("userName"), ""); // 緯度
            int cityId = StringHelper.objectToInt(map.get("cityId"), 247); // 緯度
            result = homePageService.getNewHomePageDataA20(lng, lat, userName,cityId);

        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.info(e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 获取首页分类查询数据
     * @Title: categoryData
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return
     * @return ResponseDto
     * @author Cary 2016年8月22日
     * @throws
     */
    @SuppressWarnings("deprecation")
    @RequestMapping(value = "/categoryData", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto categoryData(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = new LinkedHashMap<>();
        List<Object> rList = new ArrayList<>();
        try {
            // 首页每个分类都是查询10条
            Page<Map<String, Object>> page = createPage(1, 10);

            // 查询家电列表
            List<GoodsDto> jds = goodsService.getGoodsList(36, null, 9, 0, 0, 0, "", "", 0, null, page);
            Map<String, Object> jdMap = Maps.newHashMap();
            jdMap.put("categoryId", "36");
            jdMap.put("category", "家电");
            jdMap.put("list", jds);
            rList.add(jdMap);

            // 查询美妆列表
            List<GoodsDto> mzs = goodsService.getGoodsList(10694, null, 9, 0, 0, 0, "", "", 0, null, page);
            Map<String, Object> mzMap = Maps.newHashMap();
            mzMap.put("categoryId", "10694");
            mzMap.put("category", "美妆");
            mzMap.put("list", mzs);
            rList.add(mzMap);

            // 查询食品列表
            List<GoodsDto> foods = goodsService.getGoodsList(49, null, 9, 0, 0, 0, "", "", 0, null, page);
            Map<String, Object> foodsMap = Maps.newHashMap();
            foodsMap.put("categoryId", "49");
            foodsMap.put("category", "食品");
            foodsMap.put("list", foods);
            rList.add(foodsMap);

            // 查询箱包列表
            List<GoodsDto> bags = goodsService.getGoodsList(46, null, 9, 0, 0, 0, "", "", 0, null, page);
            Map<String, Object> bagMap = Maps.newHashMap();
            bagMap.put("categoryId", "46");
            bagMap.put("category", "箱包");
            bagMap.put("list", bags);
            rList.add(bagMap);

            // 查询汽车列表
            List<CarDto> cars = carService.getAllHotCar(7, page, requestHeader.getPlatformType());
            Map<String, Object> carMap = Maps.newHashMap();
            carMap.put("categoryId", "747");
            carMap.put("category", "汽车");
            carMap.put("list", cars);
            rList.add(carMap);

        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
            logger.error("errorMsg", e);
        }
        result.put("list", rList);
        response.getResult().putAll(result);
        return response;
    }
    
    /**
     * 获取首页分类查询数据
     * @Title: categoryData
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return
     * @return ResponseDto
     * @author Cary 2016年8月22日
     * @throws
     */
    @RequestMapping(value = "/v1.9.1/categoryData", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto categoryDataWithTagV191(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = new LinkedHashMap<>();
        List<Object> rList = new ArrayList<>();
        try {
            // 首页每个分类都是查询10条
            Page<Map<String, Object>> page = createPage(1, 10);
            // 查询家电列表
            List<GoodsDto> jds = goodsService.getGoodsListWithTag(36, null, 9, 0, 0, 0, "", "", 0, null, page);
            rList.add(this.buildOneCateData("36", "家电", jds));
            // 查询美妆列表
            List<GoodsDto> mzs = goodsService.getGoodsListWithTag(10694, null, 9, 0, 0, 0, "", "", 0, null, page);
            rList.add(this.buildOneCateData("10694", "美妆", mzs));
            // 查询食品列表
            List<GoodsDto> foods = goodsService.getGoodsListWithTag(49, null, 9, 0, 0, 0, "", "", 0, null, page);
            rList.add(this.buildOneCateData("49", "食品", foods));
            // 查询箱包列表
            List<GoodsDto> bags = goodsService.getGoodsListWithTag(46, null, 9, 0, 0, 0, "", "", 0, null, page);
            rList.add(this.buildOneCateData("46", "箱包", bags));	
            // 查询汽车列表
            List<CarDto> cars = carService.getAllHotCar(7, page, requestHeader.getPlatformType());
            rList.add(this.buildOneCateData("747", "汽车", cars));            
        } catch (WebRequestException e) {
        	rList.clear();
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
        	rList.clear();
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        result.put("list", rList);
        response.getResult().putAll(result);
        return response;
    }
    
    /**
     * 构建1个分类数据
     * @param categoryId
     * @param categoryName
     * @param data
     * @return
     */
    private Map<String, Object> buildOneCateData(String categoryId, String categoryName, List<?> data){
    	Map<String, Object> map = Maps.newHashMap();
    	map.put("categoryId", categoryId);
    	map.put("category", categoryName);
    	map.put("list", data);
    	return map;
    }
    
    /**
     * 首页配置分类
     * @Title: categoryhotData
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author liangdanhua 2016年9月18日 
     * @throws
     */
    @RequestMapping(value = "/categoryhotData", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto categoryhotData(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            List<O2oHotCategoryDto> o2oHotCategoryConfigList = homePageService.getCategoryhotData();
            result.put("list", o2oHotCategoryConfigList);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.info(e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

}
