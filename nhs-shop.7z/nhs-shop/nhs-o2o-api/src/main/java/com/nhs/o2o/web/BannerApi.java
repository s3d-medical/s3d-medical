package com.nhs.o2o.web;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Maps;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.core.web.WebController;
import com.nhs.core.web.WebExceptionCode;
import com.nhs.core.web.WebRequestException;
import com.nhs.core.web.dto.RequestHeader;
import com.nhs.core.web.dto.ResponseDto;
import com.nhs.shop.entry.legend.banner.Banner;
import com.nhs.shop.service.banner.BannerService;

/**
 * APP首页横幅广告
 * @Title: AppBannerApi.java
 * @Package com.nhs.o2o.web
 * @Description: TODO
 * @author liangdanhua
 * @date 2016年9月13日 下午4:33:31
 * @version V1.0
 */
@Controller
@RequestMapping(value = "/banner")
public class BannerApi extends WebController {

    private final Logger logger = LoggerFactory.getLogger(BannerApi.class);
    
    @Autowired
    private BannerService bannerService;

    private static String status = "";

    /**
     * 横幅广告列表
     * @Title: list
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author liangdanhua 2016年9月13日 
     * @throws
     */
    @RequestMapping(value = "/list", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto list(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            List<Banner> bannerList = bannerService.BannerList(status);
            result.put("bannerList", bannerList);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
            logger.error(e.getMessage());
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 添加
     * @Title: add
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年9月13日 
     * @throws
     */
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto add(RequestHeader requestHeader, @RequestBody Banner banner) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String isSave = bannerService.add(banner);
            result.put("isSave", isSave);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
            logger.error(e.getMessage());
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 删除
     * @Title: delete
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author liangdanhua 2016年9月13日 
     * @throws
     */
    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto delete(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            Integer brannerId = StringHelper.objectToInt(map.get("bannerId"), 0);
            bannerService.delete(brannerId);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
            logger.error(e.getMessage());
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 查找
     * @Title: find
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年9月13日 
     * @throws
     */
    @RequestMapping(value = "/find", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto find(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String title = StringHelper.objectToString(map.get("title"), "");
            List<Banner> banner = bannerService.find(title);
            result.put("banner", banner);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
            logger.error(e.getMessage());
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 更新
     * @Title: update
     * @Description: TODO
     * @param @param requestHeader
     * @param @param banner
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年9月13日 
     * @throws
     */
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto update(RequestHeader requestHeader, @RequestBody Banner banner) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String isSave = bannerService.update(banner);
            result.put("isSave", isSave);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
            logger.error(e.getMessage());
        }
        response.getResult().putAll(result);
        return response;
    }
}
