package com.nhs.o2o.web;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Maps;
import com.nhs.core.web.WebController;
import com.nhs.core.web.WebExceptionCode;
import com.nhs.core.web.WebRequestException;
import com.nhs.core.web.dto.RequestHeader;
import com.nhs.core.web.dto.ResponseDto;
import com.nhs.shop.entry.legend.investment.InvestmentInfo;
import com.nhs.shop.service.investment.InvestmentInfoService;

@Controller
@RequestMapping(value = "/investment")
public class InvestmentApi  extends WebController {
	private final Logger logger = LoggerFactory.getLogger(MemberApi.class);
	
	 @Autowired
	 private InvestmentInfoService infoService;
	
	@RequestMapping(value = "/saveInvestementInfo", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto saveInvestementInfo(HttpServletRequest request, RequestHeader requestHeader,
            @RequestBody InvestmentInfo info) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            infoService.saveInvestmentInfo(info);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

}
