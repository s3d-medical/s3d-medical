package com.nhs.o2o.bindspreader.web;


import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Maps;
import com.nhs.core.web.WebExceptionCode;
import com.nhs.core.web.WebRequestException;
import com.nhs.core.web.dto.ResponseDto;
import com.nhs.shop.bindspreader.dto.BindedSpreaderDto;
import com.nhs.shop.bindspreader.service.BindedSpreaderService;

/**
 * 绑定的推广代理商. 
 * @author wind.chen
 */
@Controller
@RequestMapping(value = "bindedSpreader")
public class BindedSpreaderController {
	private static final Logger logger = LoggerFactory.getLogger(BindedSpreaderController.class);

	private BindedSpreaderService bindedAgentService;

	@RequestMapping(value = "/v1.9.3/bindedSpreader/bind", method= RequestMethod.POST)
	@ResponseBody
	public ResponseDto saveOrUpdate(HttpServletRequest request, @RequestBody BindedSpreaderDto bindedSpreaderDto) {
		ResponseDto response = new ResponseDto(WebExceptionCode.NORMAL.errorCode,
				WebExceptionCode.NORMAL.errorMsg);
		try {
			boolean bindedResult = bindedAgentService.bindSpreader(bindedSpreaderDto);
			if (bindedResult) {
				return response;
			}
		} catch (WebRequestException e) {
			logger.error("errorMsg", e);
			response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
		} catch (Exception e) {
			logger.error("errorMsg", e);
			response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
		}
		Map<String, Object> result = Maps.newHashMap();
		response.getResult().putAll(result);
		return response;
	}

	@Autowired
	public void setBindedAgentService(BindedSpreaderService bindedAgentService) {
		this.bindedAgentService = bindedAgentService;
	}
}
