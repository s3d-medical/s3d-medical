package com.nhs.o2o.common;

import org.springframework.stereotype.Service;

@Service
public class DropdownListService {

}
