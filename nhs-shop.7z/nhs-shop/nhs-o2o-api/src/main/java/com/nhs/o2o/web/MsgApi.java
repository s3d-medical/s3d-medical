package com.nhs.o2o.web;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Maps;
import com.nhs.core.orm.Page;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.core.web.WebController;
import com.nhs.core.web.WebExceptionCode;
import com.nhs.core.web.WebRequestException;
import com.nhs.core.web.dto.RequestHeader;
import com.nhs.core.web.dto.ResponseDto;
import com.nhs.shop.entry.legend.shop.MsgText;
import com.nhs.shop.service.msg.MsgService;

/**
 * 消息处理
 * @Title: MsgApi.java
 * @Package com.nhs.o2o.web
 * @Description: TODO
 * @author Cary
 * @date 2016年8月24日 下午7:25:04
 * @version V1.0
 */
@Controller
@RequestMapping(value = "/msg")
public class MsgApi extends WebController {

    private final Logger logger = LoggerFactory.getLogger(MsgApi.class);

    @Autowired
    private MsgService msgService;

    /**
     * 查询用户未读短信条数
     * @Title: getUnReadMsgCount
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author Cary 2016年8月24日 
     * @throws
     */
    @RequestMapping(value = "/getUnReadMsgCount", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto getUnReadMsgCount(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String userName = StringHelper.objectToString(map.get("userName"), "");
            Integer count = msgService.getUnReadMsgCount(userName);
            result.put("count", count);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.info(e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 查询信息列表
     * @Title: getMsgList
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author Cary 2016年8月24日 
     * @throws
     */
    @RequestMapping(value = "/getMsgList", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto getMsgList(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            Integer pageNo = StringHelper.objectToInt(map.get("pageNo"), 0);
            Integer pageSize = StringHelper.objectToInt(map.get("pageSize"), 10);
            String userName = StringHelper.objectToString(map.get("userName"), "");
            Page<Map<String, Object>> page = createPage(pageNo, pageSize);
            List<Map<String, Object>> list = msgService.getMsgList(userName, page);
            result.put("list", list);
            result.put("totalCount", page.getTotalCount());
            result.put("totalPage", page.getTotalPage());
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.info(e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 读信息
     * @Title: readMsg
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author Cary 2016年8月24日 
     * @throws
     */
    @RequestMapping(value = "/readMsg", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto readMsg(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String userName = StringHelper.objectToString(map.get("userName"), "");
            Integer msgId = StringHelper.objectToInt(map.get("msgId"), 0);
            MsgText msgText = msgService.readMsg(userName, msgId);
            result.put("msgText", msgText);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.info(e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

}
