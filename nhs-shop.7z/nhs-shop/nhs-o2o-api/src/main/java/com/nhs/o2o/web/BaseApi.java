package com.nhs.o2o.web;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nhs.core.web.WebExceptionCode;
import com.nhs.core.web.WebRequestException;
import com.nhs.core.web.dto.ResponseDto;

public abstract class BaseApi implements ExceptionMapper<Throwable> {
    private static Logger logger = LoggerFactory.getLogger(BaseApi.class);

    @Override
    public Response toResponse(Throwable exception) {

        ResponseDto response = new ResponseDto(WebExceptionCode.DEFAULT_ERROR_MSG.errorCode,
                WebExceptionCode.DEFAULT_ERROR_MSG.errorMsg);
        WebExceptionCode exceptionCode = WebExceptionCode.SERVEREXCEPTION;
        String errorMsg = "";

        if (exception instanceof WebRequestException) {
            exceptionCode = ((WebRequestException) exception).getExceptionCode();
        } else if (exception.getCause() instanceof WebRequestException) {
            exceptionCode = ((WebRequestException) exception.getCause()).getExceptionCode();
            errorMsg = ((WebRequestException) exception.getCause()).getMessage();
        }

        if (StringUtils.isNotBlank(errorMsg)) {
            response.setErrorMsg(errorMsg);
        }

        if (null != exceptionCode) {
            response.setErrorCode(exceptionCode.errorCode);
            response.setErrorMsg(exceptionCode.errorMsg);
        }
        logger.error(response.getErrorMsg(), exception);
        return Response.ok(response).build();
    }

    public ResponseDto createNormalResponseDTO() {
        return new ResponseDto(WebExceptionCode.NORMAL.errorCode, WebExceptionCode.NORMAL.errorMsg);
    }

}
