package com.nhs.o2o.web;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Maps;
import com.nhs.core.orm.Page;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.core.web.WebController;
import com.nhs.core.web.WebExceptionCode;
import com.nhs.core.web.WebRequestException;
import com.nhs.core.web.dto.RequestHeader;
import com.nhs.core.web.dto.ResponseDto;
import com.nhs.shop.service.order.CarOrderService;
import com.nhs.shop.service.order.dto.CarOrderDetailDto;
import com.nhs.shop.service.order.dto.CarOrderListDto;
import com.nhs.shop.service.order.dto.OrderCommAddRequestDto;

/**
 * 汽车订单controller
 * 
 * @Title: HomePageApi.java
 * @Package com.nhs.o2o.web
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月16日 下午7:36:27
 * @version V1.0
 */
@Controller
@RequestMapping(value = "/carOrder")
public class CarOrderApi extends WebController {

    private final Logger logger = LoggerFactory.getLogger(CarOrderApi.class);

    @Autowired
    private CarOrderService carOrderService;

    /**
     * 创建订单
     * @Title: add
     * @Description: TODO
     * @param @param requestHeader
     * @param @param dto
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年7月20日 
     * @throws
     */
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto add(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            Map<String, Object> data = carOrderService.saveCarOrder(map, requestHeader.getPlatformType());
            result.putAll(data);
        } catch (WebRequestException e) {
            logger.error(e.getMessage(), e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 获取订单列表
     * @Title: add
     * @Description: TODO
     * @param @param requestHeader
     * @param @param dto
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年7月20日 
     * @throws
     */
    @RequestMapping(value = "/list", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto list(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String userId = StringHelper.objectToString(map.get("userId"), "");
            Integer status = StringHelper.objectToInt(map.get("status"), 0);
            Integer pageNo = StringHelper.objectToInt(map.get("pageNo"), 0);
            Integer pageSize = StringHelper.objectToInt(map.get("pageSize"), 0);
            Page<Map<String, Object>> page = createPage(pageNo, pageSize);
            List<CarOrderListDto> list = carOrderService.getOrderList(userId, status, page);
            result.put("list", list);
            result.put("totalCount", page.getTotalCount());
            result.put("totalPage", page.getTotalPage());
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.info(e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 获取订单详情
     * @Title: add
     * @Description: TODO
     * @param @param requestHeader
     * @param @param dto
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年7月20日 
     * @throws
     */
    @RequestMapping(value = "/detail", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto detail(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String userId = StringHelper.objectToString(map.get("userId"), "");
            Integer orderId = StringHelper.objectToInt(map.get("orderId"), 0);
            CarOrderDetailDto dto = carOrderService.getOrderDetail(userId, orderId);
            result.put("detail", dto);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.info(e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 订单操作
     * @Title: operate
     * @Description: TODO
     * @param @param requestHeader
     * @param @param dto
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年7月20日 
     * @throws
     */
    @RequestMapping(value = "/operate", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto operate(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String userId = StringHelper.objectToString(map.get("userId"), "");
            Integer orderId = StringHelper.objectToInt(map.get("orderId"), 0);
            String operate = StringHelper.objectToString(map.get("operate"), "");
            carOrderService.dealOrderOperate(userId, orderId, operate);
        } catch (WebRequestException e) {
            logger.error(e.getMessage(), e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 订单操作
     * @Title: add
     * @Description: TODO
     * @param @param requestHeader
     * @param @param dto
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年7月20日 
     * @throws
     */
    @RequestMapping(value = "/comment", method = RequestMethod.POST)
    @ResponseBody
    @Deprecated
    public ResponseDto comment(RequestHeader requestHeader, @RequestBody OrderCommAddRequestDto dto) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {

        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.info(e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 汽车订单信息核实提交
     * @Title: confirm
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author liangdanhua 2016年8月23日 
     * @throws
     */
    @RequestMapping(value = "/confirm", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto check(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String ordernum = StringHelper.objectToString(map.get("ordernum"), "");
            String userId = StringHelper.objectToString(map.get("userId"), "");
            result = carOrderService.confirm(userId, ordernum);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.info(e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

}
