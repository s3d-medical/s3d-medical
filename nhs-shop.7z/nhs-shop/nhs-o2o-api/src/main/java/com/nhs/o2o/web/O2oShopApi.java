package com.nhs.o2o.web;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.nhs.core.common.NhsConstant;
import com.nhs.core.context.SysPropsFactory;
import com.nhs.core.orm.Page;
import com.nhs.core.utils.common.BeanUtils;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.core.web.WebController;
import com.nhs.core.web.WebExceptionCode;
import com.nhs.core.web.WebRequestException;
import com.nhs.core.web.dto.RequestHeader;
import com.nhs.core.web.dto.ResponseDto;
import com.nhs.shop.entry.legend.shop.ShopCompanyDetail;
import com.nhs.shop.entry.legend.shop.ShopDetail;
import com.nhs.shop.service.shop.O2oShopService;
import com.nhs.shop.service.shop.dto.O2oCategoryDto;
import com.nhs.shop.service.shop.dto.O2oShopDetailDto;

/**
 * O2O商家API
 * @Title: O2oShopApi.java
 * @Package com.nhs.o2o.web
 * @Description: TODO
 * @author Cary
 * @date 2016年8月28日 下午7:25:04
 * @version V1.0
 */
@Controller
@RequestMapping(value = "/o2oShop")
public class O2oShopApi extends WebController {

    private final Logger logger = LoggerFactory.getLogger(O2oShopApi.class);

    @Autowired
    private O2oShopService o2oShopService;

    /**
     * 商家详情
     * @Title: seller
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author liangdanhua 2016年8月27日 
     * @throws
     */
    @RequestMapping(value = "/shopDetail", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto sellerDetail(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            Integer shopId = StringHelper.objectToInt(map.get("shopId"), 0); // O2O商家ID
            String userId = StringHelper.objectToString(map.get("userId"), "");
            if (StringUtils.isNotBlank(userId)) {
            	try {
					o2oShopService.buildGoodsHistory(shopId, userId);
				} catch (Exception e) {
					logger.error("创建浏览记录失败！");
				}
            }
            O2oShopDetailDto detail = o2oShopService.getO2oShopDetail(shopId, userId);
            Map<String, Object> returnMap = BeanUtils.bean2map(detail);
            if(StringUtils.isEmpty(detail.getReduce())){
            	returnMap.put("discountStr", "");
            }else{
            	String reduceFont = SysPropsFactory.getProperty(NhsConstant.SYS_CONSUME_REDUCE_FONT);
            	if(StringUtils.isEmpty(reduceFont)){
            		returnMap.put("discountStr", "");
            	}else{
            		reduceFont = reduceFont.replace("#", new BigDecimal(detail.getReduce()).multiply(new BigDecimal("100")).setScale(0, BigDecimal.ROUND_DOWN) + "%");
            		returnMap.put("discountStr", reduceFont);
            	}
            }
            String couponFont = SysPropsFactory.getProperty(NhsConstant.SYS_COUPON_FONT);
        	if(StringUtils.isEmpty(couponFont)){
        		returnMap.put("couponStr", "");
        	}else{
        		couponFont = couponFont.replace("#", detail.getSubsidy());
        		returnMap.put("couponStr", couponFont);
        	}
            result.put("detail", returnMap);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 保存企业信息
     * @Title: sellerDetail
     * @Description: TODO
     * @param @param requestHeader
     * @param @param shopCompanyDetail
     * @param @return   
     * @return ResponseDto 
     * @author zhujun 2016年8月30日 
     * @throws
     */
    @ResponseBody
    @RequestMapping(value = "/saveCertificateInfo", method = RequestMethod.POST)
    public ResponseDto sellerDetail(RequestHeader requestHeader, @RequestBody ShopCompanyDetail newShopCompanyDetail) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String flg = o2oShopService.saveCertificate(newShopCompanyDetail);
            result.put("result", flg);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
            result.put("result", "0");
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
            result.put("result", "0");
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 保存商家信息
     * @Title: saveShopInfo
     * @Description: TODO
     * @param @param requestHeader
     * @param @param newshopDetail
     * @param @return   
     * @return ResponseDto 
     * @author zhujun 2016年8月31日 
     * @throws
     */
    @ResponseBody
    @RequestMapping(value = "/saveShopInfo", method = RequestMethod.POST)
    public ResponseDto saveShopInfo(RequestHeader requestHeader, @RequestBody ShopDetail newShopDetail) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String flg = o2oShopService.saveShopDetailInfo(newShopDetail);
            result.put("result", flg);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
            result.put("result", "0");
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
            result.put("result", "0");
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 修改商家信息
     * @Title: updateShopInfo
     * @Description: TODO
     * @param @param requestHeader
     * @param @param newshopDetail
     * @param @return   
     * @return ResponseDto 
     * @author zhujun 2016年11月14日 
     * @throws
     */
    @ResponseBody
    @RequestMapping(value = "/updateShopInfo", method = RequestMethod.POST)
    public ResponseDto updateShopInfo(RequestHeader requestHeader, @RequestBody ShopDetail newShopDetail) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String shopId = o2oShopService.updateShopInfo(newShopDetail);
            result.put("shopId", shopId);
            result.put("result", "1");
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
            result.put("result", "0");
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
            result.put("result", "0");
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 保存联系人信息
     * @Title: saveContactInfo
     * @Description: TODO
     * @param @param requestHeader
     * @param @param newshopDetail
     * @param @return   
     * @return ResponseDto 
     * @author zhujun 2016年8月31日 
     * @throws
     */
    @ResponseBody
    @RequestMapping(value = "/saveContactInfo", method = RequestMethod.POST)
    public ResponseDto saveContactInfo(RequestHeader requestHeader, @RequestBody ShopDetail newShopDetail) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String shopId = o2oShopService.saveContact(newShopDetail);
            result.put("shopId", shopId);
            result.put("result", "1");
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
            result.put("result", "0");
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
            result.put("result", "0");
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * o2o店铺配置
     * @Title: saveO2oShop
     * @Description: TODO
     * @param @param requestHeader
     * @param @param 
     * @param @return   
     * @return ResponseDto 
     * @author zhujun 2016年11月23日 
     * @throws
     */
    @ResponseBody
    @RequestMapping(value = "/saveO2oShop", method = RequestMethod.POST)
    public ResponseDto saveO2oShop(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            int shopId = StringHelper.objectToInt(map.get("shopId"), 0);
            String contactTel = StringHelper.objectToString(map.get("contactTel"), "");
            String contactTelSecond = StringHelper.objectToString(map.get("contactTelSecond"), "");
            String detailDesc = StringHelper.objectToString(map.get("detailDesc"), "");
            BigDecimal perCost = StringHelper.objectToBigDecimal(map.get("perCost"), "0");
            String smsPhone = StringHelper.objectToString(map.get("smsPhone"), "");
            String serviceTime = StringHelper.objectToString(map.get("serviceTime"), "");
            String installation = StringHelper.objectToString(map.get("installation"), "");
            String story = StringHelper.objectToString(map.get("story"), "");
            o2oShopService.saveO2oShop(shopId, contactTel, contactTelSecond, detailDesc, perCost, smsPhone, serviceTime,
                    installation, story);
            result.put("result", "1");
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
            result.put("result", "0");
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
            result.put("result", "0");
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 保存环境、特色、活动图片
     * @Title: saveO2oPics
     * @Description: TODO
     * @param @param requestHeader
     * @param @param 
     * @param @return   
     * @return ResponseDto 
     * @author zhujun 2016年11月24日 
     * @throws
     */
    @ResponseBody
    @RequestMapping(value = "/saveO2oPics", method = RequestMethod.POST)
    public ResponseDto saveO2oPics(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            int shopId = StringHelper.objectToInt(map.get("shopId"), 0);
            String pictures = StringHelper.objectToString(map.get("pictures"), "");
            o2oShopService.saveO2oPics(shopId, pictures);
            result.put("result", "1");
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
            result.put("result", "0");
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
            result.put("result", "0");
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 获取商家列表
     * @Title: seller
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author zhujun 2016年8月31日 
     * @throws
     */
    @RequestMapping(value = "/checkedShop", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto checkShopList(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        List<Map<String, Object>> list = Lists.newArrayList();
        try {
            String fromDate = StringHelper.objectToString(map.get("fromDate"), "");
            String toDate = StringHelper.objectToString(map.get("toDate"), "");
            String provinceId = StringHelper.objectToString(map.get("provinceId"), "");
            String cityId = StringHelper.objectToString(map.get("cityId"), "");
            String areaIds = StringHelper.objectToString(map.get("areaId"), "");
            String shopIds = StringHelper.objectToString(map.get("shopId"), "");
            String siteName = StringHelper.objectToString(map.get("siteName"), "");
            String shopState = StringHelper.objectToString(map.get("shop_state"), "");
            String agentState = StringHelper.objectToString(map.get("agent_state"), "");
            String status = StringHelper.objectToString(map.get("status"), "");
            String contactName = StringHelper.objectToString(map.get("contactName"), "");
            String contactMobile = StringHelper.objectToString(map.get("contactMobile"), "");
            int pageNo = StringHelper.objectToInt(map.get("pageNo"), 0);
            int pageSize = StringHelper.objectToInt(map.get("pageSize"), 20);
            int shopSystem = StringHelper.objectToInt(map.get("shopSystem"), 0);
            int whiteList = StringHelper.objectToInt(map.get("whiteList"), 0);
            String agentDetail = StringHelper.objectToString(map.get("agent"), "");
            String nickName = StringHelper.objectToString(map.get("nickName"), "");
            String shopType = StringHelper.objectToString(map.get("shopType"), "");
            String userMobile = StringHelper.objectToString(map.get("userMobile"), "");
            Page<Map<String, Object>> page = createPage(pageNo, pageSize);

            page = o2oShopService.checkShopList(fromDate, toDate, provinceId, cityId, areaIds, shopIds, siteName,
                    shopState, agentState, status, shopSystem, page, contactName, contactMobile, whiteList, agentDetail,
                    nickName, shopType, userMobile);
            list = page.getResult();
            result.put("list", list);
            result.put("pageNo", pageNo);
            result.put("pageSize", page.getPageSize());
            result.put("totalPage", page.getTotalPage());
            result.put("totalCount", page.getTotalCount());

        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 获取商家详细信息
     * @Title: seller
     * @Description: TODO
     * @param @param requestHeader
     * @param @param String
     * @param @return   
     * @return ResponseDto 
     * @author zhujun 2016年8月31日 
     * @throws
     */
    @RequestMapping(value = "/lsShopDetail", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto getShopDetail(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String shopId = StringHelper.objectToString(map.get("shopId"), "");
            result = o2oShopService.shopDetail(shopId);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 更新审核结果
     * @Title: seller
     * @Description: TODO
     * @param @param requestHeader
     * @param @param String
     * @param @return   
     * @return ResponseDto 
     * @author zhujun 2016年8月31日 
     * @throws
     */
    @RequestMapping(value = "/updateShopStatus", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto updateShopStatus(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        Map<String, Object> result = Maps.newHashMap();
        ResponseDto response = new ResponseDto();
        try {
            String shopId = StringHelper.objectToString(map.get("shopId"), "");
            String status = StringHelper.objectToString(map.get("status"), "");
            String reason = StringHelper.objectToString(map.get("reason"), "");
            String transfer = StringHelper.objectToString(map.get("transfer"), "");
            BigDecimal adFeeRate = StringHelper.objectToBigDecimal(map.get("adFeeRate"), "0.16");
            o2oShopService.updateShopStatus(shopId, status, reason, transfer, adFeeRate);
            result.put("result", "1");
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            result.put("result", "0");
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
            result.put("result", "0");
        }

        response.getResult().putAll(result);
        return response;
    }

    /**
     * 获取商家订单列表
     * @Title: seller
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author zhujun 2016年8月31日 
     * @throws
     */
    @RequestMapping(value = "/shopOrderList", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto shopOrderList(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String fromDate = StringHelper.objectToString(map.get("fromDate"), "");
            String toDate = StringHelper.objectToString(map.get("toDate"), "");
            String provinceId = StringHelper.objectToString(map.get("provinceId"), "");
            String cityId = StringHelper.objectToString(map.get("cityId"), "");
            String areaIds = StringHelper.objectToString(map.get("areaId"), "");
            String shopIds = StringHelper.objectToString(map.get("shopId"), "");
            String orderNum = StringHelper.objectToString(map.get("orderNum"), "");
            String agentState = StringHelper.objectToString(map.get("agent_state"), "");
            int pageNo = StringHelper.objectToInt(map.get("pageNo"), 0);
            int pageSize = StringHelper.objectToInt(map.get("pageSize"), 20);

            if (pageNo == -1) {
                pageNo = 0;
                pageSize = Integer.MAX_VALUE;
            }
            Page<Map<String, Object>> page = createPage(pageNo, pageSize);

            result = o2oShopService.shopOrderList(fromDate, toDate, provinceId, cityId, areaIds, shopIds, orderNum,
                    agentState, page);

        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 移交店铺
     * @Title: seller
     * @Description: TODO
     * @param @param requestHeader
     * @param @param String
     * @param @return   
     * @return ResponseDto 
     * @author zhujun 2016年8月31日 
     * @throws
     */
    @RequestMapping(value = "/transferShop", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto transferShop(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        Map<String, Object> result = Maps.newHashMap();
        ResponseDto response = new ResponseDto();
        try {
            String shopIds = StringHelper.objectToString(map.get("shopId"), "");
            String transfer = StringHelper.objectToString(map.get("transfer"), "");
            o2oShopService.transferShop(shopIds, transfer);
            result.put("result", "1");
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            result.put("result", "0");
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
            result.put("result", "0");
        }

        response.getResult().putAll(result);
        return response;
    }

    /**
     * 获取o2o店铺主营范围
     * @Title: seller
     * @Description: TODO
     * @param @param requestHeader
     * @param @param String
     * @param @return   
     * @return ResponseDto 
     * @author zhujun 2016年9月5日 
     * @throws
     */
    @RequestMapping(value = "/o2oCategory", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto o2oCategory(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        Map<String, Object> result = Maps.newHashMap();
        Map<Integer, Object> cateMap = Maps.newHashMap();
        ResponseDto response = new ResponseDto();
        try {
            int parentId = StringHelper.objectToInt(map.get("parentId"), -1);
            cateMap = o2oShopService.getO2oCategory(parentId);
            result.put("map", cateMap);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }

        response.getResult().putAll(result);
        return response;
    }

    /**
     * 获取商城店铺主营范围
     * @Title: seller
     * @Description: TODO
     * @param @param requestHeader
     * @param @param String
     * @param @return   
     * @return ResponseDto 
     * @author zhujun 2016年11月18日 
     * @throws
     */
    @RequestMapping(value = "/shopCategory", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto shopCategory(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        Map<String, Object> result = Maps.newHashMap();
        Map<Integer, Object> cateMap = Maps.newHashMap();
        ResponseDto response = new ResponseDto();
        try {
            int parentId = StringHelper.objectToInt(map.get("parentId"), -1);
            cateMap = o2oShopService.shopCategory(parentId);
            result.put("map", cateMap);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }

        response.getResult().putAll(result);
        return response;
    }

    /**
     * 判断多个商铺是否属于同一地区
     * @Title: judgeArea
     * @Description: TODO
     * @param @param requestHeader
     * @param @param String[]
     * @param @return   
     * @return ResponseDto 
     * @author zhujun 2016年9月6日 
     * @throws
     */
    @RequestMapping(value = "/judgeArea", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto judgeArea(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        Map<String, Object> result = Maps.newHashMap();
        ResponseDto response = new ResponseDto();
        try {
            String shopIds = StringHelper.objectToString(map.get("shopId"), "");
            String areaId = o2oShopService.getJudgeArea(shopIds);
            result.put("result", areaId);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }

        response.getResult().putAll(result);
        return response;
    }

    /**
     * 获取地区列表
     * @Title: seller
     * @Description: TODO
     * @param @param requestHeader
     * @param @param String
     * @param @return   
     * @return ResponseDto 
     * @author zhujun 2016年9月7日 
     * @throws
     */
    @RequestMapping(value = "/getArea", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto getArea(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        Map<String, Object> result = Maps.newHashMap();
        Map<Integer, Object> areaMap = Maps.newHashMap();
        ResponseDto response = new ResponseDto();
        try {
            int id = StringHelper.objectToInt(map.get("id"), -1);
            int level = StringHelper.objectToInt(map.get("level"), 0);
            areaMap = o2oShopService.getArea(id, level);
            result.put("map", areaMap);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }

        response.getResult().putAll(result);
        return response;
    }

    /**
     * 获取省市区的名称
     * @Title: seller
     * @Description: TODO
     * @param @param requestHeader
     * @param @param String
     * @param @return   
     * @return ResponseDto 
     * @author zhujun 2016年9月7日 
     * @throws
     */
    @RequestMapping(value = "/getAreaName", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto getAreaName(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        Map<String, Object> result = Maps.newHashMap();
        Map<Integer, Object> areaMap = Maps.newHashMap();
        ResponseDto response = new ResponseDto();
        try {
            String ids = StringHelper.objectToString(map.get("id"), "");
            int level = StringHelper.objectToInt(map.get("level"), 0);
            areaMap = o2oShopService.getAreaName(ids, level);
            result.put("map", areaMap);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }

        response.getResult().putAll(result);
        return response;
    }

    /**
     * 更新代理状态
     * @Title: updateAgentState
     * @Description: TODO
     * @param @param requestHeader
     * @param @param String
     * @param @return   
     * @return ResponseDto 
     * @author zhujun 2016年9月7日 
     * @throws
     */
    @RequestMapping(value = "/updateAgentState", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto updateAgentState(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        Map<String, Object> result = Maps.newHashMap();
        ResponseDto response = new ResponseDto();
        try {
            String shopIds = StringHelper.objectToString(map.get("shopId"), "");
            o2oShopService.updateAgentState(shopIds);
            result.put("result", "1");
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            result.put("result", "0");
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
            result.put("result", "0");
        }

        response.getResult().putAll(result);
        return response;
    }

    /**
     * 获取nhs_agent_admin所有数据
     * @Title: seller
     * @Description: TODO
     * @param @param requestHeader
     * @param @param String
     * @param @return   
     * @return ResponseDto 
     * @author zhujun 2016年9月7日 
     * @throws
     */
    @RequestMapping(value = "/getAgentAdmin", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto getAgentAdmin(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        Map<String, Object> result = Maps.newHashMap();
        List<Map<String, Object>> list = Lists.newArrayList();
        ResponseDto response = new ResponseDto();
        try {
            list = o2oShopService.getAgentAdmin();
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        result.put("list", list);
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 根据手机号判断是否开店
     * @Title: judgeShopByPhone
     * @Description: TODO
     * @param @param requestHeader
     * @param @param String
     * @param @return   
     * @return ResponseDto 
     * @author zhujun 2016年9月7日 
     * @throws
     */
    @RequestMapping(value = "/judgeShopByPhone", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto judgeShopByPhone(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        Map<String, Object> result = Maps.newHashMap();
        String phone = StringHelper.objectToString(map.get("phone"), "");
        ResponseDto response = new ResponseDto();
        try {
            Map<String, Object> resultMap = o2oShopService.judgeShopByPhone(phone);
            result.putAll(resultMap);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 更新广告费率
     * @Title: seller
     * @Description: TODO
     * @param @param requestHeader
     * @param @param String
     * @param @return   
     * @return ResponseDto 
     * @author zhujun 2016年10月26日 
     * @throws
     */
    @RequestMapping(value = "/updateAdRate", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto updateAdRate(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        Map<String, Object> result = Maps.newHashMap();
        ResponseDto response = new ResponseDto();
        try {
            String shopId = StringHelper.objectToString(map.get("shopId"), "");
            BigDecimal adFeeRate = StringHelper.objectToBigDecimal(map.get("adFeeRate"), "0.16");
            int coinSwitch = StringHelper.objectToInt(map.get("coinSwitch"), 0);
            o2oShopService.updateAdRate(shopId, adFeeRate, coinSwitch);
            result.put("result", "1");
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            result.put("result", "0");
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
            result.put("result", "0");
        }

        response.getResult().putAll(result);
        return response;
    }

    /**
     * 更改黑白名单
     * @Title: seller
     * @Description: TODO
     * @param @param requestHeader
     * @param @param String
     * @param @return   
     * @return ResponseDto 
     * @author zhujun 2016年10月26日 
     * @throws
     */
    @RequestMapping(value = "/updateWhiteList", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto updateWhiteList(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        Map<String, Object> result = Maps.newHashMap();
        ResponseDto response = new ResponseDto();
        try {
            String shopId = StringHelper.objectToString(map.get("shopId"), "");
            int whiteList = StringHelper.objectToInt(map.get("whiteList"), 0);
            o2oShopService.updateWhiteList(shopId, whiteList);
            result.put("result", "1");
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            result.put("result", "0");
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
            result.put("result", "0");
        }

        response.getResult().putAll(result);
        return response;
    }

    /**
     * 获取ls_category表的一级目录
     * @Title: seller
     * @Description: TODO
     * @param @param requestHeader
     * @param @param String
     * @param @return   
     * @return ResponseDto 
     * @author zhujun 2016年9月5日 
     * @throws
     */
    @RequestMapping(value = "/lsCategory", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto lsCategory(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        Map<String, Object> result = Maps.newHashMap();
        Map<Integer, Object> cateMap = Maps.newHashMap();
        ResponseDto response = new ResponseDto();
        try {
            cateMap = o2oShopService.lsCategory();
            result.put("map", cateMap);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }

        response.getResult().putAll(result);
        return response;
    }

    /**
     * 批量更改商家银币返还开关
     * @Title: seller
     * @Description: TODO
     * @param @param requestHeader
     * @param @param String
     * @param @return   
     * @return ResponseDto 
     * @author zhujun 2016年10月26日 
     * @throws
     */
    @RequestMapping(value = "/updateBatchCoin", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto updateBatchCoin(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        Map<String, Object> result = Maps.newHashMap();
        ResponseDto response = new ResponseDto();
        try {
            String category = StringHelper.objectToString(map.get("category"), "");
            int shopSystem = StringHelper.objectToInt(map.get("shopSystem"), 0);
            int coinSwitch = StringHelper.objectToInt(map.get("coinSwitch"), 0);
            o2oShopService.updateBatchCoin(category, shopSystem, coinSwitch);
            result.put("result", "1");
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            result.put("result", "0");
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
            result.put("result", "0");
        }

        response.getResult().putAll(result);
        return response;
    }

    /**
     * 根据省获取所有的市和区
     * @Title: seller
     * @Description: TODO
     * @param @param requestHeader
     * @param @param String
     * @param @return   
     * @return ResponseDto 
     * @author zhujun 2016年11月10日 
     * @throws
     */
    @RequestMapping(value = "/getAllAreas", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto getAllAreas(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        Map<String, Object> result = Maps.newHashMap();
        ResponseDto response = new ResponseDto();
        List<Map<String, Object>> list = Lists.newArrayList();
        try {
            String provinceIds = StringHelper.objectToString(map.get("provinceId"), "");
            list = o2oShopService.getAllAreas(provinceIds);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
            logger.error("errorMsg", e);
        }
        result.put("result", list);
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 检测店铺名称是否唯一
     * @Title: checkShopName
     * @Description: TODO
     * @param @param requestHeader
     * @param @param String
     * @param @return   
     * @return ResponseDto 
     * @author zhujun 2016年11月21日 
     * @throws
     */
    @RequestMapping(value = "/checkShopName", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto checkShopName(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        Map<String, Object> result = Maps.newHashMap();
        ResponseDto response = new ResponseDto();
        String flag = "";
        try {
            String siteName = StringHelper.objectToString(map.get("siteName"), "");
            flag = o2oShopService.checkShopName(siteName);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
            logger.error("errorMsg", e);
        }
        result.put("result", flag);
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 商家分析统计
     * @Title: seller
     * @Description: TODO
     * @param @param requestHeader
     * @param @param String
     * @param @return   
     * @return ResponseDto 
     * @author zhujun 2016年11月21日 
     * @throws
     */
    @RequestMapping(value = "/shopAnalyse", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto shopAnalyse(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        Map<String, Object> result = Maps.newHashMap();
        ResponseDto response = new ResponseDto();
        try {
            String shopIds = StringHelper.objectToString(map.get("shopId"), "");
            result = o2oShopService.shopAnalyse(shopIds);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }

        response.getResult().putAll(result);
        return response;
    }

    /**
     * 订单分析统计
     * @Title: seller
     * @Description: TODO
     * @param @param requestHeader
     * @param @param String
     * @param @return   
     * @return ResponseDto 
     * @author zhujun 2016年11月21日 
     * @throws
     */
    @RequestMapping(value = "/orderAnalyse", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto orderAnalyse(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        Map<String, Object> result = Maps.newHashMap();
        ResponseDto response = new ResponseDto();
        try {
            String shopIds = StringHelper.objectToString(map.get("shopId"), "");
            result = o2oShopService.orderAnalyse(shopIds);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }

        response.getResult().putAll(result);
        return response;
    }
    
    /**
     * 获取全部分类
     * @Title: seller
     * @Description: TODO
     * @param @param requestHeader
     * @param @param String
     * @param @return   
     * @return ResponseDto 
     * @author guangrong
     * @throws
     */
    @RequestMapping(value = "/o2oAllCategory", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto o2oAllCategory(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        Map<String, Object> result = Maps.newHashMap();
        List<O2oCategoryDto> categoryDtoList = new ArrayList<>();
        ResponseDto response = new ResponseDto();
        try {
            categoryDtoList = o2oShopService.getO2oAllCategory();
            result.put("categoryList", categoryDtoList);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }

        response.getResult().putAll(result);
        return response;
    }

    @RequestMapping(value = "/o2oAddCategory", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto o2oAddCategory(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        Map<String, Object> result = Maps.newHashMap();
        ResponseDto response = new ResponseDto();
        try {
            int parentId = StringHelper.objectToInt(map.get("parentId"), 0);
            String categoryName = StringHelper.objectToString(map.get("categoryName"), "");
            int categoryId = StringHelper.objectToInt(map.get("categoryId"), 0);
            int sort = StringHelper.objectToInt(map.get("sort"), 0);

            o2oShopService.addCategory(parentId, categoryName, categoryId, sort);

        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }

        response.getResult().putAll(result);
        return response;
    }

    @RequestMapping(value = "/o2oDeleteCategory", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto o2odeleteCategory(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        Map<String, Object> result = Maps.newHashMap();
        ResponseDto response = new ResponseDto();
        try {
            int categoryId = StringHelper.objectToInt(map.get("categoryId"), 0);

            o2oShopService.deleteCategory(categoryId);

        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }

        response.getResult().putAll(result);
        return response;
    }

    @RequestMapping(value = "/v1.9/judgeCollection", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto judgeCollection(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        Map<String, Object> result = Maps.newHashMap();
        ResponseDto response = new ResponseDto();
        try {
            String type = StringHelper.objectToString(map.get("type"), "");
            String userId = StringHelper.objectToString(map.get("userId"), "");

            Integer id = StringHelper.objectToInt(map.get("id"), 0);
            String judge = o2oShopService.judgeCollection(type, id, userId);
            result.put("result", judge);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }

        response.getResult().putAll(result);
        return response;
    }
    
    /**
     * 商家详情
     * @Title: seller
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author Li Guangrong 2016年8月27日 
     * @throws
     */
    @RequestMapping(value = "/v1.9.3/shopDetail", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto shopDetail(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            Integer shopId = StringHelper.objectToInt(map.get("shopId"), 0); // O2O商家ID
            String userId = StringHelper.objectToString(map.get("userId"), "");
            if (StringUtils.isNotBlank(userId)) {
            	try {
					o2oShopService.buildGoodsHistory(shopId, userId);
				} catch (Exception e) {
					logger.error("创建浏览记录失败！");
				}
            }
            O2oShopDetailDto detail = o2oShopService.getShopDetail(shopId, userId);
            Map<String, Object> returnMap = BeanUtils.bean2map(detail);
            if(StringUtils.isEmpty(detail.getReduce())){
            	returnMap.put("discountStr", "");
            }else{
            	String reduceFont = SysPropsFactory.getProperty(NhsConstant.SYS_CONSUME_REDUCE_FONT);
            	if(StringUtils.isEmpty(reduceFont)){
            		returnMap.put("discountStr", "");
            	}else{
            		reduceFont = reduceFont.replace("#", new BigDecimal(detail.getReduce()).multiply(new BigDecimal("100")).setScale(0, BigDecimal.ROUND_DOWN) + "%");
            		returnMap.put("discountStr", reduceFont);
            	}
            }
            String couponFont = SysPropsFactory.getProperty(NhsConstant.SYS_COUPON_FONT);
        	if(StringUtils.isEmpty(couponFont)){
        		returnMap.put("couponStr", "");
        	}else{
        		couponFont = couponFont.replace("#", detail.getSubsidy());
        		returnMap.put("couponStr", couponFont);
        	}
            result.put("detail", returnMap);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

}
