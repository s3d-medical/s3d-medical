package com.nhs.o2o.web;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Maps;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.core.web.WebController;
import com.nhs.core.web.WebExceptionCode;
import com.nhs.core.web.WebRequestException;
import com.nhs.core.web.dto.RequestHeader;
import com.nhs.core.web.dto.ResponseDto;
import com.nhs.shop.service.areas.AreasService;

/**
 * 
 * @Title: AreasApi.java
 * @Package com.nhs.o2o.web
 * @Description: TODO
 * @author liangdanhua
 * @date 2016年10月25日 下午6:42:10
 * @version V1.0
 */
@Controller
@RequestMapping(value = "/areas")
public class AreasApi extends WebController {

    private final Logger logger = LoggerFactory.getLogger(AreasApi.class);

    @Autowired
    private AreasService areasService;

    /**
     * 查询所有省份
     * @Title: queryProvinces
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author liangdanhua 2016年10月26日 
     * @throws
     */
    @RequestMapping(value = "/v1.9/provinces", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto queryProvinces(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            result.put("result", areasService.queryProvinces());
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 根据省份查询所有的城市
     * @Title: queryCitys
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author liangdanhua 2016年10月26日 
     * @throws
     */
    @RequestMapping(value = "/v1.9/citys", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto queryCitys(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            Integer provinceId = StringHelper.objectToInt(map.get("provinceId"), 0);
            result.put("result", areasService.queryCitysByProvince(provinceId));
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 根据城市查询所有的区
     * @Title: queryAreas
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author liangdanhua 2016年10月26日 
     * @throws
     */
    @RequestMapping(value = "/v1.9/areas", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto queryAreas(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            Integer cityId = StringHelper.objectToInt(map.get("cityId"), 0);
            result.put("result", areasService.queryAreasByCity(cityId));
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
            logger.error(e.getMessage());
        }
        response.getResult().putAll(result);
        return response;
    }
}
