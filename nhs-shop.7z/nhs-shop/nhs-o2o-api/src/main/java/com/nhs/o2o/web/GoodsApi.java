package com.nhs.o2o.web;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Maps;
import com.nhs.core.orm.Page;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.core.web.WebController;
import com.nhs.core.web.WebExceptionCode;
import com.nhs.core.web.WebRequestException;
import com.nhs.core.web.dto.RequestHeader;
import com.nhs.core.web.dto.ResponseDto;
import com.nhs.shop.service.goods.GoodsService;
import com.nhs.shop.service.goods.dto.GoodsDetailDto;
import com.nhs.shop.service.goods.dto.GoodsDto;

/**
 * 商品controller
 * @Title: GoodsApi.java
 * @Package com.nhs.o2o.web
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月16日 下午7:25:04
 * @version V1.0
 */
@Controller
@RequestMapping(value = "/goods")
public class GoodsApi extends WebController {

    private final Logger logger = LoggerFactory.getLogger(GoodsApi.class);

    @Autowired
    private GoodsService goodsService;

    /**
     * 获取商品列表
     * @Title: list
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年7月17日 
     * @throws
     */
    @RequestMapping(value = "/list", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto list(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        // TODO liangdanhua 添加logger日记
        logger.info("********************开始执行GoodsApi/goods/list**************");
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            Integer categoryId = StringHelper.objectToInt(map.get("categoryId"), 0);
            String keyword = StringHelper.objectToString(map.get("keyword"), "");
            Integer sortType = StringHelper.objectToInt(map.get("sortType"), 0);
            Integer serve = StringHelper.objectToInt(map.get("serve"), 0);
            Integer beginPrice = StringHelper.objectToInt(map.get("beginPrice"), 0);
            Integer endPrice = StringHelper.objectToInt(map.get("endPrice"), 0);
            String address = StringHelper.objectToString(map.get("address"), "");
            String area = StringHelper.objectToString(map.get("area"), "");
            Integer provinceId = StringHelper.objectToInt(map.get("provinceId"), 0);
            Integer pageNo = StringHelper.objectToInt(map.get("pageNo"), 0);
            Integer pageSize = StringHelper.objectToInt(map.get("pageSize"), 0);
            // TODO liangdanhua 返回真实的邮费
            String userId = StringHelper.objectToString(map.get("userId"), "");
            Page<Map<String, Object>> page = createPage(pageNo, pageSize);
            @SuppressWarnings("deprecation")
            List<GoodsDto> list = goodsService.getGoodsList(categoryId, keyword, sortType, serve, beginPrice, endPrice,
                    address, area, provinceId, userId, page);
            result.put("list", list);
            result.put("totalCount", page.getTotalCount());
            result.put("totalPage", page.getTotalPage());
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        logger.info("********************GoodsApi/goods/list结束**************");
        return response;
    }

    /**
     * 获取商品详情
     * @Title: detail
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年7月17日 
     * @throws
     */
    @RequestMapping(value = "/detail", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto detail(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            Integer prodId = StringHelper.objectToInt(map.get("prodId"), 0); // 商品ID
            Integer cityId = StringHelper.objectToInt(map.get("cityId"), 247); // 城市ID
            String userId = StringHelper.objectToString(map.get("userId"), "");
            GoodsDetailDto detail = goodsService.getGoodsDetail(prodId, cityId, userId);
            // 构建浏览记录
            if (StringUtils.isNotBlank(userId)) {
            	try{
            		goodsService.buildGoodsHistory(prodId, cityId, userId);
            	}catch(Exception e){
            		logger.error("创建浏览记录失败",e);
            	}
            }
            result.put("detail", detail);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 获取商品sku
     * @Title: detail
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年7月17日 
     * @throws
     */
    @RequestMapping(value = "/sku", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto sku(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            Integer prodId = StringHelper.objectToInt(map.get("prodId"), 0); // 商品ID
            Integer skuId = StringHelper.objectToInt(map.get("skuId"), 0); // skuID
            Map<String, Object> sku = goodsService.getGoodsSku(prodId, skuId);
            result.putAll(sku);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 热门搜索
     * @Title: hot
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author liangdanhua 2016年8月10日 
     * @throws
     */
    @RequestMapping(value = "/hot", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto hot(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            List<Map<String, Object>> list = goodsService.getHotGoodsList();
            result.put("list", list);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }
}
