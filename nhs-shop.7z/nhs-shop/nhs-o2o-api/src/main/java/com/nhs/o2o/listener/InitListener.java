/**
 * 2013-7-10
 * kl-base
 */
package com.nhs.o2o.listener;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * @author Administrator
 * 
 */
@Service
public class InitListener implements ServletContextListener {
	private static Logger logger = LoggerFactory.getLogger(InitListener.class);

	public InitListener() {
		
	}

	/* (non-Javadoc)
	 * @see javax.servlet.ServletContextListener#contextInitialized(javax.servlet.ServletContextEvent)
	 */
	@Override
	public void contextInitialized(ServletContextEvent sce) {
		try {
    		System.err.println("初始化完毕");
        } catch (Exception e) {
            
        } finally {
            logger.debug("end");
        }
	}

	/* (non-Javadoc)
	 * @see javax.servlet.ServletContextListener#contextDestroyed(javax.servlet.ServletContextEvent)
	 */
	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		// TODO Auto-generated method stub
		
	}

	
}
