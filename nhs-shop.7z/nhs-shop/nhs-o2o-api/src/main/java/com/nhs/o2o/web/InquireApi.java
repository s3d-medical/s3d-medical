package com.nhs.o2o.web;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Maps;
import com.nhs.core.web.WebController;
import com.nhs.core.web.WebExceptionCode;
import com.nhs.core.web.WebRequestException;
import com.nhs.core.web.dto.RequestHeader;
import com.nhs.core.web.dto.ResponseDto;
import com.nhs.shop.entry.legend.shop.Advertising;
import com.nhs.shop.entry.legend.shop.Inquire;
import com.nhs.shop.service.shop.InquireService;

/**
 * 回访内容API
 * @Title: InquireApi.java
 * @Package com.nhs.o2o.web
 * @Description: TODO
 * @author zhujun
 * @date 2016年9月21日
 * @version V1.0
 */
@Controller
@RequestMapping(value = "/inquire")
public class InquireApi extends WebController {

    private final Logger logger = LoggerFactory.getLogger(InquireApi.class);

    @Autowired
    private InquireService inquireService;

    /**
     * 保存回访内容
     * @Title: saveInquire
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author zhujun 2016年9月21日 
     * @throws
     */
    @RequestMapping(value = "/saveInquire", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto saveInquire(RequestHeader requestHeader, @RequestBody Inquire inquire) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String flag = inquireService.saveInquireInfo(inquire);
            result.put("result", flag);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 获取所有回访内容
     * @Title: saveInquire
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author zhujun 2016年9月21日 
     * @throws
     */
    @RequestMapping(value = "/getAllInquire", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto getAllInquire(RequestHeader requestHeader) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            List<Inquire> list = inquireService.getAllInquireInfo();
            result.put("list", list);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }
    
    /**
     * 添加广告图片
     * @Title: saveInquire
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author zhujun 2016年12月7日 
     * @throws
     */
    @RequestMapping(value = "/saveAdvertising", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto getAlladvertising(RequestHeader requestHeader, @RequestBody Advertising advertising) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String flag = inquireService.saveAdvertisingInfo(advertising);
            result.put("result", flag);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }
    
    /**
     * 获取所有广告图片
     * @Title: saveInquire
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author zhujun 2016年12月7日 
     * @throws
     */
    @RequestMapping(value = "/getAllAdvertising", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto getAlladvertising(RequestHeader requestHeader) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            List<Advertising> list = inquireService.getAlladvertising();
            result.put("list", list);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }
}
