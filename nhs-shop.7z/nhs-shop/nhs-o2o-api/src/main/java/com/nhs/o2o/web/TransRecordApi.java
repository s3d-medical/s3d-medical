package com.nhs.o2o.web;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Maps;
import com.nhs.core.orm.Page;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.core.web.WebController;
import com.nhs.core.web.WebExceptionCode;
import com.nhs.core.web.WebRequestException;
import com.nhs.core.web.dto.RequestHeader;
import com.nhs.core.web.dto.ResponseDto;
import com.nhs.o2o.util.O2oConstant;
import com.nhs.shop.service.shop.O2oShopService;

@Controller
@RequestMapping(value = "/transRecord")
public class TransRecordApi extends WebController{
	
	
	 private final Logger logger = LoggerFactory.getLogger(TransRecordApi.class);
	
	 
	 @Autowired
	 private O2oShopService o2oShopService;
	 
	 	/**
		 * <pre>
		 * 	<h1>查询商超支付记录</h1>
		 * </pre>
		 * @param map
		 * @param request
		 * @param requestHeader
		 * @return
		 */
		@RequestMapping(value = "storePayRecord", method = RequestMethod.POST)
		@ResponseBody
		public ResponseDto queryPayRecord(@RequestBody Map<String, Object> map, HttpServletRequest request,
				RequestHeader requestHeader) {
			ResponseDto response = new ResponseDto();
			Map<String, Object> result = Maps.newHashMap();
			try {
				Integer pageNo = StringHelper.objectToInt(map.get("page"), O2oConstant.DATA_PAGE);
				Integer pageSize = StringHelper.objectToInt(map.get("pageSize"), O2oConstant.DATA_PAGE_SIZE);
				String userId = StringHelper.objectToString(map.get("userId"), "");

				Page<Map<String, Object>> page = createPage(pageNo, pageSize);
				List<Map<String, Object>> list = o2oShopService.queryStoreRecord(page, userId);
				result.put("list", list);
				result.put("totalCount", page.getTotalCount());
				result.put("totalPage", page.getTotalPage());

			} catch (WebRequestException e) {
				response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
				logger.info(e.getMessage());
				logger.error(e.getMessage());
			} catch (Exception e) {
				logger.error(e.getMessage());
				response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
			}
			response.getResult().putAll(result);
			return response;
		}
}
