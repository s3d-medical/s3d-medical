package com.nhs.o2o.web;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Maps;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.core.web.WebController;
import com.nhs.core.web.WebExceptionCode;
import com.nhs.core.web.WebRequestException;
import com.nhs.core.web.dto.RequestHeader;
import com.nhs.core.web.dto.ResponseDto;
import com.nhs.shop.service.basket.BasketService;

/**
 * 购物车controller
 * @Title: GoodsApi.java
 * @Package com.nhs.o2o.web
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月16日 下午7:25:04
 * @version V1.0
 */
@Controller
@RequestMapping(value = "/basket")
public class BasketApi extends WebController {

    private final Logger logger = LoggerFactory.getLogger(BasketApi.class);

    @Autowired
    private BasketService basketService;

    /**
     * 获取购物车列表
     * @Title: list
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年7月17日 
     * @throws
     */
    @RequestMapping(value = "/list", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto list(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = null;
        try {
            String userId = StringHelper.objectToString(map.get("userId"), "");
            result = basketService.getBasketList(userId);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 加入购物车
     * @Title: list
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年7月17日 
     * @throws
     */
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto add(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String userId = StringHelper.objectToString(map.get("userId"), "");
            Integer prodId = StringHelper.objectToInt(map.get("prodId"), 0);
            Integer skuId = StringHelper.objectToInt(map.get("skuId"), 0);
            Integer count = StringHelper.objectToInt(map.get("count"), 0);
            basketService.saveBasket(userId, prodId, skuId, count);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 更新购物车
     * @Title: update
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年7月18日 
     * @throws
     */
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto update(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            Integer basketId = StringHelper.objectToInt(map.get("basketId"), 0);
            Integer skuId = StringHelper.objectToInt(map.get("skuId"), 0);
            Integer count = StringHelper.objectToInt(map.get("count"), 0);
            basketService.updateBasket(basketId, skuId, count);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 删除购物车(支持批量)
     * @Title: update
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年7月18日 
     * @author liangdanhua 2016年8月10日  修改
     * @throws
     */
    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto delete(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String userId = StringHelper.objectToString(map.get("userId"), "");
            // 添加批量删除购物车
            String basketId = (String) map.get("basketId");
            String[] params = basketId.split(",");
            for (int i = 0; i < params.length; i++) {
                basketService.deleteBasket(userId, Integer.parseInt(params[i]));
            }
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

}
