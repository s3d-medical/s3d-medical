package com.nhs.o2o.web;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Maps;
import com.nhs.core.orm.Page;
import com.nhs.core.utils.common.HttpIpUtils;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.core.web.WebController;
import com.nhs.core.web.WebExceptionCode;
import com.nhs.core.web.WebRequestException;
import com.nhs.core.web.dto.RequestHeader;
import com.nhs.core.web.dto.ResponseDto;
import com.nhs.shop.entry.legend.user.UsrFeedback;
import com.nhs.user.dto.CoinRmbSilverLogDto;
import com.nhs.user.service.MemberService;

@Controller
@RequestMapping(value = "/member")
public class MemberApi extends WebController {

    private final Logger logger = LoggerFactory.getLogger(MemberApi.class);

    @Resource
    MemberService memberService;

    /**
     * 添加意见反馈
     * @Title: saveFeedback
     * @Description: TODO
     * @param @param requestHeader
     * @param @param usrFeedback
     * @param @return
     * @return ResponseDto
     * @author cary 2016年8月18日
     * @throws
     */
    @RequestMapping(value = "/saveFeedback", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto saveFeedback(HttpServletRequest request, RequestHeader requestHeader,
            @RequestBody UsrFeedback usrFeedback) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            // 过滤emoji表情
            if (StringUtils.isNotBlank(usrFeedback.getContent())) {
                usrFeedback.setContent(usrFeedback.getContent().replaceAll("[^\\u0000-\\uFFFF]", ""));
            }
            String ip = HttpIpUtils.getClientIp(request);
            if (usrFeedback != null) {
                usrFeedback.setIp(ip);
            }
            memberService.saveFeedback(usrFeedback);
        } catch (WebRequestException e) {
            e.printStackTrace();
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     *查询意见反馈
     * @Title: getFeedback
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return
     * @return ResponseDto
     * @author cary 2016年8月18日
     * @throws
     */
    @RequestMapping(value = "/getFeedback", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto getFeedback(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String userId = StringHelper.objectToString(map.get("userId"), "");
            // 卖家版传 1，买家版本不需要传
            int feedBackType = StringHelper.objectToInt(map.get("feedBackType"), 0);
            result.put("feedbacks", memberService.getFeedback(userId, feedBackType));
        } catch (WebRequestException e) {
            e.printStackTrace();
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error(e.getMessage(),e);
        } catch (Exception e) {
            logger.error(e.getMessage(),e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     *查询意见反馈
     * @Title: getFeedback
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return
     * @return ResponseDto
     * @author cary 2016年8月18日
     * @throws
     */
    @RequestMapping(value = "/v1.9/getFeedbackTWo", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto getFeedbackTWo(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            // 买家版传0，卖家版传1，不传查all
            int feedBackType = StringHelper.objectToInt(map.get("feedBackType"), 10);
            // 反馈人
            String name = StringHelper.objectToString(map.get("name"), "");
            // 开始时间
            String fromDate = StringHelper.objectToString(map.get("startDate"), "");
            // 结束时间
            String fromDateTWo = StringHelper.objectToString(map.get("endDate"), "");

            Integer pageNo = StringHelper.objectToInt(map.get("pageNo"), 0);
            Integer pageSize = StringHelper.objectToInt(map.get("pageSize"), 0);

            Page<Map<String, Object>> page = createPage(pageNo, pageSize);

            result.put("feedbacks", memberService.getFeedbackTwo(page, feedBackType, name, fromDate, fromDateTWo));
            result.put("totalCount", page.getTotalCount());
            result.put("totalPage", page.getTotalPage());

        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.info(e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    @RequestMapping(value = "/v1.9/getSilverHistory", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto getSilverHistory(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, List<CoinRmbSilverLogDto>> result = Maps.newHashMap();
        List<CoinRmbSilverLogDto> list = new ArrayList<>();
        try {
            String userId = StringHelper.objectToString(map.get("userId"), "");
            Integer pageNo = StringHelper.objectToInt(map.get("pageNo"), 0);
            Integer pageSize = StringHelper.objectToInt(map.get("pageSize"), 0);
            Page<Map<String, Object>> page = createPage(pageNo, pageSize);
            list = memberService.getSilverHistory(userId, page);
            result.put("history", list);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.info(e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 获取系统配置
     * @Title: getSystemParameter
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年10月29日 
     * @throws
     */
    @RequestMapping(value = "/v1.9/getSystemParameter", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto getSystemParameter(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        try {
            map = memberService.getSystemParameter();
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error(e.getMessage(), e);
        } catch (Exception e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
            logger.error(e.getMessage(), e);            
        }
        response.getResult().putAll(map);
        return response;
    }
    
    /**
     * 查询营业员信息
     * @Title: commission
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author liangdanhua 2016年11月21日 
     * @throws
     */
    @RequestMapping(value = "/v1.9.2/commission", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto commission(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String phone = StringHelper.objectToString(map.get("phone"), "");
            result.put("commission", memberService.queryCommission(phone));
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("error",e.getMessage());
        } catch (Exception e) {
            logger.error("error",e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

}
