package com.nhs.o2o.util;

/**
 * 
 * @Title: O2oConstant.java
 * @Package com.nhs.o2o.util
 * @Description: TODO
 * @author huxianjun
 * @date 2016年7月19日 上午8:21:11
 * @version V1.0
 */
public class O2oConstant {
    /**
     * 数据分页参数
     */
    public final static Integer DATA_PAGE = 1;
    public final static Integer DATA_PAGE_SIZE = 10;
    public final static Integer DATA_INTEGER_DEFAULT = 0;
    public final static String DATA_STRING_DEFAULT = "";

    // 最小转换金币数
    public final static Integer MIN_CONVERT_GOLD = 100;
    
    //header里token参数
    public final static String PARAM_TOKEN = "param_token";
    
    public final static String VALID_TOKEN_FAIL_PATH = "/store/validateTokenFailed";
    
    
}
