package com.nhs.o2o.web.order;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Maps;
import com.nhs.core.common.NhsConstant;
import com.nhs.core.orm.Page;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.core.web.WebController;
import com.nhs.core.web.WebExceptionCode;
import com.nhs.core.web.WebRequestException;
import com.nhs.core.web.dto.RequestHeader;
import com.nhs.core.web.dto.ResponseDto;
import com.nhs.shop.entry.legend.shop.ShopDetail;
import com.nhs.shop.service.order.ShopOrderService;
import com.nhs.shop.service.order.dto.OrderAddRequestDto;
import com.nhs.shop.service.order.dto.OrderCommAddRequestDto;
import com.nhs.shop.service.order.dto.OrderConfirmDto;
import com.nhs.shop.service.order.dto.OrderConfirmRequestDto;
import com.nhs.shop.service.order.dto.OrderDetailDto;
import com.nhs.shop.service.order.dto.OrderListDto;

/**
 * 商城订单controller
 * 
 * @Title: HomePageApi.java
 * @Package com.nhs.o2o.web
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月16日 下午7:36:27
 * @version V1.0
 */
@Controller
@RequestMapping(value = "/shopOrder")
public class ShopOrderApi extends WebController {

    private final Logger logger = LoggerFactory.getLogger(ShopOrderApi.class);

    @Autowired
    private ShopOrderService shopOrderService;

    /**
     * 获取订单确认信息
     * @Title: confirm1
     * @Description: TODO
     * @param @param requestHeader
     * @param @param dto
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年7月20日 
     * @throws
     */
    @RequestMapping(value = "/confirm", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto confirm1(RequestHeader requestHeader, @RequestBody OrderConfirmRequestDto dto) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            OrderConfirmDto orderConfirmDto = shopOrderService.getOrderConfirm(dto);
            result.put("order", orderConfirmDto);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("确认订单出错.", e);
            result.clear();
        } catch (Exception e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
            logger.error("确认订单出错.", e);
            result.clear();
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 创建订单
     * @Title: add
     * @Description: TODO
     * @param @param requestHeader
     * @param @param dto
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年7月20日 
     * @throws
     */
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto add(RequestHeader requestHeader, @RequestBody OrderAddRequestDto dto) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            Map<String, Object> map = shopOrderService.saveShopOrder(dto, requestHeader.getPlatformType());
            result.putAll(map);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg",e);
        } catch (Exception e) {
        	logger.error("errorMsg",e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 获取订单列表
     * @Title: add
     * @Description: TODO
     * @param @param requestHeader
     * @param @param dto
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年7月20日 
     * @throws
     */
    @RequestMapping(value = "/list", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto list(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String userId = StringHelper.objectToString(map.get("userId"), "");
            Integer status = StringHelper.objectToInt(map.get("status"), 0);
            Integer pageNo = StringHelper.objectToInt(map.get("pageNo"), 0);
            Integer pageSize = StringHelper.objectToInt(map.get("pageSize"), 0);
            Page<Map<String, Object>> page = createPage(pageNo, pageSize);
            List<OrderListDto> list = shopOrderService.getOrderList(userId, status, page);
            result.put("list", list);
            result.put("totalCount", page.getTotalCount());
            result.put("totalPage", page.getTotalPage());
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.info(e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 获取订单详情
     * @Title: add
     * @Description: TODO
     * @param @param requestHeader
     * @param @param dto
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年7月20日 
     * @throws
     */
    @RequestMapping(value = "/detail", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto detail(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String userId = StringHelper.objectToString(map.get("userId"), "");
            Integer orderId = StringHelper.objectToInt(map.get("orderId"), 0);

            OrderDetailDto dto = shopOrderService.getOrderDetail(userId, orderId);
            result.put("detail", dto);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.info(e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 订单操作
     * @Title: add
     * @Description: TODO
     * @param @param requestHeader
     * @param @param dto
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年7月20日 
     * @throws
     */
    @RequestMapping(value = "/operate", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto cancel(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String userId = StringHelper.objectToString(map.get("userId"), "");
            Integer orderId = StringHelper.objectToInt(map.get("orderId"), 0);
            String operate = StringHelper.objectToString(map.get("operate"), "");
            String refundReason = StringHelper.objectToString(map.get("refundReason"), "");
            // Integer isNeedRefundGoods = StringHelper.objectToInt(map.get("isNeedRefundGoods"), 0);

            shopOrderService.doOrderOperate(userId, orderId, operate, refundReason);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error(e.getMessage(),e);
        } catch (Exception e) {
            logger.error(e.getMessage(),e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 订单操作
     * @Title: add
     * @Description: TODO
     * @param @param requestHeader
     * @param @param dto
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年7月20日 
     * @throws
     */
    @RequestMapping(value = "/comment", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto comment(RequestHeader requestHeader, @RequestBody OrderCommAddRequestDto dto) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            shopOrderService.saveShopOrderComm(dto);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.info(e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
    * 
    * @Title: commentList
    * @Description: TODO
    * @param @param requestHeader
    * @param @param dto
    * @param @return   
    * @return ResponseDto 
    * @author liangdanhua 2016年10月21日 
    * @throws
    */
    @RequestMapping(value = "/v1.9/commentlist", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto commentList(RequestHeader requestHeader, @RequestBody OrderCommAddRequestDto dto) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            shopOrderService.saveShopOrderCommList(dto);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.info(e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 获取物流
     * @Title: findArriageShow
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author liangdanhua 2016年8月19日 
     * @throws
     */
    @RequestMapping(value = "/carriageShow", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto findArriageShow(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            Integer orderNumber = StringHelper.objectToInt(map.get("orderNumber"), 0);
            Map<String, Object> mapParams = shopOrderService.findArriageShow(orderNumber);
            result.putAll(mapParams);

        } catch (WebRequestException e) {
            e.printStackTrace();
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.info(e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage());
            throw new WebRequestException(WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 
     * @Title: clacCartDeleivery
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author liangdanhua 2016年8月19日 
     * @throws
     */
    @RequestMapping(value = "/clacCartDeleivery", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto clacCartDeleivery(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            int cityId = StringHelper.objectToInt(map.get("cityId"), 0);
            int prodId = StringHelper.objectToInt(map.get("prodId"), 0);
            int count = StringHelper.objectToInt(map.get("count"), 0);
            String deliveType = StringHelper.objectToString(map.get("deliveType"), "");
            BigDecimal sportFree = shopOrderService.clacCartDeleivery(cityId, prodId, count, deliveType);
            result.put("sportFree", sportFree);
        } catch (WebRequestException e) {
            e.printStackTrace();
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.info(e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage());
            throw new WebRequestException(WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 发票保存
     * @Title: saveInvoice
     * @Description: TODO
     * @param @param requestHeader
     * @param @param dto
     * @param @return   
     * @return ResponseDto 
     * @author Cary 2016年8月23日 
     * @throws
     */
    @RequestMapping(value = "/saveInvoice", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto saveInvoice(RequestHeader requestHeader, @RequestBody OrderAddRequestDto dto) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            Integer invoiceId = shopOrderService.saveInvoice(dto);
            result.put("invoiceId", invoiceId);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }
}
