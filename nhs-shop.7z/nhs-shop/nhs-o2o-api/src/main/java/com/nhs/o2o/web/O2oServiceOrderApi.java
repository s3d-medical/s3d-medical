package com.nhs.o2o.web;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Maps;
import com.nhs.core.common.NhsConstant;
import com.nhs.core.orm.Page;
import com.nhs.core.utils.common.ArithUtils;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.core.web.WebController;
import com.nhs.core.web.WebExceptionCode;
import com.nhs.core.web.WebRequestException;
import com.nhs.core.web.dto.RequestHeader;
import com.nhs.core.web.dto.ResponseDto;
import com.nhs.shop.entry.legend.pay.PayRecord;
import com.nhs.shop.entry.legend.shop.ShopDetail;
import com.nhs.shop.service.order.O2oServiceOrderService;
import com.nhs.shop.service.order.dto.OrderCommAddRequestDto;
import com.nhs.shop.service.order.dto.ServiceOrderDetailDto;
import com.nhs.shop.service.order.dto.ServiceOrderListDto;
import com.nhs.shop.service.pay.PayRecordService;
import com.nhs.shop.service.shop.ShopService;

/**
 * o2o服务订单controller
 * 
 * @Title: HomePageApi.java
 * @Package com.nhs.o2o.web
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月16日 下午7:36:27
 * @version V1.0
 */
@Controller
@RequestMapping(value = "/o2oServiceOrder")
public class O2oServiceOrderApi extends WebController {

    private final Logger logger = LoggerFactory.getLogger(O2oServiceOrderApi.class);

    @Autowired
    private O2oServiceOrderService o2oServiceOrderService;
    
    
    @Autowired
    private PayRecordService payRecordService;
    
    @Autowired
    private ShopService shopService;

    /**
     * 创建订单
     * @Title: add
     * @Description: TODO
     * @param @param requestHeader
     * @param @param dto
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年7月20日 
     * @throws
     */
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto createOrder(@org.springframework.web.bind.annotation.RequestHeader HttpHeaders headers, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            // get params
            String  userId = StringHelper.objectToString(map.get("userId"), ""); // 用户ID
            Integer shopId = StringHelper.objectToInt(map.get("shopId"), 0);    // 商户ID
            Double  totalAmount = StringHelper.objectToDouble(map.get("totalAmount"), 0);
            int consumeReduceType = StringHelper.objectToInt(map.get("consumeReduceType"), 0);  // 1：选择消费立减 0：不选择加消费立减
            int couponType = StringHelper.objectToInt(map.get("couponType"), 0);                // 1：使用佰德券     0：不选择佰德券
            
            // calculate couponMoney
            BigDecimal couponMoney = new BigDecimal(0);
            if(couponType != 0){
            	double couponCount = StringHelper.objectToDouble(map.get("couponCount"), 0);
            	couponMoney = ArithUtils.div2(BigDecimal.valueOf(couponCount), new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE), 2, BigDecimal.ROUND_DOWN);
            }
            String platForm = headers.getFirst("platformType");
            
            if (logger.isDebugEnabled()){
                logger.debug("userId: " + userId);
                logger.debug("shopId: " + shopId);
                logger.debug("totalAmount: " + totalAmount);
                logger.debug("consumeReduceType: " + consumeReduceType);
                logger.debug("couponType: " + couponType);
                logger.debug("couponMoney: " + couponMoney);
            }
			
			 ShopDetail shopDetail = shopService.getShopDetailByShopId(shopId);
            Map<String, Object> data = new HashMap<>();
            String deskNo = StringHelper.objectToString(map.get("deskNo"), "00");
            if(shopDetail != null){
            	if (4 == shopDetail.getShopSystem()){
	        		//商超订单流水记录
	        		data = payRecordService.savePayRecord(userId, shopDetail, totalAmount,
	        				platForm,couponMoney,couponType,deskNo);
            	} else{
            		 // Call o2o Service
            		data = o2oServiceOrderService.saveO2oServiceOrder(userId, shopId, totalAmount,
                    platForm, consumeReduceType, couponMoney, couponType);
            	}
            } else {
            	response = new ResponseDto(WebExceptionCode.ERROR.errorCode, "商家不存在");
            	response.getResult().putAll(result);
                return response;
            }
            
           
            
            result.putAll(data);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error(e.getMessage(), e);
        } catch (Exception e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
            logger.error(e.getMessage());
        }
        response.getResult().putAll(result);
        return response;
    }
    
    /**
     * 获取订单列表
     * @Title: add
     * @Description: 这个方法是在查询app中我的订单，限时服务订单列表的时候调用的。
     * @param @param requestHeader
     * @param @param dto
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年7月20日 
     * @author chushubin 2016年11月16日
     * @throws
     */
    @RequestMapping(value = "/list", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto list(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            // get params
            String userId = StringHelper.objectToString(map.get("userId"), "");
            Integer status = StringHelper.objectToInt(map.get("status"), 0);
            Integer pageNo = StringHelper.objectToInt(map.get("pageNo"), 0);
            Integer pageSize = StringHelper.objectToInt(map.get("pageSize"), 0);
            // generate page
            Page<Map<String, Object>> page = createPage(pageNo, pageSize);
            
            // call service
            List<ServiceOrderDetailDto> list = o2oServiceOrderService.getOrderList(userId, status, page);
            
            // construct result object
            result.put("list", list);
            result.put("totalCount", page.getTotalCount());
            result.put("totalPage", page.getTotalPage());
        } catch (WebRequestException e) {
            logger.error(e.getMessage(), e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        // return result
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 获取订单详情
     * @Title: add
     * @Description: TODO
     * @param @param requestHeader
     * @param @param dto
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年7月20日 
     * @throws
     */
    @RequestMapping(value = "/detail", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto detail(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String userId = StringHelper.objectToString(map.get("userId"), "");
            Integer orderId = StringHelper.objectToInt(map.get("orderId"), 0);
            ServiceOrderDetailDto dto = o2oServiceOrderService.getOrderDetail(userId, orderId);
            result.put("detail", dto);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.info(e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 订单操作
     * @Title: operate
     * @Description: TODO
     * @param @param requestHeader
     * @param @param dto
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年7月20日 
     * @throws
     */
    @RequestMapping(value = "/operate", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto operate(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String userId = StringHelper.objectToString(map.get("userId"), "");
            Integer orderId = StringHelper.objectToInt(map.get("orderId"), 0);
            String operate = StringHelper.objectToString(map.get("operate"), "");
            o2oServiceOrderService.dealOrderOperate(userId, orderId, operate);
        } catch (WebRequestException e) {
            logger.error(e.getMessage(), e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 订单操作
     * @Title: 获取营业员的福利码
     * @Description: TODO
     * @param @param requestHeader
     * @param @param dto
     * @param @return   
     * @return map 
     * @author Administrator 2016年7月20日 
     * @throws
     */
    @RequestMapping(value = "/v1.9.1/getValidateCode", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto validateCode(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
        	 String orderNum = StringHelper.objectToString(map.get("orderNum"), "");
        	 String validateCode = "";
        	 PayRecord payRecord = payRecordService.getPayRecordByOrderNo(orderNum);
        	 if(payRecord != null){
        		 ShopDetail shopDetail = shopService.getShopDetailByShopId(payRecord.getShopId());
                 if(shopDetail != null){
		             if (4 == shopDetail.getShopSystem()){
		        		 validateCode = payRecordService.getValidateCodeByOrderNo(orderNum);
		        	 }
                 }
        	 }else{
        		 validateCode = o2oServiceOrderService.getValidateCode(orderNum);
        	 }
        	 
        	 result.put("validateCode", validateCode);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.info(e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }
    
    
    /**
     * 创建订单
     * @Title: add(v1.9.3 新计算规则)
     * @Description: TODO
     * @param @param requestHeader
     * @param @param dto
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年7月20日 
     * @throws
     */
    @RequestMapping(value = "/v1.9.3/add", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto addO2oOrder(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String userId = StringHelper.objectToString(map.get("userId"), "");
            Integer shopId = StringHelper.objectToInt(map.get("shopId"), 0);
            Double totalAmount = StringHelper.objectToDouble(map.get("totalAmount"), 0);
            int consumeReduceType = StringHelper.objectToInt(map.get("consumeReduceType"), 0);   //1：选择消费立减   0：不选择加消费立减
            int couponType = StringHelper.objectToInt(map.get("couponType"), 0);   //1：使用佰德券   0：不选择佰德券
            BigDecimal couponMoney = new BigDecimal(0);
            if(couponType != 0){
//            	double couponCount = StringHelper.objectToDouble(map.get("couponCount"), 0);
//            	couponMoney = StringHelper.objectToBigDecimal(map.get("couponCount"), "0.00");
//            	couponMoney = ArithUtils.div2(BigDecimal.valueOf(couponCount), new BigDecimal(100), 2, BigDecimal.ROUND_DOWN);
            	double couponCount = StringHelper.objectToDouble(map.get("couponCount"), 0);
            	couponMoney = ArithUtils.div2(BigDecimal.valueOf(couponCount), new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE), 2, BigDecimal.ROUND_DOWN);
            }
            
            ShopDetail shopDetail = shopService.getShopDetailByShopId(shopId);
            Map<String, Object> data = new HashMap<>();
            String deskNo = StringHelper.objectToString(map.get("deskNo"), "00");
            if(shopDetail != null){
            	if (4 == shopDetail.getShopSystem()){
	        		//商超订单流水记录
	        		data = payRecordService.savePayRecord(userId, shopDetail, totalAmount,
		                    requestHeader.getPlatformType(),couponMoney,couponType,deskNo);
            	} else{
            		int discountBeyond = StringHelper.objectToInt(map.get("discountBeyond"), 0); // 0： 全部参加折扣，1：部分金额不参加折扣
            		BigDecimal discountBeyondMoney = BigDecimal.valueOf(0);
            		if(discountBeyond != 0){
            			discountBeyondMoney = StringHelper.objectToBigDecimal(map.get("discountBeyondMoney"), "0.00");
            		}
            		data = o2oServiceOrderService.saveO2oServiceOrder(userId, shopId, totalAmount,
                            requestHeader.getPlatformType(),consumeReduceType,couponMoney,couponType,discountBeyond,discountBeyondMoney);
            	}
            } else {
            	response = new ResponseDto(WebExceptionCode.ERROR.errorCode, "商家不存在");
            	response.getResult().putAll(result);
                return response;
            }
            result.putAll(data);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.info(e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }
    
    /**
     * 获取订单列表
     * @Title: add
     * @Description: TODO
     * @param @param requestHeader
     * @param @param dto
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年7月20日 
     * @throws
     */
    @RequestMapping(value = "/v1.9.3/list", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto orderlist(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String userId = StringHelper.objectToString(map.get("userId"), "");
            Integer status = StringHelper.objectToInt(map.get("status"), 0);
            Integer pageNo = StringHelper.objectToInt(map.get("pageNo"), 0);
            Integer pageSize = StringHelper.objectToInt(map.get("pageSize"), 0);
            Page<Map<String, Object>> page = createPage(pageNo, pageSize);
            List<ServiceOrderDetailDto> list = o2oServiceOrderService.getServiceOrderList(userId, status, page);
            result.put("list", list);
            result.put("totalCount", page.getTotalCount());
            result.put("totalPage", page.getTotalPage());
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.info(e.getMessage(),e);
            logger.error(e.getMessage(),e);
        } catch (Exception e) {
            logger.error(e.getMessage(),e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 获取订单详情
     * @Title: add
     * @Description: TODO
     * @param @param requestHeader
     * @param @param dto
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年7月20日 
     * @throws
     */
    @RequestMapping(value = "/v1.9.3/detail", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto orderDetail(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String userId = StringHelper.objectToString(map.get("userId"), "");
            Integer orderId = StringHelper.objectToInt(map.get("orderId"), 0);
            ServiceOrderDetailDto dto = o2oServiceOrderService.getServiceOrderDetail(userId, orderId);
            result.put("detail", dto);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.info(e.getMessage(),e);
            logger.error(e.getMessage(),e);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

}
