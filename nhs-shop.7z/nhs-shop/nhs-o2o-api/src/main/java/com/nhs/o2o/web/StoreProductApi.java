package com.nhs.o2o.web;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Maps;
import com.nhs.core.orm.Page;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.core.web.WebController;
import com.nhs.core.web.WebExceptionCode;
import com.nhs.core.web.WebRequestException;
import com.nhs.core.web.dto.RequestHeader;
import com.nhs.core.web.dto.ResponseDto;
import com.nhs.o2o.util.O2oConstant;
import com.nhs.shop.service.order.StoreService;

/**
 * 
 * @Title: StoreApi.java
 * @Package com.nhs.o2o.web
 * @Description: TODO
 * @author liangdanhua
 * @date 2016年11月18日 下午2:30:17
 * @version V1.0
 */
@Controller
@RequestMapping(value = "/storeProduct")
public class StoreProductApi extends WebController {

    private final Logger logger = LoggerFactory.getLogger(StoreProductApi.class);

    @Autowired
    private StoreService storeService;

    /**
    * 商超商品列表
    * @Title: tradeList
    * @Description: TODO
    * @param @param requestHeader
    * @param @param map
    * @param @return   
    * @return ResponseDto 
    * @author liangdanhua 2016年11月18日 
    * @throws
    */
    @RequestMapping(value = "/v1.9.2/list", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto list(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            Map<String, Object> params = Maps.newHashMap();
            int pageNo = StringHelper.objectToInt(map.get("page"), O2oConstant.DATA_PAGE);
            int pageSize = StringHelper.objectToInt(map.get("pageSize"), O2oConstant.DATA_PAGE_SIZE);
            params.put("shopId", StringHelper.objectToInt(map.get("shopId"), O2oConstant.DATA_INTEGER_DEFAULT));
            params.put("itemCode", StringHelper.objectToString(map.get("itemCode"), O2oConstant.DATA_STRING_DEFAULT));
            params.put("itemName", StringHelper.objectToString(map.get("itemName"), O2oConstant.DATA_STRING_DEFAULT));
            Page<Map<String, Object>> page = createPage(pageNo, pageSize);

            result.put("list", storeService.list(params, page));
            result.put("totalCount", page.getTotalCount());
            result.put("totalPage", page.getTotalPage());

        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.info(e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 商超商品
     * @Title: tradeList
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author liangdanhua 2016年11月18日 
     * @throws
     */

    @RequestMapping(value = "/v1.9.2/detail", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto detail(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String itemCode = StringHelper.objectToString(map.get("itemCode"), "");
            result.put("list", storeService.detail(itemCode));

        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.info(e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

}
