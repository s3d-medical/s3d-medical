package com.nhs.o2o.web;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Maps;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.core.web.WebController;
import com.nhs.core.web.WebExceptionCode;
import com.nhs.core.web.WebRequestException;
import com.nhs.core.web.dto.RequestHeader;
import com.nhs.core.web.dto.ResponseDto;
import com.nhs.shop.entry.em.order.OrderCodeEnum;
import com.nhs.shop.service.car.CarService;
import com.nhs.shop.service.goods.GoodsService;
import com.nhs.shop.service.goods.dto.GoodsDto;
import com.nhs.shop.service.recommend.RecommendService;
import com.nhs.shop.service.recommend.dto.VitLogDto;
import com.nhs.shop.service.shop.ShopService;
import com.nhs.shop.service.shop.dto.NearbyShopDto;

/**
 * 推荐产品
 * @Title: RecommendApi.java
 * @Package com.nhs.o2o.web
 * @Description: TODO
 * @author Administrator
 * @date 2016年8月22日 下午9:03:44
 * @version V1.0
 */
@Controller
@RequestMapping(value = "/recommend")
public class RecommendApi extends WebController {
    @Autowired
    private GoodsService goodsService;

    @Autowired
    private ShopService shopService;

    @Autowired
    private CarService carService;

    @Autowired
    private RecommendService recommendService;

    private final Logger logger = LoggerFactory.getLogger(RecommendApi.class);

    /**
     * 推荐
     * @Title: list
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author liangdanhua 2016年8月23日 
     * @throws
     */
    @RequestMapping(value = "/list", method = RequestMethod.POST)
    @ResponseBody
    @Deprecated
    public ResponseDto list(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String orderNum = StringHelper.objectToString(map.get("orderNum"), "");
            // 商城订单
            if (orderNum.endsWith(OrderCodeEnum.SHOP_ORDER.getCode().toString())) {
                List<GoodsDto> list = goodsService.getRecommendList();
                result.put("list", list);
            }
            // 服务订单
            else if (orderNum.endsWith(OrderCodeEnum.O2O_SERVICE_ORDER.getCode().toString())) {
                Integer cityId = StringHelper.objectToInt(map.get("cityId"), 0);
                double lng = StringHelper.objectToDouble(map.get("lng"), 0.0);
                double lat = StringHelper.objectToDouble(map.get("lat"), 0.0);
                NearbyShopDto dto = shopService.getNearbyShop(cityId, lng, lat, 0, 0);
                result.put("list", dto);
            }
            // 汽车订单
            else if (orderNum.endsWith(OrderCodeEnum.CAR_ORDER.getCode().toString())) {
                String channel = requestHeader.getPhoneModel();
                result.put("list", carService.getHotCar(channel));
            }
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }
    
    /**
     * 推荐
     * @Title: list
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author Li Guangrong 2016年8月23日 
     * @throws
     */
    @RequestMapping(value = "/v1.9.3/list", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto recommendList(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String orderNum = StringHelper.objectToString(map.get("orderNum"), "");
            // 商城订单
            if (orderNum.endsWith(OrderCodeEnum.SHOP_ORDER.getCode().toString())) {
                List<GoodsDto> list = goodsService.getRecommendList();
                result.put("list", list);
            }
            // 服务订单
            else if (orderNum.endsWith(OrderCodeEnum.O2O_SERVICE_ORDER.getCode().toString())) {
                Integer cityId = StringHelper.objectToInt(map.get("cityId"), 0);
                double lng = StringHelper.objectToDouble(map.get("lng"), 0.0);
                double lat = StringHelper.objectToDouble(map.get("lat"), 0.0);
                NearbyShopDto dto = shopService.getNearbyShopLike(cityId, lng, lat, 0, 0);
                result.put("list", dto);
            }
            // 汽车订单
            else if (orderNum.endsWith(OrderCodeEnum.CAR_ORDER.getCode().toString())) {
                String channel = requestHeader.getPhoneModel();
                result.put("list", carService.getHotCar(channel));
            }
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 
     * @Title: history
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author liangdanhua 2016年8月23日 
     * @throws
     */
    @RequestMapping(value = "/history", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto history(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            Integer pageNo = StringHelper.objectToInt(map.get("pageNo"), 0);
            Integer pageSize = StringHelper.objectToInt(map.get("pageSize"), 10);
            String userId = StringHelper.objectToString(map.get("userId"), "");
            //List<VitLogDto> list = recommendService.getHistoryPage(userId, pageNo, pageSize);
            List<VitLogDto> list = recommendService.getBrowsedProds(userId, pageNo, pageSize);
            result.put("list", list);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 删除浏览记录
     * @Title: delete
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author liangdanhua 2016年8月23日 
     * @throws
     */
    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto delete(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String visitIds = StringHelper.objectToString(map.get("visitIds"), "");
            String[] params = visitIds.split(",");
            for (int i = 0; i < params.length; i++) {
                int visitId = Integer.parseInt(params[i]);
                recommendService.delete(visitId);
            }
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

}
