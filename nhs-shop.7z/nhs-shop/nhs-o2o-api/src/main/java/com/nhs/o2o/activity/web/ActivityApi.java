package com.nhs.o2o.activity.web;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Maps;
import com.nhs.core.utils.common.DateUtils;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.core.web.WebController;
import com.nhs.core.web.WebExceptionCode;
import com.nhs.core.web.WebRequestException;
import com.nhs.core.web.dto.RequestHeader;
import com.nhs.core.web.dto.ResponseDto;
import com.nhs.shop.activity.entry.ActivitySchool;
import com.nhs.shop.activity.entry.ActivitySchoolAgent;
import com.nhs.shop.entry.legend.user.UsrDetail;
import com.nhs.shop.service.activity.dto.SchoolCountDto;
import com.nhs.shop.service.activity.service.ActivitySchoolAgentService;
import com.nhs.shop.service.activity.service.ActivitySchoolService;
import com.nhs.shop.service.order.O2oServiceOrderService;
import com.nhs.shop.service.order.dto.ActivityOrderDto;
import com.nhs.shop.service.order.shop.internal.ShopOrderListService;
import com.nhs.shop.service.rebate.ActivityRebateService;
import com.nhs.shop.service.shop.O2oShopService;
import com.nhs.user.activity.dto.UserDetailSchoolDto;
import com.nhs.user.dto.MemberDetailDto;
import com.nhs.user.dto.UsrDetailDto;
import com.nhs.user.service.MemberService;
import com.nhs.user.service.UserService;

@Controller
@RequestMapping(value = "/activity")
public class ActivityApi  extends WebController {
	private final Logger logger = LoggerFactory.getLogger(ActivityApi.class);
	
	 @Resource
	 MemberService memberService;
	 
	 @Autowired
	 private O2oServiceOrderService o2oServiceOrderService;
	 
	 @Autowired
	 private O2oShopService o2oShopService;
	 
	 @Autowired
	 private ShopOrderListService shopOrderService;
	 

	 @Autowired
	 private ActivityRebateService rebateService;
	 
	 @Autowired
	 private ActivitySchoolService schoolService;
	 
	 @Autowired
	 private ActivitySchoolAgentService schoolAgentService;
	 
	 @Autowired
	 UserService userService;
	 
	
	@RequestMapping(value = "/searchActivityNewUser", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto searchActivityNewUser(HttpServletRequest request, RequestHeader requestHeader,
            @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String startTime = StringHelper.objectToString(map.get("startTime"), "");
            String endTime = StringHelper.objectToString(map.get("endTime"), "");
            if(StringUtils.isEmpty(startTime) || StringUtils.isEmpty(endTime)){
                response = new ResponseDto(WebExceptionCode.MISSINGPARAMETER.errorCode, WebExceptionCode.MISSINGPARAMETER.errorMsg);
            }else{
            	List<UsrDetailDto> usrDetailList = memberService.findUserDetailByRegTime(DateUtils.str2Date(startTime,""),DateUtils.str2Date(endTime,""));
            	result.put("activityRegUserList", usrDetailList);
            }
            
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg",e);
        } catch (Exception e) {
        	logger.error("errorMsg",e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }
	
	
	@RequestMapping(value = "/findAllOrderByType", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto storeOrderList(HttpServletRequest request, RequestHeader requestHeader,
            @RequestBody Map<String, Object> map) {
		 ResponseDto response = new ResponseDto();
	        Map<String, Object> result = Maps.newHashMap();
	        try {
//	            int orderCount = StringHelper.objectToInt(map.get("orderCount"), 0);
	            int type = StringHelper.objectToInt(map.get("type"), 0);
	            String startTime = StringHelper.objectToString(map.get("startTime"), "");
	            String endTime = StringHelper.objectToString(map.get("endTime"), "");
	            if(StringUtils.isEmpty(startTime) || StringUtils.isEmpty(endTime)){
	                response = new ResponseDto(WebExceptionCode.MISSINGPARAMETER.errorCode, WebExceptionCode.MISSINGPARAMETER.errorMsg);
	            }else{
	            	List<ActivityOrderDto> activityOrderList = new ArrayList<>();
//	            	Map<String,List<ActivityOrderDto>> userActivityOrderMap = Maps.newHashMap();
	            	if(2 == type){
	            		activityOrderList = o2oServiceOrderService.getStoreOrderSuccessList(startTime,endTime);
	            		for(ActivityOrderDto dto : activityOrderList){
	            			dto.setType("o2oShop");
	            			dto.setBaseSilver(rebateService.getUserBaseSilver(dto.getUserId(), dto.getOrderNum(), "o2oShop", new Date()));
	            		}
	            	}else if(1 == type){
	            		activityOrderList = shopOrderService.getActivityOrderList(startTime,endTime);
	            		for(ActivityOrderDto dto : activityOrderList){
	            			dto.setType("shop");
	            			dto.setBaseSilver(rebateService.getUserBaseSilver(dto.getUserId(), dto.getOrderNum(), "shop", new Date()));
	            		}
	            	}else{
	            		List<ActivityOrderDto> activityOrderList1 = o2oServiceOrderService.getStoreOrderSuccessList(startTime,endTime);
	            		for(ActivityOrderDto dto : activityOrderList1){
	            			dto.setType("o2oShop");
	            			dto.setBaseSilver(rebateService.getUserBaseSilver(dto.getUserId(), dto.getOrderNum(), "o2oShop", new Date()));
	            		}
	            		List<ActivityOrderDto> activityOrderList2 = shopOrderService.getActivityOrderList(startTime,endTime);
	            		for(ActivityOrderDto dto : activityOrderList2){
	            			dto.setType("shop");
	            			dto.setBaseSilver(rebateService.getUserBaseSilver(dto.getUserId(), dto.getOrderNum(), "shop", new Date()));
	            		}
	            		activityOrderList.addAll(activityOrderList1);
	            		activityOrderList.addAll(activityOrderList2);
	            	}
	            	/*List<ActivityOrderDto> userActivityOrderList = null;
	            	for(ActivityOrderDto dto : activityOrderList){
	            		if(userActivityOrderMap.get(dto.getUserId()) == null){
	            			userActivityOrderList = new ArrayList<>();
	            			userActivityOrderList.add(dto);
	            			userActivityOrderMap.put(dto.getUserId(), userActivityOrderList);
	            		}else{
	            			userActivityOrderList = userActivityOrderMap.get(dto.getUserId());
	            			userActivityOrderList.add(dto);
	            		}
	            	}*/
	            	Collections.sort(activityOrderList);
	            	result.put("activityOrderList", activityOrderList);
	            }
	            
	        } catch (WebRequestException e) {
	            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
	            logger.info(e.getMessage());
	            logger.error("errorMsg",e);
	        } catch (Exception e) {
	        	logger.error("errorMsg",e);
	            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
	        }
	        response.getResult().putAll(result);
	        return response;
    }
	
	@RequestMapping(value = "/addActiveSilver", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto addActiveSilver(HttpServletRequest request, RequestHeader requestHeader,
            @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            List<String> userIdList =  map.get("userIdList") == null ? new ArrayList<String>() : (List<String>)map.get("userIdList");
            List<Map<String,Object>> actConsumeOrderDtoList = map.get("consumeOrderDtoList") == null ? new ArrayList<Map<String,Object>>() : (List<Map<String,Object>>)map.get("consumeOrderDtoList");
            int type = StringHelper.objectToInt(map.get("type"), 0);
//            String orderNum = StringHelper.objectToString(map.get("orderNum"), "");
//            String orderType = StringHelper.objectToString(map.get("orderType"), "");
            int activityId = StringHelper.objectToInt(map.get("activityId"), 0);
            String silver = StringHelper.objectToString(map.get("silver"), "0.00");
            String msgText = StringHelper.objectToString(map.get("msgText"), "");
            rebateService.saveActivityRebateProcess(type, userIdList,  actConsumeOrderDtoList,new Date(),silver,activityId,msgText);
            
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg",e);
        } catch (Exception e) {
        	logger.error("errorMsg",e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }
	
	
	@RequestMapping(value = "/addActivityGold", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto addActivityGold(HttpServletRequest request,
            @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
        	List<Map<String,Object>> goldSchoolRegsDtoList = map.get("goldSchoolRegsDtoList") == null ? new ArrayList<Map<String,Object>>() : (List<Map<String,Object>>)map.get("goldSchoolRegsDtoList");
            int activityId = StringHelper.objectToInt(map.get("activityId"), 0);
            String activityTitle = StringHelper.objectToString(map.get("activityTitle"), "");
            String msgText = StringHelper.objectToString(map.get("msgText"), "");
            rebateService.saveActivityGoldRebateProcess(goldSchoolRegsDtoList,new Date(),activityId,msgText,activityTitle);
            
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg",e);
        } catch (Exception e) {
        	logger.error("errorMsg",e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }
	
	
	@RequestMapping(value = "/searchActivitySchoolNewUser", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto searchActivitySchoolNewUser(HttpServletRequest request, RequestHeader requestHeader,
            @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        logger.info("###start scan activity school user.####");
        try {
            String startTime = StringHelper.objectToString(map.get("startTime"), "");
            String endTime = StringHelper.objectToString(map.get("endTime"), "");
            if(StringUtils.isEmpty(startTime) || StringUtils.isEmpty(endTime)){
                response = new ResponseDto(WebExceptionCode.MISSINGPARAMETER.errorCode, WebExceptionCode.MISSINGPARAMETER.errorMsg);
            }else{
            	List<UserDetailSchoolDto> usrDetailList = memberService.findSchoolActUserDetailByRegTime(DateUtils.str2Date(startTime,""),DateUtils.str2Date(endTime,""));
            	result.put("activityRegUserList", usrDetailList);
            }
            
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg",e);
        } catch (Exception e) {
        	logger.error("errorMsg",e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        logger.info("###end scan activity school user.####");
        response.getResult().putAll(result);
        return response;
    }
	
	@RequestMapping(value = "/bindInviterUser", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto bindInviterUser(HttpServletRequest request, RequestHeader requestHeader,
            @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String userMobile = StringHelper.objectToString(map.get("userMobile"), "");
            String userId = StringHelper.objectToString(map.get("userId"), "");
            if(StringUtils.isEmpty(userMobile) || StringUtils.isEmpty(userId)){
                response = new ResponseDto(WebExceptionCode.MISSINGPARAMETER.errorCode, WebExceptionCode.MISSINGPARAMETER.errorMsg);
            }else{
            	UsrDetail userDetail = userService.findUserByMobile(userMobile);
            	if(userDetail != null){
            		response = new ResponseDto(WebExceptionCode.HASEXIST.errorCode, WebExceptionCode.HASEXIST.errorMsg);
            	}else{
            		UsrDetail userDetailAgent = userService.findUserById(userId);//memberService.getUserDetailByUserId(userId, "");
            		if(userDetailAgent != null){
	            		ActivitySchool school = schoolService.findByInviteeUserMobile(userMobile);
			        	if(school != null){
			        		schoolService.deleteByInviteeUserMobile(userMobile);
			        	}
		        		List<ActivitySchoolAgent> list = schoolAgentService.findByUserId(userId);
		        		if(list == null || list.size() == 0){
		        			response = new ResponseDto(WebExceptionCode.AGENTHASEXPIRED.errorCode, WebExceptionCode.AGENTHASEXPIRED.errorMsg);
		        		}else{
		        			schoolService.saveActivitySchool(userMobile, userId);
		        		}
            		}else{
            			response = new ResponseDto(WebExceptionCode.AGENTNOTEXIST.errorCode, WebExceptionCode.AGENTNOTEXIST.errorMsg);
            		}
            	}
            	
            }
            
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg",e);
        } catch (Exception e) {
        	logger.error("errorMsg",e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }
	
	
	@RequestMapping(value = "/countBySchoolAct", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto countDownloadByAct(HttpServletRequest request, RequestHeader requestHeader,
            @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
        	
        	String startDateStr = StringHelper.objectToString(map.get("startDateStr"), "");
        	String endDateStr = StringHelper.objectToString(map.get("endDateStr"), "");
        	
        	String activityStartDateStr = StringHelper.objectToString(map.get("activityStartDate"), "");
        	String activityEndDateStr = StringHelper.objectToString(map.get("activityEndDate"), "");
        	
        	
        	if(StringUtils.isEmpty(activityStartDateStr) || StringUtils.isEmpty(activityEndDateStr)){
                response = new ResponseDto(WebExceptionCode.MISSINGPARAMETER.errorCode, WebExceptionCode.MISSINGPARAMETER.errorMsg);
	        }else{
	        	
	        	Date activityStartDate = DateUtils.str2Date(activityStartDateStr, DateUtils.DEFAULT_FORMAT);
	        	Date activityEndDate = DateUtils.str2Date(activityEndDateStr, DateUtils.DEFAULT_FORMAT);
	    		
	        	Date startDate = null;
	        	Date endDate = null;
	        	
	        	if(StringUtils.isEmpty(startDateStr)){
	        		startDate = activityStartDate;
	        	}else{
	        		startDate = DateUtils.str2Date(startDateStr, DateUtils.DEFAULT_FORMAT);
	        	}
	        	if(StringUtils.isEmpty(endDateStr)){
	        		endDate = new Date();
	        	}else{
	        		endDate = DateUtils.str2Date(endDateStr, DateUtils.DEFAULT_FORMAT);
	        	}
	        	
	        	List<ActivitySchoolAgent> agentList = new ArrayList<>();
	        	
	        	agentList = schoolService.getAllSchoolAgent();
	        	
	        	SchoolCountDto schoolCountDto = null;
	        	
	        	List<SchoolCountDto> schoolCountDtoList = new ArrayList<>();
	        	
	        	for(ActivitySchoolAgent agent : agentList){
	        		schoolCountDto = new SchoolCountDto();
	        		long countDownLoad = schoolService.countAll(agent.getUserId(), activityStartDate,activityEndDate);
	        		long countRegs = schoolService.countByRebateStatus(1,agent.getUserId(),activityStartDate,activityEndDate);
	        		String totalPrice = schoolService.sumConsumeHistory(DateUtils.date2Str(startDate), DateUtils.date2Str(endDate),activityStartDate,activityEndDate,agent.getUserId());
	        		schoolCountDto.setCountDownLoad((int)countDownLoad);
	        		schoolCountDto.setCountRegs((int)countRegs);
	        		schoolCountDto.setTotalResume(totalPrice);
	        		schoolCountDto.setUserId(agent.getUserId());
	        		schoolCountDto.setUserName(agent.getUserName());
	        		schoolCountDtoList.add(schoolCountDto);
	        		
	        	}
	        	
			    result.put("schoolCountDto", schoolCountDtoList);
	       }
        	
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg",e);
        } catch (Exception e) {
        	logger.error("errorMsg",e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }
	
	@RequestMapping(value = "/deleteBindUser", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto deleteBindUser(HttpServletRequest request, RequestHeader requestHeader,
            @RequestBody Map<String, Object> map) {
		ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            
        	schoolService.deleteBindUser();
            
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg",e);
        } catch (Exception e) {
        	logger.error("errorMsg",e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }
	 
}
