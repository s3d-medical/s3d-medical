package com.nhs.o2o.web;


import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Maps;
import com.nhs.core.context.SysPropsFactory;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.core.web.WebController;
import com.nhs.core.web.WebExceptionCode;
import com.nhs.core.web.WebRequestException;
import com.nhs.core.web.dto.RequestHeader;
import com.nhs.core.web.dto.ResponseDto;
import com.nhs.shop.service.system.SystemParameterService;

@Controller
@RequestMapping(value = "/systemParam")
public class SystemParameterApi  extends WebController {
	private final Logger logger = LoggerFactory.getLogger(SystemParameterApi.class);
	 
	@Autowired
	private SystemParameterService sysService;
	 
	@RequestMapping(value = "/getParamValue", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto getParamValue(HttpServletRequest request, RequestHeader requestHeader,
            @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String keyType = StringHelper.objectToString(map.get("keyType"), "");
            String keyValue = sysService.getSingleValueByType(keyType);
            result.put("keyValue", keyValue);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg",e);
        } catch (Exception e) {
        	logger.error("errorMsg",e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }
	
/**
	 * sysConfig/v1.9/getSystemParameter
	 * @Title: getParamValue
	 * @Desc: 
	 * @author wind.chen 2016年11月23日 下午6:23:13
	 *
	 * @param request
	 * @param requestHeader
	 * @param map
	 * @return
	 * @throws
	 */
	/*@RequestMapping(value = "/v2.0/getSysConfig", method=RequestMethod.POST)
	@ResponseBody
	public ResponseDto getSysConfig(HttpServletRequest request,
			RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
		ResponseDto response = new ResponseDto();
		try {
			String platformTypeHeader=SysPropsFactory.getProperty("app.custHeaderName.platformType");
			String os ="";
			if(platformTypeHeader != null){
				os = request.getHeader(platformTypeHeader);
			}
			String appVersionHeader = SysPropsFactory.getProperty("app.custHeaderName.appVersion");
			String curVer="";
			if(appVersionHeader != null){
				curVer = request.getHeader(appVersionHeader);
			}
			Map<String, Object> config = sysService.getSysConfigInMap(os, curVer);
			response.getResult().putAll(config);
			
		} catch (WebRequestException e) {
			response = new ResponseDto(WebExceptionCode.ERROR.errorCode,
					e.getMessage());
			logger.error("获取系统配置参数出错.", e);
		} catch (Exception e) {
			logger.error("获取系统配置参数出错.", e);
			response = new ResponseDto(WebExceptionCode.ERROR.errorCode,
					WebExceptionCode.ERROR.errorMsg);
		}
		return response;
	}*/
	
}
