package com.nhs.o2o.web.order;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nhs.core.web.dto.RequestHeader;
import com.nhs.shop.service.order.OrderHandleAfterPayService;
import com.nhs.shop.service.order.dto.OrderPayResultDto;

/**
 * 支付完毕后, 订单处理.
 * 
 * @author wind.chen
 */
@Controller
@RequestMapping(value = "/api/v2.0/order")
public class OrderHandleAfterPayApi {
	private static Logger logger = LoggerFactory.getLogger(OrderHandleAfterPayApi.class);
	@Autowired
	private OrderHandleAfterPayService orderHandleAfterPayService;

	/**
	 * 支付完毕后, 处理订单.
	 * @Title: handleAfterPay
	 * @Desc: 
	 * @author wind.chen 2016年11月21日 下午3:24:46
	 *
	 * @param requestHeader
	 * @param dto
	 * @return
	 * @throws
	 */
	@RequestMapping(value = "/handleOrderAfterPay", method = RequestMethod.POST)
	@ResponseBody
	public String handleAfterPay(HttpServletRequest req, OrderPayResultDto dto) {
		boolean handleResult = false;
		try {
			handleResult = orderHandleAfterPayService.handleOrderPay(dto);
		} catch (Exception e) {
			logger.error("支付后, 进行后续的订单处理失败.", e);
		}
		if (handleResult) {
			return "success";
		}
		return "failed";
	}
}