package com.nhs.o2o.web;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Maps;
import com.nhs.core.orm.Page;
import com.nhs.core.utils.common.HttpIpUtils;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.core.web.WebController;
import com.nhs.core.web.WebExceptionCode;
import com.nhs.core.web.WebRequestException;
import com.nhs.core.web.dto.RequestHeader;
import com.nhs.core.web.dto.ResponseDto;
import com.nhs.shop.service.common.service.ConfigService;
import com.nhs.shop.service.order.StoreOrderService;
import com.nhs.shop.service.order.dto.StoreOrderDto;
import com.nhs.shop.util.ExcelUtils;

/**
 * 商超订单接口
 * 
 * @Title: StoreOrderApi.java
 * @Package com.nhs.o2o.web
 * @Description: TODO
 * @author huxianjun
 * @date 2016年8月20日 上午10:34:20
 * @version V1.0
 */
@Controller
@RequestMapping(value = "/storeOrder")
public class StoreOrderApi extends WebController {

    private final Logger logger = LoggerFactory.getLogger(StoreOrderApi.class);

    @Autowired
    private StoreOrderService storeOrderService;

    @Autowired
    private ConfigService configService;

    private static Integer MAX_PAGE_SIZE = 10000;

    /**
     * 创建订单
     * @Title: add
     * @Description: TODO
     * @param @param requestHeader
     * @param @param dto
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年7月20日 
     * @throws
     */
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto add(HttpServletRequest request, RequestHeader requestHeader,
            @RequestBody Map<String, Object> map, @RequestParam(value = "systemtime") String systemtime,
            @RequestParam(value = "sign") String sign) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String ip = HttpIpUtils.getClientIp(request);
            if (map != null) {
                StringBuffer log = new StringBuffer("##store order params ==> ");
                for (Map.Entry<String, Object> entry : map.entrySet()) {
                    log.append(entry.getKey() + ": " + entry.getValue() + " ");
                }
                logger.info(log.toString() + "systemTime:" + systemtime + " sign:" + sign + "##");
            }
            Map<String, Object> data = storeOrderService.saveStoreOrder(ip, map, systemtime, sign);
            result.putAll(data);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.info(e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 获取订单列表
     * @Title: add
     * @Description: TODO
     * @param @param requestHeader
     * @param @param dto
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年7月20日 
     * @throws
     */
    @RequestMapping(value = "/list", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto list(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String userId = StringHelper.objectToString(map.get("userId"), "");
            Integer status = StringHelper.objectToInt(map.get("status"), 0);
            Integer pageNo = StringHelper.objectToInt(map.get("pageNo"), 0);
            Integer pageSize = StringHelper.objectToInt(map.get("pageSize"), 0);
            
            Page<Map<String, Object>> page = createPage(pageNo, pageSize);
            List<StoreOrderDto> list = storeOrderService.getOrderList(userId, status,page);
            result.put("list", list);
            result.put("totalCount", page.getTotalCount());
            result.put("totalPage", page.getTotalPage());
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.info(e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 获取订单列表(PC)
     * @Title: list
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author liangdanhua 2016年11月22日 
     * @throws
     */
    @RequestMapping(value = "/pcList", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto pcList(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String userId = StringHelper.objectToString(map.get("userId"), "");
            Integer status = StringHelper.objectToInt(map.get("status"), 0);
            Integer pageNo = StringHelper.objectToInt(map.get("pageNo"), 0);
            Integer pageSize = StringHelper.objectToInt(map.get("pageSize"), 0);
            // PC端按照条件查询
            String startTime = StringHelper.objectToString(map.get("startTime"), "");
            String endTime = StringHelper.objectToString(map.get("endTime"), "");
            String orderNum = StringHelper.objectToString(map.get("orderNum"), "");
            String tradeNo = StringHelper.objectToString(map.get("tradeNo"), "");
            int type = StringHelper.objectToInt(map.get("type"), 0);
            Page<Map<String, Object>> page = createPage(pageNo, pageSize);
            List<StoreOrderDto> list = storeOrderService.getOrderPcList(userId, status, startTime, endTime, orderNum,
                    tradeNo,type, page);
            result.put("list", list);
            result.put("totalCount", page.getTotalCount());
            result.put("totalPage", page.getTotalPage());
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.info(e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 获取订单详情
     * @Title: add
     * @Description: TODO
     * @param @param requestHeader
     * @param @param dto
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年7月20日 
     * @throws
     */
    @RequestMapping(value = "/detail", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto detail(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String userId = StringHelper.objectToString(map.get("userId"), "");
            Integer orderId = StringHelper.objectToInt(map.get("orderId"), 0);
            StoreOrderDto dto = storeOrderService.getOrderDetail(userId, orderId);
            result.put("detail", dto);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.info(e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 获取订单详情
     * @Title: add
     * @Description: TODO
     * @param @param requestHeader
     * @param @param dto
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年7月20日 
     * @throws
     */
    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto delete(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            Integer orderId = StringHelper.objectToInt(map.get("orderId"), 0);
            storeOrderService.delete(orderId);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.info(e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    @RequestMapping(value = "/export", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto export(RequestHeader requestHeader, @RequestBody Map<String, Object> map) throws Exception {
        ResponseDto response = new ResponseDto();
        String filePath = configService.getExcelTemplateFilePath();
        String exportPath = configService.getExcelExportPath();
        String downloadPath = configService.getExcelExportPathUrl();
        ExcelUtils excelUtils = new ExcelUtils(filePath);
        String userId = StringHelper.objectToString(map.get("userId"), "");
        int status = StringHelper.objectToInt(map.get("status"), 0);
        String startTime = StringHelper.objectToString(map.get("startTime"), "");
        String endTime = StringHelper.objectToString(map.get("endTime"), "");
        String orderNum = StringHelper.objectToString(map.get("orderNum"), "");
        String tradeNo = StringHelper.objectToString(map.get("tradeNo"), "");
        List<Map<String, Object>> result = storeOrderService.getOrderPcList(userId, status, startTime, endTime,
                orderNum, tradeNo, 0);
        if (result == null || result.size() < 1) {
            return response;
        }

        int sheetNum = 0;
        if (result.size() < MAX_PAGE_SIZE) {
            sheetNum = 1;
        } else {
            sheetNum = result.size() / MAX_PAGE_SIZE == 0 ? (result.size() / MAX_PAGE_SIZE)
                    : (result.size() / MAX_PAGE_SIZE + 1);
        }
        // 生成10万条数据
        BigDecimal totalOrderAmount = new BigDecimal("0.00");
        BigDecimal totalOrderAdFee = new BigDecimal("0.00");
        BigDecimal totalGiveSilver = new BigDecimal("0.00");
        for (int i = 0; i < sheetNum; i++) {
            excelUtils.changeSheet(i);
            int max = ((result.size() - MAX_PAGE_SIZE * i) > MAX_PAGE_SIZE) ? MAX_PAGE_SIZE * (i + 1) : result.size();
            for (int j = i * MAX_PAGE_SIZE; j < max; j++) {
                Map<String, Object> mapResult = result.get(j);
                List<Object> objects = new ArrayList<>();
                objects.add(StringHelper.objectToString(mapResult.get("order_num"), ""));
                objects.add(StringHelper.objectToString(mapResult.get("trade_no"), ""));
                objects.add(StringHelper.objectToString(mapResult.get("pay_amount"), "0.00"));
                totalOrderAmount = totalOrderAmount
                        .add(StringHelper.objectToBigDecimal(mapResult.get("pay_amount"), "0.00"))
                        .setScale(2, BigDecimal.ROUND_DOWN);
                BigDecimal totalAdFee = storeOrderService
                        .getOrderAdFee(StringHelper.objectToString(mapResult.get("order_num"), ""));
                objects.add(totalAdFee == null ? "0.00" : totalAdFee.toString());
                totalOrderAdFee = totalOrderAdFee.add(totalAdFee).setScale(2, BigDecimal.ROUND_DOWN);
                objects.add(StringHelper.objectToString(mapResult.get("give_silver"), "0.00"));
                totalGiveSilver = totalGiveSilver
                        .add(StringHelper.objectToBigDecimal(mapResult.get("give_silver"), "0.00"))
                        .setScale(2, BigDecimal.ROUND_DOWN);
                objects.add(StringHelper.objectToString(mapResult.get("pay_time"), ""));
                objects.add(StringHelper.objectToString(mapResult.get("create_time"), ""));
                excelUtils.writeLine(objects);
            }
        }
        excelUtils.changeSheet(0);
        excelUtils.write("B2", result.size());
        excelUtils.write("E2", totalOrderAmount);
        excelUtils.write("B3", totalOrderAdFee);
        excelUtils.write("E3", totalGiveSilver);
        String xlsxoutput = exportPath + "/" + getUUIDPath("商超订单");
        FileOutputStream fileOut = null;
        String urlPath = downloadPath;
        try {
            File file = new File(xlsxoutput);
            // 父目录不存在则创建
            if (!file.getParentFile().exists()) {
                file.getParentFile().mkdirs();
            }
            fileOut = new FileOutputStream(file);
            urlPath += file.getName();
        } catch (IOException e) {

        }
        excelUtils.changeSheet(1);
        excelUtils.save(fileOut);
        Map<String, Object> mapResult = new HashMap<>();
        mapResult.put("path", urlPath);
        response.getResult().putAll(mapResult);
        return response;
    }

    // 生成文件名 userName + 日期 + 随机数 + **.xlsx
    private String getUUIDPath(String userName) {
        String fileName = ".xlsx";
        StringBuilder builder = new StringBuilder();
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date());
        String uuid = UUID.randomUUID().toString();
        builder.append(cal.get(Calendar.YEAR)).append("_").append(cal.get(Calendar.MONTH) + 1).append("_")
                .append(cal.get(Calendar.DAY_OF_MONTH)).append("_").append(uuid)
                .append(fileName.substring(fileName.lastIndexOf('.')));
        fileName = userName + "_" + builder.toString();
        return fileName;
    }
}
