package com.nhs.o2o.web;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Maps;
import com.nhs.core.orm.Page;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.core.web.WebController;
import com.nhs.core.web.WebExceptionCode;
import com.nhs.core.web.WebRequestException;
import com.nhs.core.web.dto.RequestHeader;
import com.nhs.core.web.dto.ResponseDto;
import com.nhs.shop.entry.legend.shop.BenefitsBanding;
import com.nhs.shop.service.Benefits.BenefitsService;
import com.nhs.shop.service.Benefits.dto.SalesDto;
import com.nhs.shop.service.Benefits.dto.SalesclerkDto;

/**
 * 人人福利
 * @Title: BenefitsApi.java
 * @Package com.nhs.o2o.web
 * @Description: TODO
 * @author liangdanhua
 * @date 2016年11月3日 下午1:46:35
 * @version V1.0
 */
@Controller
@RequestMapping(value = "/benefits")
public class BenefitsApi extends WebController {

    private final Logger logger = LoggerFactory.getLogger(BenefitsApi.class);

    @Autowired
    private BenefitsService benefitsService;

    /**
     * 绑定
     * @Title: binding
     * @Description: TODO
     * @param @param requestHeader
     * @param @param benefitsBanding
     * @param @return   
     * @return ResponseDto 
     * @author liangdanhua 2016年11月3日 
     * @throws
     */

    @RequestMapping(value = "/v1.9.1/binding", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto binding(RequestHeader requestHeader, @RequestBody BenefitsBanding benefitsBanding) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            benefitsService.saveBenefits(benefitsBanding);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 更新
     * @Title: update
     * @Description: TODO
     * @param @param requestHeader
     * @param @param benefitsBanding
     * @param @return   
     * @return ResponseDto 
     * @author liangdanhua 2016年11月3日 
     * @throws
     */
    @RequestMapping(value = "/v1.9.1/update", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto update(RequestHeader requestHeader, @RequestBody BenefitsBanding benefitsBanding) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            benefitsService.updateBenefits(benefitsBanding);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
    * 校验领取福利
    * @Title: check
    * @Description: TODO
    * @param @param requestHeader
    * @param @param map
    * @param @return   
    * @return ResponseDto 
    * @author liangdanhua 2016年11月15日 
    * @throws
    */
    @RequestMapping(value = "/v1.9.1/verification", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto check(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String verifcationId = StringHelper.objectToString(map.get("checkCode"), "");
            String userId = StringHelper.objectToString(map.get("userId"), "");
            benefitsService.saveBenefits(verifcationId, userId);

        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 营业员管理/营业员列表
     * @Title: list
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author liangdanhua 2016年11月4日 
     * @throws
     */
    @RequestMapping(value = "/v1.9.1/findlist", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto list(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            // 查询的条件
            String startDate = StringHelper.objectToString(map.get("startDate"), "");
            String endDate = StringHelper.objectToString(map.get("endDate"), "");
            String shopName = StringHelper.objectToString(map.get("shopName"), "");
            String name = StringHelper.objectToString(map.get("name"), "");
            String phone = StringHelper.objectToString(map.get("phone"), "");
            Integer pageNo = StringHelper.objectToInt(map.get("pageNo"), 0);
            Integer pageSize = StringHelper.objectToInt(map.get("pageSize"), 0);
            String userId = StringHelper.objectToString(map.get("userId"), "");
            Integer status = StringHelper.objectToInt(map.get("status"), 100);
            Page<Map<String, Object>> page = createPage(pageNo, pageSize);
            List<SalesclerkDto> list = benefitsService.findlist(startDate, endDate, shopName, name, phone, status,
                    page);

            result.put("list", list);
            result.put("totalCount", page.getTotalCount());
            result.put("totalPage", page.getTotalPage());
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 营业员信息
     * @Title: list
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author liangdanhua 2016年11月4日 
     * @throws
     */
    @RequestMapping(value = "/v1.9.1/salesData", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto salesData(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String userId = StringHelper.objectToString(map.get("userId"), "");
            Integer id = StringHelper.objectToInt(map.get("id"), 0);

            SalesDto salesDto = benefitsService.salesData(userId, id);
            result.put("salesDto", salesDto);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 营业员订单列表
     * @Title: salesOrderList
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author liangdanhua 2016年11月4日 
     * @throws
     */
    @RequestMapping(value = "/v1.9.1/salesOrderList", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto salesOrderList(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String startDate = StringHelper.objectToString(map.get("startDate"), "");
            String endDate = StringHelper.objectToString(map.get("endDate"), "");
            String shopName = StringHelper.objectToString(map.get("shopName"), "");
            String orderNum = StringHelper.objectToString(map.get("orderNum"), "");
            Integer shopId = StringHelper.objectToInt(map.get("shopId"), 0);

            String salesId = StringHelper.objectToString(map.get("salesId"), "");
            String memberId = StringHelper.objectToString(map.get("memberId"), "");
            String userId = StringHelper.objectToString(map.get("userId"), "");
            
            Integer pageNo = StringHelper.objectToInt(map.get("pageNo"), 0);
            Integer pageSize = StringHelper.objectToInt(map.get("pageSize"), 0);
            Page<Map<String, Object>> page = createPage(pageNo, pageSize);
            // 分页
            List<SalesclerkDto> list = benefitsService.salesOrderList(startDate, endDate, shopName, orderNum, salesId,
                    memberId, userId,page ,shopId);
            // 总订单，总金额
            Map<String, Object> totoal = benefitsService.findParam(startDate, endDate, shopName, orderNum, salesId ,userId ,shopId);
            result.put("list", list);
            result.put("totoal", totoal);
            result.put("totalCount", page.getTotalCount());
            result.put("totalPage", page.getTotalPage());
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 营业员收益记录
     * @Title: salesOrderList
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author liangdanhua 2016年11月4日 
     * @throws
     */
    @RequestMapping(value = "/v1.9.1/profitReadecord", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto profitReadecord(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String startDate = StringHelper.objectToString(map.get("startDate"), "");
            String endDate = StringHelper.objectToString(map.get("endDate"), "");
            String shopName = StringHelper.objectToString(map.get("shopName"), "");
            String orderNum = StringHelper.objectToString(map.get("orderNum"), "");
            Integer pageNo = StringHelper.objectToInt(map.get("pageNo"), 0);
            Integer pageSize = StringHelper.objectToInt(map.get("pageSize"), 0);
            String salesId = StringHelper.objectToString(map.get("salesId"), "");

            Page<Map<String, Object>> page = createPage(pageNo, pageSize);
            result.put("list", benefitsService.profitReadecord(startDate, endDate, shopName, orderNum, salesId, page));
            result.put("totalCount", page.getTotalCount());
            result.put("totalPage", page.getTotalPage());

        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 营业员店铺记录
     * @Title: salesShopOpeLog
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author liangdanhua 2016年11月10日 
     * @throws
     */
    @RequestMapping(value = "/v1.9.1/salesShopOpeLog", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto salesShopOpeLog(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String salesId = StringHelper.objectToString(map.get("salesId"), "");
            result.put("list", benefitsService.salesShopOpeLogBySalesId(salesId));
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 营业员佰德券使用记录
     * @Title: coinCommissionGoldLog
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author liangdanhua 2016年11月17日 
     * @throws
     */
    @RequestMapping(value = "/v1.9.1/coinCommissionGoldLog", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto coinCommissionGoldLog(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String userId = StringHelper.objectToString(map.get("userId"), "");
            Integer pageNo = StringHelper.objectToInt(map.get("pageNo"), 0);
            Integer pageSize = StringHelper.objectToInt(map.get("pageSize"), 0);
            Page<Map<String, Object>> page = createPage(pageNo, pageSize);

            result.put("list", benefitsService.coinCommissionGoldLogByuserId(userId, page));
            result.put("totalCount", page.getTotalCount());
            result.put("totalPage", page.getTotalPage());

        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

}
