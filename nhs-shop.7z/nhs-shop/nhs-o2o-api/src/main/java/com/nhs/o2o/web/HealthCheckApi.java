package com.nhs.o2o.web;

import java.util.Date;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Maps;
import com.nhs.core.context.SysPropsFactory;
import com.nhs.core.utils.common.DateUtils;

/**
 * 健康检查
 * @Title: HealthCheckApi.java
 * @Package com.nhs.o2o.web
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年8月1日 下午4:16:15
 * @version V1.0
 */
@Controller
@RequestMapping(value = "/health")
public class HealthCheckApi {

    @RequestMapping(value = "/check", method = { RequestMethod.GET, RequestMethod.POST })
    @ResponseBody
    public Map<String, Object> check() {
        Map<String, Object> map = Maps.newHashMap();
        map.put("status", "alive");
        map.put("version", SysPropsFactory.getProperty("version"));
        map.put("title", SysPropsFactory.getProperty("title"));
        map.put("time", DateUtils.date2Str(new Date()));
        return map;
    }

}
