package com.nhs.o2o.store.web;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Maps;
import com.nhs.core.orm.Page;
import com.nhs.core.utils.common.HttpIpUtils;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.core.web.WebController;
import com.nhs.core.web.WebExceptionCode;
import com.nhs.core.web.WebRequestException;
import com.nhs.core.web.dto.RequestHeader;
import com.nhs.core.web.dto.ResponseDto;
import com.nhs.o2o.util.O2oConstant;
import com.nhs.o2o.web.MemberApi;
import com.nhs.shop.service.order.O2oServiceOrderService;
import com.nhs.shop.service.order.dto.ServiceOrderListDto;
import com.nhs.shop.service.shop.O2oShopService;
import com.nhs.shop.service.shop.dto.ShopPhotosDto;
import com.nhs.user.service.MemberService;

@Controller
@RequestMapping(value = "/store")
public class StoreApi  extends WebController {
	private final Logger logger = LoggerFactory.getLogger(MemberApi.class);
	
	 @Resource
	 MemberService memberService;
	 
	 @Autowired
	 private O2oServiceOrderService o2oServiceOrderService;
	 
	 @Autowired
	 private O2oShopService o2oShopService;

	 
	@RequestMapping(value = "/login", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto memberLogin(HttpServletRequest request, RequestHeader requestHeader,
            @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String userAccount = StringHelper.objectToString(map.get("userAccount"), "");
            String password = StringHelper.objectToString(map.get("password"), "");
            String openid = StringHelper.objectToString(map.get("openid"), "");
            Integer type = StringHelper.objectToInt(map.get("type"), 0);
            String ip = HttpIpUtils.getClientIp(request);
            logger.info("######memberLogin###### request paramters: userAccount:"+userAccount+"password:"+password);
            result = memberService.storeMemberLogin(ip, userAccount, password, type, openid);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg",e);
        } catch (Exception e) {
        	logger.error("errorMsg",e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }
	
	
	@RequestMapping(value = "/getHomeStoreInfo", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto getHomeStoreInfo(HttpServletRequest request, RequestHeader requestHeader,
            @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String userId = StringHelper.objectToString(map.get("userId"), "");
            Integer shopId = StringHelper.objectToInt(map.get("shopId"), 0);
            result = memberService.getHomeStoreInfo(userId, shopId);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg",e);
        } catch (Exception e) {
        	logger.error("errorMsg",e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }
	
	
	@RequestMapping(value = "/storeOrderList", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto storeOrderList(HttpServletRequest request, RequestHeader requestHeader,
            @RequestBody Map<String, Object> map) {
		 ResponseDto response = new ResponseDto();
	        Map<String, Object> result = Maps.newHashMap();
	        try {
	            String shopId = StringHelper.objectToString(map.get("shopId"), "");
	            Integer status = StringHelper.objectToInt(map.get("status"), 0);
	            Integer pageNo = StringHelper.objectToInt(map.get("pageNo"), 0);
	            Integer pageSize = StringHelper.objectToInt(map.get("pageSize"), 0);
	            Page<Map<String, Object>> page = createPage(pageNo, pageSize);
	            List<ServiceOrderListDto> list = o2oServiceOrderService.getO2oStoreOrderList(shopId, status, page);
	            result.put("storeOrderList", list);
	            result.put("totalCount", page.getTotalCount());
	            result.put("totalPage", page.getTotalPage());
	        } catch (WebRequestException e) {
	            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
	            logger.info(e.getMessage());
	            logger.error("errorMsg",e);
	        } catch (Exception e) {
	        	logger.error("errorMsg",e);
	            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
	        }
	        response.getResult().putAll(result);
	        return response;
    }
	
	@RequestMapping(value = "/updateStoreInfo", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto updateStoreInfo(HttpServletRequest request, RequestHeader requestHeader,
            @RequestBody Map<String, Object> map) {
		 ResponseDto response = new ResponseDto();
	        Map<String, Object> result = Maps.newHashMap();
	        try {
	        	int shopId = StringHelper.objectToInt(map.get("shopId"), 0);
	            String perCost = StringHelper.objectToString(map.get("perCost"), "");
	            String contactPhone = StringHelper.objectToString(map.get("contactPhone"), "");
	            String smsMobile = StringHelper.objectToString(map.get("smsMobile"), "");
	            String storeDesc = StringHelper.objectToString(map.get("storeDesc"), "");
	            String installation = StringHelper.objectToString(map.get("installation"), "");
	            String serviceTime = StringHelper.objectToString(map.get("serviceTime"), "");
	            String story = StringHelper.objectToString(map.get("story"), "");
	            
	           
	            o2oServiceOrderService.updateO2oStoreInfo(perCost,contactPhone,smsMobile,storeDesc,installation,serviceTime,story,shopId);
	          
	        } catch (WebRequestException e) {
	            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
	            logger.info(e.getMessage());
	            logger.error("errorMsg",e);
	        } catch (Exception e) {
	        	logger.error("errorMsg",e);
	            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
	        }
	        response.getResult().putAll(result);
	        return response;
    }
	
	/**
	 * 移动端上传店铺图片到相册
	 * @param request
	 * @param requestHeader
	 * @param map
	 * @return
	 */
	 @RequestMapping(value = "saveStorePhotos", method = RequestMethod.POST)
	 @ResponseBody
	 public ResponseDto saveStorePhotos(HttpServletRequest request, RequestHeader requestHeader, @RequestBody Map<String, Object> map){
		ResponseDto response = new ResponseDto();
		Map<String, Object> result = Maps.newHashMap();
		try {
			List<String> photosList = (List<String>) map.get("photos");
			int shopId = StringHelper.objectToInt(map.get("shopId"), 0);
			int type = StringHelper.objectToInt(map.get("type"), 1);
			String title = StringHelper.objectToString(map.get("title"), "");
			String content = StringHelper
					.objectToString(map.get("content"), "");

			o2oShopService.saveStorePhotos(shopId, photosList, type, title,
					content);
		} catch (WebRequestException e) {
			response = new ResponseDto(WebExceptionCode.ERROR.errorCode,
					e.getMessage());
			logger.info(e.getMessage());
			logger.error("errorMsg",e);
		} catch (Exception e) {
			logger.error("errorMsg",e);
			response = new ResponseDto(WebExceptionCode.ERROR.errorCode,
					WebExceptionCode.ERROR.errorMsg);
		}
		response.getResult().putAll(result);
		return response;
			
	 }
	 
	 /**
	  * 移动端获取店铺相册
	  * @param request
	  * @param requestHeader
	  * @param map
	  * @return
	  */
	 @RequestMapping(value = "getStorePhotos", method = RequestMethod.POST)
	 @ResponseBody
	 public ResponseDto getStorePhotos(HttpServletRequest request, RequestHeader requestHeader, @RequestBody Map<String, Object> map){
		ResponseDto response = new ResponseDto();
		Map<String, List<ShopPhotosDto>> result = Maps.newHashMap();
		try {
			int shopId = StringHelper.objectToInt(map.get("shopId"), 0);

			result = o2oShopService.getStorePhotos(shopId);
		} catch (WebRequestException e) {
			response = new ResponseDto(WebExceptionCode.ERROR.errorCode,
					e.getMessage());
			logger.info(e.getMessage());
			logger.error("errorMsg",e);
		} catch (Exception e) {
			logger.error("errorMsg",e);
			response = new ResponseDto(WebExceptionCode.ERROR.errorCode,
					WebExceptionCode.ERROR.errorMsg);
		}
		response.getResult().putAll(result);
		return response;
			
	 }
	 
	 @RequestMapping(value = "validateTokenFailed")
	 @ResponseBody
	 public ResponseDto validateTokenFailed(HttpServletRequest request, RequestHeader requestHeader){
		 ResponseDto response = new ResponseDto();
		 String errorParam =  request.getParameter("errorParam");
		 logger.info("####validateTokenFailed#### 验证token失败，失败的error_param为："+errorParam);
		 String errorMsg = "服务异常，请重新登录！";
		 if("1".equals(errorParam)){
			 errorMsg = "无效的Token,请重新登录！";
		 }else if("2".equals(errorParam)){
			 errorMsg = "店铺状态处于非正常状态！";
		 }else if(StringUtils.isEmpty(errorParam)){
			 errorMsg = "token为空,请重新登录！";
		 }
		 response = new ResponseDto(WebExceptionCode.EXPIRE.errorCode,
				 errorMsg);
		 return response;
	 }
	 
}
