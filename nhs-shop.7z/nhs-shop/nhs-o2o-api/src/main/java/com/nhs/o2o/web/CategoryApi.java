package com.nhs.o2o.web;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Maps;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.core.web.WebController;
import com.nhs.core.web.WebExceptionCode;
import com.nhs.core.web.WebRequestException;
import com.nhs.core.web.dto.RequestHeader;
import com.nhs.core.web.dto.ResponseDto;
import com.nhs.shop.entry.legend.shop.O2oHotCategoryConfig;
import com.nhs.shop.service.category.CategoryService;
import com.nhs.shop.service.category.dto.CategoryDto;
import com.nhs.shop.service.category.dto.O2oCategoryDto;
import com.nhs.shop.service.category.dto.O2oHotCategoryDto;

/**
 * 商品分类controller
 * @Title: CategoryApi.java
 * @Package com.nhs.o2o.web
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月16日 下午5:32:47
 * @version V1.0
 */
@Controller
@RequestMapping(value = "/category")
public class CategoryApi extends WebController {

    private final Logger logger = LoggerFactory.getLogger(CategoryApi.class);

    @Autowired
    private CategoryService categoryService;

    /**
     * 获取商品分类列表
     * @Title: getCategoryList
     * @Description: TODO
     * @param @param requestHeader
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年7月17日 
     * @throws
     */
    @RequestMapping(value = "/list", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto list(RequestHeader requestHeader) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            List<CategoryDto> list = categoryService.getCategoryList();
            result.put("list", list);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.info(e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * O2O热门分类配置组列表
     * @Title: o2ohotlist
     * @Description: TODO
     * @param @param requestHeader
     * @param @return   
     * @return ResponseDto 
     * @author liangdanhua 2016年9月18日 
     * @throws
     */
    @RequestMapping(value = "/o2oHotlist", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto o2ohotlist(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            Integer pageNo = StringHelper.objectToInt(map.get("pageNo"), 0);
            Integer pageSize = StringHelper.objectToInt(map.get("pageSize"), 0);
            List<O2oHotCategoryDto> o2ohotCategorylist = categoryService.getO2oHotCategoryList(pageNo, pageSize);
            result.put("list", o2ohotCategorylist);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.info(e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * O2O热门分类配置组新增
     * @Title: o2oHotadd
     * @Description: TODO
     * @param @param requestHeader
     * @param @return   
     * @return ResponseDto 
     * @author liangdanhua 2016年9月18日 
     * @throws
     */
    @RequestMapping(value = "/o2oHotadd", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto o2oHotadd(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String name = StringHelper.objectToString(map.get("name"), "");
            String isSave = categoryService.addO2oHotCategory(name);
            result.put("isSave", isSave);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * O2O热门分类配置组发布
     * @Title: o2oHotadd
     * @Description: TODO
     * @param @param requestHeader
     * @param @return   
     * @return ResponseDto 
     * @author liangdanhua 2016年9月18日 
     * @throws
     */
    @RequestMapping(value = "/o2oHotPublish", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto o2oHotPublish(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String isSave = categoryService.publishO2oHotCategory();
            result.put("isSave", isSave);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * O2O热门分类配保存
     * @Title: hotCategorySave
     * @Description: TODO
     * @param @param requestHeader
     * @param @param O2oHotCategorylist
     * @param @return   
     * @return ResponseDto 
     * @author liangdanhua 2016年9月18日 
     * @throws
     */
    @RequestMapping(value = "/hotCategorySave", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto hotCategorySave(RequestHeader requestHeader,
            @RequestBody List<O2oHotCategoryConfig> o2oHotCategorylist) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String isSave = categoryService.saveHotCategory(o2oHotCategorylist);
            result.put("isSave", isSave);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * O2O热门分类配二级分类获取
     * @Title: hotCategorySave
     * @Description: TODO
     * @param @param requestHeader
     * @param @param O2oHotCategorylist
     * @param @return   
     * @return ResponseDto 
     * @author liangdanhua 2016年9月18日 
     * @throws
     */
    @RequestMapping(value = "/o2oCategoryList", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto o2oHotList(RequestHeader requestHeader) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            List<O2oCategoryDto> list = categoryService.getO2oCategoryList();
            result.put("list", list);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * O2O热门分类配删除接口
     * @Title: deleteCategory
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author liangdanhua 2016年9月18日 
     * @throws
     */
    @RequestMapping(value = "/deleteCategory", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto deleteCategory(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            Integer groupId = StringHelper.objectToInt(map.get("groupId"), 0);
            String isdelete = categoryService.deleteCategoryByGroupId(groupId);
            result.put("isdelete", isdelete);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 根据分组ID获取分类信息
     * @Title: findCategory
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author liangdanhua 2016年9月28日 
     * @throws
     */
    @RequestMapping(value = "/queryCategory", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto queryCategory(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            Integer groupId = StringHelper.objectToInt(map.get("groupId"), 0);
            List<O2oHotCategoryConfig> o2oHotCategorys = categoryService.queryO2oHotCategoryDtoByGroupId(groupId);
            result.put("o2oHotCategorys", o2oHotCategorys);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 对热门分类重调换位置
     * @Title: findCategory
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author liangdanhua 2016年9月28日 
     * @throws
     */
    @RequestMapping(value = "/changeCategory", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto change(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            Integer id = StringHelper.objectToInt(map.get("id"), 0);
            Integer groupId = StringHelper.objectToInt(map.get("groupId"), 0);
            String index = StringHelper.objectToString(map.get("index"), "");
            String isSave = categoryService.saveChange(groupId, id, index);
            result.put("isSave", isSave);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }
}
