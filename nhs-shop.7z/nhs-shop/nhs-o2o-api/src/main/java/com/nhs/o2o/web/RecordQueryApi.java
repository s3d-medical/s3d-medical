package com.nhs.o2o.web;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.NumberUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Maps;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.core.web.WebController;
import com.nhs.core.web.WebExceptionCode;
import com.nhs.core.web.WebRequestException;
import com.nhs.core.web.dto.RequestHeader;
import com.nhs.core.web.dto.ResponseDto;
import com.nhs.shop.entry.legend.pay.PayLog;
import com.nhs.shop.service.pay.PayLogService;

/**
 * PC商城用
 * @Title: RecordQueryApi.java
 * @Package com.nhs.o2o.web
 * @Description: TODO
 * @author Administrator
 * @date 2016年12月6日 上午9:21:13
 * @version 
 */
@Controller
@RequestMapping(value = "/record")
public class RecordQueryApi extends WebController {

    private final Logger logger = LoggerFactory.getLogger(RecordQueryApi.class);

    @Autowired
    private PayLogService payLogService;

    /**
     * 消费记录
     * @Title: seller
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author zhujun 2016年8月31日 
     * @throws
     */
    @RequestMapping(value = "/consume/queryList", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto queryList(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String userId = StringHelper.objectToString(map.get("userId"), "");
            int pageNo = StringHelper.objectToInt(map.get("pageNo"), 0);
            int pageSize = StringHelper.objectToInt(map.get("pageSize"), 20);
            if (pageNo == -1) {
                pageNo = 0;
                pageSize = Integer.MAX_VALUE;
            }
            if (StringUtils.isNotBlank(userId)) {
                Page<PayLog> page = payLogService.getPayLogPage(new HashMap<String, Object>(), userId, pageNo,
                        pageSize);
                result.put("result", page.getContent());
                result.put("totalcount", page.getTotalElements());
            } else {
                throw new RuntimeException("参数异常");
            }

        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 删除 消费记录
     * @Title: delete
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年12月6日 
     * @throws
     */
    @RequestMapping(value = "/consume/delete", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto delete(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String pid = StringHelper.objectToString(map.get("pid"), "");
            if (StringUtils.isNotBlank(pid) && NumberUtils.isNumber(pid)) {
                payLogService.deletePayLog(Integer.valueOf(pid));
            } else {
                throw new RuntimeException("参数异常");
            }

        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 保存 消费记录
     * @Title: delete
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年12月6日 
     * @throws
     */
    @RequestMapping(value = "/consume/add", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto add(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String orderNum = StringHelper.objectToString(map.get("orderNum"), "");
            String tradeNo = StringHelper.objectToString(map.get("tradeNo"), "");
            String payAmount = StringHelper.objectToString(map.get("payAmount"), "");
            String payTypeName = StringHelper.objectToString(map.get("payTypeName"), "");
            String payStatus = StringHelper.objectToString(map.get("payStatus"), "");
            String payAccount = StringHelper.objectToString(map.get("payAccount"), "");
            String userId = StringHelper.objectToString(map.get("userId"), "");
            if (StringUtils.isBlank(orderNum) || StringUtils.isBlank(tradeNo) || StringUtils.isBlank(payAmount)
                    || StringUtils.isBlank(payTypeName) || StringUtils.isBlank(payStatus)
                    || StringUtils.isBlank(payAccount) || StringUtils.isBlank(userId)) {
                throw new RuntimeException("参数异常");
            } else {
                payLogService.savePayLog(orderNum, tradeNo, payAmount, payTypeName, payStatus, payAccount, userId);
            }

        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

}
