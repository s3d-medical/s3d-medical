package com.nhs.o2o.web;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Maps;
import com.nhs.core.orm.Page;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.core.web.WebController;
import com.nhs.core.web.WebExceptionCode;
import com.nhs.core.web.WebRequestException;
import com.nhs.core.web.dto.RequestHeader;
import com.nhs.core.web.dto.ResponseDto;
import com.nhs.shop.service.o2oshop.comment.O2oShopCommentService;
import com.nhs.shop.service.o2oshop.comment.dto.O2oShopCommentDto;

@Controller
@RequestMapping(value = "/o2oShopComment")
public class O2oShopCommentApi extends WebController {

    private final Logger logger = LoggerFactory.getLogger(O2oShopCommentApi.class);

    @Autowired
    private O2oShopCommentService commentService;

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/addComment", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto addComment(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            Integer shopId = StringHelper.objectToInt(map.get("shopId"), 0);
            String userId = StringHelper.objectToString(map.get("userId"), "");
            String commentContent = StringHelper.objectToString(map.get("commentContent"), "");
            Integer score = StringHelper.objectToInt(map.get("score"), 1);
            // String commentImage = StringHelper.objectToString(map.get("commentImage"), "");
            List<String> images = map.get("commentImage") == null ? new ArrayList<String>()
                    : (List<String>) map.get("commentImage");
            
            String orderNum = StringHelper.objectToString(map.get("orderNum"), "");
            if (StringUtils.isEmpty(orderNum) || StringUtils.isEmpty(userId) || shopId == 0) {
                response = new ResponseDto(WebExceptionCode.PARAMEXCEPTION.errorCode,
                        WebExceptionCode.PARAMEXCEPTION.errorMsg);
                response.getResult().putAll(result);
                return response;
            }
            boolean flag = commentService.findByUserIdAndShopIdAndOrderNum(userId, shopId, orderNum);
            if (flag) {
                response = new ResponseDto(WebExceptionCode.HASCOMMENT.errorCode, WebExceptionCode.HASCOMMENT.errorMsg);
                response.getResult().putAll(result);
                return response;
            }

            O2oShopCommentDto commentDto = new O2oShopCommentDto();
            commentDto.setShopId(shopId);
            commentDto.setUserId(userId);
            commentDto.setCommentContent(commentContent);
            commentDto.setScore(score);
            commentDto.setOrderNum(orderNum);
            commentService.addComment(images, commentDto);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    @RequestMapping(value = "/addLike", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto addLike(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String userId = StringHelper.objectToString(map.get("userId"), "");
            Integer commentId = StringHelper.objectToInt(map.get("commentId"), 0);
            commentService.addLike(userId, commentId);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * app端评价列表
     * @param requestHeader
     * @param map
     * @return
     */
    @RequestMapping(value = "/findCommentList", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto findCommentList(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            Integer shopId = StringHelper.objectToInt(map.get("shopId"), 0);
            String userId = StringHelper.objectToString(map.get("userId"), "");
            int type = StringHelper.objectToInt(map.get("type"), 0);
            Integer pageNo = StringHelper.objectToInt(map.get("pageNo"), 0);
            Integer pageSize = StringHelper.objectToInt(map.get("pageSize"), 0);
            String findType = StringHelper.objectToString(map.get("findType"), "");
            long countAll = 0;
            long countContansImage = 0;
            long countGoodCom = 0;
            long countMidCom = 0;
            long countBadCom = 0;
            if (StringUtils.isNotBlank(findType)) {
                countAll = commentService.countByTypeAndUserId(userId, 0);
                countContansImage = commentService.countByTypeAndUserId(userId, 1);
                countGoodCom = commentService.countByTypeAndUserId(userId, 2);
                countMidCom = commentService.countByTypeAndUserId(userId, 3);
                countBadCom = commentService.countByTypeAndUserId(userId, 4);
            } else {
                countAll = commentService.countByType(shopId, 0);
                countContansImage = commentService.countByType(shopId, 1);
                countGoodCom = commentService.countByType(shopId, 2);
                countMidCom = commentService.countByType(shopId, 3);
                countBadCom = commentService.countByType(shopId, 4);
            }

            result.put("countAll", countAll);
            result.put("countContansImage", countContansImage);
            result.put("countGoodCom", countGoodCom);
            result.put("countMidCom", countMidCom);
            result.put("countBadCom", countBadCom);

            Page<Map<String, Object>> page = createPage(pageNo, pageSize);
            List<O2oShopCommentDto> list = commentService.getShopCommentList(shopId, type, page, userId, findType);
            result.put("commentList", list);
            result.put("totalCount", page.getTotalCount());
            result.put("totalPage", page.getTotalPage());

        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 后台评价管理列表
     * @param requestHeader
     * @param map
     * @return
     */
    @RequestMapping(value = "/findCommentByCriteria", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto findCommentByCriteria(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            String shopName = StringHelper.objectToString(map.get("shopName"), "");
            String commentBy = StringHelper.objectToString(map.get("commentBy"), "");
            String startDate = StringHelper.objectToString(map.get("startDate"), "");
            String endDate = StringHelper.objectToString(map.get("endDate"), "");
            Integer pageNo = StringHelper.objectToInt(map.get("pageNo"), 0);
            Integer pageSize = StringHelper.objectToInt(map.get("pageSize"), 0);

            Page<Map<String, Object>> page = createPage(pageNo, pageSize);
            List<O2oShopCommentDto> list = commentService.findCommentByCriteria(startDate, endDate, commentBy, shopName,
                    page);
            result.put("commentList", list);
            result.put("totalCount", page.getTotalCount());
            result.put("totalPage", page.getTotalPage());

        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    @RequestMapping(value = "/deleteComment", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto deleteComment(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            Integer commentId = StringHelper.objectToInt(map.get("commentId"), 0);
            commentService.deleteComment(commentId);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error("errorMsg", e);
        } catch (Exception e) {
            logger.error("errorMsg", e);
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }
}
