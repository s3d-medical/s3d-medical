package com.nhs.o2o.web;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.mapping.Array;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Maps;
import com.nhs.core.orm.Page;
import com.nhs.core.utils.common.BeanUtils;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.core.web.WebController;
import com.nhs.core.web.WebExceptionCode;
import com.nhs.core.web.WebRequestException;
import com.nhs.core.web.dto.RequestHeader;
import com.nhs.core.web.dto.ResponseDto;
import com.nhs.shop.service.shop.O2oShopService;
import com.nhs.shop.service.shop.ShopService;
import com.nhs.shop.service.shop.dto.NearbyShopDto;
import com.nhs.shop.service.shop.dto.O2oCategoryDto;
import com.nhs.shop.service.shop.dto.ShopDto;

/**
 * 商家controller
 * @Title: GoodsApi.java
 * @Package com.nhs.o2o.web
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月16日 下午7:25:04
 * @version V1.0
 */
@Controller
@RequestMapping(value = "/shop")
public class ShopApi extends WebController {

    private final Logger logger = LoggerFactory.getLogger(ShopApi.class);

    @Autowired
    private ShopService shopService;
    
    @Autowired
    private O2oShopService o2oShopService;

    /**
     * 附近商家
     * @Title: list
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年7月17日 
     * @throws
     */
    @RequestMapping(value = "/nearby", method = RequestMethod.POST)
    @ResponseBody
    @Deprecated
    public ResponseDto getNearbyShop(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            Integer cityId = StringHelper.objectToInt(map.get("cityId"), 0);
            double lng = StringHelper.objectToDouble(map.get("lng"), 0.0); // 經度
            double lat = StringHelper.objectToDouble(map.get("lat"), 0.0); // 緯度
            int categoryId = StringHelper.objectToInt(map.get("categoryId"), 0); // 分类
            int shopId = StringHelper.objectToInt(map.get("shopId"), 0); // 分类
            NearbyShopDto dto = shopService.getNearbyShop(cityId, lng, lat, categoryId, shopId);
            result.put("data", dto);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 附近商家
     * @Title: list
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年7月17日 
     * @throws
     */
    @RequestMapping(value = "/nearby2", method = RequestMethod.POST)
    @ResponseBody
    @Deprecated
    public ResponseDto getNearbyShop2(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            Integer cityId = StringHelper.objectToInt(map.get("cityId"), 0);
            double lng = StringHelper.objectToDouble(map.get("lng"), 0.0); // 經度
            double lat = StringHelper.objectToDouble(map.get("lat"), 0.0); // 緯度
            int categoryId = StringHelper.objectToInt(map.get("categoryId"), 0); // 分类
            int shopId = StringHelper.objectToInt(map.get("shopId"), 0); // 分类
            NearbyShopDto dto = shopService.getNearbyShop2(cityId, lng, lat, categoryId, shopId);
            result.put("data", dto);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 获取商家列表
     * @Title: list
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年7月17日 
     * @throws
     */
    @RequestMapping(value = "/list", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto list(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            Integer categoryId = StringHelper.objectToInt(map.get("categoryId"), 0);
            String keyword = StringHelper.objectToString(map.get("keyword"), "");
            Integer cityId = StringHelper.objectToInt(map.get("cityId"), 0);
            double lng = StringHelper.objectToDouble(map.get("lng"), 0.0); // 經度
            double lat = StringHelper.objectToDouble(map.get("lat"), 0.0); // 緯度
            Integer pageNo = StringHelper.objectToInt(map.get("pageNo"), 0);
            Integer pageSize = StringHelper.objectToInt(map.get("pageSize"), 0);
            Integer distance = StringHelper.objectToInt(map.get("distance"), 0);
            Integer sort = StringHelper.objectToInt(map.get("sort"), 0);
            Page<Map<String, Object>> page = createPage(pageNo, pageSize);
            List<ShopDto> list = shopService.getShopList(cityId, categoryId, keyword, lng, lat, page,distance,sort);
           
            result.put("list", list);
            result.put("totalCount", page.getTotalCount());
            result.put("totalPage", page.getTotalPage());
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }
    
    
    /**
     * 获取商家列表的全部分类
     * @Title: list
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年7月17日 
     * @throws
     */
    @RequestMapping(value = "/v1.9/allCategory", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto allCategory(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            Integer categoryId = StringHelper.objectToInt(map.get("categoryId"), 0);
            String keyword = StringHelper.objectToString(map.get("keyword"), "");
            Integer cityId = StringHelper.objectToInt(map.get("cityId"), 0);
            double lng = StringHelper.objectToDouble(map.get("lng"), 0.0); // 經度
            double lat = StringHelper.objectToDouble(map.get("lat"), 0.0); // 緯度
            Integer distance = StringHelper.objectToInt(map.get("distance"), 0);
            Integer sort = StringHelper.objectToInt(map.get("sort"), 0);
            
            List<O2oCategoryDto> categoryList = new ArrayList<>();
            if(StringUtils.isEmpty(keyword)){
            	categoryList = o2oShopService.getO2oAllCategory();
            }else{
            	List<ShopDto> list = shopService.getAllShopList(cityId, categoryId, keyword, lng, lat, distance,sort);
            	if(list != null && list.size() > 0){
            		categoryList = o2oShopService.getSearchStoreO2oCategory(list);
            	}
            }
            result.put("categoryList", categoryList);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 获取商品详情
     * @Title: detail
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年7月17日 
     * @throws
     */
    @RequestMapping(value = "/detail", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto detail(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            Integer shopId = StringHelper.objectToInt(map.get("shopId"), 0); // 商品ID
            ShopDto detail = shopService.getShopDetail(shopId);
            result.put("detail", detail);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }
    
    /**
     * 附近商家猜你喜欢(新规则计算)
     * @Title: list
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年7月17日 
     * @throws
     */
    @RequestMapping(value = "/v1.9.3/nearby", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto getNearbyShopLike(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            Integer cityId = StringHelper.objectToInt(map.get("cityId"), 0);
            double lng = StringHelper.objectToDouble(map.get("lng"), 0.0); // 經度
            double lat = StringHelper.objectToDouble(map.get("lat"), 0.0); // 緯度
            int categoryId = StringHelper.objectToInt(map.get("categoryId"), 0); // 分类
            int shopId = StringHelper.objectToInt(map.get("shopId"), 0); // 分类
            NearbyShopDto dto = shopService.getNearbyShopLike(cityId, lng, lat, categoryId, shopId);
            result.put("data", dto);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

    /**
     * 附近商家首页(新规则计算)
     * @Title: list
     * @Description: TODO
     * @param @param requestHeader
     * @param @param map
     * @param @return   
     * @return ResponseDto 
     * @author Administrator 2016年7月17日 
     * @throws
     */
    @RequestMapping(value = "/v1.9.3/nearby2", method = RequestMethod.POST)
    @ResponseBody
    public ResponseDto getNearbyShop2Like(RequestHeader requestHeader, @RequestBody Map<String, Object> map) {
        ResponseDto response = new ResponseDto();
        Map<String, Object> result = Maps.newHashMap();
        try {
            Integer cityId = StringHelper.objectToInt(map.get("cityId"), 0);
            double lng = StringHelper.objectToDouble(map.get("lng"), 0.0); // 經度
            double lat = StringHelper.objectToDouble(map.get("lat"), 0.0); // 緯度
            int categoryId = StringHelper.objectToInt(map.get("categoryId"), 0); // 分类
            int shopId = StringHelper.objectToInt(map.get("shopId"), 0); // 分类
            NearbyShopDto dto = shopService.getNearbyShop2Like(cityId, lng, lat, categoryId, shopId);
            result.put("data", dto);
        } catch (WebRequestException e) {
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, e.getMessage());
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
            response = new ResponseDto(WebExceptionCode.ERROR.errorCode, WebExceptionCode.ERROR.errorMsg);
        }
        response.getResult().putAll(result);
        return response;
    }

}
