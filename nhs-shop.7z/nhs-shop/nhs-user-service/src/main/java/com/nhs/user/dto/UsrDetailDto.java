package com.nhs.user.dto;

import java.io.Serializable;

public class UsrDetailDto implements Serializable {

    private static final long serialVersionUID = -6184909547688220652L;
    
    // UserID
    private String userId;

    // 账号
    private String passport;
    
    // 用户名称
    private String userName;

    // 手机号
    private String userMobile;
    
    // Nick Name
    private String userNickName;
    
    // 注册时间
    private String regTimeStr;
    
    // 百德砖点数
    private String silver;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    /**
     * @return the passport
     */
    public String getPassport() {
        return passport;
    }

    /**
     * @param passport the passport to set
     */
    public void setPassport(String passport) {
        this.passport = passport;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserMobile() {
        return userMobile;
    }

    public void setUserMobile(String userMobile) {
        this.userMobile = userMobile;
    }

    public String getUserNickName() {
        return userNickName;
    }

    public void setUserNickName(String userNickName) {
        this.userNickName = userNickName;
    }

    public String getRegTimeStr() {
        return regTimeStr;
    }

    public void setRegTimeStr(String regTimeStr) {
        this.regTimeStr = regTimeStr;
    }

    public String getSilver() {
        return silver;
    }

    public void setSilver(String silver) {
        this.silver = silver;
    }

    /**
     * <p>Description:TODO </p>
     * @author chushubin 2016年11月16日 
     * @return
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "UsrDetailDto [userId=" + userId + ", passport=" + passport + ", userName=" + userName + ", userMobile="
                + userMobile + ", userNickName=" + userNickName + ", regTimeStr=" + regTimeStr + ", silver=" + silver
                + "]";
    }
}
