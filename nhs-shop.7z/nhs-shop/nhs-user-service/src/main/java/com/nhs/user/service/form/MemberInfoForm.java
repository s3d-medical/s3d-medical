package com.nhs.user.service.form;

import java.util.Map;

import com.nhs.core.utils.common.StringHelper;

public class MemberInfoForm {
    private String uid;
    private String nickName;
    private String image;
    private String sex;

    private String realName;
    private String userAdds;
    private Integer provinceid;
    private Integer cityid;
    private Integer areaid;

    

	public MemberInfoForm() {

    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public String getUserAdds() {
        return userAdds;
    }

    public void setUserAdds(String userAdds) {
        this.userAdds = userAdds;
    }

    public Integer getProvinceid() {
        return provinceid;
    }

    public void setProvinceid(Integer provinceid) {
        this.provinceid = provinceid;
    }

    public Integer getCityid() {
        return cityid;
    }

    public void setCityid(Integer cityid) {
        this.cityid = cityid;
    }

    public Integer getAreaid() {
        return areaid;
    }

    public void setAreaid(Integer areaid) {
        this.areaid = areaid;
    }

    public static MemberInfoForm createMember(Map<String, Object> map) {
        String uid = StringHelper.objectToString(map.get("uid"), "");
        String nickName = StringHelper.objectToString(map.get("nickName"), "");
        String image = StringHelper.objectToString(map.get("image"), "");
        String sex = StringHelper.objectToString(map.get("sex"), "M");

        String realName = StringHelper.objectToString(map.get("realName"), "");
        String userAdds = StringHelper.objectToString(map.get("userAdds"), "");
        Integer provinceid = StringHelper.objectToInt(map.get("provinceid"), -1);
        Integer cityid = StringHelper.objectToInt(map.get("cityid"), -1);
        Integer areaid = StringHelper.objectToInt(map.get("areaid"), -1);

        MemberInfoForm form = new MemberInfoForm();
        form.setAreaid(areaid);
        form.setCityid(cityid);
        form.setImage(image);
        form.setNickName(nickName);
        form.setProvinceid(provinceid);
        form.setRealName(realName);
        form.setSex(sex);
        form.setUid(uid);
        form.setUserAdds(userAdds);
        return form;
    }
}
