package com.nhs.user.dto;

import java.math.BigDecimal;

public class MemberAccountDto {
	
	//账户余额
	private BigDecimal amount;
	
	//账户名称
	private String currencyName;
	
	private String userId;
	
	//是否可以提现  1:可以
	private String canTake;
	
	//提现费率
	private BigDecimal takeRate;
	
	//唯一识别码
	private String currency;

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getCurrencyName() {
		return currencyName;
	}

	public void setCurrencyName(String currencyName) {
		this.currencyName = currencyName;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getCanTake() {
		return canTake;
	}

	public void setCanTake(String canTake) {
		this.canTake = canTake;
	}

	public BigDecimal getTakeRate() {
		return takeRate;
	}

	public void setTakeRate(BigDecimal takeRate) {
		this.takeRate = takeRate;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}
	
	
	
	
}
