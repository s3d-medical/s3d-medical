package com.nhs.user.dto;

import java.math.BigDecimal;
import java.util.List;

import com.nhs.apiproxy.member.acc.datatype.CurrencyEnum;

public class MemberDetailDto {
	/**
     * 账号id
     */
    private String userId;

    /**
     * 用户等级
     */
    private Integer gradeId;

    /**
     * 昵称
     */
    private String nickName;
    
    /**
     * 用户名称.
     */
    private String userName;
    
    /**
     * 头像地址
     */
    private String headPath;

    /**
     * 头像地址摘要
     */
    private String headSummary;

    /**
     * 真实姓名
     */
    private String realName;

    /**
     * 身份证号码
     */
    private String identity;

    /**
     * 省份id
     */
    private Integer provinceId;

    /**
     * 城市id
     */
    private Integer cityId;

    /**
     * 区县id
     */
    private Integer districtId;

    /**
     * 详细地址
     */
    private String address;

    /**
     * 手机号码
     */
    private String mobileNo;

    /**
     * 邮箱
     */
    private String email;

    /**
     * 性别
     */
    private String sex;

    /**
     * 固话
     */
    private String tel;

    /**
     * 邮编
     */
    private String postcode;

    /**
     * QQ
     */
    private String qq;

    /**
     * ip
     */
    private Long ip;

    /**
     * 创建时间
     */
    private String userRegtime;

    /**
     * 更新时间
     */
    private String updateTime;

    /**
     * 店铺id - 兼容老系统 - 后期可能删除
     */
    private Long shopId;
    

    /**
     * 用户密码
     */
    private String password;

    /**
     * 支付密码
     */
    private String payPasswd;


    /**
     * 身份证号
     */
    private String indentity;

    /**
     * 身份证验证状态
     */
    private String isPass;


    /**
     * 是否开通支付密码
     */
    private String payAuthed;

    /**
     * 邮箱是否通过认证
     */
    private String emailAuthed;

    /**
     * 手机是否通过认证
     */
    private String mobileAuthed;

    /**
     * 账号状态
     */
    private String state;

    /**
     * 注册时IP
     */
    private String userRegIp;
    
    private String userLoginLastTime;
    
    private String userLastIp;
    
    private String token;
    
    private List<MemberAccountDto> account;
    
    private String signKey;
    
    
    /**
     * 获取某个账户中的数额.
     * @param currentEnum
     * @return
     */
	public BigDecimal getAmountInAcc(CurrencyEnum currencyEnum) {
		BigDecimal val = null;
		MemberAccountDto acc = this.getAcc(currencyEnum);
		if(acc != null){
			return acc.getAmount();
		}
		return val;
	}
	
	private MemberAccountDto getAcc(CurrencyEnum currencyEnum){
		if(currencyEnum == null){
			return null;
		}
		if(account != null && account.size() >0){
			for(MemberAccountDto acc : this.account){
				if(currencyEnum.equals(acc.getCurrency())){
					return acc;
				}
			}
		}
		return null;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Integer getGradeId() {
		return gradeId;
	}

	public void setGradeId(Integer gradeId) {
		this.gradeId = gradeId;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	public String getHeadPath() {
		return headPath;
	}

	public void setHeadPath(String headPath) {
		this.headPath = headPath;
	}

	public String getHeadSummary() {
		return headSummary;
	}

	public void setHeadSummary(String headSummary) {
		this.headSummary = headSummary;
	}

	public String getRealName() {
		return realName;
	}

	public void setRealName(String realName) {
		this.realName = realName;
	}

	public String getIdentity() {
		return identity;
	}

	public void setIdentity(String identity) {
		this.identity = identity;
	}

	public Integer getProvinceId() {
		return provinceId;
	}

	public void setProvinceId(Integer provinceId) {
		this.provinceId = provinceId;
	}

	public Integer getCityId() {
		return cityId;
	}

	public void setCityId(Integer cityId) {
		this.cityId = cityId;
	}

	public Integer getDistrictId() {
		return districtId;
	}

	public void setDistrictId(Integer districtId) {
		this.districtId = districtId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getPostcode() {
		return postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

	public String getQq() {
		return qq;
	}

	public void setQq(String qq) {
		this.qq = qq;
	}

	public Long getIp() {
		return ip;
	}

	public void setIp(Long ip) {
		this.ip = ip;
	}

	public String getUserRegtime() {
		return userRegtime;
	}

	public void setUserRegtime(String userRegtime) {
		this.userRegtime = userRegtime;
	}

	public String getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}

	public Long getShopId() {
		return shopId;
	}

	public void setShopId(Long shopId) {
		this.shopId = shopId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPayPasswd() {
		return payPasswd;
	}

	public void setPayPasswd(String payPasswd) {
		this.payPasswd = payPasswd;
	}

	public String getIndentity() {
		return indentity;
	}

	public void setIndentity(String indentity) {
		this.indentity = indentity;
	}

	public String getIsPass() {
		return isPass;
	}

	public void setIsPass(String isPass) {
		this.isPass = isPass;
	}

	public String getPayAuthed() {
		return payAuthed;
	}

	public void setPayAuthed(String payAuthed) {
		this.payAuthed = payAuthed;
	}

	public String getEmailAuthed() {
		return emailAuthed;
	}

	public void setEmailAuthed(String emailAuthed) {
		this.emailAuthed = emailAuthed;
	}

	public String getMobileAuthed() {
		return mobileAuthed;
	}

	public void setMobileAuthed(String mobileAuthed) {
		this.mobileAuthed = mobileAuthed;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getUserRegIp() {
		return userRegIp;
	}

	public void setUserRegIp(String userRegIp) {
		this.userRegIp = userRegIp;
	}

	public String getUserLoginLastTime() {
		return userLoginLastTime;
	}

	public void setUserLoginLastTime(String userLoginLastTime) {
		this.userLoginLastTime = userLoginLastTime;
	}

	public String getUserLastIp() {
		return userLastIp;
	}

	public void setUserLastIp(String userLastIp) {
		this.userLastIp = userLastIp;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public List<MemberAccountDto> getAccount() {
		return account;
	}

	public void setAccount(List<MemberAccountDto> account) {
		this.account = account;
	}

	public String getUserId() {
		return userId;
	}

	public String getUserName() {
		return userName;
	}

	public String getSignKey() {
		return signKey;
	}

	public void setSignKey(String signKey) {
		this.signKey = signKey;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	
	public BigDecimal getAccountByType(String type){
		BigDecimal balance = new BigDecimal("0.00");
        if (this.account != null) {
            for (MemberAccountDto accDto : account) {
                if (type.equals(accDto.getCurrency())) {
                	balance = accDto.getAmount();
                    break;
                }
            }
        }
	    return balance;
	}


}
