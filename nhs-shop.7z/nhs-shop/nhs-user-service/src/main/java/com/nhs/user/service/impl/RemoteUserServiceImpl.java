/*******************************************************************************
 * @Title: RemoteUsrServiceImpl.java
 * @Package com.nhs.user.service
 * @Description: TODO
 * @author chushubin 2016年11月16日 
 * @version V1.0   
 * @Copyright (c) 2016 苏州哪划算网络有限公司 版权所有.
 * 注意：本内容仅限于苏州哪划算网络有限有限公司 内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
package com.nhs.user.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.ObjectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import com.google.common.collect.Lists;
import com.nhs.apiproxy.UnifiedInApiReqHelper;
import com.nhs.apiproxy.UnifiedInApiResultHelper;
import com.nhs.apiproxy.member.acc.datatype.CurrencyEnum;
import com.nhs.apiproxy.member.user.dto.UsrAddrDto;
import com.nhs.apiproxy.member.user.service.UserServiceApi;
import com.nhs.core.mapper.JsonMapper;
import com.nhs.core.rest.HttpClientUtils;
import com.nhs.core.utils.common.DateUtils;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.shop.entry.legend.user.UsrAddr;
import com.nhs.shop.entry.legend.user.UsrDetail;
import com.nhs.user.dto.MemberDetailDto;
import com.nhs.user.service.UserService;

/**   
 * @Title: RemoteUsrServiceImpl.java
 * @Package com.nhs.user.service
 * @Description: TODO
 * @author chushubin
 * @date 2016年11月16日 下午2:31:50
 * @version V1.0
 */
@Service("userService")
public class RemoteUserServiceImpl implements UserService {

    private static final Logger LOG = LoggerFactory.getLogger(RemoteUserServiceImpl.class);

    private static final String SUCCESS = "1";
    @Autowired
    private UserServiceApi userServiceApi;

    @Value("${rest.member.user.findUserDetail.url}")
    private String findUserDetailUrl;

    @Value("${rest.member.user.findUserDetailByMobile.url}")
    private String findUserDetailByMobileUrl;

    @Value("${rest.member.user.checkPayPwd.url}")
    private String checkPayPwdUrl;

    @Value("${rest.member.user.regTime.between.url}")
    private String findUsersByRegTimeBetweenUrl;
    
    @Value("${rest.member.user.simple.register.url}")
    private String simpleRegisterUrl;
    
    @Value("${rest.member.user.findUserDetailByNickName.url}")
    private String findUserDetailByNickNameUrl;

    @SuppressWarnings({ "unchecked", "deprecation" })
    @Override
    public UsrDetail findUserById(String userId) {
        Assert.notNull(userId, "userId must not be null");
        Assert.hasLength(userId);

        Map<String, Object> params = new HashMap<>();
        params.put("userId", userId);

        params = UnifiedInApiReqHelper.signParam(params);

        try {
            // 调用远程服务
            String str = HttpClientUtils.post(this.findUserDetailUrl, params);
            Map<String, Object> response = JsonMapper.nonDefaultMapper().fromJson(str, Map.class);
            // 成功
            if (SUCCESS.equals(ObjectUtils.toString(response.get("code")))) {
                Map<String, Object> userMap = (Map<String, Object>) response.get("data");

                UsrDetail userDetail = new UsrDetail();
                userDetail = new UsrDetail();
                userDetail.setUserId((String) userMap.get("userId"));
                userDetail.setProvinceid((Integer) userMap.get("provinceId"));
                userDetail.setCityid((Integer) userMap.get("cityId"));
                userDetail.setAreaid((Integer) userMap.get("districtId"));
                userDetail.setSex((String) userMap.get("address"));

                userDetail.setSex((String) userMap.get("sex"));
                userDetail.setNickName((String) userMap.get("nickName"));
                userDetail.setUserMail((String) userMap.get("email"));
                userDetail.setUserName((String) userMap.get("passport"));
                userDetail.setUserMobile((String) userMap.get("mobileNo"));

                userDetail.setQq((String) userMap.get("qq"));
                userDetail.setPortraitPic((String) userMap.get("headPath"));
                userDetail.setIdCard((String) userMap.get("identity"));
                userDetail.setRealName((String) userMap.get("realName"));
                userDetail.setModifyTime(DateUtils.str2Timestamp((String) userMap.get("updateTime")));

                userDetail.setUserLastip((String) userMap.get("userLastIp"));
                userDetail.setUserLasttime(DateUtils.str2Timestamp((String) userMap.get("userLoginLastTime")));
                userDetail.setUserRegip((String) userMap.get("userRegIp"));
                userDetail.setUserRegtime(DateUtils.str2Timestamp((String) userMap.get("userRegtime")));
                userDetail.setUserTel((String) userMap.get("userTel"));
                userDetail.setSignKey(StringHelper.objectToString(userMap.get("signKey"), ""));
                
                // 解析币种
                List<Map<String, Object>> accList = (List<Map<String, Object>>) userMap.get("account");
                if (accList != null && !accList.isEmpty()) {
                    for (Map<String, Object> accountMap : accList) {
                        String currency = ObjectUtils.toString(accountMap.get("currency"));
                        BigDecimal amount = new BigDecimal(accountMap.get("amount").toString()).setScale(2,
                                BigDecimal.ROUND_DOWN);
                        if (CurrencyEnum.CURRENCY_PERSONAL_BALANCE.getCurrency().equals(currency)) {
                            //userDetail.setAvailablePredeposit(amount);
                        } else if (CurrencyEnum.CURRENCY_BUSINESS_BALANCE.getCurrency().equals(currency)) {
                            //userDetail.setShopAvailablePred(amount);
                        } else if (CurrencyEnum.CURRENCY_PERSONAL_BALANCE.getCurrency().equals(currency)) {
                            //userDetail.setFreezePredeposit(amount);
                        } else if (CurrencyEnum.CURRENCY_BUSINESS_FORBIDEN_BALANCE.getCurrency().equals(currency)) {
                            //userDetail.setShopFreezePred(amount);
                        } else if (CurrencyEnum.CURRENCY_GOLD_COIN.getCurrency().equals(currency)) {
                            //userDetail.setGold(amount);
                        } else if (CurrencyEnum.CURRENCY_SILVER_COIN.getCurrency().equals(currency)) {
                            //userDetail.setSilver(amount);
                        } else if (CurrencyEnum.CURRENCY_FORBIDEN_SILVER_COIN.getCurrency().equals(currency)) {
                            //userDetail.setSilverFreeze(amount);
                        } else if (CurrencyEnum.CURRENCY_FORBIDEN_GOLD_COIN.getCurrency().equals(currency)) {
                            //userDetail.setGoldFreeze(amount);
                        } else if (CurrencyEnum.CURRENCY_COMMISSION_GOLD_COIN.getCurrency().equals(currency)) {
                            //userDetail.setCommissionGold(amount);
                        } else if (CurrencyEnum.CURRENCY_FORBIDEN_COMMISSION_GOLD_COIN.getCurrency().equals(currency)) {
                            //userDetail.setCommissionGoldFreeze(amount);
                        } else if (CurrencyEnum.CURRENCY_COMMISSION_SILVER_COIN.getCurrency().equals(currency)) {
                           // userDetail.setCommissionSilver(amount);
                        }
                    }
                }
                return userDetail;
            }
        } catch (Exception e) {
            LOG.error("查找用户信息出错.", e);
        }
        return null;
    }

    @Override
    public UsrAddr findShipAddrById(String userId, Integer addrId) {
        try {
            UsrAddrDto usrAddrDto = userServiceApi.findShipAddrById(userId, addrId);
            UsrAddr usrAddr = this.toUsrAddr(usrAddrDto);
            return usrAddr;
        } catch (Exception e) {
            throw new RuntimeException("获取用户发货地址出错. addrId=" + addrId, e);
        }
    }

    private UsrAddr toUsrAddr(UsrAddrDto usrAddrDto) {
        UsrAddr usrAddr = new UsrAddr();
        usrAddr.setProvinceId(usrAddrDto.getProvinceId());
        usrAddr.setAddrId(usrAddrDto.getId());
        usrAddr.setAreaId(usrAddrDto.getDistrictId());
        usrAddr.setCityId(usrAddrDto.getCityId());
        usrAddr.setReceiver(usrAddrDto.getReceiver());
        usrAddr.setUserId(usrAddrDto.getUserId());
        usrAddr.setCommonAddr(usrAddrDto.getHeadAddress());
        usrAddr.setSubAdds(usrAddrDto.getAddress());
        usrAddr.setMobile(usrAddrDto.getMobileNo());
        return usrAddr;
    }

    @Override
    public Map<String, UsrDetail> findUsers(List<String> userIds) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Integer findCityIdOfDefaultShipAddr(String userId) {
        UsrAddr usrAddr = this.findDefaultShipAddr(userId);
        if (usrAddr != null && usrAddr.getCityId() != null) {
            return usrAddr.getCityId();
        }
        return 247;
    }

    @Override
    public UsrAddr findDefaultShipAddr(String userId) {
        UsrAddrDto usrAddrDto = this.userServiceApi.findDefaultShipAddrById(userId);
        if (usrAddrDto != null) {
            return this.toUsrAddr(usrAddrDto);
        }
        return null;
    }

    /**
    * <p>Description:验证支付密码 </p>
    * @author chushubin 2016年11月22日 
    * @param userId
    * @param payPassword
    * @return
    * @see com.nhs.user.service.UserService#checkPayPassword(java.lang.String, java.lang.String)
    */
    @SuppressWarnings({ "unchecked", "deprecation" })
    @Override
    public boolean checkPayPassword(String userId, String payPassword) {
        Assert.notNull(userId, "userId must not be null");
        Assert.hasLength(userId);
        Map<String, Object> params = new HashMap<>();
        params.put("userId", userId);
        params.put("paypasswd", payPassword);

        params = UnifiedInApiReqHelper.signParam(params);

        try {
            // 调用远程服务
            String str = HttpClientUtils.post(this.checkPayPwdUrl, params);
            Map<String, Object> response = JsonMapper.nonDefaultMapper().fromJson(str, Map.class);
            // 成功
            if (SUCCESS.equals(ObjectUtils.toString(response.get("code")))) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            if (LOG.isWarnEnabled()) {
                LOG.warn(e.getMessage());
            }
            return false;
        }
    }

    @SuppressWarnings({ "unchecked", "deprecation" })
    @Override
    public UsrDetail findUserByMobile(String phone) {
        Assert.notNull(phone, "phone must not be null");
        Assert.hasLength(phone);
        Map<String, Object> params = new HashMap<>();
        params.put("account", phone);

        params = UnifiedInApiReqHelper.signParam(params);

        try {
            // 调用远程服务
            String str = HttpClientUtils.post(this.findUserDetailByMobileUrl, params);
            Map<String, Object> response = JsonMapper.nonDefaultMapper().fromJson(str, Map.class);
            // 成功
            if (SUCCESS.equals(ObjectUtils.toString(response.get("code")))) {
                Map<String, Object> userMap = (Map<String, Object>) response.get("data");

                UsrDetail userDetail = new UsrDetail();
                userDetail = new UsrDetail();
                userDetail.setUserId((String) userMap.get("userId"));
                userDetail.setProvinceid((Integer) userMap.get("provinceId"));
                userDetail.setCityid((Integer) userMap.get("cityId"));
                userDetail.setAreaid((Integer) userMap.get("districtId"));
                userDetail.setSex((String) userMap.get("address"));

                userDetail.setSex((String) userMap.get("sex"));
                userDetail.setNickName((String) userMap.get("nickName"));
                userDetail.setUserMail((String) userMap.get("email"));
                userDetail.setUserName((String) userMap.get("passport"));
                userDetail.setUserMobile((String) userMap.get("mobileNo"));

                userDetail.setQq((String) userMap.get("qq"));
                userDetail.setPortraitPic((String) userMap.get("headPath"));
                userDetail.setIdCard((String) userMap.get("identity"));
                userDetail.setRealName((String) userMap.get("realName"));
                userDetail.setModifyTime(DateUtils.str2Timestamp((String) userMap.get("updateTime")));

                userDetail.setUserLastip((String) userMap.get("userLastIp"));
                userDetail.setUserLasttime(DateUtils.str2Timestamp((String) userMap.get("userLoginLastTime")));
                userDetail.setUserRegip((String) userMap.get("userRegIp"));
                userDetail.setUserRegtime(DateUtils.str2Timestamp((String) userMap.get("userRegtime")));
                userDetail.setUserTel((String) userMap.get("userTel"));
                return userDetail;
            }
        } catch (Exception e) {
            LOG.error("查找用户信息出错.", e);
        }
        return null;
    }

    @Override
    public List<UsrDetail> findUsersByRegtime(String startTime, String endTime, List<String> mobileList) {

        Map<String, Object> params = new HashMap<>();
        params.put("startTime", startTime);
        params.put("endTime", endTime);

        params = UnifiedInApiReqHelper.signParam(params);

        List<UsrDetail> usrDetailList = new ArrayList<>();

        try {
            // 调用远程服务
            String str = HttpClientUtils.post(this.findUsersByRegTimeBetweenUrl, params);
            Map<String, Object> response = JsonMapper.nonDefaultMapper().fromJson(str, Map.class);
            // 成功
            if (SUCCESS.equals(ObjectUtils.toString(response.get("code")))) {
                Map<String, Object> userMapList = (Map<String, Object>) response.get("data");
                List<Map<String, Object>> userList = (List<Map<String, Object>>) userMapList.get("list");
                if (userList != null && userList.size() > 0) {
                    for (Map<String, Object> userMap : userList) {
                        UsrDetail userDetail = new UsrDetail();
                        userDetail = new UsrDetail();
                        userDetail.setUserId((String) userMap.get("userId"));
                        userDetail.setProvinceid((Integer) userMap.get("provinceId"));
                        userDetail.setCityid((Integer) userMap.get("cityId"));
                        userDetail.setAreaid((Integer) userMap.get("districtId"));
                        userDetail.setSex((String) userMap.get("address"));

                        userDetail.setSex((String) userMap.get("sex"));
                        userDetail.setNickName((String) userMap.get("nickName"));
                        userDetail.setUserMail((String) userMap.get("email"));
                        userDetail.setUserName((String) userMap.get("passport"));
                        userDetail.setUserMobile((String) userMap.get("mobileNo"));

                        userDetail.setQq((String) userMap.get("qq"));
                        userDetail.setPortraitPic((String) userMap.get("headPath"));
                        userDetail.setIdCard((String) userMap.get("identity"));
                        userDetail.setRealName((String) userMap.get("realName"));
                        userDetail.setModifyTime(DateUtils.str2Timestamp((String) userMap.get("updateTime")));

                        userDetail.setUserLastip((String) userMap.get("userLastIp"));
                        userDetail.setUserLasttime(DateUtils.str2Timestamp((String) userMap.get("userLoginLastTime")));
                        userDetail.setUserRegip((String) userMap.get("userRegIp"));
                        userDetail.setUserRegtime(DateUtils.str2Timestamp((String) userMap.get("userRegtime")));
                        userDetail.setUserTel((String) userMap.get("userTel"));
                        usrDetailList.add(userDetail);
                    }
                }
            }
        } catch (Exception e) {
            LOG.error("查找用户信息出错.", e);
        }
        return usrDetailList;
    }

	@Override
	public UsrDetail simpleRegister(String mobile, String password, String regType) {

        Map<String, Object> params = new HashMap<>();
        params.put("passport", mobile);
        params.put("password", password);
        params.put("regType", regType);

        params = UnifiedInApiReqHelper.signParam(params);

        UsrDetail usrDetail = null;
        
        try {
            // 调用远程服务
            String str = HttpClientUtils.post(this.simpleRegisterUrl, params);
            Map<String, Object> response = JsonMapper.nonDefaultMapper().fromJson(str, Map.class);
            // 成功
            if (SUCCESS.equals(ObjectUtils.toString(response.get("code")))) {
            	usrDetail = UnifiedInApiResultHelper.parseDataToObj(str,UsrDetail.class);
            } 
        } catch (Exception e) {
            if (LOG.isWarnEnabled()) {
                LOG.warn(e.getMessage());
            }
        }
        return usrDetail;
	}
	
    @Override
    public List<String> findUserIdByNickName(String nickName) {

    	List<String> userIdList = Lists.newArrayList();
        Map<String, Object> params = new HashMap<>();
        params.put("nickName", nickName);
        params = UnifiedInApiReqHelper.signParam(params);
        try {
            // 调用远程服务
            String str = HttpClientUtils.post(this.findUserDetailByNickNameUrl, params);
            Map<String, Object> response = JsonMapper.nonDefaultMapper().fromJson(str, Map.class);
            // 成功
            if (SUCCESS.equals(ObjectUtils.toString(response.get("code")))) {
                Map<String, Object> userMap = (Map<String, Object>) response.get("data");
                List<Map<String, Object>> userList = (List<Map<String, Object>>) userMap.get("list");
                for(Map<String, Object> map : userList){
                	userIdList.add((String)map.get("userId"));
                }
            }
        } catch (Exception e) {
            LOG.error("查找用户信息出错.", e);
        }
        return userIdList;
    }

}
