package com.nhs.user.service;

import java.math.BigDecimal;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import com.nhs.apiproxy.member.acc.service.AccountTransferService;

@Service
@Transactional
public class OperateUserAccountService {
    private static final Logger logger = LoggerFactory.getLogger(OperateUserAccountService.class);

    
    @Autowired
    private AccountTransferService accTransferService;
    
 
    
    /**
     * 冻结某笔订单涉及到的金币(冻结白德券抵用部分)
     * @param gold
     * @param userId
     */
    public boolean freezeGold(String userId, String orderNo, BigDecimal gold) {
    	Assert.isTrue(!StringUtils.isEmpty(userId), "userId不能为空.");
    	Assert.isTrue(!StringUtils.isEmpty(orderNo), "orderNo不能为空.");
    	Assert.isTrue(gold != null && gold.doubleValue() >= 0.0, "冻结佰德券 >=0.0");
    	//2金币冻结账户操作
    	boolean frozenResult = this.accTransferService.freezeGold(userId, orderNo, gold);
    	this.logTrack("佰德券冻结.", frozenResult, userId, orderNo, gold);
    	return frozenResult;
    }

   
    
    /**
     * 解冻金币， 并把金币归还原用户
     * @param userId
     * @param gold
    */
    public boolean unfreezeGold(String userId, String orderNo, BigDecimal gold) {
		Assert.isTrue(!StringUtils.isEmpty(userId), "userId不能为空.");
		Assert.isTrue(!StringUtils.isEmpty(orderNo), "orderNo不能为空.");
		Assert.isTrue(gold != null && gold.doubleValue() >= 0.0, "冻结佰德券 >=0.0");
		// 金币账户处理: 1. 给用户的金币账户增加该笔金币
		boolean success = this.accTransferService.cancelGold(userId, orderNo, gold);
		this.logTrack("解冻佰德券:", success, userId, orderNo, gold);
		return success;
    }
    
    /**
     * 解冻金币， 并扣除. 
     * @param userId
     * @param gold
     * @return
     */
    public boolean reductFrozenGold(String userId, String orderNo, BigDecimal gold) {
		Assert.isTrue(!StringUtils.isEmpty(userId), "userId不能为空.");
		Assert.isTrue(!StringUtils.isEmpty(orderNo), "orderNo不能为空.");
		Assert.isTrue(gold != null && gold.doubleValue() >= 0.0, "冻结金币 >=0.0");
		
		// 1. 金币冻结账户: 1. 减少冻结的金币金额
		boolean success = this.accTransferService.commitGold(userId, orderNo, gold);
		this.logTrack("处理冻结的佰德券:", success, userId, orderNo, gold);
		return success;
    }


	private String logTrack(String rltDesc, boolean success, String userId,
			String orderNo, BigDecimal gold) {
		StringBuilder info = new StringBuilder().append(rltDesc)
				.append(" success =" + success).append(", userId=" + userId)
				.append(", orderNo=" + orderNo);
		String strInfo = info.toString();
		logger.info(strInfo);
		return strInfo;
	}
}
