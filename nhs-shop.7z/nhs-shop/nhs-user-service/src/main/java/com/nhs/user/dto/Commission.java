package com.nhs.user.dto;

import java.io.Serializable;

public class Commission implements Serializable {

    private static final long serialVersionUID = 1L;

    private String silverFreeze;

    private String goldFreeze;

    private String commissionGold;

    private String commissionSilver;

    private String phone;

    private String nickName;

    private String userName;

    private String gold;

    private String silver;

    public String getGold() {
        return gold;
    }

    public void setGold(String gold) {
        this.gold = gold;
    }

    public String getSilver() {
        return silver;
    }

    public void setSilver(String silver) {
        this.silver = silver;
    }

    public String getSilverFreeze() {
        return silverFreeze;
    }

    public void setSilverFreeze(String silverFreeze) {
        this.silverFreeze = silverFreeze;
    }

    public String getGoldFreeze() {
        return goldFreeze;
    }

    public void setGoldFreeze(String goldFreeze) {
        this.goldFreeze = goldFreeze;
    }

    public String getCommissionGold() {
        return commissionGold;
    }

    public void setCommissionGold(String commissionGold) {
        this.commissionGold = commissionGold;
    }

    public String getCommissionSilver() {
        return commissionSilver;
    }

    public void setCommissionSilver(String commissionSilver) {
        this.commissionSilver = commissionSilver;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

}
