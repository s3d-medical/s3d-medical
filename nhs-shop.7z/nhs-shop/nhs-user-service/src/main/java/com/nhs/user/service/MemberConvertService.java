package com.nhs.user.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 后台转换使用，禁止调用
 * @Title: MemberConvertService.java
 * @Package com.nhs.user.service
 * @Description: TODO
 * @author huxianjun
 * @date 2016年8月18日 上午10:25:08
 * @version V1.0
 */
@Service
@Transactional
public class MemberConvertService {

    // public void dealMemberNotPhone() throws Exception {
    // // String notPhone[] = new String[] { "1193042160", "婕妤美容按摩", "桃花季", "南宁市金福宇", "梦吱吱_Lucky", "1262310490",
    // // "琦绣美艺",
    // // "3230764A", "海燕减肥养生馆", "zhenzhenjiayu", "e金香", "chen125610", "2939289785", "向忆秋", "阳光恋人" };
    //
    // // String notPhone[] = new String[] { "鸿智美刻", "枫芝钟表店", "金阳光母婴", "好人家建材商行", "18021657303", "15129351335",
    // // "18251221622" };
    // String notPhone[] = new String[] { "Luna91" };
    //
    // for (String usr : notPhone) {
    // MallBuilderMember member = mallBuilderMemberDao.findMallBuilderMemberByUser(usr);
    // try {
    // if (member != null) {
    // System.err.println(usr + "===");
    // this.saveMemberRegister(member);
    // }
    // } catch (Exception e) {
    // e.printStackTrace();
    // }
    // }
    // }
    //
    // /**
    // * 北京地址转换
    // * @Title: dealAreaBeiJing
    // * @Description: TODO
    // * @param @throws Exception
    // * @return void
    // * @author huxianjun 2016年7月29日
    // * @throws
    // */
    // public void dealAreaBeiJing() throws Exception {
    // List<Area> areas = areaDao.findAreaListByParentId(1);
    // if (areas != null && areas.size() > 0) {
    // for (Area area : areas) {
    // try {
    // Areas aa = new Areas();
    // aa.setArea(area.getName());
    // aa.setFirstLetter(area.getShort_());
    // aa.setCityid(595);
    // aa.setAreaid("");
    // areasDao.save(aa);
    // } catch (Exception e) {
    // e.printStackTrace();
    // }
    // }
    // }
    // }
    //
    // /**
    // * 拷回用户的完整密码
    // * @Title: dealUserPassword
    // * @Description: TODO
    // * @param @throws Exception
    // * @return void
    // * @author huxianjun 2016年7月29日
    // * @throws
    // */
    // public void dealUserPassword() throws Exception {
    // int pageNo = 1;
    // int pageSize = 10;
    // while (true) {
    // PageRequest request = new PageRequest(pageNo - 1, pageSize,
    // new Sort(new Sort.Order(Sort.Direction.ASC, "userId")));
    // Page<UsrDetail> page = usrDetailDao.findUsrDetail(request);
    // if (page.getContent() != null && page.getContent().size() > 0) {
    // for (UsrDetail user : page.getContent()) {
    // try {
    // System.err.println(user.getUserMobile() + "===");
    // this.saveUserPassword(user);
    // } catch (Exception e) {
    // e.printStackTrace();
    // }
    // }
    // pageNo++;
    // } else {
    // break;
    // }
    // }
    // }
    //
    // public void dealUserPasswordList() throws Exception {
    // String notPhone[] = new String[] { "zhenzhenjiayu", "13962185125", "18896541557", "15253368778", "18759820070",
    // "13771734940", "18251221622", "15129351335", "18021657303", "447111671", "e金香", "婕妤美容按摩", "15236724441",
    // "13814825883", "18677953865", "13277856569", "15396531717", "18652033211", "好人家建材商行", "13689074477",
    // "15296289293", "13771722191", "18626282848", "15295258250", "18550584168", "18959803111", "桃花季",
    // "3230764A", "15262423730", "海燕减肥养生馆", "13703195151", "南宁市金福宇", "13732293441" };
    // for (String usr : notPhone) {
    // UsrDetail userDetail = usrDetailDao.findUserAccount(usr);
    // try {
    // if (userDetail != null) {
    // System.err.println(usr + "===");
    // // this.updateUserPassword(userDetail);
    // }
    // } catch (Exception e) {
    // e.printStackTrace();
    // }
    // }
    // }
    //
    // public void dealRebackUserPasswordList() throws Exception {
    // String notPhone[] = new String[] { "zhenzhenjiayu", "13962185125", "18896541557", "15253368778", "18759820070",
    // "13771734940", "18251221622", "15129351335", "18021657303", "447111671", "e金香", "婕妤美容按摩", "15236724441",
    // "13814825883", "18677953865", "13277856569", "15396531717", "18652033211", "好人家建材商行", "13689074477",
    // "15296289293", "13771722191", "18626282848", "15295258250", "18550584168", "18959803111", "桃花季",
    // "3230764A", "15262423730", "海燕减肥养生馆", "13703195151", "南宁市金福宇", "13732293441", "13295118960" };
    // for (String usr : notPhone) {
    // UsrDetail userDetail = usrDetailDao.findUserAccount(usr);
    // try {
    // if (userDetail != null) {
    // System.err.println(usr + "===");
    // this.updateRebackUserPassword(userDetail);
    // }
    // } catch (Exception e) {
    // e.printStackTrace();
    // }
    // }
    // }
    //
    // /**
    // * 更新用户名
    // * @Title: dealUserName
    // * @Description: TODO
    // * @param @throws Exception
    // * @return void
    // * @author huxianjun 2016年7月30日
    // * @throws
    // */
    // public void dealUserName() throws Exception {
    // int pageNo = 1;
    // int pageSize = 10;
    // while (true) {
    // PageRequest request = new PageRequest(pageNo - 1, pageSize,
    // new Sort(new Sort.Order(Sort.Direction.ASC, "userId")));
    // Page<UsrDetail> page = usrDetailDao.findUsrDetail(request);
    // if (page.getContent() != null && page.getContent().size() > 0) {
    // for (UsrDetail user : page.getContent()) {
    // try {
    // System.err.println(user.getUserMobile() + "===");
    // this.saveUserName(user);
    // } catch (Exception e) {
    // e.printStackTrace();
    // }
    // }
    // pageNo++;
    // } else {
    // break;
    // }
    // }
    // }
    //
    // /**
    // * 添加没有安全级别的用户的记录
    // * @Title: dealAddUserSafe
    // * @Description: TODO
    // * @param @throws Exception
    // * @return void
    // * @author huxianjun 2016年8月11日
    // * @throws
    // */
    // public void dealAddUserSafe() throws Exception {
    // int pageNo = 1;
    // int pageSize = 10;
    // while (true) {
    // PageRequest request = new PageRequest(pageNo - 1, pageSize,
    // new Sort(new Sort.Order(Sort.Direction.ASC, "userId")));
    // Page<UsrDetail> page = usrDetailDao.findUsrDetail(request);
    // if (page.getContent() != null && page.getContent().size() > 0) {
    // for (UsrDetail user : page.getContent()) {
    // try {
    // this.saveAddUserSafe(user);
    // } catch (Exception e) {
    // e.printStackTrace();
    // }
    // }
    // pageNo++;
    // } else {
    // break;
    // }
    // }
    // }
    //
    // private void saveAddUserSafe(UsrDetail user) {
    // UsrSecurity safe = usrSecurityDao.findUsrSecurity(user.getUserName());
    // if (safe == null) {
    // safe = new UsrSecurity();
    // safe.setUserName(user.getUserName());
    // safe.setCreateTime(new Date());
    // if (StringUtils.isNotBlank(user.getUserMail())) {
    // safe.setMailVerifn(1);
    // } else {
    // safe.setMailVerifn(0);
    // }
    // if (StringUtils.isNotBlank(user.getPayPassword())) {
    // safe.setPaypassVerifn(1);
    // } else {
    // safe.setPaypassVerifn(0);
    // }
    // if (StringUtils.isNotBlank(user.getUserMobile())) {
    // safe.setPhoneVerifn(1);
    // } else {
    // safe.setPhoneVerifn(0);
    // }
    //
    // safe.setPayStrength(0);
    // safe.setTimes(0);
    // safe.setSecLevel(1 + safe.getMailVerifn() + safe.getPaypassVerifn() + safe.getPhoneVerifn());
    // usrSecurityDao.save(safe);
    // System.err.println("=====================" + user.getUserId());
    // }
    // }
    //
    // /**
    // * 处理用户安全级别
    // * @Title: dealUserSafe
    // * @Description: TODO
    // * @param @throws Exception
    // * @return void
    // * @author huxianjun 2016年7月28日
    // * @throws
    // */
    // public void dealUserSafe() throws Exception {
    // int pageNo = 1;
    // int pageSize = 10;
    // while (true) {
    // PageRequest request = new PageRequest(pageNo - 1, pageSize,
    // new Sort(new Sort.Order(Sort.Direction.ASC, "userId")));
    // Page<UsrDetail> page = usrDetailDao.findUsrDetail(request);
    // if (page.getContent() != null && page.getContent().size() > 0) {
    // for (UsrDetail user : page.getContent()) {
    // try {
    // // System.err.println(user.getUserName() + "===");
    // this.saveUserSafe(user);
    // } catch (Exception e) {
    // e.printStackTrace();
    // }
    // }
    // pageNo++;
    // } else {
    // break;
    // }
    // }
    // }
    //
    // /**
    // * 处理还原密码
    // * @Title: updateRebackUserPassword
    // * @Description: TODO
    // * @param @param userDetail
    // * @return void
    // * @author huxianjun 2016年8月1日
    // * @throws
    // */
    // private void updateRebackUserPassword(UsrDetail userDetail) {
    // User user = userDao.findUser(userDetail.getUserName());
    // if (user != null) {
    // user.setPassword(user.getNote());
    // userDao.save(user);
    // }
    // }
    //
    // /**
    // * 将用户密码全部更新为1
    // * @Title: updateUserPassword
    // * @Description: TODO
    // * @param @param userDetail
    // * @return void
    // * @author huxianjun 2016年8月1日
    // * @throws
    // */
    // private void updateUserPassword(UsrDetail userDetail) {
    // User user = userDao.findUser(userDetail.getUserName());
    // if (user != null) {
    // user.setPassword(EncrypMD5.generatePassword("123456"));
    // userDao.save(user);
    // }
    // }
    //
    // private void saveUserPassword(UsrDetail userDetail) {
    // User user = userDao.findUser(userDetail.getUserName());
    // MallBuilderMember member = mallBuilderMemberDao.findMallBuilderMemberByUser(userDetail.getUserName());
    // if (user == null) {
    // return;
    // }
    // if (member == null) {
    // member = mallBuilderMemberDao.findMallBuilderMember(userDetail.getUserMobile());
    // }
    // if (member != null) {
    // user.setPassword(member.getPassword());
    // userDao.save(user);
    // }
    // }
    //
    // private void saveUserName(UsrDetail userDetail) {
    // User user = userDao.findUser(userDetail.getUserName());
    // MallBuilderMember member = mallBuilderMemberDao.findMallBuilderMember(userDetail.getUserMobile());
    // if (user != null && member != null) {
    // user.setName(member.getUser());
    // userDao.save(user);
    //
    // userDetail.setUserName(member.getUser());
    // usrDetailDao.save(userDetail);
    // }
    // }
    //
    // private void saveUserSafe(UsrDetail user) {
    // UsrSecurity safe = usrSecurityDao.findUsrSecurity(user.getUserName());
    // if (safe != null) {
    // MallBuilderMember member = mallBuilderMemberDao.findMallBuilderMemberByUser(user.getUserName());
    // if (member != null) {
    // if (member.getEmailVerify() == 1) {
    // safe.setMailVerifn(1);
    // }
    // if (member.getMobileVerify() == 1) {
    // safe.setPhoneVerifn(1);
    // } else {
    // safe.setPhoneVerifn(0);
    // }
    // safe.setPayStrength(0);
    // if (StringUtils.isNotBlank(user.getPayPassword())) {
    // safe.setPaypassVerifn(1);
    // safe.setPayStrength(1);
    // }
    // }
    // safe.setSecLevel(1 + safe.getMailVerifn() + safe.getPaypassVerifn() + safe.getPhoneVerifn());
    // usrSecurityDao.save(safe);
    // } else {
    // safe = new UsrSecurity();
    // safe.setUserName(user.getUserName());
    // safe.setCreateTime(new Date());
    // if (StringUtils.isNotBlank(user.getUserMail())) {
    // safe.setMailVerifn(1);
    // } else {
    // safe.setMailVerifn(0);
    // }
    // if (StringUtils.isNotBlank(user.getPayPassword())) {
    // safe.setPaypassVerifn(1);
    // } else {
    // safe.setPaypassVerifn(0);
    // }
    // if (StringUtils.isNotBlank(user.getUserMobile())) {
    // safe.setPhoneVerifn(1);
    // } else {
    // safe.setPhoneVerifn(0);
    // }
    //
    // safe.setPayStrength(0);
    // safe.setTimes(0);
    // safe.setSecLevel(1 + safe.getMailVerifn() + safe.getPaypassVerifn() + safe.getPhoneVerifn());
    // usrSecurityDao.save(safe);
    // System.err.println("=====================");
    // }
    // }
    //
    // /**
    // * 处理两个系统用户的转换，远丰系统－>广州系统
    // * @Title: dealConvertMember
    // * @Description: TODO
    // * @param @throws Exception
    // * @return void
    // * @author huxianjun 2016年7月28日
    // * @throws
    // */
    // public void dealConvertMember() throws Exception {
    // int pageNo = 1;
    // int pageSize = 10;
    // while (true) {
    // PageRequest request = new PageRequest(pageNo - 1, pageSize,
    // new Sort(new Sort.Order(Sort.Direction.ASC, "id")));
    // Page<MallBuilderMember> page = mallBuilderMemberDao.findMallBuilderMember(request);
    // if (page.getContent() != null && page.getContent().size() > 0) {
    // for (MallBuilderMember member : page.getContent()) {
    // try {
    // if (StringUtils.isNotBlank(member.getMobile())) {
    // System.err.println(member.getMobile() + "===");
    // this.saveMemberRegister(member);
    // }
    // } catch (Exception e) {
    //
    // }
    // }
    // pageNo++;
    // } else {
    // break;
    // }
    // }
    // }
    //
    // public void saveMemberRegister(MallBuilderMember member) {
    // try {
    // PayMember pay = payMemberDao.findPayMember(member.getUserid());
    // if (pay == null) {
    // return;
    // }
    // UsrDetail usrDetail = new UsrDetail();
    // usrDetail.setGold(pay.getGoldCoins());
    // usrDetail.setSilver(pay.getSilverCoins());
    // usrDetail.setScore(0);
    // usrDetail.setGradeId(1);
    // usrDetail.setTotalCash(new BigDecimal(0.0));
    // usrDetail.setTotalConsume(new BigDecimal(0));
    // usrDetail.setModifyTime(commonSqlDao.dbDate());
    // usrDetail.setUserRegip("127.0.0.1");
    // usrDetail.setUserLastip("127.0.0.1");
    // usrDetail.setPortraitPic(member.getLogo());
    // usrDetail.setUserRegtime(member.getRegtime());
    // usrDetail.setUserLasttime(commonSqlDao.dbDate());
    // // usrDetail.setUserName(this.generateUserName());
    // usrDetail.setUserName(member.getUser());
    // usrDetail.setNickName(member.getUser());
    // if (StringUtils.isNotBlank(member.getMobile())) {
    // usrDetail.setUserMobile(member.getMobile());
    // } else {
    // usrDetail.setUserMobile(member.getUser());
    // }
    // usrDetail.setGoldConvertTime(commonSqlDao.dbDate());
    // usrDetail.setAvailablePredeposit(pay.getCash());
    // usrDetail.setFreezePredeposit(new BigDecimal(0.0));
    // usrDetail.setShopAvailablePred(pay.getMerchantCash());
    // usrDetail.setShopFreezePred(new BigDecimal(0.0));
    // usrDetail.setRealName(pay.getRealName());
    // usrDetail.setIdCard(pay.getIdentityCard());
    // usrDetail.setPayPassword(pay.getPayPass());
    // usrDetail.setQq(member.getQq());
    // usrDetail.setBirthDate(member.getBirth());
    // usrDetail.setUserMail("".equals(member.getEmail()) ? null : member.getEmail());
    // String token = StringHelper.createUUID();
    // usrDetail.setToken(token);
    // usrDetail.setSignKey(token.replace("-", ""));
    // String sex = "M";
    // if (member.getSex() != null) {
    // sex = member.getSex() == 1 ? "M" : "F";
    // }
    // usrDetail.setSex(sex);
    //
    // if (member.getProvinceid() != null) {
    // MallBuilderDistrict districtProvince = mallBuilderDistrictDao.findOne(member.getProvinceid());
    // if (districtProvince != null) {
    // String jian = districtProvince.getName().substring(0, districtProvince.getName().length() - 1);
    // Provinces province = provincesDao.findProvinces(jian, districtProvince.getName());
    // usrDetail.setProvinceid(province != null ? province.getId() : 0);
    // }
    // MallBuilderDistrict districtCity = mallBuilderDistrictDao.findOne(member.getCityid());
    // if (districtCity != null) {
    // City city = cityDao.findCity(districtCity.getName());
    // usrDetail.setCityid(city != null ? city.getId() : 0);
    // }
    // MallBuilderDistrict districtArea = mallBuilderDistrictDao.findOne(member.getAreaid());
    // if (districtArea != null) {
    // Areas area = areasDao.findAreas(districtArea.getName());
    // usrDetail.setAreaid(area != null ? area.getId() : 0);
    // }
    // }
    //
    // usrDetail = usrDetailDao.save(usrDetail);
    //
    // User user = new User();
    // user.setId(usrDetail.getUserId());
    // user.setDeptId(0);
    // user.setEnabled("1");
    // user.setName(usrDetail.getUserName());
    // // user.setPassword(member.getPassword());
    // user.setPassword(EncrypMD5.generatePassword("123456"));
    //
    // userDao.save(user);
    //
    // // 角色
    // this.saveUserRoles(usrDetail.getUserId());
    // // 默认认证
    // this.saveDefaultUserSecurity(usrDetail.getUserName());
    // // 地址
    // this.saveUserAddress(usrDetail, member);
    // } catch (Exception e) {
    // // TODO Auto-generated catch block
    // e.printStackTrace();
    // System.err.println(member.getMobile() + "------------");
    // }
    // }
    //
    // private void saveUserAddress(UsrDetail usrDetail, MallBuilderMember member) {
    // List<MallBuilderDeliveryAddress> listAddress = mallBuilderDeliveryAddressDao
    // .findMallBuilderDeliveryAddress(member.getUserid());
    // if (listAddress != null && listAddress.size() > 0) {
    // for (MallBuilderDeliveryAddress address : listAddress) {
    // UsrAddr addr = new UsrAddr();
    // addr.setAliasAddr("");
    // addr.setCreateTime(commonSqlDao.dbDate());
    // addr.setEmail("");
    // addr.setMobile(address.getMobile());
    // addr.setModifyTime(commonSqlDao.dbDate());
    // addr.setReceiver(address.getName());
    // addr.setStatus(1);
    // addr.setVersion(1);
    // addr.setTelphone(address.getMobile());
    // addr.setSubAdds(address.getAddress());
    // addr.setSubPost(address.getZip());
    // addr.setUserId(usrDetail.getUserId());
    // addr.setUserName(usrDetail.getUserName());
    // addr.setCommonAddr(address.getDefaultAddress() == 2 ? "1" : "0");
    // MallBuilderDistrict districtProvince = mallBuilderDistrictDao.findOne(address.getProvinceid());
    // if (districtProvince != null) {
    // String jian = districtProvince.getName().substring(0, districtProvince.getName().length() - 1);
    // Provinces province = provincesDao.findProvinces(jian, districtProvince.getName());
    // addr.setProvinceId(province != null ? province.getId() : 0);
    // }
    // MallBuilderDistrict districtCity = mallBuilderDistrictDao.findOne(address.getCityid());
    // if (districtCity != null) {
    // City city = cityDao.findCity(districtCity.getName());
    // addr.setCityId(city != null ? city.getId() : 0);
    // }
    // MallBuilderDistrict districtArea = mallBuilderDistrictDao.findOne(address.getAreaid());
    // if (districtArea != null) {
    // Areas area = areasDao.findAreas(districtArea.getName());
    // addr.setAreaId(area != null ? area.getId() : 0);
    // }
    // usrAddrDao.save(addr);
    // }
    // }
    // }
    //
    // private void saveUserRoles(String userId) {
    // List<Role> roles = roleDao.findRole("ROLE_USER");
    // List<UsrRole> list = Lists.newArrayList();
    // if (roles != null && roles.size() > 0) {
    // for (Role role : roles) {
    // UsrRole ur = new UsrRole();
    // ur.setAppNo(EmApplication.FRONT_END.name);
    // ur.setUserId(userId);
    // ur.setRoleId(role.getId());
    // list.add(ur);
    // }
    // usrRoleDao.save(list);
    // }
    // }
    //
    // private Long getCRC32(String crcs) {
    // CRC32 crc32 = new CRC32();
    // crc32.update(crcs.getBytes());
    // return crc32.getValue();
    // }
    //
    // /**
    // * 检查用户是否存在
    // * @Title: isUserExist
    // * @Description: TODO
    // * @param @param userName
    // * @param @return
    // * @return boolean
    // * @author huxianjun 2016年7月21日
    // * @throws
    // */
    // private boolean isUserExist(String userName) {
    // return userDao.findUser(userName) == null ? false : true;
    // }
    //
    // /**
    // * 根据用户Id 生成 用户名
    // * @Title: generateUserName
    // * @Description: TODO
    // * @param @return
    // * @return String
    // * @author huxianjun 2016年7月21日
    // * @throws
    // */
    // public String generateUserName() {
    // Random random = new Random();
    // String userName;
    // do {
    // long millis = System.currentTimeMillis();
    // userName = String.valueOf(this.getCRC32(String.valueOf(millis))) + random.nextInt(10) + random.nextInt(10);
    // } while (isUserExist(userName));
    // return userName;
    // }
    //
    // public void saveDefaultUserSecurity(String userName, Integer secLevel) {
    // UsrSecurity userSecurity = new UsrSecurity();
    // userSecurity.setUserName(userName);
    // userSecurity.setCreateTime(new Date());
    // userSecurity.setSecLevel(secLevel);
    // userSecurity.setMailVerifn(0);
    // userSecurity.setPaypassVerifn(0);
    // userSecurity.setPhoneVerifn(0);
    // userSecurity.setPayStrength(0);
    // userSecurity.setTimes(0);
    // usrSecurityDao.save(userSecurity);
    // }
    //
    // public void saveDefaultUserSecurity(String userName) {
    // saveDefaultUserSecurity(userName, EmUserSecurity.SECURITY_DANGEROUS.value);// 默认安全等级是1
    // }

}
