package com.nhs.user.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import ch.qos.logback.classic.pattern.EnsureExceptionHandling;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.nhs.apiproxy.UnifiedInApiReqHelper;
import com.nhs.apiproxy.UnifiedInApiResultHelper;
import com.nhs.apiproxy.member.acc.datatype.CurrencyEnum;
import com.nhs.apiproxy.member.acc.dto.UserAccDto;
import com.nhs.apiproxy.member.acc.dto.UserAllAccDto;
import com.nhs.apiproxy.member.acc.service.AccountTransferService;
import com.nhs.core.common.NhsConstant;
import com.nhs.core.context.SysPropsFactory;
import com.nhs.core.orm.Page;
import com.nhs.core.rest.HttpClientUtils;
import com.nhs.core.utils.common.DateUtils;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.core.utils.security.EncrypMD5;
import com.nhs.core.web.WebRequestException;
import com.nhs.core.web.dto.MemberResponseDto;
import com.nhs.shop.activity.dao.ActivitySchoolDao;
import com.nhs.shop.activity.entry.ActivitySchool;
import com.nhs.shop.dao.CommonSqlDao;
import com.nhs.shop.dao.legend.coin.CoinRmbSilverLogJdbcDao;
import com.nhs.shop.dao.legend.recommend.VitLogDao;
import com.nhs.shop.dao.legend.region.AreasDao;
import com.nhs.shop.dao.legend.region.CityDao;
import com.nhs.shop.dao.legend.region.ProvincesDao;
import com.nhs.shop.dao.legend.service.O2oServiceOrderDao;
import com.nhs.shop.dao.legend.shop.ShopDetailDao;
import com.nhs.shop.dao.legend.shop.SubDao;
import com.nhs.shop.dao.legend.shop.SubItemDao;
import com.nhs.shop.dao.legend.sms.SmsLogDao;
import com.nhs.shop.dao.legend.user.UsrFeedBackByDateDao;
import com.nhs.shop.dao.legend.user.UsrFeedbackDao;
import com.nhs.shop.dao.system.SystemParameterDao;
import com.nhs.shop.entry.em.EmSmsType;
import com.nhs.shop.entry.legend.region.Areas;
import com.nhs.shop.entry.legend.region.City;
import com.nhs.shop.entry.legend.region.Provinces;
import com.nhs.shop.entry.legend.service.O2oServiceOrder;
import com.nhs.shop.entry.legend.shop.ShopDetail;
import com.nhs.shop.entry.legend.shop.Sub;
import com.nhs.shop.entry.legend.shop.SubItem;
import com.nhs.shop.entry.legend.sms.SmsLog;
import com.nhs.shop.entry.legend.user.UsrDetail;
import com.nhs.shop.entry.legend.user.UsrFeedback;
import com.nhs.shop.entry.system.SystemParameter;
import com.nhs.shop.service.BaseService;
import com.nhs.shop.util.BasicConstant;
import com.nhs.sms.service.SmsService;
import com.nhs.user.activity.dto.UserDetailSchoolDto;
import com.nhs.user.dto.CoinRmbSilverLogDto;
import com.nhs.user.dto.Commission;
import com.nhs.user.dto.MemberAccountDto;
import com.nhs.user.dto.MemberDetailDto;
import com.nhs.user.dto.UsrDetailDto;

@Service
@Transactional
public class MemberService extends BaseService {

    private final Logger logger = LoggerFactory.getLogger(MemberService.class);

    @Value("${rest.member.user.shop.login.url}")
    private String shopLoginUrl;

    @Value("${rest.member.user.findUserDetail.url}")
    private String findUserDetailUrl;

    @Value("${rest.member.account.findUserAccUrl.url}")
    private String findUserAccUrl;

    @Autowired
    private CommonSqlDao commonSqlDao;

    @Autowired
    private ProvincesDao provincesDao;

    @Autowired
    private CityDao cityDao;

    @Autowired
    private SmsLogDao smsLogDao;

    @Autowired
    private SmsService smsService;

    @Autowired
    private UsrFeedbackDao usrFeedbackDao;

    @Autowired
    private ShopDetailDao shopDetailDao;

    @Autowired
    private VitLogDao vitLogDao;

    @Autowired
    private O2oServiceOrderDao o2oServiceOrderDao;

    @Autowired
    private UsrFeedBackByDateDao usrFeedBackByDateDao;

    @Autowired
    private SubDao subDao;

    @Autowired
    private CoinRmbSilverLogJdbcDao silverLogJdbcDao;

    @Autowired
    private ActivitySchoolDao actSchoolDao;

    @Autowired
    private SystemParameterDao sysDao;

    @Autowired
    private SubItemDao subItemDao;

    @Autowired
    private AreasDao areasDao;

    @Autowired
    private UserService userService;
    @Autowired
    private AccountTransferService accountService;
    
    public void dealSendValid(String phone, Integer type) {
        String code = "";
        SmsLog sms = smsLogDao.findSmsValidate(phone);

        if (type == 1) {
            if (sms != null) {
                Date over = sms.getRecDate();
                if (DateUtils.dateAddHourMin(over, 0, 2).after(commonSqlDao.dbDate())) {
                    return;
                }
            }
            code = StringHelper.radomCode(BasicConstant.VALIDATE_LENGTH);
            smsService.saveSendSms(10001, phone, code, EmSmsType.VAL.value, new String[] { code, "2" });
        } else if (type == 2) {
            if (sms != null) {
                code = sms.getMobileCode();
            } else {
                code = StringHelper.radomCode(BasicConstant.VALIDATE_LENGTH);
            }
            // TODO hxj 语音验证码处理
            // smsService.saveSendSms(10001, phone, code, EmSmsType.VAL.value,
            // new String[] { code, "2" });
        }
    }

    /**
     * 添加用户反馈
     * @Title: saveFeedback
     * @Description: TODO
     * @param feedback
     * @author cary 2016年8月18日
     * @throws
     */
    public void saveFeedback(UsrFeedback feedback) {

        if (null == feedback || null == feedback.getContent() || feedback.getContent().length() > 200) {
            throw new WebRequestException("反馈内容为空，或超长");
        }
        feedback.setRecDate(new Date());
        usrFeedbackDao.save(feedback);
    }

    /**
     * 查询用户反馈
     * @Title: getFeedback
     * @Description: TODO
     * @param userId
     * @author cary 2016年8月18日
     * @throws
     */
    public List<Map<String, Object>> getFeedbackTwo(Page<Map<String, Object>> page, int feedBackType, String name,
            String fromDate, String fromDateTWo) {
        List<Map<String, Object>> result = Lists.newArrayList();

        Page<Map<String, Object>> pageData = null;

        // 1 为卖家版的意见反馈;其它为买家版的意见反馈
        pageData = usrFeedBackByDateDao.findByUserIdAndFeedBackType(name, fromDate, fromDateTWo, page, feedBackType);

        if (pageData.getResult() != null && pageData.getResult().size() > 0) {
            for (Map<String, Object> feedback : pageData.getResult()) {
                Map<String, Object> card = Maps.newHashMap();
                card.put("id", feedback.get("ip"));
                card.put("userId", feedback.get("user_id"));
                card.put("contactInformation", feedback.get("contact_information"));
                card.put("content", feedback.get("content"));
                card.put("respMgntId", feedback.get("resp_mgnt_id"));
                card.put("respContent", feedback.get("resp_content"));
                card.put("respDate", DateUtils.date2Str((Date) feedback.get("rec_date"), "yyyy-MM-dd HH:mm:ss"));
                card.put("name", feedback.get("name"));
                card.put("feedBackType", feedback.get("feed_back_type"));

                result.add(card);
            }
        }
        return result;
    }

    private MemberDetailDto memberLogin(String userAccount, String password) {
        Map<String, Object> param = new HashMap<>();
        param.put("passport", userAccount);
        param.put("password", password);
        MemberDetailDto memberDetail = this.getResponseMember(param, this.shopLoginUrl);
		
        return memberDetail;
    }

    protected MemberDetailDto getResponseMember(Map<String, Object> param, String url) {
        Assert.isTrue(param != null && param.size() > 0, "查询成员信息时, 参数不能为空.");
        Assert.isTrue(!StringUtils.isEmpty(url), "查询成员信息的地址不能为空.");
        param = UnifiedInApiReqHelper.signParam(param);
        
        String result = "";
		try {
			result = HttpClientUtils.post(url, param);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
        MemberResponseDto responseDto = UnifiedInApiResultHelper.parseResultToObj(result, MemberResponseDto.class);
        if(1 != responseDto.getCode()){
        	throw new WebRequestException(responseDto.getMsg());
        }
        MemberDetailDto memberDetailDto = UnifiedInApiResultHelper.parseDataToObj(result, MemberDetailDto.class);
        return memberDetailDto;
       
    }

    /**
     * 店铺人员登录
     * @param ip
     * @param userAccount
     * @param password
     * @param type
     * @param openid
     * @return
     */
    public Map<String, Object> storeMemberLogin(String ip, String userAccount, String password, Integer type,
            String openid) {

        MemberDetailDto usrDetail = this.memberLogin(userAccount.trim(), password);

        ShopDetail shopDetail = shopDetailDao.findShopDetail(usrDetail.getUserId());

        if (shopDetail == null) {
            throw new WebRequestException("该用户尚未开通店铺");
        } else if (shopDetail.getShopSystem() != 2) {
            throw new WebRequestException("目前只支持O2O实体店店铺");
        } else if (shopDetail.getStatus() != 1) {
            throw new WebRequestException("该用户对应的店铺状态处于非正常状态，请联系管理员");
        }

        return this.sotreLoginDeal(ip, type, openid, usrDetail, shopDetail);
    }

    private Map<String, Object> sotreLoginDeal(String ip, Integer type, String openid, MemberDetailDto usrDetail,
            ShopDetail shopDetail) {
        Map<String, Object> info = Maps.newHashMap();

        info = this.encodeStoreMemberInfo(usrDetail, type, shopDetail);
        return info;
    }

    @Transactional
    private Map<String, Object> encodeStoreMemberInfo(MemberDetailDto usrDetail, Integer type, ShopDetail shopDetail) {
        // 微信处理
        if (type == 1) {

        }

        Map<String, Object> info = convertUserInfo(usrDetail, shopDetail);

        return info;
    }

    private Map<String, Object> convertUserInfo(MemberDetailDto usrDetail, ShopDetail shopDetail) {
        Map<String, Object> info = Maps.newHashMap();

        info.put("userName", usrDetail.getMobileNo());
        info.put("nickName", usrDetail.getNickName());
        info.put("userId", usrDetail.getUserId());
        info.put("mobile", usrDetail.getMobileNo());
        String image = usrDetail.getHeadPath();
        if (StringUtils.isNotBlank(image) && image.indexOf("http:") < 0) {
            image = SysPropsFactory.getProperty("imgServer") + "/" + image;
        }
        info.put("image", image);

        List<MemberAccountDto> accDtoList = usrDetail.getAccount();
        BigDecimal shopBalance = new BigDecimal("0.00");
        if (accDtoList != null) {
            for (MemberAccountDto accDto : accDtoList) {
                if (CurrencyEnum.CURRENCY_BUSINESS_BALANCE.getCurrency().equals(accDto.getCurrency())) {
                    shopBalance = accDto.getAmount();
                    break;
                }
            }
        }

        info.put("balance",
                shopBalance == null ? "0.00" : shopBalance.setScale(2, BigDecimal.ROUND_HALF_UP).toString());

        info.put("realName", usrDetail.getRealName());
        info.put("provinceid", shopDetail.getProvinceid());
        info.put("cityid", shopDetail.getCityid());
        info.put("areaid", shopDetail.getAreaid());
        // info.put("userAdds", usrDetail.getUserAdds());
        info.put("shopId", shopDetail.getShopId());
        info.put("shopName", shopDetail.getSiteName());
        info.put("shopSystem", shopDetail.getShopSystem());
        info.put("token", usrDetail.getToken());
        // if (StringUtils.isNotBlank(usrDetail.getSignKey())) {
        // info.put("signKey", usrDetail.getSignKey());
        // } else {
        // info.put("signKey", usrDetail.getUserId().replace("-", ""));
        //
        // }
        info.put("signKey", usrDetail.getSignKey());
        // 有无支付密码 0没有支付密码 1有支付密码
        if ("1".equals(usrDetail.getPayAuthed())) {
            info.put("ispayPassword", "1");
        } else {
            info.put("ispayPassword", "0");
        }

        String address = "";
        String provinceName = "";
        String cityName = "";
        String areaName = "";
        if (null != shopDetail.getProvinceid() && shopDetail.getProvinceid() != 0) {
            Provinces provinces = provincesDao.findOne(shopDetail.getProvinceid());
            if (provinces != null) {
                address += provinces.getProvince();
                provinceName = provinces.getProvince();
            }
        }
        if (null != shopDetail.getCityid() && shopDetail.getCityid() != 0) {
            City city = cityDao.findOne(shopDetail.getCityid());
            if (city != null) {
                address += city.getCity();
                cityName = city.getCity();
            }
        }
        if (null != shopDetail.getAreaid() && shopDetail.getAreaid() != 0) {
            Areas area = areasDao.findOne(shopDetail.getAreaid());
            if (area != null) {
                address += area.getArea();
                areaName = area.getArea();
            }
        }
        info.put("address", address);
        info.put("provinceName", provinceName);
        info.put("cityName", cityName);
        info.put("areaName", areaName);
        // 获取昨日访问量
        Date date = new Date();
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(date);
        calendar.add(Calendar.DATE, -1);
        date = calendar.getTime();
        String startDate = DateUtils.date2Str(date, DateUtils.DAY_START_TIME_FORMAT);
        String endDate = DateUtils.date2Str(date, DateUtils.DAY_END_TIME_FORMAT);
        long countVisitYestoday = vitLogDao.countVisitByShopIdAndDate(shopDetail.getShopId(), startDate, endDate);

        info.put("countVisitYestoday", countVisitYestoday);

        // 获取今日订单数量 (O2o的订单数量)
        Date currentdate = new Date();
        String currentStartDate = DateUtils.date2Str(currentdate, DateUtils.DAY_START_TIME_FORMAT);
        String currentEndDate = DateUtils.date2Str(currentdate, DateUtils.DAY_END_TIME_FORMAT);
        long orderNumCurrent = o2oServiceOrderDao.countByShopIdAndStatusAndCreateTime(shopDetail.getShopId(),
                currentStartDate, currentEndDate);

        info.put("orderNumCurrent", orderNumCurrent);

        // 获取待付款订单数
        long countWaitForPay = o2oServiceOrderDao.countByShopIdAndStatus(shopDetail.getShopId(), 1);

        info.put("countWaitForPay", countWaitForPay);

        // 获取交易完成订单数
        long countFinished = o2oServiceOrderDao.countByShopIdAndStatus(shopDetail.getShopId());
        info.put("countFinished", countFinished);

        // 获取交易关闭订单数
        long countCancel = o2oServiceOrderDao.countByShopIdAndStatus(shopDetail.getShopId(), 4);
        info.put("countCancel", countCancel);

        // 获取昨日订单总额
        BigDecimal totalAmountYestoday = o2oServiceOrderDao.sumTotalAmount(shopDetail.getShopId(), startDate, endDate);
        if (totalAmountYestoday == null) {
            totalAmountYestoday = new BigDecimal("0.00");
        }
        info.put("totalAmountYestoday", totalAmountYestoday.setScale(2, BigDecimal.ROUND_HALF_UP).toString());

        return info;
    }

    public Map<String, Object> getHomeStoreInfo(String userId, int shopId) {

        MemberDetailDto usrDetail = this.getUserDetailByUserId(userId);

        ShopDetail shopDetail = shopDetailDao.findShopDetail(usrDetail.getUserId());

        if (shopDetail == null) {
            throw new WebRequestException("该用户尚未开通店铺");
        } else if (shopDetail.getShopSystem() != 2) {
            throw new WebRequestException("目前只支持O2O实体店店铺");
        } else if (shopDetail.getStatus() != 1) {
            throw new WebRequestException("该用户对应的店铺状态处于非正常状态，请联系管理员");
        }

        Map<String, Object> info = convertUserInfo(usrDetail, shopDetail);

        return info;
    }

    /**
     * 查询所有新注册活动期间注册的用户
     * @param startTime
     * @param endTime
     * @return
     */
    public List<UsrDetailDto> findUserDetailByRegTime(Date startTime, Date endTime) {

        List<UsrDetail> usrDetailList = userService.findUsersByRegtime(DateUtils.date2Str(startTime),
                DateUtils.date2Str(endTime), null);
        List<UsrDetailDto> userDetailDtoList = new ArrayList<>();
        for (UsrDetail userDetail : usrDetailList) {
            UsrDetailDto dto = new UsrDetailDto();
            dto.setUserId(userDetail.getUserId());
            dto.setUserName(userDetail.getUserName());
            dto.setRegTimeStr(DateUtils.date2Str(userDetail.getUserRegtime()));
            dto.setUserNickName(userDetail.getUserName());
            dto.setUserMobile(userDetail.getUserMobile());
            UserAllAccDto userAllAcc = this.accountService.findUserAllAcc(userDetail.getUserId());
            dto.setSilver(userAllAcc.getPSliver().toString());
            userDetailDtoList.add(dto);
        }

        return userDetailDtoList;

    }

    /**
     * 用户银币记录
     * @param userId
     * @return
     */
    public List<CoinRmbSilverLogDto> getSilverHistory(String userId, Page<Map<String, Object>> page) {

        Page<Map<String, Object>> pageData = silverLogJdbcDao.getSilverHistoryByUserId(userId, page);

        List<Map<String, Object>> silverLogList = pageData.getResult();

        List<CoinRmbSilverLogDto> list = new ArrayList<>();

        if (silverLogList != null) {

            for (Map<String, Object> map : silverLogList) {

                CoinRmbSilverLogDto silverLogDto = new CoinRmbSilverLogDto();
                silverLogDto.setUserId(userId);
                String orderNum = StringHelper.objectToString(map.get("sub_number"), "");
                silverLogDto.setSubNumber(orderNum);
                String coinSum = StringHelper.objectToString(map.get("coin_sum"), "0");
                silverLogDto.setCoinSum("+" + coinSum);
                int activityId = StringHelper.objectToInt(map.get("activity_id"), 0);
                String acitvityTitle = StringHelper.objectToString(map.get("activity_title"), "");
                Date createTime = map.get("create_time") == null ? null : (Date) map.get("create_time");
                silverLogDto.setShowDateTime(DateUtils.date2Str(createTime));
                String type = StringHelper.objectToString(map.get("type"), "0");
                silverLogDto.setType(Integer.parseInt(type));
                if (activityId != 0) {
                    silverLogDto.setTitle(acitvityTitle);
                    silverLogDto.setLogo(getSingleValueByType(NhsConstant.PARAM_DEFAULT_ACTIVITY_LOGO));
                } else {
                    String shopName = "";
                    int shopId = 0;
                    List<SubItem> subList = subItemDao.findBySubItemNumber(orderNum);
                    if (subList == null || subList.size() == 0) {
                        O2oServiceOrder serviceOrder = o2oServiceOrderDao.findO2oServiceOrderByOrderNum(orderNum);
                        if (serviceOrder != null) {
                            shopName = serviceOrder.getShopName();
                            shopId = serviceOrder.getShopId();
                        }
                    } else {
                        SubItem item = subList.get(0);
                        Sub sub = subDao.findSubBySubNum(item.getSubNumber());
                        if (sub != null) {
                            shopName = sub.getShopName();
                            shopId = sub.getShopId();
                        }
                    }

                    silverLogDto.setShopId(shopId);
                    silverLogDto.setShopName(shopName);

                    if ("1".equals(type)) {
                        silverLogDto.setTitle(shopName + "消费");
                        ShopDetail shop = shopDetailDao.findByShopIdAndStatus(shopId, 1);
                        if (shop != null) {
                            silverLogDto
                                    .setLogo(buildImg(SysPropsFactory.getProperty("imgServer"), shop.getShopPic2()));
                        } else {
                            silverLogDto.setLogo("");
                        }
                    } else if ("2".equals(type)) {
                        silverLogDto.setLogo(getSingleValueByType(NhsConstant.PARAM_DEFAULT_SELLER_LOGO));
                        silverLogDto.setTitle("推广费" + getSingleValueByType(NhsConstant.PARAM_PRESENT_SIGN)
                                + getSingleValueByType(NhsConstant.PARAM_SILVER_NAME));
                    } else if ("3".equals(type)) {
                        silverLogDto.setLogo(getSingleValueByType(NhsConstant.PARAM_DEFAULT_SELERS_COMISSION_LOGO));
                        silverLogDto.setTitle("赢业宝活动" + getSingleValueByType(NhsConstant.PARAM_PRESENT_SIGN)
                                + getSingleValueByType(NhsConstant.PARAM_SILVER_NAME));
                    }
                }

                operateDate(silverLogDto, createTime);

                list.add(silverLogDto);

            }

        }

        return list;

    }

    private String getSingleValueByType(String type) {

        List<SystemParameter> paramList = sysDao.findByTypeAndState(type, 0);

        if (paramList != null && paramList.size() > 0) {
            SystemParameter param = paramList.get(0);
            return param.getKeyValue();
        }
        return "";

    }

    private void operateDate(CoinRmbSilverLogDto silverLogDto, Date createTime) {
        if (createTime != null) {
            String year = DateUtils.queryCurrYearWith4Bit(createTime);
            String month = DateUtils.queryCurrMonthWith2Bit(createTime);
            String day = DateUtils.queryCurrDayWith2Bit(createTime);

            String currentYear = DateUtils.queryCurrYearWith4Bit(new Date());
            String currentMonth = DateUtils.queryCurrMonthWith2Bit(new Date());
            String currentDay = DateUtils.queryCurrDayWith2Bit(new Date());

            String ymd = year + month + day;

            String curYmd = currentYear + currentMonth + currentDay;

            if (curYmd.equals(ymd)) {
                silverLogDto.setShowDate("今天");
                silverLogDto.setShowTime(DateUtils.getHourAndMinute(createTime));
            } else {
                Date yestoday = DateUtils.addDays(new Date(), -1);
                String yestodayYMD = DateUtils.queryYMDCurrDate(yestoday);
                if (ymd.equals(yestodayYMD)) {
                    silverLogDto.setShowDate("昨天");
                    silverLogDto.setShowTime(DateUtils.getHourAndMinute(createTime));
                } else {
                    silverLogDto.setShowDate(DateUtils.getWeekOfDate(createTime));
                    silverLogDto.setShowTime(month + "-" + day);
                }
            }

        }
    }

    /**
     * 查询所有新注册活动期间注册的用户
     * @param startTime
     * @param endTime
     * @return
     */
    public List<UserDetailSchoolDto> findSchoolActUserDetailByRegTime(Date startTime, Date endTime) {

        List<ActivitySchool> schoolUserList = actSchoolDao.findByRebateStatus(0);

        List<UsrDetail> usrDetailList = new ArrayList<>();

        List<String> userMobileList = new ArrayList<>();

        for (ActivitySchool school : schoolUserList) {
            if (StringUtils.isNotEmpty(school.getInviteeUserMobile())) {
                userMobileList.add(school.getInviteeUserMobile());
            }
        }

        if (userMobileList != null && userMobileList.size() > 0) {
            usrDetailList = userService.findUsersByRegtime(DateUtils.date2Str(startTime), DateUtils.date2Str(endTime),
                    userMobileList);// .findByUserMobileInAndUserRegtimeBetween(userMobileList, startTime, endTime); }
        }

        List<UserDetailSchoolDto> userDetailDtoList = new ArrayList<>();

        for (UsrDetail userDetail : usrDetailList) {
            UserDetailSchoolDto dto = new UserDetailSchoolDto();
            dto.setInviteeUserId(userDetail.getUserId());
            dto.setRegTimeStr(DateUtils.date2Str(userDetail.getUserRegtime()));
            ActivitySchool school = actSchoolDao.findByInviteeUserMobile(userDetail.getUserMobile());
            String inviterUserId = school.getInviterUserId();
            dto.setInviterUserId(inviterUserId);
            userDetailDtoList.add(dto);
        }

        return userDetailDtoList;

    }

    /**
     * 查询用户反馈
     * @Title: getFeedback
     * @Description: TODO
     * @param userId
     * @author cary 2016年8月18日
     * @throws
     */
    public List<Map<String, Object>> getFeedback(String userId, int feedBackType) {
        List<Map<String, Object>> result = Lists.newArrayList();

        if (StringUtils.isBlank(userId)) {
            throw new WebRequestException("userId为空");
        }
        List<UsrFeedback> feedbacks = new ArrayList<UsrFeedback>();

        // 1 为卖家版的意见反馈;其它为买家版的意见反馈
        feedbacks = usrFeedbackDao.findByUserIdAndFeedBackType(userId, feedBackType);

        if (feedbacks != null && feedbacks.size() > 0) {
            for (UsrFeedback feedback : feedbacks) {
                Map<String, Object> card = Maps.newHashMap();
                card.put("id", feedback.getId());
                card.put("userId", feedback.getUserId());
                card.put("contactInformation", feedback.getContactInformation());
                card.put("ip", feedback.getIp());
                card.put("content", feedback.getContent());
                card.put("recDate", (Date) feedback.getRecDate());
                card.put("respMgntId", feedback.getRespMgntId());
                card.put("respContent", feedback.getRespContent());
                card.put("respDate", (Date) feedback.getRespDate());
                result.add(card);
            }
        }
        return result;
    }

    public MemberDetailDto getUserDetailByUserId(String userId) {
        Map<String, Object> param = new HashMap<>();
        param.put("userId", userId);
        MemberDetailDto memberDetailDto = this.getResponseMember(param, this.findUserDetailUrl);
        // 查询余额
        Map<String, Object> param2 = new HashMap<>();
        param2.put("userId", userId);
        this.addbalance(memberDetailDto, param2, this.findUserAccUrl);

        return memberDetailDto;
    }

    private void addbalance(MemberDetailDto memberDetailDto, Map<String, Object> param, String url) {
        Assert.isTrue(param != null && param.size() > 0, "查询余额信息时, 参数不能为空.");
        Assert.isTrue(!StringUtils.isEmpty(url), "查询余额信息不能为空.");
        param = UnifiedInApiReqHelper.signParam(param);
        try {
            String result = HttpClientUtils.post(url, param);
            List<MemberAccountDto> account = UnifiedInApiResultHelper.parseDataToList(result, MemberAccountDto.class);
            memberDetailDto.setAccount(account);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    protected String buildImg(String prefix, String img) {
        if (StringUtils.isBlank(img)) {
            return "";
        }
        if (img.startsWith("http") || img.startsWith("https")) {
            return img;
        }
        return prefix + "/" + img;
    }

    public Map<String, Object> getSystemParameter() {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("goldName", getSingleValueByType(NhsConstant.PARAM_GOLD_NAME));
        map.put("silverName", getSingleValueByType(NhsConstant.PARAM_SILVER_NAME));
        map.put("iosNeedUpdate", getSingleValueByType(NhsConstant.PARAM_IOS_NEED_UPDATE).toUpperCase());

        return map;
    }

    private MemberDetailDto convertToMemberDetailDto(MemberResponseDto responseDto) {
        Map<String, Object> map = responseDto.getData();
        MemberDetailDto memberDetail = null;

        if (responseDto.isSuccess()) {
            if (!MapUtils.isEmpty(map)) {
                String jsonString = JSON.toJSONString(map);
                memberDetail = JSON.parseObject(jsonString, MemberDetailDto.class);
            } else {
                throw new WebRequestException(responseDto.getMsg());
            }
        } else {
            throw new WebRequestException(responseDto.getMsg());
        }

        return memberDetail;
    }

    public UsrDetail saveMemberRegister(String userMobile, String password, String regType) {
    	password = EncrypMD5.generatePassword(password);
    	UsrDetail usrDetail = userService.simpleRegister(userMobile, password, regType);
        return usrDetail;
    }

    public Commission queryCommission(String phone) {
        Commission csson = new Commission();
        UsrDetail usrDetail = userService.findUserByMobile(phone);
        if (usrDetail == null) {
            throw new WebRequestException("该手机号码未注册！");
        }
        UserAllAccDto userAllAcc = this.accountService.findUserAllAcc(usrDetail.getUserId());
        csson.setCommissionGold(userAllAcc.getEmCommissionGold().toString());
        csson.setCommissionSilver(userAllAcc.getEmCommissionSliver().toString());
        UserAllAccDto userAcc = this.accountService.findUserAllAcc(usrDetail.getUserId());
        csson.setGoldFreeze(userAcc.getPFrozenGold().toPlainString());
        csson.setSilverFreeze(userAcc.getPFrozenSliver().toPlainString());
        csson.setNickName(usrDetail.getNickName());
        csson.setPhone(phone);
        csson.setUserName(usrDetail.getUserName());
        csson.setGold(userAcc.getPGold().toPlainString());
        csson.setSilver(userAcc.getPSliver().toPlainString());
        return csson;
    }

}