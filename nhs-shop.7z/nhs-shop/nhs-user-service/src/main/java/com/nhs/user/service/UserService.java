/*******************************************************************************
 * @Title: UserService.java
 * @Package com.nhs.user.service
 * @Description: TODO
 * @author chushubin 2016年11月16日 
 * @version V1.0   
 * @Copyright (c) 2016 苏州哪划算网络有限公司 版权所有.
 * 注意：本内容仅限于苏州哪划算网络有限有限公司 内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
package com.nhs.user.service;

import java.util.List;
import java.util.Map;

import com.nhs.shop.entry.legend.user.UsrAddr;
import com.nhs.shop.entry.legend.user.UsrDetail;

/**   
 * @Title: UserService.java
 * @Package com.nhs.user.service
 * @Description: TODO
 * @author chushubin
 * @date 2016年11月16日 下午2:17:22
 * @version V1.0   
 */
public interface UserService {
    
    /**
     * 查找当前用户设置的默认收货地址所在城市. 
     * @param userId
     * @return
     */
    public Integer findCityIdOfDefaultShipAddr(String userId);
   
    /**
     * 获取用户设置的默认收货地址.
     * @Title: findDefaultAddr
     * @Desc: 
     * @author wind.chen 2016年11月21日 上午10:27:30
     *
     * @param userId
     * @return
     * @throws
     */
    public UsrAddr findDefaultShipAddr(String userId);
   
    /**
     * @Title: findUserById
     * @Description: 根据用户ID获取用户详情
     * @param @param userId
     * @param @return   
     * @return UsrDetail 
     * @author chushubin 2016年11月17日 
     * @throws
     */
    public UsrDetail findUserById(String userId);
    
    /**
     * @Title: findUserByMobile
     * @Description: TODO
     * @param @param userId
     * @param @return   
     * @return UsrDetail 
     * @author chushubin 2016年11月28日 
     * @throws
     */
    public UsrDetail findUserByMobile(String phone);
    
    /**
     * @Title: findUsers
     * @Description: 根据userIds查询用户详情列表
     * @param @param userIds
     * @param @return   
     * @return Map<String,UsrDetail> 
     * @author chushubin 2016年11月17日 
     * @throws
     */
    public Map<String, UsrDetail> findUsers(List<String> userIds);

    /**
     * 根据id获取用户收货地址
     * @param userId  user id.
     * @param addrId  地址id
     * @return
     */
    public UsrAddr findShipAddrById(String userId, Integer addrId);
    
    /**
     * @Title: checkPayPassword
     * @Description: 验证Pay Password（支付密码）
     * @param @param userId
     * @param @param payPassword
     * @param @return   
     * @return boolean 
     * @author chushubin 2016年11月22日 
     * @throws
     */
    public boolean checkPayPassword(String userId, String payPassword);
    
    /**
     * 根据注册时间段查用户信息
     * @param startTime
     * @param endTime
     * @return
     */
    public List<UsrDetail> findUsersByRegtime(String startTime, String endTime, List<String> mobileList);
    
    /**
     * 商超 -- 快速注册
     * @param mobile
     * @param password
     * @param regType
     * @return
     */
    public UsrDetail simpleRegister(String mobile,String password,String regType);
    
    /**
     * 根据昵称查询UserId
     * @param nickName
     * @return userId
     */
    public List<String> findUserIdByNickName(String nickName);

}
