package com.nhs.user.activity.dto;

import java.io.Serializable;

public class UserDetailSchoolDto implements Serializable {

	private static final long serialVersionUID = -6184909547688220652L;
	
	
	private String regTimeStr;
	
	private String inviteeUserId;
	
	private String inviterUserId;

	public String getRegTimeStr() {
		return regTimeStr;
	}

	public void setRegTimeStr(String regTimeStr) {
		this.regTimeStr = regTimeStr;
	}

	public String getInviteeUserId() {
		return inviteeUserId;
	}

	public void setInviteeUserId(String inviteeUserId) {
		this.inviteeUserId = inviteeUserId;
	}

	public String getInviterUserId() {
		return inviterUserId;
	}

	public void setInviterUserId(String inviterUserId) {
		this.inviterUserId = inviterUserId;
	}
	
	

}
