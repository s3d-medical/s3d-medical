package com.nhs.core.common;

public class MemberConstant {
	
	 //会员中心api地址前缀
	 public final static String SYS_MEMBER_API_URL = "member.api.url";
	 
	 //获取用户列表接口
	 public final static String SEARCH_USER_LIST = "";
	 
	 //获取用户详情by用户ID
	 public final static String SEARCH_USER_BY_USER_ID = "v1/user/get";
	 
	 //获取用户详情by用户ID
	 public final static String SEARCH_USER_BY_USER_MOBILE = "v1/user/get/by/account";
	 
	 //用户登录并获取用户信息
	 public final static String MEMBER_LOGIN = "v1/passport/login";
	
}
