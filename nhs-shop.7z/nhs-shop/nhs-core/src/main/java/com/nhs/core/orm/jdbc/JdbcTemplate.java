package com.nhs.core.orm.jdbc;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.nhs.core.orm.Page;

/**
 * JDBC原生操作模板类
 * @Title: JdbcUtils.java
 * @Package com.nhs.core.orm.jdbc
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月17日 上午10:29:04
 * @version V1.0
 */
@Repository
public class JdbcTemplate {

    private final Logger logger = LoggerFactory.getLogger(JdbcTemplate.class);

    private static final int DEFAULT_PAGE_SIZE = 10; // 默认每页记录条数

    @Autowired
    private DataSource dataSource;

    /**
     * 获取connection
     * @Title: getConnection
     * @Description: TODO
     * @param @return
     * @param @throws SQLException   
     * @return Connection 
     * @author Administrator 2016年7月17日 
     * @throws
     */
    public Connection getConnection() throws SQLException {
        return dataSource.getConnection();
    }

    /**
     * 关闭connection对象
     * @Title: close
     * @Description: TODO
     * @param @param conn   
     * @return void 
     * @author Administrator 2016年7月17日 
     * @throws
     */
    public void close(Connection conn) {
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 关闭ResultSet对象
     * @Title: close
     * @Description: TODO
     * @param @param rs   
     * @return void 
     * @author Administrator 2016年7月17日 
     * @throws
     */
    public void close(ResultSet rs) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 关闭Statement对象
     * @Title: close
     * @Description: TODO
     * @param @param stmt   
     * @return void 
     * @author Administrator 2016年7月17日 
     * @throws
     */
    public void close(Statement stmt) {
        if (stmt != null) {
            try {
                stmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 按顺序关闭rs,stmt,conn
     * @Title: close
     * @Description: TODO
     * @param @param conn
     * @param @param stmt
     * @param @param rs   
     * @return void 
     * @author Administrator 2016年7月17日 
     * @throws
     */
    public void close(Connection conn, Statement stmt, ResultSet rs) {
        close(rs);
        close(stmt);
        close(conn);
    }

    /**
     * 查询单一记录sql
     * @Title: query
     * @Description: TODO
     * @param @param sql
     * @param @return   
     * @return List<Map<String,Object>> 
     * @author Administrator 2016年7月16日 
     * @throws
     */
    public Map<String, Object> query(String sql) {
        Map<String, Object> map = Maps.newHashMap();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            logger.info("sql:" + sql);
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                int count = rs.getMetaData().getColumnCount();
                for (int i = 1; i <= count; i++) {
                    String key = rs.getMetaData().getColumnLabel(i);
                    Object value = rs.getObject(i);
                    map.put(key, value);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            close(conn, pstmt, rs);
        }
        return map;
    }

    /**
     * 查询单一记录sql
     * @Title: query
     * @Description: TODO
     * @param @param sql
     * @param @return   
     * @return List<Map<String,Object>> 
     * @author Administrator 2016年7月16日 
     * @throws
     */
    public Map<String, Object> query(String sql, List<Object> params) {
        Map<String, Object> map = Maps.newHashMap();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            logger.info("sql:" + sql);
            pstmt = conn.prepareStatement(sql);
            setParameter(pstmt, params);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                int count = rs.getMetaData().getColumnCount();
                for (int i = 1; i <= count; i++) {
                    String key = rs.getMetaData().getColumnLabel(i);
                    Object value = rs.getObject(i);
                    map.put(key, value);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            close(conn, pstmt, rs);
        }
        return map;
    }

    /**
     * 查询列表sql
     * @Title: query
     * @Description: TODO
     * @param @param sql
     * @param @return   
     * @return List<Map<String,Object>> 
     * @author Administrator 2016年7月16日 
     * @throws
     */
    public List<Map<String, Object>> queryList(String sql) {
        List<Map<String, Object>> list = Lists.newArrayList();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            logger.info("sql:" + sql);
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                Map<String, Object> map = Maps.newHashMap();
                int count = rs.getMetaData().getColumnCount();
                for (int i = 1; i <= count; i++) {
                    String key = rs.getMetaData().getColumnLabel(i);
                    Object value = rs.getObject(i);
                    map.put(key, value);
                }
                list.add(map);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            close(conn, pstmt, rs);
        }
        return list;
    }

    /**
     * 查询列表
     * @Title: queryList
     * @Description: TODO
     * @param @param sql
     * @param @param params
     * @param @return   
     * @return List<Map<String,Object>> 
     * @author Administrator 2016年7月17日 
     * @throws
     */
    public List<Map<String, Object>> queryList(String sql, List<Object> params) {
        List<Map<String, Object>> list = Lists.newArrayList();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            logger.info("sql:" + sql);
            pstmt = conn.prepareStatement(sql);
            setParameter(pstmt, params);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                Map<String, Object> map = Maps.newHashMap();
                int count = rs.getMetaData().getColumnCount();
                for (int i = 1; i <= count; i++) {
                    String key = rs.getMetaData().getColumnLabel(i);
                    Object value = rs.getObject(i);
                    map.put(key, value);
                }
                list.add(map);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            close(conn, pstmt, rs);
        }
        return list;
    }

    /**
    * 分页查询
    * @Title: queryAsPage
    * @Description: TODO
    * @param @param sql
    * @param @param page
    * @param @return   
    * @return Page<Map<String,Object>> 
    * @author Administrator 2016年7月17日 
    * @throws
    */
    public Page<Map<String, Object>> queryAsPage(String sql, Page<Map<String, Object>> page) {
        int pageNo = page.getPageNo();
        int pageSize = page.getPageSize();
        List<Map<String, Object>> list = Lists.newArrayList();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = this.getConnection();
            if (pageNo <= 0) {
                pageSize = 1;
            }
            if (pageSize <= 0) {
                pageSize = DEFAULT_PAGE_SIZE;
            }
            int totalCount = count(sql);
            int begin = (pageNo - 1) * pageSize;
            int totalPage = (int) Math.ceil(totalCount * 1.0 / pageSize);
            if (pageNo > totalPage) {
                pageNo = totalPage;
            }
            page.setTotalCount(totalCount);
            page.setTotalPage(totalPage);
            page.setPageNo(pageNo);
            page.setPageSize(pageSize);
            String limit = " limit " + begin + "," + pageSize;

            logger.info("page sql:" + sql + limit);
            pstmt = conn.prepareStatement(sql + limit);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                Map<String, Object> map = Maps.newHashMap();
                int count = rs.getMetaData().getColumnCount();
                for (int i = 1; i <= count; i++) {
                    String key = rs.getMetaData().getColumnLabel(i);
                    Object value = rs.getObject(i);
                    map.put(key, value);
                }
                list.add(map);
            }
            page.setResult(list);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            close(conn, pstmt, rs);
        }
        return page;
    }

    /**
     * 查询count条数
     * @Title: count
     * @Description: TODO
     * @param @param conn
     * @param @param sql
     * @param @return   
     * @return int 
     * @author Administrator 2016年7月17日 
     * @throws
     */
    public int count(String sql) {
        int count = 0;
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            String countSql = "select count(*) from (" + sql + ") t";
            logger.info("count sql:" + sql);
            pstmt = conn.prepareStatement(countSql);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                count = rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            close(conn, pstmt, rs);
        }
        return count;
    }

    /**
     * 设置查询参数
     * @Title: setParameter
     * @Description: TODO
     * @param @param pstmt
     * @param @param params
     * @param @throws SQLException   
     * @return void 
     * @author Administrator 2016年7月17日 
     * @throws
     */
    private void setParameter(PreparedStatement pstmt, List<Object> params) throws SQLException {
        if (CollectionUtils.isNotEmpty(params)) {
            for (int i = 0; i < params.size(); i++) {
                pstmt.setObject(i + 1, params.get(i));
            }
        }
    }

    /**
     * 获取主键序列号
     * @Title: getNextVal
     * @Description: TODO
     * @param @param sequenceName
     * @param @return   
     * @return int 
     * @author Administrator 2016年7月18日 
     * @throws
     */
    public int getNextVal(String sequenceName) {
        int nextVal = 0;
        String procedure = "select nextVal (?)";
        Connection conn = null;
        CallableStatement cstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            cstmt = conn.prepareCall(procedure);
            cstmt.setString(1, sequenceName);
            cstmt.execute();
            rs = cstmt.getResultSet();
            if (rs.next()) {
                nextVal = rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            close(conn, cstmt, rs);
        }
        return nextVal;
    }

    /**
     * 执行sql
     * @Title: sql
     * @Description: TODO
     * @param @param sequenceName
     * @param @return
     * @author Cary 2016年8月24日
     * @throws
     */
    public void execute(String sql) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            logger.info("execute sql:" + sql);
            pstmt = conn.prepareStatement(sql);
            pstmt.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            close(conn, pstmt, rs);
        }
    }
    
    
    /**
     * 分页查询
     * @Title: queryAsPage
     * @Description: TODO
     * @param @param sql
     * @param @param page
     * @param @return   
     * @return Page<Map<String,Object>> 
     * @author Administrator 2016年7月17日 
     * @throws
     */
     public Page<Map<String, Object>> queryAsPage(String sql, Page<Map<String, Object>> page,List<Object> params) {
         int pageNo = page.getPageNo();
         int pageSize = page.getPageSize();
         List<Map<String, Object>> list = Lists.newArrayList();
         Connection conn = null;
         PreparedStatement pstmt = null;
         ResultSet rs = null;
         try {
             conn = this.getConnection();
             if (pageNo <= 0) {
                 pageSize = 1;
             }
             if (pageSize <= 0) {
                 pageSize = DEFAULT_PAGE_SIZE;
             }
             int totalCount = count(sql,params);
             int begin = (pageNo - 1) * pageSize;
             int totalPage = (int) Math.ceil(totalCount * 1.0 / pageSize);
             if (pageNo > totalPage) {
                 pageNo = totalPage;
             }
             page.setTotalCount(totalCount);
             page.setTotalPage(totalPage);
             page.setPageNo(pageNo);
             page.setPageSize(pageSize);
             String limit = " limit " + begin + "," + pageSize;

             logger.info("page sql:" + sql + limit);
             pstmt = conn.prepareStatement(sql + limit);
             setParameter(pstmt, params);
             rs = pstmt.executeQuery();

             while (rs.next()) {
                 Map<String, Object> map = Maps.newHashMap();
                 int count = rs.getMetaData().getColumnCount();
                 for (int i = 1; i <= count; i++) {
                     String key = rs.getMetaData().getColumnLabel(i);
                     Object value = rs.getObject(i);
                     map.put(key, value);
                 }
                 list.add(map);
             }
             page.setResult(list);
         } catch (SQLException e) {
             e.printStackTrace();
         } finally {
             close(conn, pstmt, rs);
         }
         return page;
     }

     
     
     public int count(String sql, List<Object> params) {
         int count = 0;
         Connection conn = null;
         PreparedStatement pstmt = null;
         ResultSet rs = null;
         try {
             conn = getConnection();
             String countSql = "select count(*) from (" + sql + ") t";
             logger.info("count sql:" + sql);
             pstmt = conn.prepareStatement(countSql);
             setParameter(pstmt, params);
             rs = pstmt.executeQuery();
             if (rs.next()) {
                 count = rs.getInt(1);
             }
         } catch (SQLException e) {
             e.printStackTrace();
         } finally {
             close(conn, pstmt, rs);
         }
         return count;
     }
	 
	 
	  /**
     * 执行sql
     * @Title: sql
     * @Description: TODO
     * @param @param sequenceName
     * @param @return
     * @author Cary 2016年8月24日
     * @throws
     */
	  public int executeUpdate(String sql) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = getConnection();
            logger.info("execute sql:" + sql);
            pstmt = conn.prepareStatement(sql);
            return pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            close(conn, pstmt, rs);
        }
        
        return 0;
    }
}
