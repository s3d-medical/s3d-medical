/**
 * Description:
 * ApplicationController.java Create on 2013-3-19 下午4:30:55 
 * @version 1.0
 * Copyright (c) 2013 BMS,Inc. All Rights Reserved.
 */
package com.nhs.core.web;

import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.nhs.core.context.SysPropsFactory;

/**
 * @ClassName: ApplicationController
 * @Description: TODO
 * @author 
 * @date 2013-3-19 下午4:30:55
 * 
 */
public abstract class ApplicationController {

    /**
     * log4j 记录器
     */
    protected static final Logger log = LoggerFactory.getLogger(ApplicationController.class);

    @InitBinder
    protected void initBinder(WebDataBinder binder) {
    	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		dateFormat.setLenient(false);

		SimpleDateFormat datetimeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		datetimeFormat.setLenient(false);

//		binder.registerCustomEditor(java.util.Date.class, new CustomDateEditor(
//				dateFormat, true));
		binder.registerCustomEditor(java.util.Date.class, new CustomTimestampEditor(datetimeFormat, true));
		binder.registerCustomEditor(java.sql.Timestamp.class, new CustomTimestampEditor(datetimeFormat, true));
    }

    /**
     * 抽象方法,用于子类初始化页面
     * 
     * @return
     */
    public abstract String execute(HttpServletRequest request, ModelMap model) throws Exception;

    @RequestMapping(method = RequestMethod.GET)
    public String initPage(HttpServletRequest request, HttpServletResponse response, ModelMap model) throws Exception {
        response.addHeader("Cache-Control", "no-cache");
        response.addHeader("Pragma", "no-cache");
        response.addHeader("Expires", "-1");
        String contextPath = request.getContextPath();
        model.addAttribute("contextPath", contextPath);
        Iterator<Entry<Object, Object>> it = SysPropsFactory.getSysProps().entrySet().iterator();  
        while (it.hasNext()) {  
            Entry<Object, Object> entry = it.next();  
            model.addAttribute((String)entry.getKey(), entry.getValue());
        }
        return execute(request, model);
    }
}
