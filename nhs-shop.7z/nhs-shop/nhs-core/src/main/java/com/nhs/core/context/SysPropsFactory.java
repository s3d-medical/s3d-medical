/**
 * Description:
 * SysPropsFactory.java Create on 2013-3-19 下午4:41:09 
 * @version 1.0
 * Copyright (c) 2013 BMS,Inc. All Rights Reserved.
 */
package com.nhs.core.context;

import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.Resource;

/**
 * @ClassName: SysPropsFactory
 * @Description: TODO
 * @author
 * @date 2013-3-19 下午4:41:09
 * 
 */
public class SysPropsFactory {

	private static Logger logger = LoggerFactory.getLogger(SysPropsFactory.class);

	private static Properties sysProps = new Properties();

	public static Properties getSysProps() {
		return sysProps;
	}

	/**
	 * 获取属性配置
	 * 
	 * @param key
	 * @return
	 */
	public static String getProperty(String key) {
		return sysProps.getProperty(key);
	}

	public void setResource(Resource resource) {
		try {
			sysProps.load(resource.getInputStream());
			// CoreConstant.file_domain =
			// sysProps.get("file_domain").toString();
		} catch (Exception e) {
			logger.error("初化sys.properties出错", e);
		}
	}

}
