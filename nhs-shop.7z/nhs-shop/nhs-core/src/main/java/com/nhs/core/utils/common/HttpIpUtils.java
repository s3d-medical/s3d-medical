package com.nhs.core.utils.common;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;

public class HttpIpUtils {
    /**
     * 获取客户端IP
     * @Title: getClientIp
     * @Description: TODO
     * @param @param request
     * @param @return   
     * @return String 
     * @author huxianjun 2016年8月24日 
     * @throws
     */
    public static String getClientIp(HttpServletRequest request) {
        String ip = "127.0.0.1";
        try {
            ip = request.getHeader("x-forwarded-for");
            if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                ip = request.getHeader("Proxy-Client-IP");
            }
            if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                ip = request.getHeader("WL-Proxy-Client-IP");
            }
            if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                ip = request.getRemoteAddr();
            }
            if (StringUtils.isNotBlank(ip)) {
                ip = ip.split(",")[0];
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ip;
    }
}
