/**
 * 2014-10-7
 * jkc-core
 */
package com.nhs.core.utils.common;

/**
 * @author hxj
 *
 */
public class CoreConstant {

    public static String me_system_short = "ME";
    public static String cur_system_short = "";
    public static String cur_system_url = "";
    public static String me_system_url = "";
    public static String file_domain = "";
    public static String office_resource_domain = "";
    public static String system_project_name = "";

    public static int FILE_CACHE = 1024; // 缓存 1024 byte
}
