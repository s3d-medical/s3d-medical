package com.nhs.core.web;


public class WebRequestException extends RuntimeException {

	/**
	 * @Fields serialVersionUID
	 */
	private static final long serialVersionUID = 8025434620321706646L;
	private String exceptionDetails;
	private WebExceptionCode exceptionCode;

	public WebRequestException() {
	}

	/**
	 * @param message
	 */
	public WebRequestException(int message) {
		super(String.valueOf(message));
	}

	/**
	 * @param message
	 */
	public WebRequestException(String message) {
		super(message);
	}
	
	/**
	 * @param WebExceptionCode
	 */
	public WebRequestException(WebExceptionCode exceptionCode) {
		this.setExceptionCode(exceptionCode);
	}
	
	public WebRequestException(WebExceptionCode exceptionCode, String details) {
		this.setExceptionCode(exceptionCode);
		this.exceptionDetails = details;
	}

	/**
	 * @param cause
	 */
	public WebRequestException(Throwable cause) {
		super(cause);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public WebRequestException(String message, Throwable cause) {
		super(message, cause);
	}

	public String getExceptionDetails() {
		return exceptionDetails;
	}

	public void setExceptionDetails(String exceptionDetails) {
		this.exceptionDetails = exceptionDetails;
	}

	public WebExceptionCode getExceptionCode() {
		return exceptionCode;
	}

	public void setExceptionCode(WebExceptionCode exceptionCode) {
		this.exceptionCode = exceptionCode;
	}


}
