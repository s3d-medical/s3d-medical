package com.nhs.core.context;
//import java.text.DateFormat;
//import java.text.SimpleDateFormat;
//
//import org.apache.commons.lang3.StringUtils;
//import org.codehaus.jackson.map.DeserializationConfig;
//import org.codehaus.jackson.map.ObjectMapper;
//import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;
//
///**
// * 
// * @Description: 增强 Jackson ObjectMapper类,使得自动支持日期的转型, 主要是配合Spring @ResponseBody注解使用
// * @date Mar 24, 2011
// * @author hfren
// * @since JDK 1.6.0_12
// */
//public class EnhanceObjectMapper extends ObjectMapper {
//
//	private String datePattern = "yyyy-MM-dd HH:mm:ss";
//
//	public EnhanceObjectMapper() {
//		super();
//		initDateFormat(datePattern);
//		Inclusion inclusion = Inclusion.NON_NULL;
//		// 设置输出时包含属性的风格
//		this.setSerializationInclusion(inclusion);
//		// 设置输入时忽略在JSON字符串中存在但Java对象实际没有的属性
//		this.configure(DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
//		// 禁止使用int代表Enum的order()來反序列化Enum,非常危險
//		this.configure(DeserializationConfig.Feature.FAIL_ON_NUMBERS_FOR_ENUMS, true);
//	}
//
//	public void initDateFormat(String pattern) {
//		if (StringUtils.isNotBlank(pattern)) {
//			DateFormat df = new SimpleDateFormat(pattern);
//			this.setDateFormat(df);
//			this.writer(df);
//		}
//	}
//
//	public String getDatePattern() {
//		return datePattern;
//	}
//
//	public void setDatePattern(String datePattern) {
//		this.datePattern = datePattern;
//	}
//
//}
