/*******************************************************************************
 * @Title: P2BigDecimalSerializer.java
 * @Package com.nhs.core.json
 * @Description: TODO
 * @author Administrator 2016年11月9日 
 * @version V1.0   
 * @Copyright (c) 2016 苏州哪划算网络有限公司 版权所有.
 * 注意：本内容仅限于苏州哪划算网络有限有限公司 内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
package com.nhs.core.json;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.DecimalFormat;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

/**   
 * @Title: P2BigDecimalSerializer.java
 * @Package com.nhs.core.json
 * @Description: TODO
 * @author chushubin
 * @date 2016年11月9日 下午1:05:26
 * @version V1.0   
 */
public class P2BigDecimalSerializer extends JsonSerializer<BigDecimal> {

    /**
     * <p>Description:TODO </p>
     * @author Administrator 2016年11月9日 
     * @param value
     * @param gen
     * @param serializers
     * @throws IOException
     * @throws JsonProcessingException
     * @see com.fasterxml.jackson.databind.JsonSerializer#serialize(java.lang.Object, com.fasterxml.jackson.core.JsonGenerator, com.fasterxml.jackson.databind.SerializerProvider)
     */
    @Override
    public void serialize(BigDecimal value, JsonGenerator gen, SerializerProvider serializers)
            throws IOException, JsonProcessingException {
        DecimalFormat format = new DecimalFormat("0.00");
        gen.writeNumber(format.format(value));
    }
}
