package com.nhs.core.web.dto;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonView;
import com.nhs.core.web.WebExceptionCode;

public class ResponseDto implements Serializable {

    private static final long serialVersionUID = -1671607286610174732L;
    private Integer errorCode = WebExceptionCode.NORMAL.errorCode;
    private String errorMsg = WebExceptionCode.NORMAL.errorMsg;
    private final Map<String, Object> result = new HashMap<>();
    private Timestamp systemTime;

    public ResponseDto() {
        this.systemTime = new Timestamp(System.currentTimeMillis());
    }

    public ResponseDto(Integer errorCode, String errorMsg) {
        this.systemTime = new Timestamp(System.currentTimeMillis());
        this.errorCode = errorCode;
        this.errorMsg = errorMsg;
    }

    @JsonProperty("errCode")
    @JsonView(BaseView.class)
    public Integer getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(Integer errorCode) {
        this.errorCode = errorCode;
    }

    public Map<String, Object> getResult() {
        return result;
    }

    @JsonProperty("errMsg")
    @JsonView(BaseView.class)
    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    public Timestamp getSystemTime() {
        return systemTime;
    }

    public void setSystemTime(Timestamp systemTime) {
        this.systemTime = systemTime;
    }

}
