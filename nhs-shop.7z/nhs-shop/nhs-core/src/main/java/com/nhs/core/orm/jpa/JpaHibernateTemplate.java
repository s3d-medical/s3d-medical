package com.nhs.core.orm.jpa;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

/**
 * @author 
 * 
 * 基于hibernate实现的jpa模板
 *
 */
@Repository
public final class JpaHibernateTemplate implements JpaTemplate {
    /** jpa持久化上下文 */
    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public <T> void delete(Class<T> clazz, int entityId) {
        T entity = this.entityManager.find(clazz, entityId);
        this.entityManager.remove(entity);
    }

    @Override
    public <T> T get(Class<T> clazz, Serializable entityId) {
        return this.entityManager.find(clazz, entityId);
    }

    @Override
    public <T> void merge(T entity) {
        this.entityManager.merge(entity);
    }

    @Override
    public <T> void save(T entity) {
        this.entityManager.persist(entity);
    }

    @Override
    public <T> void batchSave(List<T> entities) {
        for (int i = 0, n = entities.size(); i < n; i++) {
            this.entityManager.persist(entities.get(i));
            if (i % 20 == 0) {
                this.entityManager.flush();
            }
        }
    }

    @Override
    public void doUpdateQuery(String sql) {
        Query sqlQuery = this.entityManager.createNativeQuery(sql);
        sqlQuery.executeUpdate();
    }

    @Override
    public void doUpdateQuery(String sql, List<Object> args) {
        Query query = this.entityManager.createNativeQuery(sql);
        for (int i = 0, n = args.size(); i < n; i++) {
            query.setParameter(i + 1, args.get(i));
        }
        query.executeUpdate();
    }

    @Override
    public Object getSingleReslut(String sql) {
        Query query = this.entityManager.createNativeQuery(sql);
        return query.getSingleResult();
    }

    @Override
    public Object getSingleResult(String sql, List<Object> args) {
        Query query = this.entityManager.createNativeQuery(sql);
        for (int i = 0, n = args.size(); i < n; i++) {
            query.setParameter(i + 1, args.get(i));
        }
        return query.getSingleResult();
    }

    @Override
    public <T> T getSingleResult(String sql, Class<T> clazz) {
        Query query = this.entityManager.createNativeQuery(sql, clazz);
        return (T) query.getSingleResult();
    }

    @Override
    public <T> T getSingleResult(String sql, Class<T> clazz, List<Object> args) {
        Query query = this.entityManager.createNativeQuery(sql, clazz);
        for (int i = 0, n = args.size(); i < n; i++) {
            query.setParameter(i + 1, args.get(i));
        }
        return (T) query.getSingleResult();
    }

    @Override
    public List<?> getResultList(String sql) {
        Query query = this.entityManager.createNativeQuery(sql);
        List<?> list = query.getResultList();
        return list;
    }

    @Override
    public List<?> getResultList(String sql, List<Object> args) {
        Query query = this.entityManager.createNativeQuery(sql);
        for (int i = 0, n = args.size(); i < n; i++) {
            query.setParameter(i + 1, args.get(i));
        }
        return query.getResultList();
    }

    @Override
    public <T> List<T> getResultList(String sql, Class<T> clazz) {
        // TODO Auto-generated method stub
        Query query = this.entityManager.createNativeQuery(sql, clazz);
        return query.getResultList();
    }

    @Override
    public <T> List<T> getResultList(String sql, List<Object> args, Class<T> clazz) {
        Query query = this.entityManager.createNativeQuery(sql, clazz);
        for (int i = 0, n = args.size(); i < n; i++) {
            query.setParameter(i + 1, args.get(i));
        }
        return query.getResultList();
    }

    @Override
    public List<?> getPageList(String sql, int beginIndex, int pageSize) {
        Query query = this.entityManager.createNativeQuery(sql);
        query.setFirstResult(beginIndex);
        query.setMaxResults(pageSize);
        return query.getResultList();
    }

    @Override
    public <T> List<T> getPageList(String sql, int beginIndex, int pageSize, Class<T> clazz) {
        Query query = this.entityManager.createNativeQuery(sql, clazz);
        query.setFirstResult(beginIndex);
        query.setMaxResults(pageSize);
        return query.getResultList();
    }

    @Override
    public List<?> getPageList(String sql, int beginIndex, int pageSize, List<Object> args) {
        Query query = this.entityManager.createNativeQuery(sql);
        query.setFirstResult(beginIndex);
        query.setMaxResults(pageSize);
        for (int i = 0, n = args.size(); i < n; i++) {
            query.setParameter(i + 1, args.get(i));
        }
        return query.getResultList();
    }

    @Override
    public <T> List<T> getPageList(String sql, int beginIndex, int pageSize, List<Object> args,
                                   Class<T> clazz) {
        Query query = this.entityManager.createNativeQuery(sql, clazz);
        query.setFirstResult(beginIndex);
        query.setMaxResults(pageSize);
        for (int i = 0, n = args.size(); i < n; i++) {
            query.setParameter(i + 1, args.get(i));
        }
        return query.getResultList();
    }

    @Override
    public int getTotalCount(String sql, List<Object> args) {
        Query query = this.entityManager.createNativeQuery(sql);
        for (int i = 0, n = args.size(); i < n; i++) {
            query.setParameter(i + 1, args.get(i));
        }
        BigInteger count = (BigInteger) query.getSingleResult();
        return count.intValue();
    }

    @Override
    public int getTotalCount(String sql) {
        Query query = this.entityManager.createNativeQuery(sql);
        BigInteger count = (BigInteger) query.getSingleResult();
        return count.intValue();
    }

    @Override
    public <T> T getSingleResultJpql(String jpql, List<Object> args) {
        Query query = this.entityManager.createQuery(jpql);
        for (int i = 0, n = args.size(); i < n; i++) {
            query.setParameter(i + 1, args.get(i));
        }
        Object obj = null;
        try {
            obj = query.getSingleResult();
        } catch (NoResultException nrEx) {
            return null;
        }
        return (T) obj;
    }

    @Override
    public <T> T getSingleResultJpql(String jpql) {
        Query query = this.entityManager.createQuery(jpql);
        return (T) query.getSingleResult();
    }

    @Override
    public <T> List<T> getResultListJpql(String jpql) {
        Query query = this.entityManager.createQuery(jpql);
        return query.getResultList();
    }

    @Override
    public <T> List<T> getResultListJpql(String jpql, List<Object> args) {
        Query query = this.entityManager.createQuery(jpql);
        for (int i = 0, n = args.size(); i < n; i++) {
            query.setParameter(i + 1, args.get(i));
        }
        return query.getResultList();
    }

    @Override
    public <T> List<T> getPageListJpql(String jpql, int beginIndex, int pageSize, List<Object> args) {
        Query query = this.entityManager.createQuery(jpql);
        for (int i = 0, n = args.size(); i < n; i++) {
            query.setParameter(i + 1, args.get(i));
        }
        query.setFirstResult(beginIndex);
        query.setMaxResults(pageSize);
        return query.getResultList();
    }

    @Override
    public <T> List<T> getPageListJpql(String jpql, int beginIndex, int pageSize) {
        Query query = this.entityManager.createQuery(jpql);
        query.setFirstResult(beginIndex);
        query.setMaxResults(pageSize);
        return query.getResultList();
    }

    @Override
    public void doUpdateJpql(String jpql, List<Object> args) {
        Query query = this.entityManager.createQuery(jpql);
        for (int i = 0, n = args.size(); i < n; i++) {
            query.setParameter(i + 1, args.get(i));
        }
        query.executeUpdate();
    }

    @Override
    public void doUpdateJpql(String jpql) {
        Query query = this.entityManager.createQuery(jpql);
        query.executeUpdate();
    }

}
