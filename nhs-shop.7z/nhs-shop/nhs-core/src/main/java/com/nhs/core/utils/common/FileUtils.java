package com.nhs.core.utils.common;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

/**
 * 
 * @Title: ReadFileUtil.java
 * @Package com.nhs.nscp.utils.common
 * @Description: 读取文件内容
 * @author sungs
 * @date 2016年12月16日 上午11:37:21
 * @version V1.0
 */
public class FileUtils {

    private static Logger logger = LoggerFactory.getLogger(FileUtils.class);

    public static String readFile(String path) {
        InputStream inputStream = null;
        InputStreamReader inputStreamReader = null;
        BufferedReader bufferedReader = null;
        String str = "";
        try {
            File file = new File(path);
            inputStream = new FileInputStream(file);
            inputStreamReader = new InputStreamReader(inputStream);
            bufferedReader = new BufferedReader(inputStreamReader);
            String line = "";
            while ((line = bufferedReader.readLine()) != null && StringUtils.isEmpty(line)) {
                str = str + line + "\n";
            }
            return str;
        } catch (Exception e) {
            logger.error("读取文件异常:" + e.getMessage());
            return str;
        } finally {
            try {
                if (bufferedReader != null)
                    bufferedReader.close();
                if (inputStreamReader != null)
                    inputStreamReader.close();
                if (inputStream != null)
                    inputStream.close();
            } catch (Exception e2) {
                logger.error("关闭链接异常：" + e2.getMessage());
            }
        }
    }

}
