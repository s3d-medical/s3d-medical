package com.nhs.core.web.dto;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class RequestDto implements Serializable {

    private static final long serialVersionUID = 3467214898131190924L;

    private String appVersion;
    private String phoneModel;
    private String platformType;
    private String accessToken;

    private final Map<String, Object> param = new HashMap<>();

    public String getAppVersion() {
        return appVersion;
    }

    public void setAppVersion(String appVersion) {
        this.appVersion = appVersion;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getPlatformType() {
        return platformType;
    }

    public void setPlatformType(String platformType) {
        this.platformType = platformType;
    }

    public Map<String, Object> getParam() {
        return param;
    }

    public String getPhoneModel() {
        return phoneModel;
    }

    public void setPhoneModel(String phoneModel) {
        this.phoneModel = phoneModel;
    }

}
