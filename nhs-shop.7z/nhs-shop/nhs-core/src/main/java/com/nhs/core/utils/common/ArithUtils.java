
package com.nhs.core.utils.common;

import java.math.BigDecimal;

/**
 * 数学运算工具类
 * @Title: ArithUtils.java
 * @Package com.nhs.core.utils.common
 * @Description: TODO
 * @author Administrator
 * @date 2016年7月17日 下午4:07:20
 * @version V1.0
 */
public class ArithUtils {
    // 默认除法运算精度
    /** The Constant DEF_DIV_SCALE. */
    private static final int DEF_DIV_SCALE = 10;

    // 这个类不能实例化
    /**
     * Instantiates a new arith.
     */
    private ArithUtils() {
    }

    /**
     * 提供精确的加法运算。.
     * 
     * @param v1
     *            被加数
     * @param v2
     *            加数
     * @return 两个参数的和
     */
    public static double add(double v1, double v2) {
        BigDecimal b1 = new BigDecimal(Double.toString(v1));// 必须转换成String
        BigDecimal b2 = new BigDecimal(Double.toString(v2));
        return b1.add(b2).doubleValue();
    }

    /**
     * 提供精确的减法运算。.
     * 
     * @param v1
     *            被减数
     * @param v2
     *            减数
     * @return 两个参数的差
     */
    public static double sub(double v1, double v2) {
        BigDecimal b1 = new BigDecimal(Double.toString(v1));
        BigDecimal b2 = new BigDecimal(Double.toString(v2));
        return b1.subtract(b2).doubleValue();
    }

    /**
     * 提供精确的乘法运算。.
     * 
     * @param v1
     *            被乘数
     * @param v2
     *            乘数
     * @return 两个参数的积
     */
    public static double mul(double v1, double v2) {
        BigDecimal b1 = new BigDecimal(Double.toString(v1));
        BigDecimal b2 = new BigDecimal(Double.toString(v2));
        return b1.multiply(b2).doubleValue();
    }

    /**
     * 提供精确的乘法运算。.
     * 
     * @param v1
     *            被乘数
     * @param v2
     *            乘数
     * @return 两个参数的积
     */
    public static double mul(double v1, double v2, int newScale) {
        BigDecimal b1 = new BigDecimal(Double.toString(v1));
        BigDecimal b2 = new BigDecimal(Double.toString(v2));
        BigDecimal b3 = b1.multiply(b2);
        double f1 = b3.setScale(newScale, BigDecimal.ROUND_HALF_UP).doubleValue();
        return f1;
    }

    /**
     * 提供（相对）精确的除法运算，当发生除不尽的情况时，精确到 小数点以后10位，以后的数字四舍五入。.
     * 
     * @param v1
     *            被除数
     * @param v2
     *            除数
     * @return 两个参数的商
     */
    public static double div(double v1, double v2) {
        return div(v1, v2, DEF_DIV_SCALE);
    }

    /**
     * 提供（相对）精确的除法运算。当发生除不尽的情况时，由scale参数指 定精度，以后的数字四舍五入。.
     * 
     * @param v1
     *            被除数
     * @param v2
     *            除数
     * @param scale
     *            表示表示需要精确到小数点以后几位。
     * @return 两个参数的商
     */
    public static double div(double v1, double v2, int scale) {
        if (scale < 0) {
            throw new IllegalArgumentException("The scale must be a positive integer or zero");
        }
        BigDecimal b1 = new BigDecimal(Double.toString(v1));
        BigDecimal b2 = new BigDecimal(Double.toString(v2));
        return b1.divide(b2, scale, BigDecimal.ROUND_HALF_UP).doubleValue();
    }

    /**
     * 提供精确的小数位四舍五入处理。.
     * 
     * @param v
     *            需要四舍五入的数字
     * @param scale
     *            小数点后保留几位
     * @return 四舍五入后的结果
     */
    public static double round(double v, int scale) {
        if (scale < 0) {
            throw new IllegalArgumentException("The scale must be a positive integer or zero");
        }
        BigDecimal b = new BigDecimal(Double.toString(v));
        BigDecimal one = new BigDecimal("1");
        return b.divide(one, scale, BigDecimal.ROUND_HALF_UP).doubleValue();
    }

    public static BigDecimal add2(BigDecimal v1, BigDecimal v2, int newScale,int round) {
        return v1.add(v2).setScale(newScale, round);
    }

    public static BigDecimal sub2(BigDecimal v1, BigDecimal v2, int newScale,int round) {
        return v1.subtract(v2).setScale(newScale, round);
    }

    public static BigDecimal mul2(BigDecimal v1, BigDecimal v2, int newScale,int round) {
        return v1.multiply(v2).setScale(newScale, round);
    }

    public static BigDecimal div2(BigDecimal v1, BigDecimal v2, int scale,int round) {
        if (scale < 0) {
            throw new IllegalArgumentException("The scale must be a positive integer or zero");
        }
        return v1.divide(v2, scale, round);
    }

    // 最后我们利用BigDecimal提供的精确计算

    /**
     * The main method.
     * 
     * @param args
     *            the arguments
     */
    public static void main(String[] args) {
        // 直接使用浮点数进行计算，得到的结果是有问题的
        System.out.println(0.01 + 0.05);
        // 使用了BigDecimal类进行计算后，可以做到精确计算
        System.out.println(ArithUtils.add(0.05, 0.01));

        System.out.println(1.0 - 0.42);
        System.out.println(ArithUtils.sub(1.0, 0.42));
        System.out.println(4.015 * 100);
        System.out.println(ArithUtils.mul(4.015, 100));
        System.out.println(123.3 / 100);
        System.out.println(ArithUtils.div(123.3, 100, 2));

        /*
         * 0.060000000000000005 0.06 0.5800000000000001 0.58 401.49999999999994 401.5 1.2329999999999999 1.233
         */

    }
}