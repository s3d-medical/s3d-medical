package com.nhs.core.orm.jpa;

import java.io.Serializable;
import java.util.List;

/**
 * @author
 * 
 * jpa持久化模板
 *
 */
public interface JpaTemplate {
	/**
	 * @param <T>
	 * @param entity
	 * 保存新建状态的实体
	 */
	public <T>void save(T entity);
	
	/**
	 * @param <T>
	 * @param entitys
	 * 批量保存新建状态实体
	 */
	public <T>void batchSave(List<T> entitys);
	
	/***
	 * @param <T>
	 * @param clazz
	 * @param entityId
	 * 删除脱管状态的实体
	 */
	public <T>void delete(Class<T> clazz, int entityId);
	
	/***
	 * @param <T>
	 * @param entity
	 * 合并实体
	 * 新建状态的实体，直接持久化
	 * 脱管状态的实体，更新状态
	 */
	public <T>void merge(T entity);
	
	/***
	 * @param <T>
	 * @param entityId
	 * @return
	 * 按照实体主键进行查找
	 */
	public <T>T get(Class<T> clazz,  Serializable entityId);
	
	/***
	 * @param sql
	 * 执行DDL,DML等sql语句
	 */
	public void doUpdateQuery(String sql);
	
	/**
	 * @param sql
	 * @param args
	 * 执行DDL,DML等sql语句
	 */
	public void doUpdateQuery(String sql, List<Object> args);
	
	/**
	 * @param sql
	 * @return
	 * 查询单行数据
	 */
	public Object getSingleReslut(String sql);
	
	/**
	 * @param sql
	 * @param args
	 * @return
	 * 查询单行数据
	 */
	public Object getSingleResult(String sql, List<Object> args);
	
	/**
	 * @param <T>
	 * @param sql
	 * @param clazz
	 * @return
	 * 查询单行数据
	 */
	public <T>T getSingleResult(String sql, Class<T> clazz);
	
	/**
	 * @param <T>
	 * @param sql
	 * @param clazz
	 * @param args
	 * @return
	 * 查询单行数据
	 */
	public <T>T getSingleResult(String sql, Class<T> clazz, List<Object> args);
	
	/**
	 * @param sql
	 * @return
	 * 查询列表
	 */
	public List<?> getResultList(String sql);
	
	/**
	 * @param <T>
	 * @param sql
	 * @param clazz
	 * @return
	 * 查询列表
	 */
	public <T>List<T> getResultList(String sql, Class<T> clazz);
	
	/**
	 * @param sql
	 * @param args
	 * @return
	 * 查询列表
	 */
	public List<?> getResultList(String sql, List<Object> args);
	
	/**
	 * @param <T>
	 * @param sql
	 * @param args
	 * @param clazz
	 * @return
	 * 查询列表
	 */
	public <T>List<T> getResultList(String sql, List<Object> args, Class<T> clazz);
	
	/**
	 * @param sql
	 * @param beginIndex
	 * @param pageSize
	 * @return
	 * 查询分页列表
	 */
	public List<?> getPageList(String sql, int beginIndex, int pageSize);
	
	/**
	 * @param <T>
	 * @param sql
	 * @param beginIndex
	 * @param pageSize
	 * @param clazz
	 * @return
	 * 查询分页列表
	 */
	public <T>List<T> getPageList(String sql, int beginIndex, int pageSize, Class<T> clazz);
	
	/**
	 * @param sql
	 * @param beginIndex
	 * @param pageSize
	 * @param args
	 * @return
	 * 查询分页列表
	 */
	public List<?> getPageList(String sql, int beginIndex, int pageSize, List<Object> args);
	
	/**
	 * @param <T>
	 * @param sql
	 * @param beginIndex
	 * @param pageSize
	 * @param args
	 * @param clazz
	 * @return
	 * 查询分页列表
	 */
	public <T>List<T> getPageList(String sql, int beginIndex, int pageSize, List<Object> args, Class<T> clazz);
	
	/**
	 * @param sql
	 * @return
	 * 查询行总数
	 */
	public int getTotalCount(String sql);
	
	/**
	 * @param sql
	 * @param args
	 * @return
	 * 查询行总数
	 */
	public int getTotalCount(String sql, List<Object> args);
	
	/**
	 * @param <T>
	 * @param jpql
	 * @return
	 * 按JPQL查询单行记录
	 */
	public <T>T getSingleResultJpql(String jpql);
	
	/**
	 * @param <T>
	 * @param jpql
	 * @param args
	 * @return
	 * 按JPQL查询单行记录
	 */
	public <T>T getSingleResultJpql(String jpql, List<Object> args);
	
	/**
	 * @param <T>
	 * @param jpql
	 * @return
	 * 按jpql查询列表
	 */
	public <T>List<T> getResultListJpql(String jpql);
	
	/**
	 * @param <T>
	 * @param jpql
	 * @param args
	 * @return
	 * 按jpql查询列表
	 */
	public <T>List<T> getResultListJpql(String jpql, List<Object> args);
	
	/**
	 * @param jpql
	 * 执行更新jpql
	 */
	public void doUpdateJpql(String jpql);
	
	/**
	 * @param jpql
	 * @param args
	 * 执行更新jpql
	 */
	public void doUpdateJpql(String jpql, List<Object> args);
	
	/**
	 * @param <T>
	 * @param jpql
	 * @param beginIndex
	 * @param pageSize
	 * @return
	 * 按jpql分页查询列表
	 */
	public <T>List<T> getPageListJpql(String jpql, int beginIndex, int pageSize);
	
	/**
	 * @param <T>
	 * @param jpql
	 * @param beginIndex
	 * @param pageSize
	 * @param args
	 * @return
	 * 按jpql分页查询列表
	 */
	public <T>List<T> getPageListJpql(String jpql, int beginIndex, int pageSize, List<Object> args);
	
	
}
