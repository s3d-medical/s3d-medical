package com.nhs.core.utils.common;

import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.collections.MapUtils;

import com.nhs.core.utils.security.SignMD5;

public class MemberEncryptUtil {

    public static String encode(Map<String, Object> inParams, String key) {
        if (MapUtils.isEmpty(inParams))
            return null;
        Map<String, Object> treeMap = MemberEncryptUtil.putToTreeMap(inParams);
        String source =  MemberEncryptUtil.getMemberMd5Source(treeMap, key);
        return SignMD5.MD5Encode(source, "utf-8");
    }

    /**
     * 将普通Map转成treeMap,移除不需要加密的参数
     * @param maps
     * @return
     */
    public static Map<String, Object> putToTreeMap(Map<String, Object> maps) {
        if (MapUtils.isEmpty(maps))
            return null;
        Map<String, Object> treeMap = new TreeMap<String, Object>();
        for (Map.Entry<String, Object> entry : maps.entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();
            treeMap.put(key, value);
        }
        return treeMap;
    }

    /**
     * 
     * @Title: getMemberMd5Source
     * @Description: TODO
     * @param @param maps
     * @param @return   
     * @return String 
     * @author Administrator 2016年11月11日 
     * @throws
     */
    public static String getMemberMd5Source(Map<String, Object> maps, String md5key) {
        if (MapUtils.isEmpty(maps))
            return null;
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, Object> entry : maps.entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();
            sb.append(key).append(value);
        }
        sb.append(md5key);
        return sb.toString();
    }

}
