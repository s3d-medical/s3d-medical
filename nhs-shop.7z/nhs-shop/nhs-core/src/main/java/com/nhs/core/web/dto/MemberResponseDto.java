package com.nhs.core.web.dto;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import com.nhs.core.web.WebExceptionCode;

public class MemberResponseDto implements Serializable {

	    private static final long serialVersionUID = -1671607286610174732L;
	    private Integer code = WebExceptionCode.MEMBER_NORMAL.errorCode;
	    private String msg = WebExceptionCode.MEMBER_NORMAL.errorMsg;
	    private final Map<String, Object> data = new HashMap<>();

	    public MemberResponseDto() {
	    }

	    public MemberResponseDto(Integer code, String msg) {
	        this.code = code;
	        this.msg = msg;
	    }

		public Integer getCode() {
			return code;
		}

		public void setCode(Integer code) {
			this.code = code;
		}

		public String getMsg() {
			return msg;
		}

		public void setMsg(String msg) {
			this.msg = msg;
		}

		public Map<String, Object> getData() {
			return data;
		}
		
		public boolean isSuccess(){
	        return WebExceptionCode.MEMBER_NORMAL.errorCode.equals(this.code);
	    }
		
	    
}
