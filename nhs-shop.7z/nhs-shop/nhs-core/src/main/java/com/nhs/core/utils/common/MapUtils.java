package com.nhs.core.utils.common;


import java.lang.reflect.InvocationTargetException;
import java.util.Date;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtilsBean;
import org.apache.commons.beanutils.ConvertUtilsBean;
import org.apache.commons.beanutils.PropertyUtilsBean;

import com.nhs.core.json.JsonParseFastJson;


/**
 * Map工具类<br>
 * 
 * @author Wesley<br>
 * 
 */
public class MapUtils extends org.apache.commons.collections.MapUtils {

	/**
	 * 将Map转换为Object
	 * 
	 * @param clazz
	 *            目标对象的类
	 * @param map
	 *            待转换Map
	 * @return
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 */
	public static <T, V> T toObject(Class<T> clazz, Map<String, V> map) throws InstantiationException, IllegalAccessException, InvocationTargetException {
		T object = clazz.newInstance();
		return toObject(object, map);
	}
	
	public static <T, V> T toObject(T object, Map<String, V> map) throws InstantiationException, IllegalAccessException, InvocationTargetException {
		DateTimeConverter dtConverter = new DateTimeConverter();  
        ConvertUtilsBean convertUtilsBean = new ConvertUtilsBean();  
        convertUtilsBean.deregister(Date.class);  
        convertUtilsBean.register(dtConverter, Date.class);  
        BeanUtilsBean beanUtilsBean = new BeanUtilsBean(convertUtilsBean,  
            new PropertyUtilsBean());  
		
        beanUtilsBean.populate(object, map);
		
		return object;
	}

	public static Map<String, Object> toMap(Object srcBean){
		if(srcBean == null){
			return null;
		}
		// bean to json
		String json = JsonParseFastJson.toJson(srcBean);
		// json to map
		Map<String, Object> map = JsonParseFastJson.toObj(json, Map.class);
		return map;
	}
}
