package com.nhs.core.utils.common;

import java.util.List;

import com.google.common.collect.Lists;

/**
 * @author Administrator
 *
 */
public class MeArrayStackUtil <T> implements MeStackInterface<T> {
	private Object[] objs = new Object[36];
	private int size = 0;

	@Override
	public boolean isEmpty() {
		return size == 0;
	}

	@Override
	public void clear() {
		// 将数组中的数据置为null, 方便GC进行回收
		for (int i = 0; i < size; i++) {
			objs[i] = null;
		}
		size = 0;
	}

	@Override
	public int length() {
		return size;
	}

	@Override
	public boolean push(T data) {
		// 判断是否需要进行数组扩容
		if (size >= objs.length) {
			resize(); 
		}
		objs[size++] = data;
		return true;
	}

	public boolean pushNotResize(T data) {
		// 判断是否需要进行数组扩容
		if (size >= objs.length) {
			size = 0;
		}
		objs[size++] = data;
		return true;
	}
	
	/**
	 * 数组扩容
	 */
	private void resize() {
		Object[] temp = new Object[objs.length * 2];
		for (int i = 0; i < size; i++) {
			temp[i] = objs[i];
			objs[i] = null;
		}
		objs = temp;
		temp = null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public T pop() {
		if (size == 0) {
			return null;
		}
		return (T) objs[--size];
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("ArrayStack: [");
		for (int i = 0; i < size; i++) {
			sb.append(objs[i].toString());
			if (i != size - 1) {
				sb.append(", ");
			}
		}
		sb.append("]");
		return sb.toString();
	}
	
	public List<Object> toList(){
		List<Object> list = Lists.newArrayList();
		for (int i=0; i < objs.length; i++){
			if (objs[i] != null){
				list.add(objs[i]);
			}
		}
		return list;
	}
	
	public static void main(String[] args) {
		
	}
}
