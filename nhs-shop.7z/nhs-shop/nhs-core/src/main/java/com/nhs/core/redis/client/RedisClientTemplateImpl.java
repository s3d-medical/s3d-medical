package com.nhs.core.redis.client;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import redis.clients.jedis.BinaryClient.LIST_POSITION;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.ShardedJedis;

import com.nhs.core.redis.data.RedisDataSource;

/**
 * 
 * @Title: RedisClientTemplateImpl.java
 * @Package com.qihao.core.redis.client
 * @Description: TODO
 * @author hxj
 * @date 2016-4-27 下午11:46:33
 * @version V1.0
 */
public class RedisClientTemplateImpl implements RedisClientTemplate {

    protected static final Logger logger = LoggerFactory.getLogger(RedisClientTemplateImpl.class);

    private RedisDataSource dataSource;

    @Override
    public List<String> brpop(int timeout, String key) {
        List<String> result = null;
        ShardedJedis shardedJedis = dataSource.getShardedJedis();
        if (shardedJedis == null)
            return result;
        try {
            result = shardedJedis.brpop(timeout, key);
        } catch (Exception e) {
            logger.error("method brpop occur error,key:" + key, e);
        } finally {
            dataSource.returnShardedJedis(shardedJedis);
        }
        return result;
    }

    /**
     * 删除
     * 
     * @param key
     * @return
     *
     */
    @Override
    public String delVal(String key) {
        ShardedJedis shardedJedis = dataSource.getShardedJedis();
        String value = null;
        try {
            shardedJedis.del(key);
        } catch (Exception e) {
            logger.error("jedisPoolFactory delVal error!key=" + key + ",value=" + value, e);
            throw e;
        } finally {
            dataSource.returnShardedJedis(shardedJedis);
        }
        return value;
    }

    @Override
    public Object eval(String script, int keyCount, String... params) {
        ShardedJedis shardedJedis = dataSource.getShardedJedis();
        Object value = null;
        try {
            Jedis jedis = shardedJedis.getShard("script");
            value = jedis.eval(script, keyCount, params);
        } catch (Exception e) {
            logger.error("jedisPoolFactory eval error!eval=" + script, e);
            throw e;
        } finally {
            dataSource.returnShardedJedis(shardedJedis);
        }
        return value;
    }

    @Override
    public Boolean exists(String key) {
        ShardedJedis shardedJedis = dataSource.getShardedJedis();
        Boolean value = false;
        try {
            value = shardedJedis.exists(key);
        } catch (Exception e) {
            logger.error("jedisPoolFactory exists error!key=" + key + ",value=" + value, e);
            throw e;
        } finally {
            dataSource.returnShardedJedis(shardedJedis);
        }
        return value;
    }

    @Override
    public Long expire(String key, int seconds) {
        ShardedJedis shardedJedis = dataSource.getShardedJedis();
        Long value = null;
        try {
            value = shardedJedis.expire(key, seconds);
        } catch (Exception e) {
            logger.error("jedisPoolFactory expire error!key=" + key, e);
            throw e;
        } finally {
            dataSource.returnShardedJedis(shardedJedis);
        }
        return value;
    }

    /**
        *  获得值
        * 
        * @param key
        * @return
        *
        */
    @Override
    public String getVal(String key) {
        ShardedJedis shardedJedis = dataSource.getShardedJedis();
        String value = null;
        try {
            value = shardedJedis.get(key);
        } catch (Exception e) {
            logger.error("jedisPoolFactory getVal error!key=" + key + ",value=" + value, e);
            throw e;
        } finally {
            dataSource.returnShardedJedis(shardedJedis);
        }
        return value;
    }

    @Override
    public Long hdel(String key, String... fields) {
        ShardedJedis shardedJedis = dataSource.getShardedJedis();
        Long value = null;
        try {
            value = shardedJedis.hdel(key, fields);
        } catch (Exception e) {
            logger.error("jedisPoolFactory hdel error!key=" + key + ",value=" + value, e);
            throw e;
        } finally {
            dataSource.returnShardedJedis(shardedJedis);
        }
        return value;
    }

    @Override
    public Boolean hexists(String key, String field) {
        ShardedJedis shardedJedis = dataSource.getShardedJedis();
        Boolean value = false;
        try {
            value = shardedJedis.hexists(key, field);
        } catch (Exception e) {
            logger.error("jedisPoolFactory hexists error!key=" + key + ",field=" + field + ",value=" + value, e);
            throw e;
        } finally {
            dataSource.returnShardedJedis(shardedJedis);
        }
        return value;
    }

    /**
     *  获得值
     * 
     * @param key
     * @return
     *
     */
    @Override
    public String hgetVal(String key, String field) {
        ShardedJedis shardedJedis = dataSource.getShardedJedis();
        String value = null;
        try {
            value = shardedJedis.hget(key, field);
        } catch (Exception e) {
            logger.error("jedisPoolFactory hgetVal error!key=" + key + ",field=" + field + ",value=" + value, e);
            throw e;
        } finally {
            dataSource.returnShardedJedis(shardedJedis);
        }
        return value;
    }

    /**
    * 保存值
    * 
    * @param key
    * @param value
    *
    */
    @Override
    public void hsetVal(String key, String field, String value) {
        ShardedJedis shardedJedis = dataSource.getShardedJedis();
        try {
            shardedJedis.hset(key, field, value);
        } catch (Exception e) {
            logger.error("jedisPoolFactory hset error!key=" + key + ",field=" + field + ",value=" + value, e);
        } finally {
            dataSource.returnShardedJedis(shardedJedis);
        }

    }

    /**
    * 将str插入key对应的队列，pivot之前位置
    * @param key
    * @param pivot
    * @param str
    * @return
    * @author linruzhou
    */
    @Override
    public Long linsert(String key, String pivot, String str) {
        ShardedJedis shardedJedis = dataSource.getShardedJedis();
        Long value = null;
        try {
            value = shardedJedis.linsert(key, LIST_POSITION.BEFORE, pivot, str);
        } catch (Exception e) {
            logger.error("jedisPoolFactory delVal error!key=" + key + ",value=" + value, e);
            throw e;
        } finally {
            dataSource.returnShardedJedis(shardedJedis);
        }
        return value;
    }

    @Override
    public Long lpush(String key, String... value) {
        Long result = null;
        ShardedJedis shardedJedis = dataSource.getShardedJedis();
        if (shardedJedis == null)
            return result;
        try {
            result = shardedJedis.lpush(key, value);
        } catch (Exception e) {
            logger.error("method lpush occur error,key:" + key + ",value:" + value, e);
        } finally {
            dataSource.returnShardedJedis(shardedJedis);
        }
        return result;
    }

    @Override
    public List<String> lrange(String key, long start, long end) {
        List<String> result = null;
        ShardedJedis shardedJedis = dataSource.getShardedJedis();
        if (shardedJedis == null)
            return result;
        try {
            result = shardedJedis.lrange(key, start, end);
        } catch (Exception e) {
            logger.error("method lrange occur error,key:" + key, e);
        } finally {
            dataSource.returnShardedJedis(shardedJedis);
        }
        return result;
    }

    /**
     * 从key中删除与str匹配的数据，count为0说明全部删除，1：从头开始删除一个相同的数据,2:删除两个，-1：从尾开始删除一个相同的数据
     * @param key
     * @param count
     * @param str
     * @return
     * @author linruzhou
     */
    @Override
    public Long lrem(String key, long count, String str) {
        ShardedJedis shardedJedis = dataSource.getShardedJedis();
        Long value = null;
        try {
            value = shardedJedis.lrem(key, count, str);
        } catch (Exception e) {
            logger.error("jedisPoolFactory delVal error!key=" + key + ",value=" + value, e);
            throw e;
        } finally {
            dataSource.returnShardedJedis(shardedJedis);
        }
        return value;
    }

    @Override
    public String rpop(String key) {
        String result = null;
        ShardedJedis shardedJedis = dataSource.getShardedJedis();
        if (shardedJedis == null)
            return result;
        try {
            result = shardedJedis.rpop(key);
        } catch (Exception e) {
            logger.error("method rpop occur error,key:" + key, e);
        } finally {
            dataSource.returnShardedJedis(shardedJedis);
        }
        return result;
    }

    @Override
    public Long rpush(String key, String... value) {
        Long result = null;
        ShardedJedis shardedJedis = dataSource.getShardedJedis();
        if (shardedJedis == null)
            return result;
        try {
            result = shardedJedis.rpush(key, value);
        } catch (Exception e) {
            logger.error("method rpush occur error,key:" + key + ",value:" + value, e);
        } finally {
            dataSource.returnShardedJedis(shardedJedis);
        }
        return result;
    }

    @Override
    public String scriptLoad(String script) {
        ShardedJedis shardedJedis = dataSource.getShardedJedis();
        String value = null;
        try {
            Jedis jedis = shardedJedis.getShard("script");
            value = jedis.scriptLoad(script);
        } catch (Exception e) {
            logger.error("jedisPoolFactory scriptLoad error!script=" + script, e);
            throw e;
        } finally {
            dataSource.returnShardedJedis(shardedJedis);
        }
        return value;
    }

    public void setDataSource(RedisDataSource dataSource) {
        this.dataSource = dataSource;
    }

    /**
     * 
     * <p>Description:TODO </p>
     * @author hxj 2016-4-27 
     * @param key
     * @param value
     * @see com.nhs.core.redis.client.RedisClientTemplate#setVal(java.lang.String, java.lang.String)
     */
    @Override
    public void setVal(String key, String value) {
        ShardedJedis shardedJedis = dataSource.getShardedJedis();
        try {
            shardedJedis.set(key, value);
        } catch (Exception e) {
            logger.error("jedisPoolFactory set error!key=" + key + ",value=" + value, e);
        } finally {
            dataSource.returnShardedJedis(shardedJedis);
        }

    }

    /**
     * 设置+过期。操作是原子的。
     * 
     * @param key
     * @param value
     * @param seconds
     *
     */
    @Override
    public void setValEx(String key, String value, int seconds) {
        ShardedJedis shardedJedis = dataSource.getShardedJedis();
        try {
            shardedJedis.setex(key, seconds, value);
        } catch (Exception e) {
            logger.error("jedisPoolFactory setValEx error!key=" + key + ",value=" + value, e);
        } finally {
            dataSource.returnShardedJedis(shardedJedis);
        }
    }

}
