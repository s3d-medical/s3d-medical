package com.nhs.core.utils.common;

import java.text.DecimalFormat;

/**
 * @author Administrator
 *
 */
public class MathDealUtil {
	public static double COMPARE_VALUE = 0.000001;
	public static Integer floatCompare(double a,double b){
		return Double.compare(a, b);
	}
	
	public static Double formatDouble(Double src){
		return Double.parseDouble(new DecimalFormat("#.######").format(src));
	}
	
	public static void main(String[] args) {
		System.err.println(MathDealUtil.floatCompare(1.00001, 1.00001));
	}
}
