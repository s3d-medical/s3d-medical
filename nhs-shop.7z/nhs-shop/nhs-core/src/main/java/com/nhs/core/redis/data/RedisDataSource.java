package com.nhs.core.redis.data;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import redis.clients.jedis.ShardedJedis;
import redis.clients.jedis.ShardedJedisPool;

/**
 * 
 * @Title: RedisDataSource.java
 * @Package com.qihao.core.redis.data
 * @Description: TODO
 * @author hxj
 * @date 2016-4-27 下午11:46:42
 * @version V1.0
 */
public class RedisDataSource {

    protected static final Logger logger = LoggerFactory.getLogger(RedisDataSource.class);

    private ShardedJedisPool shardedJedisPool;

    public ShardedJedis getShardedJedis() {
        try {
            ShardedJedis shardedJedis = shardedJedisPool.getResource();
            return shardedJedis;
        } catch (Exception e) {
            logger.error("get jedis client from shardedJedisPool occur error", e);
        }
        return null;
    }

    public void returnShardedJedis(ShardedJedis shardedJedis) {
        if (shardedJedis != null)
            shardedJedisPool.returnResource(shardedJedis);
    }

    public void setShardedJedisPool(ShardedJedisPool shardedJedisPool) {
        this.shardedJedisPool = shardedJedisPool;
    }
}
