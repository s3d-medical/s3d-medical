package com.nhs.core.web.dto;

import java.io.Serializable;

public class RequestHeader implements Serializable {

    private static final long serialVersionUID = 3467214898131190924L;

    private String appVersion;
    private String phoneModel;
    private String platformType;
    private String accessToken;

    public String getAppVersion() {
        return appVersion;
    }

    public void setAppVersion(String appVersion) {
        this.appVersion = appVersion;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getPlatformType() {
        return platformType;
    }

    public void setPlatformType(String platformType) {
        this.platformType = platformType;
    }

    public String getPhoneModel() {
        return phoneModel;
    }

    public void setPhoneModel(String phoneModel) {
        this.phoneModel = phoneModel;
    }

}
