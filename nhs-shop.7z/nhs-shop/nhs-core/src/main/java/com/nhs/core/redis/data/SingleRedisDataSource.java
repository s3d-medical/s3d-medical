package com.nhs.core.redis.data;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

/**
 * 
 * @Title: SingleRedisDataSource.java
 * @Package com.qihao.core.redis.data
 * @Description: TODO
 * @author hxj
 * @date 2016-4-27 下午11:46:48
 * @version V1.0
 */
public class SingleRedisDataSource {

    private JedisPool jedisPool;

    public Jedis getShardedJedis() {
        return jedisPool.getResource();
    }

    public void returnShardedJedis(Jedis jedis) {
        jedisPool.returnResource(jedis);

    }

    public void setJedisPool(JedisPool jedisPool) {
        this.jedisPool = jedisPool;
    }
}
