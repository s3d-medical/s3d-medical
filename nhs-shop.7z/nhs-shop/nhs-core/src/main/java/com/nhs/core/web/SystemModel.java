package com.nhs.core.web;

/**
 * 定义整个平台所有的业务模块
 *
 */
public enum SystemModel {
	CRM("crm"),
	SERVICE("service");
	
	public String value;
	
	SystemModel(String value){
		this.value = value;
	}
	

}
