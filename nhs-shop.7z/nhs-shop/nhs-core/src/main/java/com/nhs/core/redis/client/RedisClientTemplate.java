package com.nhs.core.redis.client;

import java.util.List;

/**
 * 
 * @Title: RedisClientTemplate.java
 * @Package com.qihao.core.redis.client
 * @Description: TODO
 * @author hxj
 * @date 2016-4-27 下午11:46:23
 * @version V1.0
 */
public interface RedisClientTemplate {

    List<String> brpop(int timeout, String key);

    /**
     * 删除
     * 
     * @param key
     * @return
     *
     */
    String delVal(String key);

    Object eval(String script, int keyCount, String... params);

    Boolean exists(String key);

    Long expire(String key, int seconds);

    /**
        *  获得值
        * 
        * @param key
        * @return
        *
        */
    String getVal(String key);

    Long hdel(String key, String... fields);

    Boolean hexists(String key, String field);

    /**
    *  获得值
    * 
    * @param key
    * @return
    *
    */
    String hgetVal(String key, String field);

    /**
     * 保存值
     * 
     * @param key
     * @param value
     *
     */
    void hsetVal(String key, String field, String value);

    /**
    * 将str插入key对应的队列，pivot之前位置
    * @param key
    * @param pivot
    * @param str
    * @return
    * @author linruzhou
    */
    Long linsert(String key, String pivot, String str);

    Long lpush(String key, String... value);

    List<String> lrange(String key, long start, long end);

    /**
    * 从key中删除与str匹配的数据，count为0说明全部删除，1：从头开始删除一个相同的数据,2:删除两个，-1：从尾开始删除一个相同的数据
    * @param key
    * @param count
    * @param str
    * @return
    * @author linruzhou
    */
    Long lrem(String key, long count, String str);

    String rpop(String key);

    Long rpush(String key, String... value);

    String scriptLoad(String script);

    /**
     * 保存值
     * 
     * @param key
     * @param value
     *
     */
    void setVal(String key, String value);

    /**
    * 设置+过期。操作是原子的。
    * 
    * @param key
    * @param value
    * @param seconds
    *
    */
    void setValEx(String key, String value, int seconds);
}
