package com.nhs.core.web;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Date;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.nhs.core.orm.Page;
import com.nhs.core.utils.common.EncodeUtils;

/**
 * 所有控制器的基类
 * @author hxj
 *
 */
@ControllerAdvice
public abstract class WebController {

    @ExceptionHandler({ WebRequestException.class })
    @ResponseBody
    public void webDataException(WebRequestException ex, HttpServletRequest request, HttpServletResponse response) {
        response.addHeader("Cache-Control", "no-cache");
        response.addHeader("Pragma", "no-cache");
        response.addHeader("Expires", "-1");
        response.setCharacterEncoding("UTF-8");
        response.setHeader("content-type", "text/plain;charset=utf-8");
        response.setStatus(300);
        String exceptionName = ex.getClass().getName();
        if (exceptionName.lastIndexOf("WebRequestException") != -1) {
            response.setHeader("Error-Json",
                    EncodeUtils.urlEncode("{\"code\":\"WebRequestException\",\"msg\":\"" + ex.getMessage() + "\"}"));
        } else if (exceptionName.lastIndexOf("CannotCreateTransactionException") >= 0) {
            response.setHeader("Error-Json",
                    EncodeUtils.urlEncode("{\"code\":\"Exception\",\"msg\":\"数据库连接错误，请确认数据库已经启动\"}"));
        } else if (exceptionName.lastIndexOf("Exception") >= 0 && exceptionName.indexOf("DataAccess") >= 0) {
            response.setHeader("Error-Json",
                    EncodeUtils.urlEncode("{\"code\":\"Exception\",\"msg\":\"数据库操作异常，可能数据表之间存在关联,请与管理员联系\"}"));
        } else {
            response.setHeader("Error-Json", EncodeUtils.urlEncode("{\"code\":\"Exception\",\"msg\":\"系统内部错误\"}"));
        }
    }

    @ExceptionHandler({ RuntimeException.class })
    public ModelAndView webDataException(RuntimeException ex, HttpServletRequest request) {
        ModelAndView model = new ModelAndView("error/500");
        model.addObject("errMsg", "系统不给力,请稍后再试!");
        model.addObject("ctx", request.getContextPath());
        return model;
    }

    @InitBinder
    protected void initBinder(HttpServletRequest request, ServletRequestDataBinder binder) throws Exception {
        // 对于需要转换为Date类型的属性，使用DateEditor进行处理
        binder.registerCustomEditor(Date.class, new DateEditor());
    }

    /**
     * 
     * @ClassName: WebController.java
     * @Description: 判断是否是ajax请求
     * @param: WebController
     * @date: 
     * @return: boolean
     * 
     */
    public boolean isAjax(HttpServletRequest request) {
        String accept = request.getHeader("accept");
        String header = request.getHeader("X-Requested-With");
        if (header != null && "XMLHttpRequest".equals(header)) {
            return true;
        } else if (!"".equals(accept) && null != accept) {
            return accept.indexOf("application/json") >= 0;
        } else {
            return false;
        }
    }

    public String getErrorStack(Exception e, int length) {
        String error = null;
        if (e != null) {
            try {
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                PrintStream ps = new PrintStream(baos);
                e.printStackTrace(ps);
                error = baos.toString();
                if (length > 0) {
                    if (length > error.length()) {
                        length = error.length();
                    }
                    error = error.substring(0, length);
                }
                baos.close();
                ps.close();
            } catch (Exception e1) {
                error = e.toString();
            }
        }
        return error;
    }
    
    /**
     * 创建Page对象
     * @Title: newPage
     * @Description: TODO
     * @param @param pageNo
     * @param @param pageSize
     * @param @return   
     * @return Page<Map<String,Object>> 
     * @author Administrator 2016年7月17日 
     * @throws
     */
    public Page<Map<String,Object>> createPage(int pageNo,int pageSize){
        Page<Map<String,Object>> page = new Page<Map<String,Object>>();
        page.setPageNo(pageNo);
        page.setPageSize(pageSize);
        return page;
    }
}
