package com.nhs.core.utils.common;

import java.text.DecimalFormat;

/**
 * 数据格式化工具类
 * @Title: FormatUtils.java
 * @Package com.nhs.core.utils.common
 * @Description: TODO
 * @author penghuaiyi
 * @date 2016年7月26日 下午2:39:53
 * @version V1.0
 */
public class FormatUtils {

    /**
     * 跟石斛
     * @Title: format
     * @Description: TODO
     * @param @param pattern
     * @param @param value
     * @param @return   
     * @return String 
     * @author Administrator 2016年7月26日 
     * @throws
     */
    public static String format(String pattern, Object value) {
        DecimalFormat df = new DecimalFormat(pattern);
        return df.format(value);
    }

    /**
     * 格式化金额
     * <p>如：857111222格式化后：857,111,222</p>
     * @Title: formatMoney
     * @Description: TODO
     * @param @param value
     * @param @return   
     * @return String 
     * @author Administrator 2016年7月26日 
     * @throws
     */
    public static String formatMoney(double value) {
        return format("###,###.##", value);
    }
    
}
