package com.nhs.core.orm;

import org.apache.commons.lang3.StringUtils;

/**
 * 
 * @ClassName: SqlSelector
 * @Description: sql动态封装类
 * @date Jul 22, 2011 1:56:47 PM
 * 
 */
public class SqlSelector {

	private StringBuffer sb;

	public SqlSelector() {
		sb = new StringBuffer();
	}

	public Criteria createCriteria(String sql) {
		sb = sb.append(sql);
		return new Criteria(sb);
	}

	public String toSqlString() {
		return sb.toString();
	}

	static String getFieldName(String field) {
		if (StringUtils.isBlank(field)) {
			throw new RuntimeException(field + " cannot be null");
		}
		return field;
	}

	/**
	 * 
	 * @ClassName: Criteria
	 * @Description: 构造Criteria查询条件
	 * @date Jul 22, 2011 3:40:23 PM
	 * 
	 */
	public static class Criteria {

		private StringBuffer sb;

		public Criteria(StringBuffer sb) {
			this.sb = sb;
		}

		public Criteria addCriterion(String str) {
			sb.append(" ").append(str).append(" ");
			return this;
		}

		public Criteria addCriterion(String fieldName, String fieldValue) {
			return this;
		}

		public Criteria isNull(String field) {
			addCriterion(" and " + getFieldName(field) + " is null");
			return this;
		}

		public Criteria isNotNull(String field) {
			addCriterion(" and " + getFieldName(field) + " is not null");
			return this;
		}

		public Criteria eq(String field, Object value) {
			if (null != value && !"".equals(value)) {
				String result = getFieldName(field) + "=" + convertValue(value);
				addCriterion(" and " + result);
			}
			return this;
		}

		public Criteria notEq(String field, String value) {
			if (null != value && !"".equals(value)) {
				addCriterion(" and " + getFieldName(field) + " <>" + convertValue(value));
			}
			return this;
		}

		public Criteria gt(String field, String value) {
			if (null != value && !"".equals(value)) {
				addCriterion(" and " + getFieldName(field) + " >" + convertValue(value));
			}
			return this;
		}

		public Criteria ge(String field, String value) {
			if (null != value && !"".equals(value)) {
				addCriterion(" and " + getFieldName(field) + " >=" + convertValue(value));
			}
			return this;
		}

		public Criteria lt(String field, String value) {
			if (null != value && !"".equals(value)) {
				addCriterion(" and " + getFieldName(field) + " <" + convertValue(value));
			}
			return this;
		}

		public Criteria le(String field, String value) {
			if (null != value && !"".equals(value)) {
				addCriterion(" and " + getFieldName(field) + " <=" + convertValue(value));
			}
			return this;
		}

		public Criteria like(String field, String value) {
			if (null != value && !"".equals(value)) {
				addCriterion(" and " + getFieldName(field) + " like " + convertLikeValue(value));
			}
			return this;
		}

		public Criteria notLike(String field, String value) {
			if (null != value && !"".equals(value)) {
				addCriterion(" and " + getFieldName(field) + " not like " + convertLikeValue(value));
			}
			return this;
		}

		public Criteria in(String field, String value) {
			String inValues = "";
			if (null == value || "".equals(value)) {
				return this;
			}
			String[] values = value.split(",");
			String[] result = new String[values.length];
			for (int i = 0; i < values.length; i++) {
				result[i] = "'" + values[i] + "'";
			}
			inValues = " (" + StringUtils.join(result, ",") + ")";
			addCriterion(" and " + getFieldName(field) + " in" + inValues);
			return this;
		}

		public Criteria in(String field, Object[] values) {
			String inValues = "";
			if (null == values || values.length == 0) {
				return this;
			}
			if (values instanceof String[]) {
				String[] arr = new String[values.length];
				for (int i = 0; i < values.length; i++) {
					arr[i] = "'" + values[i] + "'";
				}
				inValues = " (" + StringUtils.join(arr, ",") + ")";
			}
			else {
				inValues = " (" + StringUtils.join(values, ",") + ")";
			}
			addCriterion(" and " + getFieldName(field) + " in" + inValues);
			return this;
		}

		public Criteria notIn(String field, Object[] values) {
			String inValues = "";
			if (null == values || values.length == 0) {
				return this;
			}
			if (values instanceof String[]) {
				String[] arr = new String[values.length];
				for (int i = 0; i < values.length; i++) {
					arr[i] = "'" + values[i] + "'";
				}
				inValues = " (" + StringUtils.join(arr, ",") + ")";
			}
			else {
				inValues = " (" + StringUtils.join(values, ",") + ")";
			}
			addCriterion(" and " + getFieldName(field) + " not in " + inValues);
			return this;
		}

		public Criteria between(String field, String value1, String value2) {
			if (null != value1 && !"".equals(value1) && null != value2 && !"".equals(value2)) {
				addCriterion(" and " + getFieldName(field) + " between " + convertValue(value1) + " and "
						+ convertValue(value2));
			}
			return this;
		}

		public Criteria notBetween(String field, String value1, String value2) {
			if (null != value1 && !"".equals(value1)) {
				addCriterion(" and " + getFieldName(field) + " not between" + convertValue(value1) + " and "
						+ convertValue(value2));
			}
			return this;
		}

		public Criteria orderAsc(String[] orderFields) {
			addCriterion(" order by " + StringUtils.join(orderFields, ",") + " asc");
			return this;
		}

		public Criteria orderDesc(String[] orderFields) {
			addCriterion(" order by " + StringUtils.join(orderFields, ",") + " desc");
			return this;
		}

		public Criteria groupBy(String[] groupFields) {
			addCriterion(" group by " + StringUtils.join(groupFields, ","));
			return this;
		}

		public Criteria having(String[] havingFields) {
			String var = "";
			for (String value : havingFields) {
				if (StringUtils.isNotBlank(value)) {
					var += value + " and ";
				}
			}
			if (StringUtils.isNotBlank(var)) {
				addCriterion(" having " + var.substring(0, var.lastIndexOf("and")));
			}
			return this;
		}

		public Criteria extraString(String str) {
			sb.append(" ").append(str).append(" ");
			return this;
		}

		private Object convertValue(Object str) {
			if (null == str)
				return null;
			if (str instanceof String) {
				return "'" + str + "'";
			}
			else {
				return str;
			}
		}

		private Object convertLikeValue(Object str) {
			if (str instanceof String) {
				return "'" + str + "%'";
			}
			else {
				return str+"%";
			}
		}
	}

	public static void main(String[] args) {
		SqlSelector cri = new SqlSelector();
		cri.createCriteria("select * from table where 1=1").eq("org_code", "vvv")
				.in("day_code", new String[] { "2011-07-12", "2011-07-16" });
		System.out.println(cri.toSqlString());
	}
}
