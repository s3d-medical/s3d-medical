/*******************************************************************************
 * @Title: IpUtils.java
 * @Package com.nhs.core.utils.common
 * @Description: TODO
 * @author Administrator 2016年11月15日 
 * @version V1.0   
 * @Copyright (c) 2016 苏州哪划算网络有限公司 版权所有.
 * 注意：本内容仅限于苏州哪划算网络有限有限公司 内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
package com.nhs.core.utils.common;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**   
 * @Title: IpUtils.java
 * @Package com.nhs.core.utils.common
 * @Description: TODO
 * @author chushubin
 * @date 2016年11月15日 下午7:53:56
 * @version V1.0   
 */
public class IpUtils {
    private static final Logger LOG = LoggerFactory.getLogger(IpUtils.class);

    private IpUtils() {

    }

    public static String getHostIp() {
        InetAddress netAddress = getInetAddress();
        if (netAddress == null) {
            return "127.0.0.1";
        }
        String ip = netAddress.getHostAddress(); // get the ip address
        return ip;
    }

    public static String getHostName() {
        InetAddress netAddress = getInetAddress();
        if (netAddress == null) {
            return "127.0.0.1";
        }
        String name = netAddress.getHostName(); // get the host address
        return name;
    }

    public static InetAddress getInetAddress() {
        try {
            return InetAddress.getLocalHost();
        } catch (UnknownHostException e) {
            if (LOG.isWarnEnabled()) {
                LOG.warn(e.getLocalizedMessage());
            }
        }
        return null;
    }
}
