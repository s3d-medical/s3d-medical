package com.nhs.core.redis;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

public class TestRedis {
    private static JedisPoolConfig config = new JedisPoolConfig();
    private static JedisPool pool;
    private static String host = "";
    private static int port = 6379;
    private static boolean isAuth = false;
    private static String password = "";
    private static Jedis jedis = new Jedis("");

    public static void main(String[] args) {

        config.setMaxIdle(1500);
        config.setMinIdle(0);
        config.setMaxWaitMillis(1000);
        config.setTestOnBorrow(true);
        config.setTestOnReturn(true);
        config.setMinEvictableIdleTimeMillis(600000);
        pool = new JedisPool(config, host, port, 3000000, "");
        System.err.println(pool.getResource());
        Jedis shardedJedis = pool.getResource();
        shardedJedis.hset("haha", "ok", "123");

        pool.returnResource(shardedJedis);
    }
}
