package com.nhs.core.common;


public class NhsConstant {
	
	public final static Double DEFAULT_LAT = 31.258948;
		
	public final static Double DEFAULT_LNG = 120.621625;
		
	public final static Integer DEFAULT_CITY_ID = 247;
	
	public final static String PARAM_DEFAULT_ACTIVITY_LOGO = "activity_logo_path";
	
	public final static String PARAM_DEFAULT_SELLER_LOGO = "seller_logo_path";
	
	public final static String PARAM_DEFAULT_SELERS_COMISSION_LOGO = "seles_comission_logo_path";
	
	public final static String PARAM_PRESENT_SIGN = "present_sign";
    
    public final static String PARAM_GOLD_NAME = "gold_name";
    
    public final static String PARAM_SILVER_NAME = "silver_name";
    
    public final static String PARAM_RMB_ICON = "rmb_icon";
    
    public final static String PARAM_IOS_NEED_UPDATE = "ios_need_update";
    
    public final static String DEFAULT_REBATE = "0.625";
    
    public final static String DEFAULT_AD_FEE_RATE = "0.160";
    
    public final static String DEFAULT_AD_FEE_BASIC_RATE = "0.160";
    
    public final static String DEFAULT_AD_FEE_RATE_CRITICAL = "0.10";
    
    public final static String SYS_CONSUME_REDUCE_FONT = "consume.reduce.font";
    
    public final static String SYS_CONSUME_REDUCE_LABEL = "consume.reduce.label";
    
    public final static String SYS_COUPON_FONT = "coupon.font";
    
    public final static String SYS_COUPON_LABEL = "coupon.label";
    
    public final static String SYS_COUPON_ORDER_FONT = "order.coupon.font";
    
    public final static String DEFAULT_STORE_ORDER_USER_MOBILE = "18168185182";
    
    public final static String PAY_RECORD_BACK_URL_PREFIX = "pay.record.back.url";
    
    public final static String DEFAULT_AD_FEE_RATE_CRITICAL_O2O = "0.10";
    
    public final static String DEFAULT_REBATE_O2O = "0.625";
    
    public final static String DEFAULT_SHOP_DISCOUNT_RATE_O2O = "1.000";
    
    public final static String SYS_SHOP_DISCOUNT_FONT_O2O = "o2o.order.shop.discount.font";
    
    public final static String SYS_SHOP_DISCOUNT_LABEL_O2O = "o2o.order.shop.discount.label";
    
    public final static String SYS_VERSION_V193 = "v193";
    
    public final static String SYS_EXCHAGE_RATE = "1";	//RMB兑换比例
    
    public final static String DEFAULT_AD_FEE_RATE_NEW_MAX_SHOP = "0.05";  //商城推广费率超过5%，返利按5%算
    
    public final static String DEFAULT_AD_FEE_RATE_NEW_MAX_O2O = "0.05";  //o2o推广费率超过5%，返利按5%算
    
    public final static String DEFAULT_AD_FEE_RATE_NEW_MAX_STORE = "0.05";  //商超推广费率超过5%，返利按5%算
    
}
