package com.nhs.core.rest;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.CoreConnectionPNames;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nhs.core.mapper.JsonMapper;

@SuppressWarnings("deprecation")
public class HttpClientUtils {

    private static Logger logger = LoggerFactory.getLogger(HttpClientUtils.class);

    public final static int DEF_TIME_OUT = 5000;

    public final static String DEF_CHARSET = "utf-8";

    /**
     * <h1>Post请求</h1>
     * 1.超时时间默认 5000毫秒
     * 2.默认字符集 utf-8
     * @param url
     * @param params
     * @return
     */
    public static String post(String url, Map<String, Object> params) throws Exception {
        return post(url, null, params, DEF_TIME_OUT, DEF_CHARSET);
    }

    /**
     * post请求
     * @param url
     * @param headerMap
     * @param params
     * @param timeout
     * @param charset
     * @return
     * @throws Exception
     */
    @SuppressWarnings("resource")
    public static String post(String url, Map<String, Object> headerMap, Map<String, Object> params, int timeout,
            String charset) throws Exception {
        HttpClient httpClient = new DefaultHttpClient();
        httpClient.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, timeout);
        httpClient.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT, timeout);

        String result = "";
        HttpPost httpPost = new HttpPost(url);
        if (headerMap != null && headerMap.size() > 0) {
            for (Map.Entry<String, Object> entry : headerMap.entrySet()) {
                String key = entry.getKey();
                String value = ObjectUtils.toString(entry.getValue());
                httpPost.setHeader(key, value);
            }
        }

        List<NameValuePair> list = new ArrayList<NameValuePair>();
        if (params != null && params.size() > 0) {
            for (Map.Entry<String, Object> entry : params.entrySet()) {
                String key = entry.getKey();
                String value = ObjectUtils.toString(entry.getValue());
                list.add(new BasicNameValuePair(key, value));
            }
        }

        UrlEncodedFormEntity entity = new UrlEncodedFormEntity(list, "UTF-8");
        httpPost.setEntity(entity);

        ResponseHandler<String> responseHandler = new BasicResponseHandler();
        result = httpClient.execute(httpPost, responseHandler);
        logger.info("HTTP URL:" + url + ", 返回：" + result);
        return result;

    }
    
    /**
     * post请求
     * @param url
     * @param headerMap
     * @param params
     * @param timeout
     * @param charset
     * @return
     * @throws Exception
     */
    @SuppressWarnings("resource")
    public static String postBody(String url, Map<String, Object> headerMap, Map<String, Object> params, int timeout,
            String charset) throws Exception {
        HttpClient httpClient = new DefaultHttpClient();
        httpClient.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, timeout);
        httpClient.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT, timeout);

        String result = "";
        HttpPost httpPost = new HttpPost(url);
        if (headerMap != null && headerMap.size() > 0) {
            for (Map.Entry<String, Object> entry : headerMap.entrySet()) {
                String key = entry.getKey();
                String value = ObjectUtils.toString(entry.getValue());
                httpPost.setHeader(key, value);
            }
        }

        String body = JsonMapper.nonDefaultMapper().toJson(params);
        StringEntity entity = new StringEntity(body);
        httpPost.setEntity(entity);
        
        ResponseHandler<String> responseHandler = new BasicResponseHandler();
        result = httpClient.execute(httpPost, responseHandler);
        logger.info("HTTP URL:" + url + ", 返回：" + result);
        return result;

    }

}
