package com.nhs.core.utils.common;

import java.util.Random;

public class RandomUtils {
	/**
	 * java生成随机数字
	 * 
	 * @param length
	 *            [生成随机数的长度]
	 * @return
	 */
	public static String getOrderValidateCode(int length) {
		String val = "";
		Random random = new Random();
		for (int i = 0; i < length; i++) {
			val += String.valueOf(random.nextInt(10));
		}
		return val.toUpperCase();
	}
	
	public static String getRandomStr(int length){
  	  Random rd = new Random();
  	  String n="";
  	  int getNum;
  	  do {
  	   getNum = Math.abs(rd.nextInt())%10 + 48;//产生数字0-9的随机数
  	   //getNum = Math.abs(rd.nextInt())%26 + 97;//产生字母a-z的随机数
  	   char num1 = (char)getNum;
  	   String dn = Character.toString(num1);
  	   n += dn;
  	  } while (n.length()<length);
  	  return n;
  }

}
