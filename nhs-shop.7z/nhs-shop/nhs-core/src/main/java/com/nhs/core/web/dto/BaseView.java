package com.nhs.core.web.dto;

/**
 * @author xingkong1221
 * @date 2015-11-30
 */
public interface BaseView {
}
