package com.nhs.core.json;

import java.util.List;

import org.springframework.util.StringUtils;

import com.alibaba.fastjson.JSON;

/**
 * object <-> json 互转.
 * @author wind.chen
 */
public class JsonParseFastJson {
	
	public static String toJson(Object obj){
		if(StringUtils.isEmpty(obj)){
			return null;
		}
		return (String) JSON.toJSONString(obj);
	}
	
	public static <T> List<T> toObjList(String json, Class<T> targetClass){
		if(StringUtils.isEmpty(json) || targetClass == null){
			return null;
		}
		return JSON.parseArray(json, targetClass);
	}
	
	public static <T> T toObj(String json, Class<T> targetClass){
		if(StringUtils.isEmpty(json) || targetClass == null){
			return null;
		}
		return JSON.parseObject(json, targetClass);
	}
	
}
