package com.nhs.core.utils.common;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang3.StringUtils;

import com.google.common.collect.Maps;

@SuppressWarnings("all")
public class BeanUtils {

    public static void map2map(Map map1, Map map2) {
        for (Iterator i = map2.keySet().iterator(); i.hasNext();) {
            String key = (String) i.next();
            if (key != null) {
                String value[] = (String[]) map2.get(key);
                if (value != null && value.length > 0)
                    map1.put(key, value[0]);
            }
        }
    }

    
    /** 
    * @Title: bean2map 
    * @Description: 将javabean转换成map
    * @param javaBean
    * @return
    * @throws Exception
    * @return Map<String,Object>
    */ 
    public static Map<String, Object> bean2map(Object javaBean) throws Exception {

        Map<String, Object> result = Maps.newHashMap();
        Method[] methods = javaBean.getClass().getMethods();

        for (Method method : methods) {
            try {
                if (method.getName().startsWith("get") && !method.getName().equals("getClass")) {
                    String field = method.getName();
                    field = field.substring(field.indexOf("get") + 3);
                    field = field.toLowerCase().charAt(0) + field.substring(1);
                    Object value = method.invoke(javaBean);
                    if(value!=null && value instanceof java.util.Date){
                        result.put(field, DateUtils.date2Str((java.util.Date)value, DateUtils.DEFAULT_FORMAT));
                    }else{
                        result.put(field, value);
                    }
                }

            } catch (Exception e) {
            }

        }

        return result;

    }
    
    /**
     * 转换驼峰格式字段,去掉包含"_"字符并且字符后面一个字母大写
     * 
     * @param str
     * @param initial
     * @return
     */
    public static String capitalize(String str, boolean initial) {
        String result = "";
        if (str.indexOf("_") >= 0) {
            String[] arrs = str.split("\\_");
            // 首字母需要大写
            if (initial) {
                for (String v : arrs) {
                    result += StringUtils.capitalize(v);
                }
            } else {
                for (int i = 0; i < arrs.length; i++) {
                    if (i == 0) {
                        result += arrs[i];
                    } else {
                        result += StringUtils.capitalize(arrs[i]);
                    }
                }
            }
        } else {
            if (initial) {
                result = StringUtils.capitalize(str);
            } else {
                result = str;
            }
        }
        return result;
    }
}
