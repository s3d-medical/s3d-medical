package com.nhs.core.web;

import java.io.IOException;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.ParseException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.ByteArrayBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.springframework.web.multipart.MultipartFile;

public class HttpPostFile {

    /**
     * 批量上传字节流
     * @param url
     * @param dir
     * @param mapBytes
     */
    public static String postByte(String url, Map<String, byte[]> mapBytes) {
        HttpClient httpclient = new DefaultHttpClient();
        String result = "";
        try {
            HttpPost httppost = new HttpPost(url);
            MultipartEntity reqEntity = new MultipartEntity();
            for (Map.Entry entry : mapBytes.entrySet()) {
                ByteArrayBody fileBody = new ByteArrayBody((byte[]) entry.getValue(), entry.getKey().toString());
                reqEntity.addPart(entry.getKey().toString(), fileBody);
            }
            httppost.setEntity(reqEntity);

            HttpResponse response = httpclient.execute(httppost);
            int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode == HttpStatus.SC_OK) {
                HttpEntity resEntity = response.getEntity();
                result = EntityUtils.toString(resEntity);
                System.err.println(result);
                EntityUtils.consume(resEntity);
            }
        } catch (ParseException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                httpclient.getConnectionManager().shutdown();
            } catch (Exception ignore) {

            }
        }
        return result;
    }

    /**
     * 批量上传
     * @param url
     * @param dir
     * @param mapFiles
     */
    public static String postFile(String url, Map<String, MultipartFile> mapFiles) {
        HttpClient httpclient = new DefaultHttpClient();
        try {
            HttpPost httppost = new HttpPost(url);
            MultipartEntity reqEntity = new MultipartEntity();
            for (Map.Entry entry : mapFiles.entrySet()) {
                MultipartFile file = (MultipartFile) entry.getValue();
                ByteArrayBody fileBody = new ByteArrayBody(file.getBytes(), entry.getKey().toString());
                reqEntity.addPart(file.getName(), fileBody);
            }

            httppost.setEntity(reqEntity);

            HttpResponse response = httpclient.execute(httppost);
            int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode == HttpStatus.SC_OK) {
                HttpEntity resEntity = response.getEntity();
                String result = EntityUtils.toString(resEntity);
                EntityUtils.consume(resEntity);
                return result;
            }
        } catch (ParseException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                httpclient.getConnectionManager().shutdown();
            } catch (Exception ignore) {

            }
        }
        return "";
    }

    public static String postFile(String url, String fileName, MultipartFile file) {
        HttpClient httpclient = new DefaultHttpClient();
        try {
            HttpPost httppost = new HttpPost(url);
            // httppost.setHeader("content-type", "multipart/form-data");

            ByteArrayBody fileBody = new ByteArrayBody(file.getBytes(), fileName);

            MultipartEntity reqEntity = new MultipartEntity();
            reqEntity.addPart("file", fileBody);
            httppost.setEntity(reqEntity);

            HttpResponse response = httpclient.execute(httppost);
            int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode == HttpStatus.SC_OK) {
                HttpEntity resEntity = response.getEntity();
                String result = EntityUtils.toString(resEntity);
                System.err.println(result);
                EntityUtils.consume(resEntity);

                return result;
            }
        } catch (ParseException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                httpclient.getConnectionManager().shutdown();
            } catch (Exception ignore) {

            }
        }
        return "";
    }
}
