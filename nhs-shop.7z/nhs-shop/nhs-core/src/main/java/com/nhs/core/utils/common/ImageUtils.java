package com.nhs.core.utils.common;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import javax.imageio.ImageIO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ImageUtils {
	
	private final static Logger logger = LoggerFactory.getLogger(ImageUtils.class);
	
	 private ImageUtils() {
	 }
	
	 public static Map<String, String> getImageWidthAndHeight(String imagePath){
		Map<String, String> map = new HashMap<>();
		BufferedImage image;
		try {
			logger.info("###########ImageUtils######### >>>>> start to read image attr from path: "+imagePath);
			URL url=new URL(imagePath);
			HttpURLConnection conn= (HttpURLConnection)url.openConnection();
			conn.setDoOutput(true);
			image = ImageIO.read(conn.getInputStream());
			logger.info("###########ImageUtils######### >>>>> end read image attr.");
			map.put("width", String.valueOf(image.getWidth()));
			map.put("height",String.valueOf(image.getHeight()));
		} catch (MalformedURLException e) {
			map.put("width", String.valueOf(0));
			map.put("height",String.valueOf(0));
			logger.error("MalformedURLException",e);
		} catch (IOException e) {
			map.put("width", String.valueOf(0));
			map.put("height",String.valueOf(0));
			logger.error("IO Exception",e);
		}  
		
		return map;
	 }

}
