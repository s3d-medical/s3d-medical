/**  
 * Filename:    SqlDao.java  
 * Description:   
 * Copyright:   Copyright (c)2011
 * @author:     hfren 
 * @version:    1.0  
 * Create at:   Mar 16, 2011 9:55:40 AM  
 *  
 * Modification History:  
 * Date         Author      Version     Description  
 * ------------------------------------------------------------------  
 * Mar 16, 2011    hfren            1.0        1.0 Version  
 */
package com.nhs.core.orm.hibernate;

import java.util.Collection;
import java.util.List;

import com.nhs.core.orm.Page;

/**
 * SqlDao接口，主要是基于SQL而封装的一些常用数据库操作方法
 * 
 * @author hfren
 * 
 */
@SuppressWarnings("all")
public interface SqlDAO {

	/**
	 * 根据sql查询数据库,返回唯一一条数据
	 * 
	 * @author 任鹤峰
	 * @version 1.0 2010-1-4
	 * @param sql
	 * @param cls
	 *            对象实例
	 * @param values
	 *            代替sql中的?占位符
	 * @return 返回Map或者po
	 */
	<T> T query(final String sql, final Class<T> cls, final Object... values);

	/**
	 * 查询指定SQL，并返回集合
	 * 
	 * @param sql
	 *            SQL语句
	 * @param cls
	 *            指定对象的Class实例类型 Map或者po
	 * @param values
	 *            可变的参数列表
	 * @return list集合
	 */
	<T> List<T> queryAsList(String sql, Class cls, Object... values);

	/**
	 * 执行特定hql返回唯一值
	 * 
	 * @param sql
	 * @param values
	 * @return
	 */
	<T> T uniqueResult(final String sql, final Object... values);

	/**
	 * 执行count查询获得本次Sql查询所能获得的对象总数.
	 * 
	 * @param sql
	 * @param values
	 * @return
	 */
	Long countSqlResult(final String sql, final Object... values);

	/**
	 * 按SQL分页查询.
	 * 
	 * @page page页面对象
	 * @param sql
	 *            SQL语句
	 * @param cls
	 *            实体
	 * @param values
	 *            可变参数列表
	 * @return 分页数据
	 */
	public <T> Page<T> queryAsPage(final Page<T> page, final String sql, final Class cls, final Object... values);

	/**
	 * 根据实体对象更新
	 * 
	 * @param sql
	 *            实体对象
	 * @param param
	 *            参数列表
	 * @return list
	 * @author 任鹤峰
	 * @version 1.0 2010-1-4
	 */
	int update(final String sql, final List<? super Object> param);

	/**
	 * 根据实体对象更新
	 * 
	 * @param sql
	 *            实体对象
	 * @param objects
	 *            optional parameters
	 * @return list
	 * @author 任鹤峰
	 * @version 1.0 2010-1-4
	 */
	int update(final String sql, final Object... objects);

	/**
	 * 批量更新sql语句
	 * 
	 * @param sql
	 *            实体对象
	 * @param objects
	 *            optional parameters
	 * @return list
	 * @author 任鹤峰
	 * @version 1.0 2010-1-4
	 */
	void batchUpdate(final Collection<String> sqlList);
}
