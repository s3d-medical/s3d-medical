package com.nhs.core.orm.hibernate;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.nhs.core.orm.FilterData;
import com.nhs.core.orm.Page;

/**
 * 基类dao接口,主要是基于对象实体封装的一些数据库操作方法
 * 
 * @version 1.0 2011-6-3
 * @author 任鹤峰
 * @since JDK 1.6.0_12
 */
public interface DAO<T> {

	/**
	 * 根据实体类获取全部对象
	 * 
	 * @param cls
	 *            对象所属的实例
	 * @param id
	 * 
	 * @return
	 */
	T get(Class<T> cls, Serializable id);

	/**
	 * 根据实体类获取全部对象
	 * 
	 * @param entity
	 *            对象所属的实例
	 * @return
	 */
	T find(T entity);

	/**
	 * 根据hql查询数据库,返回唯一一条数据
	 * 
	 * @author 任鹤峰
	 * @version 1.0 2010-1-4
	 * @param hql
	 * @param values
	 *            代替hql中的?占位符
	 */
	<V> V find(String hql, Object... values);

	/**
	 * 根据hql查询数据库,返回唯一一条数据
	 * 
	 * @author 任鹤峰
	 * @version 1.0 2010-1-4
	 * @param hql
	 * @param filters
	 *            过滤数据集合,配合hibernate的filterDef和filter属性使用
	 * @param values
	 *            代替hql中的?占位符
	 */
	<V> V find(final String hql, final List<FilterData> filters, final Object... values);

	/**
	 * 根据hql查询数据库,返回唯一一条数据
	 * 
	 * @author 任鹤峰
	 * @version 1.0 2011-09-09
	 * @param hql
	 * @param param
	 *            参数列表
	 */
	T find(String hql, List<? super Object> param);

	/**
	 * 保存实体
	 * 
	 * @param entity
	 *            pojo instance
	 */
	void save(Object entity);

	/**
	 * 删除指定的实体类
	 * 
	 * @param entity
	 */
	void delete(Object entity);

	/**
	 * 根据实体查询所有信息
	 * 
	 * @param cls
	 *            对象所属的Class实例
	 * @return
	 */
	List<T> findAll(Class<T> cls);

	/**
	 * 根据实体po保存或者更新数据
	 * 
	 * @param po
	 */
	void saveOrUpdate(Object po);

	/**
	 * 主键查询实体返回业务对象
	 * 
	 * @author 任鹤峰
	 * @version 1.0 2010-1-4
	 * @param id
	 *            主键
	 * @param cls
	 *            对象所属的Class实例
	 */
	T findById(Serializable id, Class<T> cls);

	/**
	 * 根据hql查询数据库,返回list
	 * 
	 * @author 任鹤峰
	 * @version 1.0 2010-1-4
	 * @param hql
	 * @param values
	 *            代替hql中的?占位符
	 */
	<v> v loadAsList(final String hql, final Object... values);

	/**
	 * 根据hql查询数据库,返回list,无缓存
	 * 
	 * @author 邵帅华
	 * @version 2.0 2012-5-7
	 * @param hql
	 * @param values
	 *            代替hql中的?占位符
	 */
	<v> v reloadAsList(final String hql, final Object... values);

	/**
	 * 根据hql查询数据库,返回list
	 * 
	 * @author 任鹤峰
	 * @version 1.0 2010-1-4
	 * @param hql
	 * @param filters
	 *            过滤数据集合,配合hibernate的filterDef和filter属性使用
	 * @param values
	 *            代替hql中的?占位符
	 */
	<v> v loadAsList(final String hql, final List<FilterData> filters, final Object... values);

	/**
	 * 根据hql查询数据库,返回list
	 * 
	 * @author 任鹤峰
	 * @version 1.0 2010-1-4
	 * @param hql
	 * @param param
	 *            参数列表
	 */
	<v> v loadAsList(String hql, List<? super Object> param);

	/**
	 * 根据实体查询数据库,返回list
	 * 
	 * @author 任鹤峰
	 * @version 1.0 2010-1-4
	 * @param entity
	 * 
	 */
	List<T> loadAsList(T entity);

	/**
	 * 查询指定HQL，并返回集合
	 * 
	 * @param HQL
	 *            HQL语句
	 * @param values
	 *            可变的参数列表
	 * @return list集合
	 */
	Map<String, Object> queryAsMap(String hql, Object... values);

	/**
	 * 查询指定HQL，并返回集合
	 * 
	 * @param HQL
	 *            HQL语句
	 * @param values
	 *            可变的参数列表
	 * @return list集合
	 */
	public List<Object[]> queryAsList(String hql, Object... values);

	/**
	 * 查找指定属性的实体集合
	 * 
	 * @param propertyName
	 *            查询属性字段名称
	 * @param cls
	 *            实体
	 * @param value
	 *            条件
	 * @return 实体集合
	 */
	List<T> findByProperty(String propertyName, Class<T> cls, Object... value);

	/**
	 * 按HQL分页查询.
	 * 
	 * @param Page
	 *            page对象
	 * @param hql
	 *            HQL语句
	 * @param values
	 *            可变参数列表
	 * @return 分页数据
	 */
	public <V> Page<V> loadAsPage(final Page<V> page, final String hql, final Object... values);

	/**
	 * 按HQL分页查询.
	 * 
	 * @param Page
	 *            page对象
	 * @param hql
	 *            HQL语句
	 * @param values
	 *            可变参数列表
	 * @return 分页数据
	 */
	public <V> Page<V> loadAsPage(final Page<V> page, final String hql, final List<? super Object> param);

	/**
	 * 根据实体对象更新
	 * 
	 * @param Object
	 *            操作对象可以是po或者sql
	 * @return list
	 * @author 任鹤峰
	 * @version 1.0 2010-1-4
	 */
	void update(Object obj);

	/**
	 * 
	 * @Title: batchSave
	 * @Description 批量保存数据
	 * @author hfren
	 * @param obj
	 * @return void
	 * @throws
	 */
	void batchSave(final Collection<T> obj);

	/**
	 * 
	 * @Title: batchSave
	 * @Description 批量更新数据
	 * @author hfren
	 * @param hql
	 * @param values
	 * 
	 * @return void
	 * @throws
	 */
	int batchUpdate(String hql, Object... values);

	/**
	 * 
	 * @Title: batchUpdate
	 * @Description 批量更新数据
	 * @author hfren
	 * @param @param obj
	 * @return void
	 * @throws
	 */
	void batchUpdate(final Collection<T> obj);

	/**
	 * 合并实体
	 * 
	 * @param entity
	 * @return
	 */
	<V> V merge(V entity);

	/**
	 * 执行count查询获得本次Hql查询所能获得的对象总数.
	 * 
	 * @param hql
	 * @param values
	 * @return
	 */
	Long countHqlResult(String hql, Object... values);

	/**
	 * 执行count查询获得本次Hql查询所能获得的对象总数.
	 * 
	 * @param hql
	 * @param param
	 *            list参数结合，按顺序存放
	 * @return
	 */
	Long countHqlResult(String hql, List<? super Object> param);

	/**
	 * 执行特定hql返回唯一值
	 * 
	 * @param hql
	 * @param values
	 * @return
	 */
	<V> V uniqueResult(String hql, Object... values);

	
	HibernateTemplate getHibernateTemplate() ;
	
}
