package com.nhs.core.web;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

public class CommonInterceptor extends HandlerInterceptorAdapter {
    private static Logger logger = LoggerFactory.getLogger(CommonInterceptor.class);

    public static Logger getLogger() {
        return logger;
    }

    protected String excludeFile;

    protected String excludeFileSuffix;

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
            throws Exception {
    }

    public String getExcludeFile() {
        return excludeFile;
    }

    public String getExcludeFileSuffix() {
        return excludeFileSuffix;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
            ModelAndView modelAndView) throws Exception {
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        HttpSession session = request.getSession();
        boolean isAccessPath = true;
        String currentUri = request.getServletPath();
        if (currentUri.length() > 1
                && (validateUrlFile(currentUri) || excludeFileSuffix.indexOf(currentUri.substring(currentUri
                        .lastIndexOf(".") + 1)) >= 0)) {
        } else {

        }
        return isAccessPath;
    }

    protected void printToPage(HttpServletRequest request, HttpServletResponse response, String url) {
        try {
            PrintWriter out = response.getWriter();
            out.println("<html><head><title>redirect</title></head>");
            out.println("<body>");
            out.println("<SCRIPT language=JavaScript>window.location='" + url + "';</script>");
            out.println("</body></html>");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setExcludeFile(String excludeFile) {
        this.excludeFile = excludeFile;
    }

    public void setExcludeFileSuffix(String excludeFileSuffix) {
        this.excludeFileSuffix = excludeFileSuffix;
    }

    protected boolean validateUrlFile(String url) {
        String[] excs = excludeFile.split(",");
        for (String exc : excs) {
            if (url.indexOf(exc) > -1) {
                return true;
            }
        }
        return false;
    }
}
