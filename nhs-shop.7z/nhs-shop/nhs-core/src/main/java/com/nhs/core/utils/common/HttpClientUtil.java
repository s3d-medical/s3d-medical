package com.nhs.core.utils.common;



import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;






import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpRequest;
import org.apache.http.HttpResponse;
import org.apache.http.ProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.DefaultRedirectStrategy;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;

/**
 * http client util.
 * 不支持连接池模式
 * @author zhigang.chen
 *
 */
public class HttpClientUtil {

	/**
	 * return string by http get.
	 * @param url
	 * @return
	 */
	public static String getByHttpGet(String url) {
		DefaultHttpClient httpClient = new DefaultHttpClient();
		HttpGet method = null;
		HttpResponse response = null;
		try {
			url = URLDecoder.decode(url, UTF_8);
			method = new HttpGet(url);
			response = httpClient.execute(method);
			/** 请求发送成功，并得到响应 **/
			if (response.getStatusLine().getStatusCode() == 200) {
					/** 读取服务器返回过来的json字符串数据 **/
				String result = EntityUtils.toString(response.getEntity());
				return result;
			}
			method.releaseConnection();
			if(response != null) { 
				EntityUtils.consume(response.getEntity()); //会自动释放连接
			}
		} catch (IOException e) {
			if(method != null){
				method.abort();
			}
			LOGGER.error("httclient get failed.", e);
		}
		return null;
	}
	
	/**
	 * 通用HTTP Post请求
	 * @author yaohua.zhou@gareatech.com 2015.10.26 add
	 * 
	 * @param url HTTP请求地址
	 * @param paramObj 请求参数
	 * @return 请求报文
	 */
	public static String post(String url, Object paramObj) {
		// 返回报文
        String responseText = null;
        
		// HttpClient
		DefaultHttpClient httpClient = new DefaultHttpClient();
		httpClient.setRedirectStrategy(new DefaultRedirectStrategy() {                
	        public boolean isRedirected(HttpRequest request, HttpResponse response, HttpContext context)  {
	            boolean isRedirect = false;
	            try {
	                isRedirect = super.isRedirected(request, response, context);
	            } catch (ProtocolException e) {
	            	LOGGER.error(e.getMessage(), e);
	            }
	            if (!isRedirect) {
	                int responseCode = response.getStatusLine().getStatusCode();
	                if (responseCode == 301 || responseCode == 302) {
	                    return true;
	                }
	            }
	            return isRedirect;
	        }
	    });
		HttpPost httpPost = new HttpPost(url);
		HttpResponse response = null;
		try {
			// 请求参数设置
            if (null != paramObj) {
                List<BasicNameValuePair> params = new ArrayList<BasicNameValuePair>();
                Class<?> clazz = paramObj.getClass();
                String fieldName = "";
                Method method = null;
                String value = "";
                for (Field field : clazz.getDeclaredFields()) {
                    fieldName = field.getName();
                    method = clazz.getMethod("get" + Character.toUpperCase(fieldName.charAt(0)) + fieldName.substring(1));
                    value = String.valueOf(method.invoke(paramObj));
                    if (null != value) {
                        params.add(new BasicNameValuePair(fieldName, value));
                    }
                }
                httpPost.setEntity(new UrlEncodedFormEntity(params, UTF_8));
            }
            response =httpClient.execute(httpPost);
            HttpEntity entity = response.getEntity();
            
            // 响应报文
            if (entity != null && entity.getContentLength() != -1) {
                responseText = EntityUtils.toString(entity);
            }
            httpPost.releaseConnection();
            if(response != null) { 
				EntityUtils.consume(response.getEntity()); //会自动释放连接
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			if(httpPost != null){
				httpPost.abort();
			}
		}
		return responseText;
	}

    /**
     * post json
     * @param url
     * @param json
     * @return
     */
    public static String postJsonStr(String url, Map<String, Object> headerMap , Map<String, Object> params) {
        if(StringUtils.isEmpty(url) || MapUtils.isEmpty(params)){
            throw new RuntimeException("url and posted object can not be null.");
        }
        DefaultHttpClient httpClient = new DefaultHttpClient();
        
        HttpPost method = new HttpPost(url);
        if(MapUtils.isNotEmpty(headerMap)) {
        	for (Map.Entry<String, Object> entry : headerMap.entrySet()){
        		String name = entry.getKey();
        		String value = ObjectUtils.toString(entry.getValue());
        		method.addHeader(name, value);
        	}
        }
        
        StringEntity entity = null;//解决中文乱码问题
        try {
        	String reqbody = JSON.toJSONString(params);
            entity = new StringEntity(reqbody, "utf-8");
            entity.setContentEncoding("UTF-8");
            entity.setContentType("application/json");
            method.setEntity(entity);
            HttpResponse result = httpClient.execute(method);
            // 请求结束，返回结果
            String resData = EntityUtils.toString(result.getEntity());
            LOGGER.info("method: postJsonStr. return value= " + resData);
            method.releaseConnection();
            return resData;
        } catch (Exception e) {
            if(method != null){
                method.releaseConnection();
            }
            throw new RuntimeException("PostJson数据出错.", e);
        }
    }




    public static final String UTF_8 = "UTF-8";

    private static Logger LOGGER = LoggerFactory.getLogger(HttpClientUtil.class);
}
