package com.nhs.sms.service;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cloopen.rest.sdk.CCPRestSDK;
import com.google.common.collect.Maps;

public class YtxSendSms {
    private static final Logger logger = LoggerFactory.getLogger(YtxSendSms.class);

    public static String accountSid = "8a216da8550b8ac001550ece461e01ca";
    public static String accountToken = "f95fdaa5f313468baa1baf1ac49a59f7";
    public static String appId = "8a216da8550b8ac001550ece468c01d0";

    public static String ytxUrl = "app.cloopen.com";
    public static String ytxPort = "8883";

    /**
     * 测试
     * @Title: testValidateCode
     * @Description: TODO
     * @param @param phone
     * @param @param code
     * @param @return   
     * @return Map<String,Object> 
     * @author huxianjun 2016年7月16日 
     * @throws
     */
    public static Map<String, Object> testValidateCode(String phone, String code) {
        String[] args = new String[] { code, "2" };
        Map<String, Object> map = Maps.newHashMap();
        map.put("phone", phone);
        map.put("tempId", "90981");
        map.put("args", args);
        return map;
    }

    public static boolean sendSms(Map<String, Object> map) {
        HashMap<String, Object> result = null;

        CCPRestSDK restAPI = new CCPRestSDK();
        restAPI.init(ytxUrl, ytxPort);// 初始化服务器地址和端口，格式如下，服务器地址不需要写https://
        restAPI.setAccount(accountSid, accountToken);// 初始化主帐号名称和主帐号令牌
        restAPI.setAppId(appId);// 初始化应用ID
        result = restAPI.sendTemplateSMS(map.get("phone").toString(), map.get("tempId").toString(),
                (String[]) map.get("args"));

        logger.info("sendSms result=" + result);

        if ("000000".equals(result.get("statusCode"))) {
            return true;
        } else {
            return false;
        }
    }

    public static boolean sendVoiceVerify(Map<String, Object> map) {
        HashMap<String, Object> result = null;

        CCPRestSDK restAPI = new CCPRestSDK();
        restAPI.init(ytxUrl, ytxPort);
        restAPI.setAccount(accountSid, accountToken);
        restAPI.setAppId(appId);
        result = restAPI.voiceVerify(map.get("remark").toString(), map.get("phone").toString(), "4006767882", "2", "");
        logger.info("sendVoiceVerify result=" + result);

        if ("000000".equals(result.get("statusCode"))) {
            return true;
        } else {
            return false;
        }
    }

    /**
    * @param args
    */
    public static void main(String[] args) {
        Map<String, Object> sms = YtxSendSms.testValidateCode("181681851", "6582");
        YtxSendSms.sendSms(sms);
    }
}
