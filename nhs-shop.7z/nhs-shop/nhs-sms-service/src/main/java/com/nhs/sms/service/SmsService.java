package com.nhs.sms.service;

import java.util.Date;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.google.common.collect.Maps;
import com.nhs.core.utils.common.DateUtils;
import com.nhs.core.web.WebRequestException;
import com.nhs.shop.dao.CommonSqlDao;
import com.nhs.shop.dao.legend.sms.SmsChannelDao;
import com.nhs.shop.dao.legend.sms.SmsChannelTemplateDao;
import com.nhs.shop.dao.legend.sms.SmsLogDao;
import com.nhs.shop.dao.legend.sms.SmsTemplateDao;
import com.nhs.shop.entry.legend.sms.SmsChannelTemplate;
import com.nhs.shop.entry.legend.sms.SmsLog;
import com.nhs.shop.entry.legend.sms.SmsTemplate;

@Service
public class SmsService {

    private final Logger logger = LoggerFactory.getLogger(SmsService.class);
    @Autowired
    private CommonSqlDao commonSqlDao;
    @Autowired
    private SmsLogDao smsLogDao;
    @Autowired
    private SmsTemplateDao smsTemplateDao;
    @Autowired
    private SmsChannelDao smsChannelDao;
    @Autowired
    private SmsChannelTemplateDao smsChannelTemplateDao;


    /**
     * 获取已经发送的最近一次短信验证码
     * @Title: getSmsValidate
     * @Description: TODO
     * @param @param phone
     * @param @return   
     * @return String 
     * @author huxianjun 2016年7月16日 
     * @throws
     */
    public String getSmsValidate(String phone) {
        SmsLog sms = smsLogDao.findSmsValidate(phone);
        if (sms != null) {
            Date over = sms.getRecDate();
            if (DateUtils.dateAddHourMin(over, 0, 2).after(commonSqlDao.dbDate())) {
                return sms.getMobileCode();
            } else {
                throw new WebRequestException("验证码失效，请重新获取");
            }
        }
        return "";
    }

    /**
     * 
     * @Title: saveSendSms
     * @Description: TODO
     * @param @param templateNo
     * @param @param phone
     * @param @param remark 订单编号或者验证码
     * @param @param smsType
     * @param @param args   
     * @return void 
     * @author huxianjun 2016年7月16日 
     * @throws
     */
    public void saveSendSms(Integer templateNo, String phone, String remark, Integer smsType, String[] args) {
        SmsTemplate template = smsTemplateDao.findSmsTemplate(templateNo);
        if (template == null) {
            throw new WebRequestException("短信模板不存在");
        }
        // 选择通道，当前默认云通信
        this.saveSmsYtx(template, phone, remark, smsType, args);
    }

    /**
     * 北京云通讯提供商
     * @Title: saveSmsYtx
     * @Description: TODO
     * @param @param template
     * @param @param phone
     * @param @param remark
     * @param @param smsType
     * @param @param args   
     * @return void 
     * @author huxianjun 2016年7月16日 
     * @throws
     */
    @Async
    public void saveSmsYtx(SmsTemplate template, String phone, String remark, Integer smsType, String[] args) {
        SmsChannelTemplate channelTempalte = smsChannelTemplateDao.findSmsChannelTemplate(template.getTemplateNo(), 1);
        if (channelTempalte == null) {
            throw new WebRequestException("通道模板不存在");
        }

        String content = template.getContent();
        for (int i = 0; i < args.length; i++) {
            content = content.replace("{" + (i + 1) + "}", args[i]);
        }
        content = "［" + template.getSignHeader() + "］" + content;

        Map<String, Object> map = Maps.newHashMap();
        map.put("phone", phone);
        map.put("tempId", channelTempalte.getChannelTemplateId());
        map.put("args", args);
        map.put("content", content);
        boolean state = false;
        state = this.ytxSms(map);

        SmsLog sms = new SmsLog();
        sms.setStatus(state == true ? 1 : 0);
        sms.setMobileCode(remark);
        sms.setType(smsType);
        sms.setUserName(phone);
        sms.setUserPhone(phone);
        this.saveSms(sms, map);
    }

    /**
     * 语音发送验证码
     * @Title: saveYtxVoiceVerify
     * @Description: TODO
     * @param @param map
     * @param @param msgType   
     * @return void 
     * @author huxianjun 2016年7月16日 
     * @throws
     */
    @Async
    public void saveYtxVoiceVerify(Map<String, Object> map, Integer msgType) {
        boolean state = false;
        state = this.ytxVoiceVerify(map);
        SmsLog sms = new SmsLog();
        sms.setStatus(state == true ? 1 : 0);
        sms.setType(msgType);
        this.saveSms(sms, map);
    }

    private void saveSms(SmsLog sms, Map<String, Object> map) {
        sms.setRecDate(commonSqlDao.dbDate());
        sms.setContent(map.get("content").toString());
        smsLogDao.save(sms);
    }

    /**
     * 云通信短信发送的结果
     * @param map
     * @param msgType
     * @return
     */
    private boolean ytxSms(Map<String, Object> map) {
        try {
            return YtxSendSms.sendSms(map);
        } catch (Exception e) {
            logger.error("云通信短信错误：" + e.getMessage());
        }
        return false;
    }

    /**
     * 云通信语音发送结果
     * @param map
     * @param msgType
     * @return
     */
    private boolean ytxVoiceVerify(Map<String, Object> map) {
        try {
            return YtxSendSms.sendVoiceVerify(map);
        } catch (Exception e) {
            logger.error("云通信语音错误：" + e.getMessage());
        }
        return false;
    }
}
