/*******************************************************************************
 * @Title: TransferLogEntity.java
 * @Package com.nhs.shop.entry.legend.transfer
 * @Description: TODO
 * @author Administrator 2016年11月15日 
 * @version V1.0   
 * @Copyright (c) 2016 苏州哪划算网络有限公司 版权所有.
 * 注意：本内容仅限于苏州哪划算网络有限有限公司 内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
package com.nhs.apiproxy.member.acc.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**   
 * @Title: TransferLogEntity.java
 * @Package com.nhs.shop.entry.legend.transfer
 * @Description: TODO
 * @author chushubin
 * @date 2016年11月15日 下午7:23:06
 * @version V1.0   
 */
@Entity
@Table(name = "nhs_transfer_log")
public class TransferLogEntity implements Serializable {

    private static final long serialVersionUID = 3646085015823476292L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "n_id")
    private Integer id;

    @Column(name = "s_user_id")
    private String userId;

    @Column(name = "s_order_id")
    private String orderId;

    @Column(name = "s_biz_data")
    private String bizData;

    @Column(name = "s_order_type")
    private String orderType;

    @Column(name = "s_biz_type")
    private String bizType;

    @Column(name = "s_comments")
    private String comments;

    @Column(name = "d_create")
    private Date create;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getBizData() {
        return bizData;
    }

    public void setBizData(String bizData) {
        this.bizData = bizData;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getBizType() {
        return bizType;
    }

    public void setBizType(String bizType) {
        this.bizType = bizType;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public Date getCreate() {
        return create;
    }

    public void setCreate(Date create) {
        this.create = create;
    }

    @Override
    public String toString() {
        return "TransferLogEntity [id=" + id + ", userId=" + userId + ", orderId=" + orderId + ", bizData=" + bizData
                + ", orderType=" + orderType + ", bizType=" + bizType + ", comments=" + comments + ", create=" + create
                + "]";
    }
}
