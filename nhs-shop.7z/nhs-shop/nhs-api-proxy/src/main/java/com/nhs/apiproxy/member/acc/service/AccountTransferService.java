/*******************************************************************************
 * @Title: TransferService.java
 * @Package com.nhs.shop.service.transfer
 * @Description: TODO
 * @author Administrator 2016年11月15日 
 * @version V1.0   
 * @Copyright (c) 2016 苏州哪划算网络有限公司 版权所有.
 * 注意：本内容仅限于苏州哪划算网络有限有限公司 内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
package com.nhs.apiproxy.member.acc.service;

import java.math.BigDecimal;
import java.util.List;

import com.nhs.apiproxy.member.acc.datatype.BizTypeEnum;
import com.nhs.apiproxy.member.acc.datatype.OrderTypeEnum;
import com.nhs.apiproxy.member.acc.dto.Balance;
import com.nhs.apiproxy.member.acc.dto.UserAccDto;
import com.nhs.apiproxy.member.acc.dto.UserAllAccDto;

/**   
 * @Title: TransferService.java
 * @Package com.nhs.shop.service.transfer
 * @Description: TODO
 * @author chushubin
 * @date 2016年11月15日 下午6:18:58
 * @version V1.0   
 */
public interface AccountTransferService {

    /**
     * 查找用户各类账户.
     * @Title: findUserAccList
     * @Desc: 
     * @author wind.chen 2016年11月22日 下午12:01:00
     *
     * @param userId
     * @return
     * @throws
     */
	List<UserAccDto> findUserAccList(String userId);
    
	/**
	 * 找到用户所有的账户.
	 * @Title: findUserAllAcc
	 * @Desc: 
	 * @author wind.chen 2016年12月3日 下午4:35:53
	 *
	 * @param userId
	 * @return
	 * @throws
	 */
	UserAllAccDto findUserAllAcc(String userId);
	
    /**
     * @Title: transfer
     * @Description: 调用远程transfer接口，并记录日志
     * @param @param orderId
     * @param @param userId
     * @param @param balances
     * @param @param BizType
     * @param @param orderType
     * @param @param comments
     * @param @return   
     * @return String 
     * @author Administrator 2016年11月15日 
     * @throws
     */
    public boolean transfer(String orderId, String userId, List<Balance> balances, BizTypeEnum BizType,
            OrderTypeEnum orderType, String comments);

    /**
     * @Title: rebateSilver
     * @Description: 返利佰德钻
     * @param @param userId
     * @param @param orderNo
     * @param @param amount   
     * @return void 
     * @author chushubin 2016年11月18日 
     * @throws
     */
    public void rebateSilver(String userId, String orderNo, BigDecimal amount);

    /**
     * @Title: rebateFrozenSilver
     * @Description: 返利冻结佰德砖
     * @param @param userId
     * @param @param orderNo
     * @param @param amount   
     * @return void 
     * @author chushubin 2016年11月18日 
     * @throws
     */
    public void rebateFrozenSilver(String userId, String orderNo, BigDecimal amount);

    /**
     * @Title: rebateGold
     * @Description: 返利佰德券
     * @param @param userId
     * @param @param orderNo
     * @param @param amount   
     * @return void 
     * @author chushubin 2016年11月18日 
     * @throws
     */
    public void rebateGold(String userId, String orderNo, BigDecimal amount);
    
    
    /**
     * 冻结返利佰德券
     * @param userId
     * @param orderNo
     * @param amount
     */
    public void rebateFrozenGold(String userId, String orderNo, BigDecimal amount);

    /**
     * @Title: depositUserBizAccount
     * @Description: 增加账号的企业账户余额
     * @param @param userId
     * @param @param orderNo
     * @param @param amount   
     * @return void 
     * @author chushubin 2016年11月18日 
     * @throws
     */
    public void depositUserBizAccount(String userId, String orderNo, BigDecimal amount);
    
    /**
     * 增加个人账户余额
     * @param userId
     * @param orderNo
     * @param amount
     */
    public void depositUserAccount(String userId, String orderNo, BigDecimal amount);

    /**
     * @Title: unfreezeSilver
     * @Description: 解冻冻结的佰德钻
     * @param @param userId
     * @param @param orderNo
     * @param @param amount   
     * @return void 
     * @author chushubin 2016年11月18日 
     * @throws
     */
    public void unfreezeSilver(String userId, String orderNo, BigDecimal amount);
    
    /**
     * 解冻冻结的佰德券
     * @param userId
     * @param orderNo
     * @param amount
     */
    public void unfreezeGold(String userId, String orderNo, BigDecimal amount);

    /**
     * @Title: freezeGold
     * @Description: 预冻金币
     * @param @param userId
     * @param @param orderNo
     * @param @param amount
     * @param @return   
     * @return boolean 
     * @author chushubin 2016年11月21日 
     * @throws
     */
    public boolean freezeGold(String userId, String orderNo, BigDecimal amount);

    /**
    * @Title: commitGold
    * @Description: 解冻确认
    * @param @param userId
    * @param @param orderNo
    * @param @param amount
    * @param @return   
    * @return boolean 
    * @author chushubin 2016年11月21日 
    * @throws
    */
    public boolean commitGold(String userId, String orderNo, BigDecimal amount);
    /**
     * 以人民币为单位, 处理佰德劵. 
     * 100佰德劵 = 1RMB * 100
     * @Title: commitGoldByRMB
     * @Desc: 
     * @author wind.chen 2016年12月2日 下午5:12:12
     *
     * @param userId
     * @param orderNo
     * @param amount
     * @return
     * @throws
     */
    public boolean commitGoldByRMB(String userId, String orderNo, BigDecimal amount);

    /**
    * @Title: commitGold
    * @Description: 解冻取消
    * @param @param userId
    * @param @param orderNo
    * @param @param amount
    * @param @return   
    * @return boolean 
    * @author chushubin 2016年11月21日 
    * @throws
    */
    public boolean cancelGold(String userId, String orderNo, BigDecimal amount);
    
    
    /**
     * 对个人账户减余额 
     * @param userId
     * @param orderNo
     * @param amount
     */
    public boolean deductYueBao(String userId, String orderNo, BigDecimal amount);
    
    /**
     * 给佣金账户增加数量.
     * @Title: addCommissionSilver
     * @Desc: 
     * @author wind.chen 2016年11月22日 上午9:34:35
     *
     * @param userId
     * @param silver
     * @return
     * @throws
     */
	boolean addCommissionSilver(String userId, String orderNo,
			BigDecimal sliver);

}
