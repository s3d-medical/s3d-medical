/*******************************************************************************
 * @Title: Balance.java
 * @Package com.nhs.shop.service.transfer
 * @Description: TODO
 * @author Administrator 2016年11月15日 
 * @version V1.0   
 * @Copyright (c) 2016 苏州哪划算网络有限公司 版权所有.
 * 注意：本内容仅限于苏州哪划算网络有限有限公司 内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
package com.nhs.apiproxy.member.acc.dto;

import java.io.Serializable;
import java.math.BigDecimal;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.nhs.core.json.P2BigDecimalSerializer;

/**   
 * @Title: Balance.java
 * @Package com.nhs.shop.service.transfer
 * @Description: TODO
 * @author chushubin
 * @date 2016年11月15日 下午6:19:25
 * @version V1.0   
 */
public class Balance implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 8102613600652141218L;

    private String currency;

//    @JsonSerialize(using = P2BigDecimalSerializer.class)
    private String amount;

    public Balance() {
    }

    public Balance(String currency, BigDecimal amount) {
        this.currency = currency;
        this.amount = amount.toPlainString();
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }
}
