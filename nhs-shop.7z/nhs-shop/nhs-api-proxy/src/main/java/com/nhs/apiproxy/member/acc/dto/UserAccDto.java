package com.nhs.apiproxy.member.acc.dto;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 用户账户信息
 * 
 * @author wind.chen
 * 
 */
public class UserAccDto implements Serializable {

	private static final long serialVersionUID = -8645869859980093723L;
	private String currency;// S 币种编码
	private String currencyName;// S 币种名称
	private String userId; // S 用户id
	private String amount;// S 币种余额
	private String canTake; // S 是否可以提现
	private BigDecimal takeRate; // N 提现手续费

	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getCurrencyName() {
		return currencyName;
	}
	public void setCurrencyName(String currencyName) {
		this.currencyName = currencyName;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getAmount() {
		if(amount == null){
			this.amount = "0.00";
		}
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getCanTake() {
		return canTake;
	}
	public void setCanTake(String canTake) {
		this.canTake = canTake;
	}
	public BigDecimal getTakeRate() {
		return takeRate;
	}
	public void setTakeRate(BigDecimal takeRate) {
		this.takeRate = takeRate;
	}
}
