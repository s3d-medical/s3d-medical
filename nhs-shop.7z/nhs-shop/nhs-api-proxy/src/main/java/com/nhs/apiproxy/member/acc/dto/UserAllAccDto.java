package com.nhs.apiproxy.member.acc.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.nhs.apiproxy.member.acc.datatype.CurrencyEnum;

public class UserAllAccDto implements Serializable{
	private static final long serialVersionUID = -7127006356660827259L;
	
	Map<String, UserAccDto> allAccs = new HashMap<String, UserAccDto>();
	
	public UserAllAccDto(List<UserAccDto> accList) {
		super();
		if(accList != null){
			for(UserAccDto acc : accList){
				allAccs.put(acc.getCurrency(), acc);
			}
		}
	}

	public BigDecimal getOneAccAmount(CurrencyEnum accType){
		UserAccDto acc = this.getOneAcc(accType);
		if(acc != null && acc.getAmount() != null){
			return new BigDecimal(acc.getAmount());
		}
		return new BigDecimal("0.00");
	}
	
	public UserAccDto getOneAcc(CurrencyEnum accType){
		if(accType == null){
			return null;
		}
		return this.allAccs.get(accType.getCurrency());
	}

    /**
     * 个人余额 CURRENCY_PERSONAL_BALANCE("C"),
     */
	public BigDecimal getPBalance(){
		return this.getOneAccAmount(CurrencyEnum.CURRENCY_PERSONAL_BALANCE);
	}
    
    /**
     * 商家余额 CURRENCY_BUSINESS_BALANCE("B"),
     */
	public BigDecimal getBBalance(){
		return this.getOneAccAmount(CurrencyEnum.CURRENCY_BUSINESS_BALANCE);
	}
	
    /**
     * 个人冻结金额 CURRENCY_PERSONAL_FORBIDEN_BALANCE("E"),
     */
	public BigDecimal getPFrozenBalance(){
		return this.getOneAccAmount(CurrencyEnum.CURRENCY_PERSONAL_FORBIDEN_BALANCE);
	}
	
    /**
     * 商家冻结金额CURRENCY_BUSINESS_FORBIDEN_BALANCE("F"),
     */
	public BigDecimal getBFrozenBalance(){
		return this.getOneAccAmount(CurrencyEnum.CURRENCY_BUSINESS_FORBIDEN_BALANCE);
	}
    /**
     * 个人百德券CURRENCY_GOLD_COIN("G"),
     */
	public BigDecimal getPGold(){
		return this.getOneAccAmount(CurrencyEnum.CURRENCY_GOLD_COIN);
	}
     
 
    /**
     * 百德钻CURRENCY_SILVER_COIN("S"),
     */
    public BigDecimal getPSliver(){
    	return this.getOneAccAmount(CurrencyEnum.CURRENCY_SILVER_COIN);
    }

    /**
     * 百德钻冻结CURRENCY_FORBIDEN_SILVER_COIN("Q"),
     */
    public BigDecimal getPFrozenSliver(){
    	return this.getOneAccAmount(CurrencyEnum.CURRENCY_FORBIDEN_SILVER_COIN);
    }
    
    /**
     * 冻结佰德券CURRENCY_FORBIDEN_GOLD_COIN("W"),
     */
    public BigDecimal getPFrozenGold(){
    	return this.getOneAccAmount(CurrencyEnum.CURRENCY_FORBIDEN_GOLD_COIN);
    }

    /**
     * 营业员福利佰德券CURRENCY_COMMISSION_GOLD_COIN("T"),
     */
    public BigDecimal getEmCommissionGold(){
    	return this.getOneAccAmount(CurrencyEnum.CURRENCY_COMMISSION_GOLD_COIN);
    }
    
    /**
     * 营业员福利佰德券冻结CURRENCY_FORBIDEN_COMMISSION_GOLD_COIN("Y"),
     */
    public BigDecimal getEmCommissionFrozenGold(){
    	return this.getOneAccAmount(CurrencyEnum.CURRENCY_FORBIDEN_COMMISSION_GOLD_COIN);
    }

    /**
     * 营业员福利百德钻CURRENCY_COMMISSION_SILVER_COIN("U");
     */
    public BigDecimal getEmCommissionSliver(){
    	return this.getOneAccAmount(CurrencyEnum.CURRENCY_COMMISSION_SILVER_COIN);
    }
    
}
