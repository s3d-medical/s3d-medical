package com.nhs.apiproxy.member.user.service;

import com.nhs.apiproxy.member.user.dto.UsrAddrDto;

/**
 * 远端调用api
 * @author wind.chen
 *
 */
public interface UserServiceApi {
    /**
     * 根据id获取用户收货地址
     * @param userId  user id.
     * @param addrId  地址id
     * @return
     */	
    public UsrAddrDto findShipAddrById(String userId, Integer addrId);
    
    /**
     * 获取默认收货地址.
     * @Title: findDefaultShipAddrById
     * @Desc: 
     * @author wind.chen 2016年11月21日 上午10:30:41
     *
     * @param userId
     * @param addrId
     * @return
     * @throws
     */
    public UsrAddrDto findDefaultShipAddrById(String userId);
    
}
