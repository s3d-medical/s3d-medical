package com.nhs.apiproxy;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.ObjectUtils;

import com.nhs.core.json.JsonParseFastJson;

/**
 * rest api调用返回值处理工具. 
 * @author wind.chen
 *
 */
public class UnifiedInApiResultHelper {

	private static final String SUCCESS = "1";

	/**
	 * 从返回json中获取data节点值.
	 * @param json
	 * @param targetClass
	 * @return
	 */
	public static <T> T parseDataToObj(String json, Class<T> targetClass) {
		Object dataNode = getDataNode(json);
		// 将data节点转为json.
		String objJson = JsonParseFastJson.toJson(dataNode); 
		// json转为指定的class对象.
		T realObj = JsonParseFastJson.toObj(objJson, targetClass);  //json to real object.
	    return realObj;
	}
	
	/**
	 * 从返回json中获取data节点值.
	 * @param json
	 * @param targetClass
	 * @return
	 */
	public static <T> T parseResultToObj(String json, Class<T> targetClass) {
		Object resultNode = getResultNode(json);
		// 将data节点转为json.
		String objJson = JsonParseFastJson.toJson(resultNode); 
		// json转为指定的class对象.
		T realObj = JsonParseFastJson.toObj(objJson, targetClass);  //json to real object.
	    return realObj;
	}
	
	public static <T> List<T> parseDataToList(String json, Class<T> targetClass) {
		Object dataNode = getDataNode(json);
		// 将data节点转为json.
	    String objJson = JsonParseFastJson.toJson(dataNode); 
	    // json转为指定的class对象.
	    List<T> realObj = JsonParseFastJson.toObjList(objJson, targetClass);  //json to real object.
	    return realObj;
	}
	
	/**
	 * 获取data节点, 以json解析出来的Object返回.
	 * @Title: getDataNode
	 * @Desc: 
	 * @author wind.chen 2016年11月24日 下午7:19:16
	 *
	 * @param json
	 * @return
	 * @throws
	 */
	private static Object getDataNode(String json) {
		// check code.
		Class t = new HashMap<String, Map<String, Object>>().getClass();
		Map result = (Map)JsonParseFastJson.toObj(json, t);
		if (!SUCCESS.equals(ObjectUtils.toString(result.get("code")))) {
			return null;
		}
		//处理2层或者1层data节点.
		Map objInMap = (Map)result.get("data");
		if(objInMap != null && objInMap.get("data") == null){
			return objInMap;
		}else{
			return objInMap.get("data");
		}
	}
	
	/**
	 * 获取返回结果的所有节点, 以json解析出来的Object返回.
	 * @Title: getDataNode
	 * @Desc: 
	 * @author wind.chen 2016年11月24日 下午7:19:16
	 *
	 * @param json
	 * @return
	 * @throws
	 */
	private static Object getResultNode(String json) {
		// check code.
		Class t = new HashMap<String, Map<String, Object>>().getClass();
		Map result = (Map)JsonParseFastJson.toObj(json, t);
		return result;
	}
}
