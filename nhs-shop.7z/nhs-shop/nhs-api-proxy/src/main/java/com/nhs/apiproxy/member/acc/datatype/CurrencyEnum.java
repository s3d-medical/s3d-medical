package com.nhs.apiproxy.member.acc.datatype;

/**
 * 
 * @Title: CurrencyEnum.java
 * @Package com.nhs.nscp.pojo.account
 * @Description: 币种定义枚举
 * @author Administrator
 * @date 2016年10月24日 下午4:28:07
 * @version V1.0
 */
public enum CurrencyEnum {

    /**
     * 个人余额
     */
    CURRENCY_PERSONAL_BALANCE("C"),

    /**
     * 商家余额
     */
    CURRENCY_BUSINESS_BALANCE("B"),

    /**
     * 个人冻结金额
     */
    CURRENCY_PERSONAL_FORBIDEN_BALANCE("E"),

    /**
     * 商家冻结金额
     */
    CURRENCY_BUSINESS_FORBIDEN_BALANCE("F"),

    /**
     * 百德券
     */
    CURRENCY_GOLD_COIN("G"),

    /**
     * 百德钻
     */
    CURRENCY_SILVER_COIN("S"),

    /**
     * 百德钻冻结
     */
    CURRENCY_FORBIDEN_SILVER_COIN("Q"),

    /**
     * 冻结佰德券
     */
    CURRENCY_FORBIDEN_GOLD_COIN("W"),

    /**
     * 营业员福利佰德券
     */
    CURRENCY_COMMISSION_GOLD_COIN("T"),

    /**
     * 营业员福利佰德券冻结
     */
    CURRENCY_FORBIDEN_COMMISSION_GOLD_COIN("Y"),

    /**
     * 营业员福利百德钻
     */
    CURRENCY_COMMISSION_SILVER_COIN("U");

    private final String currency;

    private CurrencyEnum(String currency) {
        this.currency = currency;
    }

    public String getCurrency() {
        return currency;
    }

    public static boolean contain(String currency) {
        for (CurrencyEnum currencyEnum : CurrencyEnum.values()) {
            if (currencyEnum.getCurrency().equals(currency)) {
                return true;
            }
        }
        return false;
    }

}
