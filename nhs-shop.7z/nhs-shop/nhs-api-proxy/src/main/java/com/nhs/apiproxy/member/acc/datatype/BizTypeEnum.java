/*******************************************************************************
 * @Title: BizTypeEnum.java
 * @Package com.nhs.shop.service.transfer
 * @Description: TODO
 * @author Administrator 2016年11月15日 
 * @version V1.0   
 * @Copyright (c) 2016 苏州哪划算网络有限公司 版权所有.
 * 注意：本内容仅限于苏州哪划算网络有限有限公司 内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
package com.nhs.apiproxy.member.acc.datatype;

/**   
 * @Title: BizTypeEnum.java
 * @Package com.nhs.shop.service.transfer
 * @Description: TODO
 * @author chushubin
 * @date 2016年11月15日 下午7:15:30
 * @version V1.0   
 */
public enum BizTypeEnum {
    
    ACTIVITY_BONUS("1"),  // 活动赠送
    
    REBATE("2"),          // 返利赠送
    
    USER_CONSUME("3"),    // 用户
    
    COMMERCIAL("4"),      // 商户
    
	FREEZE_GOLD("5"),     // 冻结金币
	
	UNFREEZE_GOLD("6"),   // 解冻金币
	
    FREEZE_SILVER("7"),   // 冻结银币
    
    UNFREEZE_SILVER("8"); // 解冻银币
    
    private final String value;
    
    private BizTypeEnum(String value) {
        this.value = value;
    }
    
    public String getValue() {
        return value;
    }
}
