/*******************************************************************************
a * @Title: TransferLog.java
 * @Package com.nhs.shop.dao.legend.transfer
 * @Description: TODO
 * @author Administrator 2016年11月15日 
 * @version V1.0   
 * @Copyright (c) 2016 苏州哪划算网络有限公司 版权所有.
 * 注意：本内容仅限于苏州哪划算网络有限有限公司 内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
package com.nhs.apiproxy.member.acc.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nhs.apiproxy.member.acc.entity.TransferLogEntity;


/**   
 * @Title: TransferLog.java
 * @Package com.nhs.shop.dao.legend.transfer
 * @Description: TODO
 * @author chushubin
 * @date 2016年11月15日 下午7:28:34
 * @version V1.0   
 */
@Repository
public interface TransferLogDao extends JpaRepository<TransferLogEntity, Integer>{

}
