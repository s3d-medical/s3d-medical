package com.nhs.apiproxy.member.acc.datatype;

/**
 * 
 * @Title: OrderTypeEnum.java
 * @Package com.nhs.shop.service.transfer
 * @Description: 订单类型枚举类
 * @author sungs
 * @date 2016年10月25日 上午10:18:08
 * @version V1.0
 */
public enum OrderTypeEnum {

    /**
     * 充值
     */
    ORDER_TYPE_IMPREST("1"),

    /**
     * 商城赠送
     */
    ORDER_TYPE_SHOP_LARGESS("2"),

    /**
     * 活动赠送
     */
    ORDER_TYPE_ACTIVITY_LARGESS("3"),

    /**
     * 提取金币
     */
    ORDER_TYPE_GOLD("4"),

    /**
     * 账户交易
     */
    ORDER_TYPE_TRANSFER("5"),

    /**
     * 提现
     */
    ORDER_TYPE_APPLY_HANDLER("6"),

    /**
     * 提现处理
     */
    ORDER_TYPE_APPLY("7"),

    /**
     * 币种转换
     */
    ORDER_TYPE_CONVERT("8"),

    /**
     * 营业员佣金
     */
    ORDER_TYPE_ASSISTANT_COMMISSION("9");
    
    private final String type;

    private OrderTypeEnum(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }
}