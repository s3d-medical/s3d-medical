/*******************************************************************************
 * @Title: package-info.java
 * @Package com.nhs.shop.service.transfer
 * @Description: TODO
 * @author Administrator 2016年11月15日 
 * @version V1.0   
 * @Copyright (c) 2016 苏州哪划算网络有限公司 版权所有.
 * 注意：本内容仅限于苏州哪划算网络有限有限公司 内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
/**   
 * @Title: package-info.java
 * @Package com.nhs.shop.service.transfer
 * @Description: TODO
 * @author chushubin
 * @date 2016年11月15日 下午6:18:39
 * @version V1.0   
 */
package com.nhs.apiproxy.member;