package com.nhs.apiproxy.member.user.dto;

import java.io.Serializable;

/**
 * 发货地址.
 * @author wind.chen
 *
 */
public class UsrAddrDto implements Serializable {
	private static final long serialVersionUID = -6174842416924704193L;
	private Integer id;
	/**
	 * 系统用户(购买人)
	 */
	private String userId;
	private String mobileNo;

	/**
	 * 收货人
	 */
	private String  receiver;
	private Integer provinceId;
	private Integer cityId;
	private Integer districtId;
	private String isDefault;
	private String address;
	/**
	 * 常用地址.
	 */
	private String headAddress;
	private String version;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public Integer getProvinceId() {
		return provinceId;
	}
	public void setProvinceId(Integer provinceId) {
		this.provinceId = provinceId;
	}
	public Integer getCityId() {
		return cityId;
	}
	public void setCityId(Integer cityId) {
		this.cityId = cityId;
	}
	public Integer getDistrictId() {
		return districtId;
	}
	public void setDistrictId(Integer districtId) {
		this.districtId = districtId;
	}
	public String getReceiver() {
		return receiver;
	}
	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}
	public String getIsDefault() {
		return isDefault;
	}
	public void setIsDefault(String isDefault) {
		this.isDefault = isDefault;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getHeadAddress() {
		return headAddress;
	}
	public void setHeadAddress(String headAddress) {
		this.headAddress = headAddress;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}

}
