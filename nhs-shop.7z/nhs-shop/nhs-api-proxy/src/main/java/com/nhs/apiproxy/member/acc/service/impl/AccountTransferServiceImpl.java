/*******************************************************************************
 * @Title: AccountTransferServiceImpl.java
 * @Package com.nhs.shop.service.transfer
 * @Description: TODO
 * @author Administrator 2016年11月15日 
 * @version V1.0   
 * @Copyright (c) 2016 苏州哪划算网络有限公司 版权所有.
 * 注意：本内容仅限于苏州哪划算网络有限有限公司 内部传阅，禁止外泄以及用于其他商业目的!
 ******************************************************************************/
package com.nhs.apiproxy.member.acc.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import com.nhs.apiproxy.UnifiedInApiReqHelper;
import com.nhs.apiproxy.UnifiedInApiResultHelper;
import com.nhs.apiproxy.member.acc.dao.TransferLogDao;
import com.nhs.apiproxy.member.acc.datatype.BizTypeEnum;
import com.nhs.apiproxy.member.acc.datatype.CurrencyEnum;
import com.nhs.apiproxy.member.acc.datatype.OrderTypeEnum;
import com.nhs.apiproxy.member.acc.dto.Balance;
import com.nhs.apiproxy.member.acc.dto.UserAccDto;
import com.nhs.apiproxy.member.acc.dto.UserAllAccDto;
import com.nhs.apiproxy.member.acc.entity.TransferLogEntity;
import com.nhs.apiproxy.member.acc.service.AccountTransferService;
import com.nhs.core.common.NhsConstant;
import com.nhs.core.mapper.JsonMapper;
import com.nhs.core.rest.HttpClientUtils;
import com.nhs.core.utils.common.IpUtils;
import com.nhs.core.web.WebRequestException;

/**   
 * @Title: AccountTransferServiceImpl.java
 * @Package com.nhs.shop.service.transfer
 * @Description: TODO
 * @author chushubin
 * @date 2016年11月15日 下午7:30:25
 * @version V1.0   
 */
@Service("accountTransferService")
public class AccountTransferServiceImpl implements AccountTransferService {

    private static final Logger LOG = LoggerFactory.getLogger(AccountTransferServiceImpl.class);

    private static final String SUCCESS = "1";

    @Autowired
    private TransferLogDao transferLogDao;

    @Value("${rest.member.account.transfer.url}")
    private String accTransferUrl;

    /**
     * 获取资金账户的url
     */
    @Value("${rest.member.account.findUserAccUrl.url}")
    private String findUserAccUrl;

    /**
     * 获取command
     * @param balaceList
     * @return
     */
    public static String genarateTransferCommand(List<Balance> balances) {
        if (balances == null || balances.isEmpty()) {
            return OrderTypeEnum.ORDER_TYPE_TRANSFER.getType();
        }
        StringBuilder sb = new StringBuilder();
        for (Balance balance : balances) {
            BigDecimal amount = new BigDecimal(balance.getAmount());
            String currency = balance.getCurrency();
            if (amount.compareTo(BigDecimal.ZERO) < 0) {
                sb.append(currency).append("2");
            } else if (amount.compareTo(BigDecimal.ZERO) > 0) {
                sb.append(currency).append("1");
            } else {
                sb.append(currency).append("0");
            }
        }
        return sb.toString();
    }

    @SuppressWarnings({ "unchecked", "deprecation" })
    @Override
    @Transactional
    public boolean transfer(String orderId, String userId, List<Balance> balances, BizTypeEnum BizType,
            OrderTypeEnum orderType, String comments) {
        Assert.notNull(orderId, "orderId must not be null");
        Assert.hasLength(orderId);
        Assert.notNull(userId, "userId must not be null");
        Assert.hasLength(userId);
        if (balances == null || balances.isEmpty()) {
            throw new IllegalArgumentException("Balances must not be empty");
        }

        String command = AccountTransferServiceImpl.genarateTransferCommand(balances);
        String bizData = JsonMapper.nonDefaultMapper().toJson(balances);
        Map<String, Object> params = new HashMap<>();
        params.put("partnerOrderNo", orderId);
        params.put("userId", userId);
        params.put("businessData", bizData);
        params.put("command", command);
        params.put("clientIp", IpUtils.getHostIp());
        params = UnifiedInApiReqHelper.signParam(params);

        LOG.info("Params :" + params);

        TransferLogEntity log = new TransferLogEntity();
        log.setUserId(userId);
        log.setOrderId(orderId);
        log.setBizData(bizData);
        log.setBizType(BizType.getValue());
        log.setOrderType(orderType.getType());
        log.setCreate(new Date());

        try {
            // 调用远程服务
            String str = HttpClientUtils.post(this.accTransferUrl, params);
            Map<String, Object> response = JsonMapper.nonDefaultMapper().fromJson(str, Map.class);
            log.setComments(comments + " 成功");
            // 如果返回失败
            if (!SUCCESS.equals(ObjectUtils.toString(response.get("code")))) {
                log.setComments(comments + ";" + response.get("code") + ":" + response.get("msg"));
                return false;
            }
            return true;
        } catch (Exception e) {
            LOG.error(e.getLocalizedMessage(), e);
            log.setComments(comments + " ： " + e.getLocalizedMessage());
        } finally {
            this.transferLogDao.saveAndFlush(log);
        }
        return false;
    }

    @Override
    public void rebateSilver(String userId, String orderNo, BigDecimal amount) {
        if (amount == null || amount.compareTo(BigDecimal.ZERO) < 0) {
            return;
        }
        List<Balance> balances = new ArrayList<>();
        balances.add(new Balance(CurrencyEnum.CURRENCY_SILVER_COIN.getCurrency(), amount)); // + 佰德砖
        boolean ret = this.transfer(orderNo, userId, balances, BizTypeEnum.REBATE,
                OrderTypeEnum.ORDER_TYPE_SHOP_LARGESS, "返利佰德钻");
        if (!ret) {
            throw new WebRequestException("返利佰德钻失败");
        }
    }

    @Override
    public void rebateFrozenSilver(String userId, String orderNo, BigDecimal amount) {
        if (amount == null || amount.compareTo(BigDecimal.ZERO) < 0) {
            return;
        }
        List<Balance> balances = new ArrayList<>();
        balances.add(new Balance(CurrencyEnum.CURRENCY_FORBIDEN_SILVER_COIN.getCurrency(), amount)); // + 冻结佰德砖
        boolean ret = this.transfer(orderNo, userId, balances, BizTypeEnum.REBATE,
                OrderTypeEnum.ORDER_TYPE_SHOP_LARGESS, "返利冻结佰德钻");
        if (!ret) {
            throw new WebRequestException("返利冻结佰德钻失败");
        }
    }

    @Override
    public void rebateGold(String userId, String orderNo, BigDecimal amount) {
        if (amount == null || amount.compareTo(BigDecimal.ZERO) < 0) {
            return;
        }
        List<Balance> balances = new ArrayList<>();
        balances.add(new Balance(CurrencyEnum.CURRENCY_GOLD_COIN.getCurrency(), amount)); // + 佰德券
        boolean ret = this.transfer(orderNo, userId, balances, BizTypeEnum.REBATE,
                OrderTypeEnum.ORDER_TYPE_SHOP_LARGESS, "返利佰德券");
        if (!ret) {
            throw new WebRequestException("返利佰德券失败");
        }
    }

    @Override
    public void rebateFrozenGold(String userId, String orderNo, BigDecimal amount) {
        if (amount == null || amount.compareTo(BigDecimal.ZERO) < 0) {
            return;
        }
        List<Balance> balances = new ArrayList<>();
        balances.add(new Balance(CurrencyEnum.CURRENCY_FORBIDEN_GOLD_COIN.getCurrency(), amount)); // + 冻结佰德券
        boolean ret = this.transfer(orderNo, userId, balances, BizTypeEnum.REBATE,
                OrderTypeEnum.ORDER_TYPE_SHOP_LARGESS, "冻结返利佰德券");
        if (!ret) {
            throw new WebRequestException("冻结返利佰德券失败");
        }
    }

    @Override
    public void depositUserBizAccount(String userId, String orderNo, BigDecimal amount) {
        if (amount == null || amount.compareTo(BigDecimal.ZERO) < 0) {
            return;
        }
        List<Balance> balances = new ArrayList<>();
        balances.add(new Balance(CurrencyEnum.CURRENCY_BUSINESS_BALANCE.getCurrency(), amount)); // + 商家余额
        boolean ret = this.transfer(orderNo, userId, balances, BizTypeEnum.COMMERCIAL,
                OrderTypeEnum.ORDER_TYPE_TRANSFER, "增加用户的企业账户余额");
        if (!ret) {
            throw new WebRequestException("增加用户的企业账户余额失败");
        }
    }
    
    @Override
    public void depositUserAccount(String userId, String orderNo, BigDecimal amount) {
        if (amount == null || amount.compareTo(BigDecimal.ZERO) < 0) {
            return;
        }
        List<Balance> balances = new ArrayList<>();
        balances.add(new Balance(CurrencyEnum.CURRENCY_PERSONAL_BALANCE.getCurrency(), amount)); // + 商家余额
        boolean ret = this.transfer(orderNo, userId, balances, BizTypeEnum.COMMERCIAL,
                OrderTypeEnum.ORDER_TYPE_TRANSFER, "增加用户的企业账户余额");
        if (!ret) {
            throw new WebRequestException("增加用户的企业账户余额失败");
        }
    }

    @Override
    public void unfreezeSilver(String userId, String orderNo, BigDecimal amount) {
        if (amount == null || amount.compareTo(BigDecimal.ZERO) < 0) {
            return;
        }
        List<Balance> balances = new ArrayList<>();
        balances.add(new Balance(CurrencyEnum.CURRENCY_FORBIDEN_SILVER_COIN.getCurrency(), amount.negate())); // - 冻结佰德砖
        balances.add(new Balance(CurrencyEnum.CURRENCY_SILVER_COIN.getCurrency(), amount)); // + 佰德砖
        boolean ret = this.transfer(orderNo, userId, balances, BizTypeEnum.UNFREEZE_SILVER,
                OrderTypeEnum.ORDER_TYPE_TRANSFER, "解冻冻结佰德钻");
        if (!ret) {
            throw new WebRequestException("解冻冻结佰德钻失败");
        }
    }

    @Override
    public void unfreezeGold(String userId, String orderNo, BigDecimal amount) {
        if (amount == null || amount.compareTo(BigDecimal.ZERO) < 0) {
            return;
        }
        List<Balance> balances = new ArrayList<>();
        balances.add(new Balance(CurrencyEnum.CURRENCY_FORBIDEN_GOLD_COIN.getCurrency(), amount.negate())); // - 冻结佰德券
        balances.add(new Balance(CurrencyEnum.CURRENCY_GOLD_COIN.getCurrency(), amount)); // + 佰德券
        boolean ret = this.transfer(orderNo, userId, balances, BizTypeEnum.UNFREEZE_SILVER,
                OrderTypeEnum.ORDER_TYPE_TRANSFER, "解冻冻结佰德券");
        if (!ret) {
            throw new WebRequestException("解冻冻结佰德钻失败");
        }
    }

    @Override
    public List<UserAccDto> findUserAccList(String userId) {
        // check.
        Assert.isTrue(!StringUtils.isBlank(userId), "用户id不能为空. ");
        // request.
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("userId", userId);
        params = UnifiedInApiReqHelper.signParam(params);

        try {
            String jsonData = HttpClientUtils.post(this.findUserAccUrl, params);
            List<UserAccDto> userAccDtos = UnifiedInApiResultHelper.parseDataToList(jsonData, UserAccDto.class);
            return userAccDtos;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public UserAllAccDto findUserAllAcc(String userId) {
        List<UserAccDto> accList = this.findUserAccList(userId);
        UserAllAccDto userAllAccDto = new UserAllAccDto(accList);
        return userAllAccDto;
    }

    /**
     * <p>Description:预冻佰德券 </p>
     * @author chushubin 2016年11月21日 
     * @param userId
     * @param orderNo
     * @param amount
     * @return
     * @see com.nhs.apiproxy.member.acc.service.AccountTransferService#freezeGold(java.lang.String, java.lang.String, java.math.BigDecimal)
     */
    @Override
    public boolean freezeGold(String userId, String orderNo, BigDecimal amount) {
        if (amount == null || amount.compareTo(BigDecimal.ZERO) < 0) {
            return true;
        }
        // 构建转换货币类型
        List<Balance> balances = new ArrayList<>();
        balances.add(new Balance(CurrencyEnum.CURRENCY_GOLD_COIN.getCurrency(), amount.negate())); // - 佰德券
        balances.add(new Balance(CurrencyEnum.CURRENCY_FORBIDEN_GOLD_COIN.getCurrency(), amount)); // + 冻结佰德券
        if (LOG.isDebugEnabled()) {
            LOG.debug("balances : " + balances);
        }

        boolean flag = this.transfer(orderNo, userId, balances, BizTypeEnum.USER_CONSUME,
                OrderTypeEnum.ORDER_TYPE_TRANSFER, "创建订单 - 预冻佰德券");
        if (!flag) {
            // 个人账户抵用券余额不足
            // 调用远程transfer接口时，所有的错误，都返回"抵用券数量不足"提示
            // TODO 这个地方捕获的异常，还应该区分一下，给用户的提醒信息能够更加友好
            throw new WebRequestException("佰德券券数量不足");
        }
        return true;
    }

    /**
     * <p>Description:解冻确认佰德券 </p>
     * @author chushubin 2016年11月21日 
     * @param userId
     * @param orderNo
     * @param amount
     * @return
     */
    @Override
    public boolean commitGold(String userId, String orderNo, BigDecimal amount) {
        if (amount == null || amount.compareTo(BigDecimal.ZERO) < 0) {
            return true;
        }
        List<Balance> balances = new ArrayList<>();
        balances.add(new Balance(CurrencyEnum.CURRENCY_FORBIDEN_GOLD_COIN.getCurrency(), amount.negate())); // - 冻结佰德券
        boolean ret = this.transfer(orderNo, userId, balances, BizTypeEnum.USER_CONSUME,
                OrderTypeEnum.ORDER_TYPE_TRANSFER, "支付成功，冻结的佰德券直接扣除");
        if (!ret) {
            throw new WebRequestException("扣除冻结佰德券失败");
        }
        return false;
    }

    @Override
    public boolean commitGoldByRMB(String userId, String orderNo, BigDecimal amount) {
        BigDecimal coupon = (amount == null ? new BigDecimal("0.00") : amount);
        coupon = coupon.multiply(new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE));
        LOG.info("消费的冻结的佰德劵数量=" + coupon.toString());
        this.commitGold(userId, orderNo, coupon);
        return false;
    }

    /**
     * <p>Description:解冻取消佰德券 </p>
     * @author chushubin 2016年11月21日 
     * @param userId
     * @param orderNo
     * @param amount
     * @return
     * @see com.nhs.apiproxy.member.acc.service.AccountTransferService#cancelGold(java.lang.String, java.lang.String, java.math.BigDecimal)
     */
    @Override
    public boolean cancelGold(String userId, String orderNo, BigDecimal amount) {
        List<Balance> balances = new ArrayList<>();
        balances.add(new Balance(CurrencyEnum.CURRENCY_GOLD_COIN.getCurrency(), amount)); // + 佰德券
        balances.add(new Balance(CurrencyEnum.CURRENCY_FORBIDEN_GOLD_COIN.getCurrency(), amount.negate())); // - 冻结佰德券
        if (LOG.isDebugEnabled()) {
            LOG.debug("balances : " + balances);
        }
        boolean flag = this.transfer(orderNo, userId, balances, BizTypeEnum.USER_CONSUME,
                OrderTypeEnum.ORDER_TYPE_TRANSFER, "解冻取消冻结的佰德券");
        if (!flag) {
            throw new WebRequestException("解冻取消冻结的佰德券失败，请重试");
        }
        return true;
    }

    /**
     * <p>Description:TODO </p>
     * @author chushubin 2016年11月21日 
     * @param userId
     * @param orderNo
     * @param amount
     * @return
     * @see com.nhs.apiproxy.member.acc.service.AccountTransferService#deductYueBao(java.lang.String, java.lang.String, java.math.BigDecimal)
     */
    @Override
    public boolean deductYueBao(String userId, String orderNo, BigDecimal amount) {
        List<Balance> balances = new ArrayList<>();
        balances.add(new Balance(CurrencyEnum.CURRENCY_PERSONAL_BALANCE.getCurrency(), amount.negate()));
        boolean ret = this.transfer(orderNo, userId, balances, BizTypeEnum.USER_CONSUME,
                OrderTypeEnum.ORDER_TYPE_TRANSFER, "扣减用户积蓄宝余额");
        if (!ret) {
            // 如果扣费失败，抛出您积蓄宝余额不足
            throw new WebRequestException("您积蓄宝余额不足");
        }
        return true;
    }

    @Override
    public boolean addCommissionSilver(String userId, String orderNo, BigDecimal sliver) {
        Assert.isTrue(!StringUtils.isEmpty(userId), "添加佣金时, userId不能为空.");
        Assert.isTrue(!StringUtils.isEmpty(orderNo), "订单号不能为空");
        Assert.isTrue(sliver != null && sliver.compareTo(BigDecimal.ZERO) >= 0, "添加的佣金必须>0.00");

        List<Balance> balances = new ArrayList<>();
        balances.add(new Balance(CurrencyEnum.CURRENCY_COMMISSION_SILVER_COIN.getCurrency(), sliver));
        return this.transfer(orderNo, userId, balances, BizTypeEnum.ACTIVITY_BONUS,
                OrderTypeEnum.ORDER_TYPE_ASSISTANT_COMMISSION, "佣金送钻.");
    }

}
