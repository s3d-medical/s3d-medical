package com.nhs.apiproxy.member.user.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import com.nhs.apiproxy.UnifiedInApiReqHelper;
import com.nhs.apiproxy.UnifiedInApiResultHelper;
import com.nhs.apiproxy.member.user.dto.UsrAddrDto;
import com.nhs.apiproxy.member.user.service.UserServiceApi;
import com.nhs.core.rest.HttpClientUtils;

@Service
public class UserServiceApiImpl implements UserServiceApi {
	private static final Logger LOG = LoggerFactory
			.getLogger(UserServiceApiImpl.class);

	@Value("${rest.member.shipaddr.findShipAddr.url}")
	private String findShipAddrUrl;
	
	@Value("${rest.member.shipaddr.findDefaultShipAddr.url}")
	private String findDefaultShipAddrUrl;
	
	@Override
	public UsrAddrDto findShipAddrById(String userId, Integer addrId) {
		// check get address
		Assert.isTrue(userId != null, "购买用户id不能为空.");
		Assert.isTrue(addrId != null, "发货地址id不能为空.");
		try {
			// param
			Map<String, Object> params = new HashMap<>();// params
			params.put("userId", userId); // 用户id
			params.put("subId", addrId); // 地址id
			params = UnifiedInApiReqHelper.signParam(params);
			// data
			String jsonData = HttpClientUtils.post(this.findShipAddrUrl, params);
			UsrAddrDto usrAddrDto = UnifiedInApiResultHelper.parseDataToObj(jsonData, UsrAddrDto.class);
			return usrAddrDto;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public UsrAddrDto findDefaultShipAddrById(String userId) {
		// check get address
		Assert.isTrue(userId != null, "购买用户id不能为空.");
		try {
			// param
			Map<String, Object> params = new HashMap<>();// params
			params.put("userId", userId); // 用户id
			params = UnifiedInApiReqHelper.signParam(params);
			// data findShipAddrUrl
			String jsonData = HttpClientUtils.post(this.findDefaultShipAddrUrl, params); 
			UsrAddrDto usrAddrDto = UnifiedInApiResultHelper.parseDataToObj(jsonData,
					UsrAddrDto.class);
			return usrAddrDto;
		} catch (Exception e) {
			throw new RuntimeException("查找用户默认发货地址出错.", e);
		}
	}
}
