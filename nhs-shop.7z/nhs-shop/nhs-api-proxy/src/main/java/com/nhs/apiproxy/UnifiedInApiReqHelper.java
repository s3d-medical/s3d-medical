
package com.nhs.apiproxy;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.nhs.core.rest.MemberEncryptUtil;

/**
 * 辅助类:内部子系统rest api调用时， 签名处理. 
 * @author wind.chen
 *
 */
@Service
public class UnifiedInApiReqHelper {
	private static final Logger LOG = LoggerFactory.getLogger(UnifiedInApiReqHelper.class);

	private static String accessId;

	private static String accessType;

	private static String accessKey;
	
	private static String payKey;

	/**
	 * 对请求参数sign.
	 * @Title: signParam
	 * @Desc: 
	 * @author wind.chen 2016年11月24日 下午7:43:26
	 *
	 * @param params
	 * @return
	 * @throws
	 */
	public static Map<String, Object> signParam(Map<String, Object> params) {
		params.put("accessId", accessId);
		params.put("accessType", accessType);
		LOG.info("Params :" + params);
		String sign = MemberEncryptUtil.encode(params, accessKey);
		params.put("sign", sign);
		LOG.info("Sign :" + sign);
		return params;
	}
	
	/**
	 * 验证给定的签名和根据verifiedObjInMap给定的值计算出来的sign是否相同. 
	 * @Title: verifySign
	 * @Desc: 
	 * @author wind.chen 2016年11月25日 上午9:51:31
	 *
	 * @param verifiedSign            已生成的sign内容
	 * @param verifiedParam        参与sign计算的对象, 保证该对象
	 * @return
	 * @throws
	 */
	public static boolean verifyParamSign(String verifiedSign,
			Map<String, Object> verifiedParam) {
		// 1.check.
		if (verifiedParam == null || verifiedSign == null) {
			return false;
		}
		LOG.info("传入sign=" + verifiedSign);
		
		//2 calculate sign.
		String calSign = MemberEncryptUtil.encode(verifiedParam, payKey);
		LOG.info("计算出的sign=" + calSign);

		//3 compare sign.
		boolean compared = calSign.equalsIgnoreCase(verifiedSign);
		return compared;
	}
	
	/**
	 * 针对传递过来的sign, 进行验证是否正确. 
	 * 
	 * @Title: verifySign
	 * @Desc:
	 * @author wind.chen 2016年11月25日 上午9:48:50
	 * @param map  Map 必须包含一个key=sign表示已生成的sign内容
	 * @return
	 * @throws
	 */
	public static boolean verifyParamSign(Map<String, Object> map){
		//1.check.
		if(map == null){
			return false;
		}
		// calculate sign.
		String sign = (String)map.get("sign");
		LOG.info("map content size =" + map.size());
		
		Map<String, Object> signMap = new HashMap<String, Object>();
		signMap.putAll(map);
		signMap.remove("sign");
		LOG.info("map content size =" + signMap.size());
    	return verifyParamSign(sign, signMap);
	}

	@Value("${rest.member.accessId}")
	public void setAccessId(String accessId) {
		UnifiedInApiReqHelper.accessId = accessId;
	}
	
	@Value("${rest.member.accessType}")
	public void setAccessType(String accessType) {
		UnifiedInApiReqHelper.accessType = accessType;
	}
	
	@Value("${rest.member.accessKey}")
	public void setAccessKey(String accessKey) {
		UnifiedInApiReqHelper.accessKey = accessKey;
	}
	
	@Value("${rest.payment.key}")
	public void setPayKey(String payKey) {
		UnifiedInApiReqHelper.payKey = payKey;
	}
}
