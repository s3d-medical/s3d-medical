package com.nhs.task.task;

import java.util.Date;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.nhs.task.service.StoreOrderTaskService;

/**
 *  
 * 商超订单发送到邮箱
 * @author shiy
 *
 */
@Service
public class StoreOrderTask {

    @Resource
    StoreOrderTaskService storeOrderTaskService;

    public void excuteTimer() {
        try {
            System.err.println("========================商超订单记录任务开始执行" + new Date());
            storeOrderTaskService.dealStoreOrderTask();
            System.err.println("========================商超订单记录任务执行结束" + new Date());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
