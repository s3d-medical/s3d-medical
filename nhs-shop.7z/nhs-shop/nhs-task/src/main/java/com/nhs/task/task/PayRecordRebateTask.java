/**
 * 商超支付生成的支付记录
 * 对支付失败或者未支付的支付记录，扣除的抵用券做返还
 */
package com.nhs.task.task;

import java.util.Date;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.nhs.task.service.taskprocess.ClearRebatePayRecordProcess;

/**
 * @author Administrator
 *
 */
@Service
public class PayRecordRebateTask {
	
	@Resource
	ClearRebatePayRecordProcess clearRebatePayRecordProcess;
	
	public void excuteTimer() {
        try {
            System.err.println("========================解冻未支付的抵用的佰德券任务开始执行" + new Date());
            clearRebatePayRecordProcess.dealRebate();
            System.err.println("========================解冻未支付的抵用的任务执行结束" + new Date());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	
}
