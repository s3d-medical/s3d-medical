/**
 * 
 */
package com.nhs.task.task;

import java.util.Date;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.nhs.task.service.taskprocess.ClearShopOrderProcess;

/**
 * @author Administrator
 *
 */
@Service
public class ConfirmShopOrderTask {
	@Resource
	ClearShopOrderProcess clearShopOrderProcess;
	
	public void excuteTimer() {
        try {
            System.err.println("========================7天未收货的订单自动确认收货任务开始执行" + new Date());
            clearShopOrderProcess.handleUnAcklodge();
            System.err.println("========================7天未收货的订单自动确认收货任务执行结束" + new Date());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
