package com.nhs.task.common;

import org.springframework.stereotype.Service;

@Service
public class DropdownListService {

}
