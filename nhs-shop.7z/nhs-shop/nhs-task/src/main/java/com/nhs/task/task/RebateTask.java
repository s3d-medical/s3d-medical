/**
 * 2013-7-10
 * kl-base
 */
package com.nhs.task.task;

import java.util.Date;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.nhs.task.service.taskprocess.ClearRebateUnfreezeProcess;

/**
 * <pre>
 * 	<h1>处理冻结金币、银币定时任务<h1>
 * 
 * 	1.处理冻结银币
 *  2.处理冻结金币
 * </pre>
 * @author Administrator
 *
 */
@Service
public class RebateTask {

    @Resource
    ClearRebateUnfreezeProcess clearRebateUnfreezeProcess;

    // @Scheduled(cron = "0 48 11 * * ?") // 每天定点执行一次
    // @Scheduled(cron = "0/5 * * * * ? ") // 每5秒执行一次
    public void excuteTimer() {
        try {
            System.err.println("========================解冻任务开始执行" + new Date());
            clearRebateUnfreezeProcess.dealRebate();
            clearRebateUnfreezeProcess.dealGoldRebate();
            System.err.println("========================解冻任务执行结束" + new Date());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
