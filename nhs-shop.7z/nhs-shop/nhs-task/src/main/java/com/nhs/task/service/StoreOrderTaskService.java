package com.nhs.task.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nhs.core.orm.Page;
import com.nhs.core.utils.common.DateUtils;
import com.nhs.core.utils.common.StringHelper;
import com.nhs.shop.dao.legend.store.StoreOrderItemDao;
import com.nhs.shop.dao.legend.store.StoreOrderJdbcDao;
import com.nhs.shop.dao.task.StoreOrderSettingDao;
import com.nhs.shop.dao.task.TaskMailSendRecordDao;
import com.nhs.shop.entry.task.MailSendRecord;
import com.nhs.shop.entry.task.StoreOrderSetting;
import com.nhs.shop.service.common.service.ConfigService;
import com.nhs.shop.util.ExcelUtils;
import com.nhs.task.util.MailUtils;

/**
 * 商超订单记录 service
 * @Title: StoreOrderTaskService.java
 * @Package com.nhs.task.service
 * @Description: TODO
 * @author shiy
 * @date 2016年12月13日 上午9:23:44
 * @version V1.0
 */
@Service
public class StoreOrderTaskService {

    @Autowired
    private StoreOrderItemDao storeOrderItemDao;

    @Autowired
    private ConfigService configService;

    @Autowired
    private StoreOrderSettingDao storeOrderSettingDao;

    @Autowired
    private StoreOrderJdbcDao storeOrderJdbcDao;

    @Autowired
    private TaskMailSendRecordDao taskMailSendRecordDao;

    private static final int PAGE_SIZE = 5000;

    private static final String TITLE = "超市订单记录";

    // private static final String CONTENT = "Dear all:<br>&nbsp;&nbsp;&nbsp;&nbsp;请查收附件\"超市订单记录\"，谢谢。";
    private static final String CONTENT = "Dear all:\r     请查收附件\"超市订单记录\"，谢谢。";

    public boolean dealStoreOrderTask() throws Exception {
        boolean res = false;
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, -1);
        SimpleDateFormat sdfdName = new SimpleDateFormat("yyyyMMdd");
        String titleDate = sdfdName.format(calendar.getTime());
        MailSendRecord mailSendRecord = taskMailSendRecordDao
                .findMailSendRecord(MailSendRecord.TypeEnum.STOREORDER.toString(), titleDate);
        if (mailSendRecord != null) {
            System.err.println("商超订单记录已经处理");
            return false;
        } else {
            res = true;
        }
        List<StoreOrderSetting> sosList = storeOrderSettingDao
                .findStoreOrderSetting(StoreOrderSetting.StateEnum.ENABLE.toString());
        if (res && sosList != null && sosList.size() > 0) {
            String exportPath = configService.getDownloadOrderRecordPath();
            String subject = TITLE + titleDate;
            String sourceFilePath = exportPath + File.separator + titleDate;
            String templatePath = configService.getOrderTemplatePath();
            for (StoreOrderSetting sos : sosList) {
                String shopId = sos.getShopId();
                String mailTo = sos.getMailTo();
                System.out.println("***********商超哪划算记录生成Excel开始" + new Date());
                String fileOutPath = sourceFilePath + File.separator + shopId + File.separator + subject + ".xlsx";
                this.buildExcel(NumberUtils.toInt(shopId), templatePath, fileOutPath);
                System.out.println("***********商超哪划算记录生成Excel结束" + new Date());
                MailSendRecord msr = new MailSendRecord();
                msr.setCreateTime(titleDate);
                msr.setFileFlag(MailSendRecord.flagEnum.fail.toString());
                msr.setSendFlag(MailSendRecord.flagEnum.fail.toString());
                msr.setTaskType(MailSendRecord.TypeEnum.STOREORDER.toString());
                if (this.mailToDes(mailTo, subject.toString(), CONTENT, fileOutPath)) {
                    msr.setSendFlag(MailSendRecord.flagEnum.success.toString());
                    try {
                        deleteAllFilesOfDir(new File(exportPath));
                    } catch (Exception ex) {
                        System.err.println("*******删除发送文件异常：" + ex);
                    }
                }
                // if(this.packageExcels(sourceFilePath+File.separator+shopId, zipFilePath, subject+"_"+shopId)){
                // msr.setFileFlag(MailSendRecord.flagEnum.success.toString());
                // if(this.mailToDes(mailTo, subject.toString(),
                // CONTENT,zipFilePath+File.separator+subject+"_"+shopId+".zip")){
                // msr.setSendFlag(MailSendRecord.flagEnum.success.toString());
                // }
                // }
                taskMailSendRecordDao.save(msr);
            }

        } else {
            System.err.println("配置表中无符合信息");
            return false;
        }

        return true;
    }

    public static final String DATE_FORMAT = "yyyyMMdd";

    /*
     * private boolean packageExcels(String sourceFilePath,String zipFilePath,String fileName){ FileToZipUtil fzu=new
     * FileToZipUtil(); boolean flag = fzu.fileToZip(sourceFilePath, zipFilePath, fileName); if(flag){
     * System.out.println("文件打包成功!"); }else{ System.out.println("文件打包失败!"); } return flag; }
     */

    private boolean mailToDes(String mailTo, String subject, String content, String attachfilePath) throws Exception {
        MailUtils sendmail = new MailUtils(configService.getMailHost(), 465, 0, true,
                configService.getMailSendUserName(), configService.getMailSendPassword(), false);
        Collection col = new ArrayList();
        col.add(attachfilePath);
        try {
            sendmail.sendEmail(configService.getMailFrom(), configService.getMailFrom(), mailTo, subject, content, col);
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }

    /**
     * 生成Excel
     * @Title: buildExcel
     * @return boolean true 需要打包  false 不需要打包 
     * @author shiy
     * @date 2016年12月08日
     */
    private void buildExcel(int shopId, String templatePath, String exportPath) throws Exception {

        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, -1);
        SimpleDateFormat sdfBegin = new SimpleDateFormat("yyyy-MM-dd 00:00:00");
        SimpleDateFormat sdfEnd = new SimpleDateFormat("yyyy-MM-dd 23:59:59");
        String beginDate = sdfBegin.format(calendar.getTime());
        String endDate = sdfEnd.format(calendar.getTime());
        ExcelUtils excelUtils = new ExcelUtils(templatePath);
        Integer totalSize = 0;
        BigDecimal totalOrderAmount = new BigDecimal("0.00");
        BigDecimal totalOrderAdFee = new BigDecimal("0.00");
        BigDecimal totalGiveSilver = new BigDecimal("0.00");

        Page<Map<String, Object>> pageData = storeOrderJdbcDao.getOrderListPC(null, -1, beginDate, endDate, null, null,
                shopId, this.createPage(1, PAGE_SIZE));
        Integer totalpage = pageData.getTotalPage();
        int i = 0;
        long st = System.currentTimeMillis();
        do {
            int currentPage = i + 1;
            if (i > 0) {
                pageData = storeOrderJdbcDao.getOrderListPC(null, -1, beginDate, endDate, null, null, shopId,
                        this.createPage(currentPage, PAGE_SIZE));
            }
            List<Map<String, Object>> result = pageData.getResult();
            for (Map<String, Object> map : result) {
                totalSize++;
                List<Object> objects = new ArrayList<>();
                String orderNum = StringHelper.objectToString(map.get("order_num"), "");
                objects.add(orderNum);
                objects.add(StringHelper.objectToString(map.get("trade_no"), ""));
                BigDecimal totalmount = StringHelper.objectToBigDecimal(map.get("total_amount"), "0.00").setScale(2,
                        BigDecimal.ROUND_DOWN);
                objects.add(totalmount.toString());
                totalOrderAmount = totalOrderAmount.add(totalmount).setScale(2, BigDecimal.ROUND_DOWN);
                BigDecimal totalAdFee = storeOrderItemDao.getTotalProdAdFee(orderNum);
                objects.add(totalAdFee == null ? "0.00" : totalAdFee.toString());
                totalOrderAdFee = totalOrderAdFee.add(totalAdFee).setScale(2, BigDecimal.ROUND_DOWN);
                BigDecimal giveSilver = StringHelper.objectToBigDecimal(map.get("give_silver"), "0.00").setScale(2,
                        BigDecimal.ROUND_DOWN);
                objects.add(giveSilver.toString());
                totalGiveSilver = totalGiveSilver.add(giveSilver).setScale(2, BigDecimal.ROUND_DOWN);
                objects.add(DateUtils.date2Str((Date) map.get("pay_time")));
                objects.add(DateUtils.date2Str((Date) map.get("create_time")));
                excelUtils.writeLine(objects);
            }
            if (currentPage == totalpage || totalpage == 0) {
                break;
            }
            i++;
        } while (true);
        excelUtils.write("B2", totalSize);
        excelUtils.write("E2", totalOrderAmount);
        excelUtils.write("B3", totalOrderAdFee);
        excelUtils.write("E3", totalGiveSilver);
        FileOutputStream fileOut = null;
        try {
            File file = new File(exportPath);
            // 父目录不存在则创建
            if (!file.getParentFile().exists()) {
                file.getParentFile().mkdirs();
            }
            fileOut = new FileOutputStream(file);
        } catch (IOException e) {

        }
        excelUtils.save(fileOut);
        System.out.println("listDto.size is: " + totalSize + "，耗时：" + (System.currentTimeMillis() - st) + " ms");
        fileOut.flush();
        fileOut.close();
    }

    private static void deleteAllFilesOfDir(File path) {
        if (!path.exists())
            return;
        if (path.isFile()) {
            path.delete();
            return;
        }
        File[] files = path.listFiles();
        for (int i = 0; i < files.length; i++) {
            deleteAllFilesOfDir(files[i]);
        }
        path.delete();
    }

    private Page<Map<String, Object>> createPage(int pageNo, int pageSize) {
        Page<Map<String, Object>> page = new Page<Map<String, Object>>();
        page.setPageNo(pageNo);
        page.setPageSize(pageSize);
        return page;
    }

    public static String formatDate(java.util.Date date, String format) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(format);
        return dateFormat.format(date);
    }

}
