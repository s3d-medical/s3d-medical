package com.nhs.task.task;

import java.util.Date;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.nhs.task.service.taskprocess.ClearShopOrderProcess;

@Service
public class CancelShopOrderTask {
	
	@Resource
	ClearShopOrderProcess clearShopOrderProcess;
	
	public void excuteTimer() {
        try {
            System.err.println("========================自动取消商城未支付的订单任务开始执行" + new Date());
            clearShopOrderProcess.handleUnPay();
            System.err.println("========================自动取消商城未支付的订单任务任务执行结束" + new Date());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
