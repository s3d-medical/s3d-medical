/**
 * 2016-12-08
 * jun
 */
package com.nhs.task.task;

import java.util.Date;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.nhs.task.service.PayRecordMailService;

/**
 * @author Administrator
 * 
 */
@Service
public class PayRecordMailTask {

    @Resource
    PayRecordMailService payRecordMailService;

    // @Scheduled(cron = "0 48 11 * * ?") // 每天定点执行一次
    // @Scheduled(cron = "0/5 * * * * ? ") // 每5秒执行一次
    public void excuteTimer() {
        try {
            System.err.println("========================商超支付订单发邮件任务开始执行" + new Date());
            payRecordMailService.sendMail();
            System.err.println("========================商超支付订单发邮件任务执行结束" + new Date());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
