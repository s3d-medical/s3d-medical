package com.nhs.task.service.taskprocess;

import java.sql.Timestamp;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.nhs.core.utils.common.DateUtils;
import com.nhs.shop.dao.legend.coin.CoinFreezeGoldDao;
import com.nhs.shop.dao.legend.coin.CoinFreezeSilverDao;
import com.nhs.shop.entry.legend.coin.CoinFreezeGold;
import com.nhs.shop.entry.legend.coin.CoinFreezeSilver;
import com.nhs.task.service.UnfreezeSilverService;

/**
 * 解冻服务
 * @Title: ClearRebateUnfreezeService.java
 * @Package com.nhs.task.service
 * @Description: TODO
 * @author huxianjun
 * @date 2016年11月8日 下午1:40:41
 * @version V1.0
 */
@Service
public class ClearRebateUnfreezeProcess {

    private static Logger logger = LoggerFactory.getLogger(ClearRebateUnfreezeProcess.class);
    // 确认收货后1天结算
    private static final Integer rebate_exchange_days = 1;
    // 每天结算时间
    public static final String REBATE_TIME_FORMAT = "yyyy-MM-dd 00:00:00";

    @Autowired
    private CoinFreezeSilverDao coinFreezeSilverDao;
    
    @Autowired
    private CoinFreezeGoldDao coinFreezeGoldDao;

    @Autowired
    private UnfreezeSilverService unfreezeSilverService;

    /**
     * 处理清算
     * @Title: dealRebate
     * @Description: TODO
     * @param @throws Exception   
     * @return void 
     * @author huxianjun 2016年7月30日 
     * @throws
     */
    public void dealRebate() throws Exception {
        int pageNo = 1;
        int pageSize = 100;
        try {
            Timestamp ts = new Timestamp(System.currentTimeMillis());
            Date compareTime = DateUtils.addDays(ts, -rebate_exchange_days);
            while (true) {
                PageRequest request = new PageRequest(pageNo - 1, pageSize,
                        new Sort(new Sort.Order(Sort.Direction.DESC, "createTime")));
                Page<CoinFreezeSilver> page = coinFreezeSilverDao.findCoinFreezeSilver(compareTime, request);
                if (page.getContent() != null && page.getContent().size() > 0) {
                    for (CoinFreezeSilver silver : page.getContent()) {
                        try {
                            unfreezeSilverService.saveUnfreezeSilver(silver);
                        } catch (Exception e) {
                            logger.error("订单号："+silver.getSubNumber()+" ,银币解冻失败：" + e.getMessage() );
                            // 异常订单设置状态 3 - 此操作需要人工处理
                            silver.setUnfreezeStatus(CoinFreezeSilver.STATUE_UNFREEZE_FAILED);
                            coinFreezeSilverDao.saveAndFlush(silver);
                        }
                    }
                } else {
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("银币解冻失败");
            logger.error(e.getMessage());
        }
    }
    
    public void dealGoldRebate() throws Exception {
        int pageNo = 1;
        int pageSize = 100;
        try {
            Timestamp ts = new Timestamp(System.currentTimeMillis());
            Date compareTime = DateUtils.addDays(ts, -rebate_exchange_days);
            while (true) {
                PageRequest request = new PageRequest(pageNo - 1, pageSize,
                        new Sort(new Sort.Order(Sort.Direction.DESC, "createTime")));
                Page<CoinFreezeGold> page = coinFreezeGoldDao.findCoinFreezeGold(compareTime, request);
                if (page.getContent() != null && page.getContent().size() > 0) {
                    for (CoinFreezeGold gold : page.getContent()) {
                        try {
                            unfreezeSilverService.saveUnfreezeGold(gold);
                        } catch (Exception e) {
                            logger.info("---------清算解冻失败：" + gold.getSubNumber());
                            logger.error(e.getMessage());

                            gold.setUnfreezeStatus(CoinFreezeGold.STATUE_UNFREEZE_FAILED);
                            coinFreezeGoldDao.saveAndFlush(gold);
                        }
                    }
                } else {
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("金币解冻失败");
            logger.error(e.getMessage());
        }
    }
}
