package com.nhs.task.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nhs.core.utils.common.StringHelper;
import com.nhs.shop.dao.task.PayRecordMailDao;
import com.nhs.shop.dao.task.StoreOrderSettingDao;
import com.nhs.shop.dao.task.TaskMailSendRecordDao;
import com.nhs.shop.entry.legend.user.UsrDetail;
import com.nhs.shop.entry.task.MailSendRecord;
import com.nhs.shop.entry.task.StoreOrderSetting;
import com.nhs.shop.service.common.service.ConfigService;
import com.nhs.shop.util.ExcelUtils;
import com.nhs.task.util.MailUtils;
import com.nhs.user.service.UserService;

import jersey.repackaged.com.google.common.collect.Lists;

/**
 * 商超支付订单发邮件
 * @Title: PayRecordMailService.java
 * @author zhujun
 * @date 2016年12月08日
 */
@Service
public class PayRecordMailService {

    private static Logger logger = LoggerFactory.getLogger(PayRecordMailService.class);

    private static final String TITLE = "商超哪划算支付记录";

    // private static final String CONTENT = "Dear all:<br>&nbsp;&nbsp;&nbsp;&nbsp;请查收附件\"商超哪划算支付记录\"，谢谢。";

    private static final String CONTENT = "Dear all:\r     请查收附件\"商超哪划算支付记录\"，谢谢。";

    @Autowired
    private PayRecordMailDao payRecordDao;

    @Autowired
    private UserService userService;

    @Autowired
    private ConfigService configService;

    @Autowired
    private StoreOrderSettingDao storeOrderSettingDao;

    @Autowired
    private TaskMailSendRecordDao taskMailSendRecordDao;

    public boolean sendMail() throws Exception {
        boolean res = false;
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, -1);
        SimpleDateFormat sdfdName = new SimpleDateFormat("yyyyMMdd");
        String titleDate = sdfdName.format(calendar.getTime());
        MailSendRecord mailSendRecord = taskMailSendRecordDao
                .findMailSendRecord(MailSendRecord.TypeEnum.STOREORDERPAY.toString(), titleDate);
        if (mailSendRecord != null) {
            System.err.println("订单支付记录已经处理");
            return false;
        } else {
            res = true;
        }
        List<StoreOrderSetting> sosList = storeOrderSettingDao
                .findStoreOrderSetting(StoreOrderSetting.StateEnum.ENABLE.toString());
        if (res && sosList != null && sosList.size() > 0) {
            String exportPath = configService.getDownloadPayRecordPath();
            String subject = TITLE + titleDate;
            String sourceFilePath = exportPath + File.separator + titleDate;
            // String zipFilePath=configService.getPayRecordZipPath();
            // StringBuffer sendFilePath=zipFilePath.append(File.separator).append(subject).append(".zip");
            String templatePath = configService.getPayTemplatePath();
            for (StoreOrderSetting sos : sosList) {
                String shopId = sos.getShopId();
                String mailTo = sos.getMailTo();
                System.out.println("***********商超哪划算支付记录生成Excel开始" + new Date());
                String fileOutPath = sourceFilePath + File.separator + shopId + File.separator + subject + ".xlsx";
                this.buildExcel(NumberUtils.toInt(shopId), templatePath, fileOutPath);
                System.out.println("***********商超哪划算支付记录生成Excel结束" + new Date());
                MailSendRecord msr = new MailSendRecord();
                msr.setCreateTime(titleDate);
                msr.setFileFlag(MailSendRecord.flagEnum.fail.toString());
                msr.setSendFlag(MailSendRecord.flagEnum.fail.toString());
                msr.setTaskType(MailSendRecord.TypeEnum.STOREORDERPAY.toString());
                if (this.mailToDes(mailTo, subject.toString(), CONTENT, fileOutPath)) {
                    msr.setSendFlag(MailSendRecord.flagEnum.success.toString());
                    try {
                        deleteAllFilesOfDir(new File(exportPath));
                    } catch (Exception ex) {
                        System.err.println("*******删除发送文件异常：" + ex);
                    }
                }
                // if(this.packageExcels(sourceFilePath+File.separator+shopId, zipFilePath, subject+"_"+shopId)){
                // msr.setFileFlag(MailSendRecord.flagEnum.success.toString());
                // if(this.mailToDes(mailTo, subject.toString(),
                // CONTENT,zipFilePath+File.separator+subject+"_"+shopId+".zip")){
                // msr.setSendFlag(MailSendRecord.flagEnum.success.toString());
                // }
                // }
                taskMailSendRecordDao.save(msr);
            }

        } else {
            System.err.println("配置表中无符合信息");
            return false;
        }

        return true;

    }

    private static void deleteAllFilesOfDir(File path) {
        if (!path.exists())
            return;
        if (path.isFile()) {
            path.delete();
            return;
        }
        File[] files = path.listFiles();
        for (int i = 0; i < files.length; i++) {
            deleteAllFilesOfDir(files[i]);
        }
        path.delete();
    }

    /**
     * 生成Excel
     * @Title: buildExcel
     * @return void 
     * @author zhujun
     * @date 2016年12月08日
     */
    private void buildExcel(int shopId, String templatePath, String exportPath) throws Exception {

        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, -1);
        SimpleDateFormat sdfd = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat sdfdName = new SimpleDateFormat("yyyyMMdd");
        String yesterday = sdfd.format(calendar.getTime());
        String titleDate = sdfdName.format(calendar.getTime());
        double totalMoney = 0;
        ExcelUtils excelUtils = new ExcelUtils(templatePath);

        List<Map<String, Object>> payRecordList = payRecordDao.getPayRecord(shopId, yesterday);
        for (Map<String, Object> map : payRecordList) {
            List<Object> list = Lists.newArrayList();
            String userId = StringHelper.objectToString(map.get("user_id"), "");
            UsrDetail usrDetail = userService.findUserById(userId);
            double money = StringHelper.objectToDouble(map.get("total_money"), 0);
            totalMoney = totalMoney + money;

            list.add(StringHelper.objectToString(map.get("order_no"), ""));
            list.add(StringHelper.objectToString(map.get("payment_order_no"), ""));
            list.add(StringHelper.objectToString(map.get("payment_type"), ""));
            list.add(StringHelper.objectToString(map.get("payment_type_name"), ""));
            list.add(StringHelper.objectToDouble(map.get("total_money"), 0));
            list.add(StringHelper.objectToDouble(map.get("payment_money"), 0));
            list.add(StringHelper.objectToDouble(map.get("coupon_money"), 0));
            list.add(StringHelper.objectToString(map.get("shop_id"), ""));
            list.add(StringHelper.objectToString(map.get("shop_name"), ""));
            list.add(StringHelper.objectToString(map.get("user_id"), ""));
            list.add(StringHelper.objectToString(map.get("sub_name"), ""));
            list.add(StringHelper.objectToString(map.get("payment_state"), ""));
            list.add(StringHelper.objectToString(map.get("order_state"), ""));
            list.add(StringHelper.objectToString(map.get("payment_pay_time"), ""));
            list.add(StringHelper.objectToString(map.get("match_state"), ""));
            list.add(StringHelper.objectToString(map.get("create_time"), ""));
            list.add(StringHelper.objectToString(map.get("validate_code"), ""));
            list.add(StringHelper.objectToString(map.get("desk_no"), ""));
            list.add(StringHelper.objectToString(map.get("invalid_time"), ""));
            list.add(usrDetail == null ? "" : usrDetail.getUserMobile());
            excelUtils.writeLine(list);
        }
        excelUtils.write("A1", TITLE + titleDate);
        excelUtils.write("B2", totalMoney);
        FileOutputStream fileOut = null;
        try {
            File file = new File(exportPath);
            // 父目录不存在则创建
            if (!file.getParentFile().exists()) {
                file.getParentFile().mkdirs();
            }
            fileOut = new FileOutputStream(file);
        } catch (IOException e) {

        }
        excelUtils.save(fileOut);
        fileOut.flush();
        fileOut.close();
    }

    /*
     * private boolean packageExcels(String sourceFilePath,String zipFilePath,String fileName){ FileToZipUtil fzu=new
     * FileToZipUtil(); boolean flag = fzu.fileToZip(sourceFilePath, zipFilePath, fileName); if(flag){
     * System.out.println("文件打包成功!"); }else{ System.out.println("文件打包失败!"); } return flag; }
     */

    private boolean mailToDes(String mailTo, String subject, String content, String attachfilePath) throws Exception {
        MailUtils sendmail = new MailUtils(configService.getMailHost(), 465, 0, true,
                configService.getMailSendUserName(), configService.getMailSendPassword(), false);
        Collection col = new ArrayList();
        col.add(attachfilePath);
        try {
            sendmail.sendEmail(configService.getMailFrom(), configService.getMailFrom(), mailTo, subject, content, col);
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }
}
