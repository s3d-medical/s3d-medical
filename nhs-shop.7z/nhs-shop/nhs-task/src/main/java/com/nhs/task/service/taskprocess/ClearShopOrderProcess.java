package com.nhs.task.service.taskprocess;

import java.sql.Timestamp;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.nhs.core.utils.common.DateUtils;
import com.nhs.shop.dao.legend.shop.SubDao;
import com.nhs.shop.entry.em.order.ShopOrderStatusEnum;
import com.nhs.shop.entry.legend.shop.Sub;
import com.nhs.task.service.ShopOrderScheduledService;

/**
 * <pre>
 * 	自动取消一小时内未付款的订单
 * </pre>
 * @author Administrator
 *
 */
@Service
public class ClearShopOrderProcess{
	
	private static Logger logger = LoggerFactory.getLogger(ClearShopOrderProcess.class);
	
	@Autowired
    private SubDao subDao;
	
	@Autowired
    private ShopOrderScheduledService shopOrderScheduledService;

	/**
	 * 自动取消订单
	 */
	public void handleUnPay() {

		int pageNo = 1;
	    int pageSize = 100;
        try {
        	Timestamp ts = new Timestamp(System.currentTimeMillis());
            Date compareTime = DateUtils.dateAddMinute(ts, -60);   
            while (true) {
                PageRequest request = new PageRequest(pageNo - 1, pageSize,
                        new Sort(new Sort.Order(Sort.Direction.DESC, "updateDate")));
                Page<Sub> page = subDao.findSubToAutoOperate(compareTime,ShopOrderStatusEnum.UNPAY.getStatus(), request);
                if (page.getContent() != null && page.getContent().size() > 0) {
                    for (Sub sub : page.getContent()) {
                        try {
                        	logger.info("---------开始关闭订单：" + sub.getSubNumber());
                        	shopOrderScheduledService.saveOrderCancel(sub);
                        	logger.info("---------结束关闭订单：" + sub.getSubNumber());
                        } catch (Exception e) {
                        	sub.setUpdateDate(DateUtils.dateAddMinute(ts, 5));
                        	subDao.save(sub);
                            logger.info("---------取消订单：" + sub.getSubNumber());
                            logger.error(e.getMessage());
                        }
                    }
                } else {
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage());
        }
		 
		
	}

	/**
	 * 自动确认收货
	 */
	public void handleUnAcklodge() {
		
		int pageNo = 1;
	    int pageSize = 100;
		
		try {
			Timestamp ts = new Timestamp(System.currentTimeMillis());
	        Date compareTime = DateUtils.addDays(ts, -7);
            while (true) {
                PageRequest request = new PageRequest(pageNo - 1, pageSize,
                        new Sort(new Sort.Order(Sort.Direction.DESC, "updateDate")));
                Page<Sub> page = subDao.findSubToAutoOperate(compareTime,ShopOrderStatusEnum.CONSIGNMENT.getStatus(), request);
                if (page.getContent() != null && page.getContent().size() > 0) {
                    for (Sub sub : page.getContent()) {
                        try {
                        	logger.info("---------开始自动确认收货：" + sub.getSubNumber());
                        	shopOrderScheduledService.saveOrderConfirm(sub);
                        	logger.info("---------结束自动确认收货：" + sub.getSubNumber());
                        } catch (Exception e) {
                        	sub.setUpdateDate(DateUtils.dateAddMinute(ts,60));
                        	subDao.save(sub);
                            logger.info("---------自动确认收货出错：" +  sub.getSubNumber());
                            logger.error(e.getMessage());
                        }
                    }
                } else {
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage());
        }
		 
	}

}
