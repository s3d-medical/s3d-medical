package com.nhs.task.service;

import java.math.BigDecimal;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nhs.apiproxy.member.acc.service.AccountTransferService;
import com.nhs.core.common.NhsConstant;
import com.nhs.core.utils.common.DateUtils;
import com.nhs.shop.dao.legend.shop.SubDao;
import com.nhs.shop.dao.legend.shop.SubHistDao;
import com.nhs.shop.entry.em.order.ShopOrderStatusEnum;
import com.nhs.shop.entry.em.order.SubHistoryEnum;
import com.nhs.shop.entry.em.shop.EmRebateStatus;
import com.nhs.shop.entry.legend.shop.Sub;
import com.nhs.shop.entry.legend.shop.SubHist;
import com.nhs.shop.service.rebate.ShopRebateService;

@Service
public class ShopOrderScheduledService {
	
	private static Logger logger = LoggerFactory.getLogger(ShopOrderScheduledService.class);
	
	@Autowired
    private SubDao subDao;
	
	@Autowired
    private SubHistDao subHistDao;
	
	@Autowired
    private ShopRebateService shopRebateService;

	@Autowired
    private AccountTransferService accountTransferService;
	
	/**
	 * <pre>
	 * 	系统自动取消订单
	 * </pre>
	 * @param sub
	 * @throws Exception
	 */
	public void saveOrderCancel(Sub sub) throws Exception {
		try {
			// 1.调用远程服务
			accountTransferService.cancelGold(sub.getUserId(), sub.getSubNumber(), sub.getCouponAmount().multiply(new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE)));
			
			// 2.更改订单状态
			sub.setUpdateDate(new Date());
			sub.setStatus(ShopOrderStatusEnum.CLOSE.getStatus());
			sub.setCancelDate(new Date());
			subDao.save(sub);
			
			// 3.创建日志并保存
			SubHist subHistory = new SubHist();
			subHistory.setRecDate(new Date());
			subHistory.setSubId(sub.getSubId());
			subHistory.setStatus(SubHistoryEnum.ORDER_OVER_TIME.value());
			StringBuilder sb = new StringBuilder();
			sb.append("于").append(DateUtils.date2Str(new Date())).append("系统自动取消订单");
			subHistory.setUserName("系统自动");
			subHistory.setReason(sb.toString());
			subHistDao.save(subHistory);
		} catch (Exception e) {
			logger.error("订单号:" +sub.getSubNumber()+ ", 自动取消订单失败:" + e.getMessage());
		}
	}

	/**
	 * <pre>
	 * 	系统自动确认收货
	 * </pre>
	 * @param sub
	 * @throws Exception
	 */
	public void saveOrderConfirm(Sub sub)  throws Exception{
		try {
			// 1.更改订单状态
			sub.setUpdateDate(new Date());
			sub.setFinallyDate(new Date());
			sub.setStatus(ShopOrderStatusEnum.SUCCESS.getStatus());
			subDao.save(sub);
			
			// 2.保存记录
			SubHist subHistory = new SubHist();
			subHistory.setRecDate(new Date());
			subHistory.setSubId(sub.getSubId());
			subHistory.setStatus(SubHistoryEnum.TAKE_DELIVER_TIME.value());
			StringBuilder sb = new StringBuilder();
			sb.append("于").append(DateUtils.date2Str(new Date())).append("系统自动确认收货");
			subHistory.setUserName("系统自动");
			subHistory.setReason(sb.toString());
			subHistDao.save(subHistory);
			
			// 3.调用远程服务，解冻银币
			accountTransferService.commitGold(sub.getUserId(), sub.getSubNumber(), sub.getCouponAmount().multiply(new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE)));
            
			// 4.清算
			shopRebateService.saveSynchronizeRebate(sub, new Date());
        } catch (Exception e) {
            logger.error("订单号：" + sub.getSubNumber() + ",自动确认收货异常：" + e.getMessage());
            // 5.设置该订单状态为异常,需要人工处理
            sub.setRebateStatus(EmRebateStatus.rebate_exception.status);
            subDao.saveAndFlush(sub);
        }
	}

}
