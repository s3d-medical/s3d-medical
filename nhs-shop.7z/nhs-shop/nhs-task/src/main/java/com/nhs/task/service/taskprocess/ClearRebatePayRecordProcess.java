/**
 * 
 */
package com.nhs.task.service.taskprocess;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.nhs.shop.dao.legend.pay.PayRecordDao;
import com.nhs.shop.entry.legend.pay.PayRecord;
import com.nhs.task.service.UnfreezeSilverService;

/**
 * @author Administrator
 *
 */
@Service
public class ClearRebatePayRecordProcess {
	
	private static Logger logger = LoggerFactory.getLogger(ClearRebatePayRecordProcess.class);
	
	@Autowired
    private UnfreezeSilverService unfreezeSilverService;
	
	@Autowired
    private PayRecordDao payRecordDao;
	
	/**
     * 处理清算
     * @Title: dealRebate
     * @Description: TODO
     * @param @throws Exception   
     * @return void 
     * @author liguangrong 2016年11月23日 
     * @throws
     */
    public void dealRebate() throws Exception {
        int pageNo = 1;
        int pageSize = 100;
        try {
            Date compareTime = new Date();
            while (true) {
                PageRequest request = new PageRequest(pageNo - 1, pageSize,
                        new Sort(new Sort.Order(Sort.Direction.DESC, "createTime")));
                Page<PayRecord> page = payRecordDao.findUnPayRecord(compareTime, request);
                if (page.getContent() != null && page.getContent().size() > 0) {
                    for (PayRecord payRecord : page.getContent()) {
                        try {
                            unfreezeSilverService.saveUnfreezeForStorePayRecord(payRecord);
                        } catch (Exception e) {
                        	payRecord.setInvalidTime(compareTime);
                        	payRecordDao.save(payRecord);
                            logger.info("---------清算解冻失败：" + payRecord.getOrderNo());
                            logger.error(e.getMessage());
                        }
                    }
                } else {
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("银币解冻失败");
            logger.error(e.getMessage());
        }
    }
}
