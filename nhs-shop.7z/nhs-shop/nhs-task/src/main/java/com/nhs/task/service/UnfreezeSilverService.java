package com.nhs.task.service;

import java.math.BigDecimal;

import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nhs.apiproxy.member.acc.service.AccountTransferService;
import com.nhs.core.common.NhsConstant;
import com.nhs.shop.dao.legend.coin.CoinFreezeGoldDao;
import com.nhs.shop.dao.legend.coin.CoinFreezeSilverDao;
import com.nhs.shop.dao.legend.coin.CoinRmbGoldLogDao;
import com.nhs.shop.dao.legend.coin.CoinRmbSilverLogDao;
import com.nhs.shop.dao.legend.pay.PayRecordDao;
import com.nhs.shop.entry.em.order.PayRecordStatusEnum;
import com.nhs.shop.entry.legend.coin.CoinFreezeGold;
import com.nhs.shop.entry.legend.coin.CoinFreezeSilver;
import com.nhs.shop.entry.legend.coin.CoinRmbGoldLog;
import com.nhs.shop.entry.legend.coin.CoinRmbSilverLog;
import com.nhs.shop.entry.legend.pay.PayRecord;

/**
 * 解冻银币服务
 * 
 * @Title: UnfreezeSilverService.java
 * @Package com.nhs.task.service
 * @Description: TODO
 * @author huxianjun
 * @date 2016年11月8日 下午2:35:51
 * @version V1.0
 */
@Service
public class UnfreezeSilverService {

	private static Logger logger = LoggerFactory.getLogger(UnfreezeSilverService.class);

	@Autowired
	private CoinRmbSilverLogDao coinRmbSilverLogDao;

	@Autowired
	private CoinRmbGoldLogDao coinRmbGoldLogDao;

	@Autowired
	private CoinFreezeSilverDao coinFreezeSilverDao;

	@Autowired
	private CoinFreezeGoldDao coinFreezeGoldDao;

	@Autowired
	private PayRecordDao payRecordDao;

	@Autowired
	private AccountTransferService accountTransferService;
	
	/**
	 * <pre>
	 * 	1.调用远程服务解冻
	 *  2.更改状态
	 *  3.记录日志
	 *  <span style='color:red'><h2>注意：</h2></span>
	 *  1.此方法想完成的目标是失败回滚，正常不回滚
	 *  2.此方法需要有事务
	 *  3.上层调用不需要加事务，加上事务，此方法只要出现异常，则所有操作都回滚
	 * <pre>
	 * @param freezeSilver
	 * @throws Exception
	 */
	public void saveUnfreezeSilver(CoinFreezeSilver freezeSilver) throws Exception {
		try {
			// 1.调用远程服务
			// - 冻结佰德钻
			// + 佰德钻
			BigDecimal coins = freezeSilver.getCoinSum();
			this.accountTransferService.unfreezeSilver(freezeSilver.getUserId(), freezeSilver.getSubNumber()+"-"+freezeSilver.getId(), coins);

			// 2.更改订单状态
			freezeSilver.setUnfreezeStatus(CoinFreezeSilver.STATUE_UNFREEZE_YES);
			coinFreezeSilverDao.saveAndFlush(freezeSilver);

			// 3.记录日志,并保存日志
			CoinRmbSilverLog silverLog = new CoinRmbSilverLog();
			BeanUtils.copyProperties(silverLog, freezeSilver);
			coinRmbSilverLogDao.save(silverLog);
		} catch (Exception e) {
			logger.error("订单号："+freezeSilver.getSubNumber()+"，解冻银币出现异常：" + e.getMessage());
			// 4.异常出现，设置状态为 3 ，用于人工处理 , 或者提供接口 ，人工调用重试
			freezeSilver.setUnfreezeStatus(CoinFreezeSilver.STATUE_UNFREEZE_FAILED);
			coinFreezeSilverDao.saveAndFlush(freezeSilver);
		}
	}
	
	/**
	 * <pre>
	 * 	1.调用远程服务解冻
	 *  2.更改状态
	 *  3.记录日志
	 *  <span style='color:red'><h2>注意：</h2></span>
	 *  1.此方法想完成的目标是失败回滚，正常不回滚
	 *  2.此方法需要有事务
	 *  3.上层调用不需要加事务，加上事务，此方法只要出现异常，则所有操作都回滚
	 * <pre>
	 * @param freezeGold
	 * @throws Exception
	 */
	public void saveUnfreezeGold(CoinFreezeGold freezeGold) throws Exception {
		try {
			// 1.调用远程服务
			// - 冻结佰德券
			// + 佰德券
			// 减除冻结的，给我个人账户加上
			BigDecimal coins = freezeGold.getGoldSum();
			this.accountTransferService.unfreezeGold(freezeGold.getUserId(), freezeGold.getSubNumber()+"-"+freezeGold.getId(), coins);
			
			// 2.更新是否解冻状态
			freezeGold.setUnfreezeStatus(CoinFreezeGold.STATUE_UNFREEZE_YES);
			coinFreezeGoldDao.saveAndFlush(freezeGold);
			
			// 3.记录日志,并保存日志
			CoinRmbGoldLog goldLog = new CoinRmbGoldLog();
			BeanUtils.copyProperties(goldLog, freezeGold);
			coinRmbGoldLogDao.save(goldLog);
		} catch (Exception e) {
			logger.error("订单号："+freezeGold.getSubNumber()+"，解冻金币出现异常：" + e.getMessage());
			// 4.异常出现，设置状态为 3 ，用于人工处理 , 或者提供接口 ，人工调用重试
			freezeGold.setUnfreezeStatus(CoinFreezeGold.STATUE_UNFREEZE_FAILED);
			coinFreezeGoldDao.saveAndFlush(freezeGold);
		}

	}
	
	/**
	 * <pre>
	 * 	1.调用远程服务解冻
	 *  2.更改状态
	 *  3.记录日志
	 *  <span style='color:red'><h2>注意：</h2></span>
	 *  1.此方法想完成的目标是失败回滚，正常不回滚
	 *  2.此方法需要有事务
	 *  3.上层调用不需要加事务，加上事务，此方法只要出现异常，则所有操作都回滚
	 * <pre>
	 * @param payRecord
	 * @throws Exception
	 */
	public void saveUnfreezeForStorePayRecord(PayRecord payRecord) throws Exception {
		try {
			// 1.调用远程服务
			// - 冻结佰德券
			// + 佰德券
			BigDecimal goldNum = payRecord.getCouponMoney().multiply(new BigDecimal(NhsConstant.SYS_EXCHAGE_RATE));
			this.accountTransferService.unfreezeGold(payRecord.getUserId(), payRecord.getOrderNo(), goldNum);
			
			// 2.更改商超记录状态为关闭
			payRecord.setOrderState(PayRecordStatusEnum.CLOSED.getStatus());
			payRecordDao.saveAndFlush(payRecord);
		} catch (Exception e) {
			logger.error("订单号："+payRecord.getOrderNo()+"，解冻金币出现异常：" + e.getMessage());
			// 3.异常出现，设置状态为 4，用于人工处理 , 或者提供接口 ，人工调用重试
			payRecord.setOrderState(PayRecordStatusEnum.UNFREE_FAILED.getStatus());
			payRecordDao.saveAndFlush(payRecord);
		}

	}

}
