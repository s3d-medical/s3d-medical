package com.nhs.task.unit;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
public class TestSever {

   


    @Test
    public void convertGold() throws Exception {
        // goldConvertService.dealConvertGold();
        System.err.println("OK");
    }

    @Test
    public void dealRebate() throws Exception {
        // clearRebateService.dealRebate();
        System.err.println("OK");
    }

    @Test
    public void dealO2oRebate() throws Exception {
        // clearRebateO2oService.dealRebate();
        System.err.println("OK");
    }

}
